from openai import OpenAI
from llama_parse import LlamaParse
from llama_index.core import SimpleDirectoryReader
from pathlib import Path
import asyncio
import json
import os

class Batch_API:
    def __init__(self) -> None:
        pass
    
    def openai_batch_task(self, instr : str, descr : str, title : str):
        # Creating an array of json tasks
        task = {
            "custom_id": f"File: {title}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                # This is what you would have in your Chat Completions API call
                "model": "gpt-4o-mini",
                "temperature": 0.1,
                #"response_format": { "type": "json_object"},
                "messages": [
                    {
                        "role": "system",
                        "content": instr
                    },
                    {
                        "role": "user",
                        "content": descr
                    }
                ],
            }
        }
        return task

    async def llama_parsing(self, file_name, prompt):
        #key1 = "llx-UE4921w5KFUtNs0ihn1icbkSDtulvP3VBOMbTZrMqfJOE6Gc"
        key2 = "llx-wblp7gcY4J5zTlJl02mc4xTD6ODiYfro9mLnc4n12zCVbLnO"
        parser = LlamaParse(api_key=key2,
                            result_type="markdown",
                            parsing_instruction=prompt,
                            show_progress=True)
        extractor = {".pdf": parser}
        doc_pages = await SimpleDirectoryReader(input_files=[file_name], file_extractor=extractor).aload_data()
        return doc_pages

    #Llamaparses the formulae and notations in LATEX markdown before passing it for text cleaning
    def initial_parse_as_markdown(self, paper_directory : str, md_dir : str, light_prompt : str):   
        directory_path = Path(paper_directory)
        md_dir_path = Path(md_dir)
        current_markdown_filenames = [file.name for file in md_dir_path.glob('*.md')]
        print(f"Existing files : {len(current_markdown_filenames)}")
        # Iterate through all PDF files in the directory
        count = 1
        for pdf_file_path in directory_path.glob('*.pdf'):
            #if count < 4:
            file_path = Path(pdf_file_path)
            paper_name = file_path.stem
            if paper_name in current_markdown_filenames:
                continue    
            else:
                page_text = ""
                doc_pages = asyncio.run(self.llama_parsing(pdf_file_path, light_prompt))   #List[Document]
                for page in doc_pages:
                    page_text += page.text
                
                save_markdown_dir = f"/home/ritwik-gosh/Fine_tuning/data/Marker/{paper_name}.md"
                with open(save_markdown_dir, "w") as file:
                    file.write(page_text)
                count += 1
                print(f"Number of papers parsed till now: {count}")
            print(f"Current number of files : {count + len(current_markdown_filenames)}")
        

    def create_batch_tasks(self, markdown_dir, batch_json_target_path, sys_prompt):
        #Creating the task_file -> json.l
        md_dir = Path(markdown_dir)
        tasks = []
        for md_file_path in md_dir.glob('*.md'):
            with open(md_file_path, 'r') as file:
                content = file.read()
            filename = Path(md_file_path).stem
            tasks.append(self.openai_batch_task(instr=sys_prompt, descr=content, title=filename))
            
        
        file_name = batch_json_target_path
        with open(file_name, 'w') as file:
            for obj in tasks:
                file.write(json.dumps(obj) + '\n')

        # Uploading the task_file
        key_openai = ""
        key_gpt_4 = ""
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY", key_gpt_4))
        batch_file = client.files.create(
        file=open(batch_json_target_path, "rb"),
        purpose="batch")

        # Creating the job
        batch_job = client.batches.create(
        input_file_id=batch_file.id,
        endpoint="/v1/chat/completions",
        completion_window="24h"
        )
        return batch_job

        


if __name__=="__main__":

    obj = Batch_API()

    

    
