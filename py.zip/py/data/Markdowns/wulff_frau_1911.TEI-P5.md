# Frauenwahlrecht

## Politische Rechte der Frauen

Darf die Frau als minderwertig vom politischen Recht ausgeschlossen bleiben? Wahlrecht und Wählbarkeit zu allen gesetzgebenden und verwaltenden Körperschaften müßten alle Frauen fordern und nicht bloß die, welche in der Gesellschaft produktiv tätig sind. Auch die Nur-Hausfrauen und Mütter leisten der Allgemeinheit die wichtigsten Dienste. Über die gesellschaftliche Bedeutung der produktiven Frauenarbeit zu reden, ist kaum noch nötig. Daß die Frau als Berufstätige ebenbürtig neben dem Manne steht, beweist besser als viele Worte die stetige und rasche Ausdehnung der Frauenarbeit.

## Die Rolle der nicht erwerbstätigen Frauen

Aber lenken wir einmal den Blick auf das Wirken der Frauen, die nicht erwerbstätig sind. Die Gesellschaft könnte gar nicht bestehen ohne das, was heute Millionen Frauen in den vier Pfählen leisten, und was unter geänderten sozialen Verhältnissen in anderen Formen von ihnen geleistet werden müßte. Die Männer würden heute nicht imstande sein, die Anforderungen zu erfüllen, welche die Ausbeutung der menschlichen Arbeitskraft und der Staat an sie stellen, wenn nicht der „Frauen weises Schalten im häuslichen Kreise“ wäre. Hinter dem Verdienst und der Steuerkraft des Mannes steht die sparende Arbeit der Frau im Hause. Und wie viel Intelligenz, Umsicht und Energie müssen nicht gerade die Proletarierinnen aufwenden, um durch „das Regen ohn' Ende der fleiß'gen Hände“ den Mann als Arbeiter, Familienvater und Staatsbürger gesund und leistungsfähig zu erhalten. Welche Finanzkunst müssen sie nicht zu diesem Zwecke betätigen! Mancher Staatsmann könnte es darin mit ihnen nicht aufnehmen.

## Die Bedeutung der Kindererziehung

Außerdem ist da eine andere hochwichtige Leistung: die Pflege und Erziehung der Kinder. Setzt sie nicht viele Fähigkeiten des Geistes und Charakters voraus, und liegt sie nicht ganz besonders im Interesse der Gesellschaft? Sie erhält und bildet ja die lebendigen menschlichen Kräfte, die morgen ihre Träger sein und ihren Reichtum an Gütern und Kultur schaffen werden. Viele Frauen der kleinen Leute sind im stillen wahre Heldinnen an Mut und Aufopferung, um ihren Kindern eine erträgliche Jugend zu bereiten; sie betätigen die größte Umsicht und Klugheit, um lebenstüchtige Menschen aus ihnen zu machen. Sie selbst verkümmern und sterben, ehe daß die Kinder es ihnen vergelten könnten; der Allgemeinheit haben sie den wertvollen Reichtum geschenkt: einen gesunden und tüchtigen Nachwuchs.

## Anerkennung der sozialen Verdienste

Die Gesellschaft will aber die sozialen Verdienste des Weibes als Mutter nicht anerkennen. Sie findet in ihnen keinen Grund zur politischen Gleichberechtigung. Von zwei Dingen eins: Sind die Leistungen der Mutter vom Standpunkt des Gesellschaftsinteresses so nebensächlich und minderwertig, daß man die Frau nicht als vollberechtigte Bürgerin anerkennen kann, so nehme man den schwachen und ungeeigneten Händen die wichtige Aufgabe der Kindererziehung ab. Sind diese Leistungen dagegen so schätzenswert, wie die Dichter gelegentlich singen, dann vorenthalte man der Mutter, der Erzieherin der künftigen Bürger, nicht länger ihre volle Gleichberechtigung. Ein wenig Logik, ein wenig Gerechtigkeit, ihr, die ihr die Mutter in der# Die Rolle der Frau in der Gesellschaft

Familie mit einem Heiligenschein verklärt, die nämliche Mutter
aber in Staat und Gemeinde nicht kennt!
Sicherlich hat das Weib seine Eigenart. Sie bewirkt, daß
die Frauen die Dinge vielfach anders ansehen und erfassen wie
die Männer. Jm Jnteresse der Gesellschaft ist es jedoch nur
gut, daß dem so ist. Daß die Frau anders ist als der Mann,
bedeutet ja keineswegs, daß sie weniger wert ist als er, und daß
ihre Leistungen geringer sind als die seinigen.

# Das Wohl der Gesamtheit

Das Wohl der Gesamtheit erfordert, daß auch dem öffentlichen Leben alle der
Frau eigentümlichen Kräfte nutzbar gemacht werden. Das volle
Bürgerrecht der Frau ist der Nutzen der Gesamtheit.
Hausfrauen, Mütter, reicht euren erwerbstätigen Schwestern die Hand
um euer aller Recht zu erkämpfen!
Frida Wulff.