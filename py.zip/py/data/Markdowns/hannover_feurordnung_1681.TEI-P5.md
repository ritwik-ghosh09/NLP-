# Revidirte Feur-Ordnung

## Einleitung
WIr Bürgermeister und Raht der Stadt Hannover / allen und jeden unsern Bürgern / Einwohnern / und männiglichen / so unser Bottmessigkeit unterworffen / thun hiemit kund und zuwissen; Daß / ob zwar auch vor Jahren aus guter Meinunge und getreuer Vorsorge der Stadt Wolfahrt / behörige Anstalt und Ordnung ist gemachet / wie höchstschäd- und gefährliche Feuers-Brunste bestmöglichst zuvermeiden / und durch behufige Mittel hinwiederumb zu dämpffen; Dennoch die Erfahrung es Leider! hat bezeuget / daß denselben in fürgefallenen Nöthen / nicht allerdinges gelebet / sondern viele unvermuthete Verwirrungen und Mängel sich ereuget / durch welche der lieben Bürgerschafftein unwiederbringlicher Schade sich leichtlich mögen erregen.

## Maßnahmen zur Verhütung von Feuers-Brünsten
Caput I. Wie durch Abschaffung allerhand Gelegenheiten eine Feuers-Brunst vorzukommen.

1. Auff daß nun zufoderst und für allen Dingen die Gelegenheit zu Feuers-Brunsten verhütet werden möge / so sol ein jeder in seinem Hause die Brandmauren / Feurstette / Camine / Schorsteine / Darren / Brenn- Schmelz- und Back-Ofen / Aesen / Ferbekessel / Brandtwein-Blasen und alle andere dergleichen gefährliche Oerter und Gerethschafften / auch das Brau-Hauß solcher gestalt anlegen und behutsamlich verwahren / daß kein Schade noch Anzündung dahero zubesorgen.

2. Derobehueff dann selbe / bevorab die Schorsteine / nicht von Holtz / Brettern oder Zaunwerck gemachet / sondern mit Steinen auff- und die Schorsteine aus dem Tache geführet werden sollen.

3. Auch sollen die Becker an jhren Backöfen kein höltzern Stenderwerck haben / noch die Rauchlöcher hinten oder oben / sondern forne außgehen lassen / damit der brennende Rauch desto sicherer auffwerts in- und aus den Schorstein geführet werde.

4. So sol auch niemand sein Hauß / Scheuren noch Ställe / mit Stroh decken / noch unter die Dachpfannen / Stroh mit einstecken lassen / sondern / da es befunden / wieder auffgerissen / und der Haußwirth in 20. Fl. straffe / der Dachdecker aber in gefängliche Hafft genommen / und folgends nach Befindung angesehen werden.

5. Nicht minder sollen die Back- Brenn- und Schmeltzöfen / imgleichen Kupffer- und Eisen-Schmiede nicht zu nahe bey dem Rath-Hause / der Apotheken / item Kirchen und Schulen / oder andern gemeiner Stadt zustehenden Gebäuden / noch bey Häusern / so von Holtz auffgeführet / geduldet / wenigers an denen Oertern / da sie nicht von Alters her gewesen / ohne unsern / und der Nachbarschafft vorwissen / und Bewilligung / von neuen angeleget werden.

6. Ferner sol ein jeder seine Schorsteine des Jahres zum wenigsten einmahl lassen außfegen / und so daß nicht geschicht / der Schorstein aber brennend würde / ob gleich das Feuer ohne sondern Schaden hinwieder gelöschet / dennoch der Haußwirth deßwegen / wie hergebracht / in 10. Fl. straffe genommen werden.

7. Deßgleichen sollen bey eben derselben Straffe die Brauer und Multzer jhre Darren / so offt sie# Feuerordnung und Sicherheit

## Verantwortung des Hauswirts
Nicht minder sol ein jeder Haußwirth / insonderheit Gastgeber / Krüger / und wer sonst Gäste setzet / oder andere Leute neben sich im Hause hat / herberget / und verpfleget / acht haben / daß seine Frau / Kinder / Gesinde / Gäste / Häußlinge und Verpflegte / nicht gefährlich mit Feuer / Licht / Fackeln / Lampen / oder Thoback-schmeuchen auff Boden / in Kammern / bey Betten / in Scheuren und Ställen / noch auff dem Hoffe / da Stroh und dergleichen leicht anzündende Dinge verhanden / umbgehen / noch er solches bey Trunckenheit oder anderer Gestalt für sich selbst thue / sondern das Thoback-schmeuchen entweder gäntzlich abgewendet / oder aber an solchen Ort verrichtet werde / da deßwegen keine Gefahr zubesorgen: über dem die Feurstette alle Abend wol verwahret / die annoch brennende Köhle oder gluende Aschen an keine gefährliche Oerter / Stender / höltzerne Grunde / oder Bretterwerck / noch in Fässer oder auff die Boden geschüttet werde.

## Haftung bei Fahrlässigkeit
Allermassen denn / wofern den Benachbarten durch dergleichen verwahrlosung / und dahero veruhrsachte Feuersbrunst einiger Schade entstunde / der Haußwirth / durch dessen Fahrlässigkeit es erwachsen / den Schaden gelten / daß sorglose Gesinde aber / nach Befindung an Leib und Leben gestraffet werden sollen.

## Verbotene Handlungen
Würde aber der Wirth es verbieten / und die Gäste oder Häußlinge dennoch mit so gefährlichen Dingen nicht inne halten / so sol er sie alsofort aus dem Hause schaffen / und da sie nicht gehorchen wolten / die Nachbarn oder die Wache zu Hülffe nehmen / oder es auch uns zu fernerer nachtrücklichen Verordnung fordersambst andeuten.

## Meldepflicht für Gäste
Gestalt dann auch niemand unserer Bürger / er sey wer er wolle / jemand zu sich sol in sein Hauß nehmen / jhm dasselbe gantz oder zum Theil vermiethen / er habe es denn vor dem Thorschliessen den Worthabenden Bürgermeister durch einen Zettel angezeiget / wie er heisse / woher er sey / wessen er sich nehre / oder was sonst alhie seine Verrichtung sey / wie viel / und was für Leute er bey sich habe / bey 5. Fl. oder 8. tägiger Gefängniß straffe für einen jeden Tag / den er also verholen / jemand in seinem Hause gehabt / und sol nichts desto minder den also unangemeldeten Gast oder Heußling bey Sonnenschein wieder hinaus zu schaffen schuldig / oder in weit härtere wilkührliche Straffe / nach Bewandnüß der Sachen verfallen seyn.

## Kontrolle durch die Behörden
Derobehueff denn ein jeder Corporal / oder wen wir sonst dazu werden gebrauchen / auff entstandenen Verdacht in seiner Corporalschafft / ohne einiges Ansehen der Personen zu visitiren / und die er befindt / ohnverzuglich anzumelden hat: worwieder bey 10. Rthl. Straffe sich niemand sol unterstehen zu reden / noch jhm einige Behinderung in dem Wege zu werffen.

## Sicherheitsvorkehrungen für Handwerker
So sollen auch die Mültzer / Brauer / Bäcker / Bötticher / Drechsler / Tischer / Bildschnitzer / Brantwein Brenner / Töpffer / Schmiede und dergleichen / jhr Torff oder Holtz / Höfel oder andere Späne / so sie zu jhrer Handthirung gebrauchen / oder jhnen in der Arbeit abfallen / imgleichen auch die Seiler jhren Hanff / Flachs und Heden / dem Feuer nicht zu nahe legen / noch / bevorab ungebunden / liegen lassen / sondern bey wilkührlicher Straffe / nach Gelegenheit jhres Hauses also verwahren / daß dahero kein Schade zu besorgen.

## Umgang mit gefährlichen Materialien
Nicht minder sollen die / so Pulver / Pech / Schwefel und dergleichen Dinge verkaufen / verarbeiten / oder in verwahrunge haben / selbiges an sichere örter / keines weges aber Pulver unter in die Keller und Gewölbe legen / darauß dem gantzen Hause und der Nachbarschafft gefahr entstehen möchte.

## Strafen für unsichere Praktiken
Welcher Abends oder Morgens / bey angezündeten Lichte / Latern oder Lampe am Flachs arbeiten / oder Getreidig dröschen / Stroh schneiden / Unschlit oder Talch schmeltzen und Lichte ziehen / mit Buchsen Pulver / Pech / Schwefel / und andern Dingen / so leicht brennen / umbgehen / oder daß solches geschehe / befehlen wird / sol in 6. fl. Straffe verfallen.

## Regelungen für Feiertage
Eben dasselbe haben zu erwarten / die am Sonn- oder Feyertagen / wie auch des Abends nach 8. Uhren Maltz darren.

## Vorschriften für die Tierhaltung
Als auch viele unserer Mitbürger vermeinen / sie können nicht wol leben / wo sie nicht zum wenigsten eine Kuhe halten / ob sie gleich in jhrem Hause nicht so viel raum haben / daß sie dieselbe nottürfftig stallen und futtern können / so sol hinfüro keinem / der nicht so viel raum in seinem Hause hat / daß er das Futter und Stallunge weit gnug vom Feur haben möge / eine Kuhe zu halten / vergönnet seyn.

## Überwachung durch die Feuermeister
Damit nun diesem sambt und sonders also gelebet / und dawider nicht gehandelt werde / so sollen unsere verordnete / und insonderheit dazu beeydigte Feurmeister acht darauff haben / alle Jahr zum wenigsten zweymahl herumb gehen / bevorab umb Michaelis / unsere Maur- und Zimmerleute zu sich nehmen / alle Feurstete und gefährliche örter besichtigen.# Verordnung über die Feuerbekämpfung

## Caput II.
### Wie alles bereit zu halten / was zu dämpffung des Feuers von nöthen.

1. Auff daß nun weiter an behöriger Geretschafft und Wasser zu dempffung des Feuers es nicht ermangeln möge / so sollen unsere verordnete Feuermeister alle Jahr den 6ten Tag / nach dem sich der Rath hat umbgesetzet / ein richtiges inventarium aller Feuer-Leitern / Gabeln / Feuerhaken / Ledern Eimer / Wassersprützen / messing- und holtzern Handsprützen / Küben / Schlitten / Schlopen / imgleichen die Leute / so selbe ans Feuer zu tragen / und zu führen bestellet (deren abgang sie dann alsofort zu zeitiger ersetzung jedesmahl anzumelden haben) für dißmahl aber innerhalb 14. Tagen auffzurichten und gedoppelt zu übergeben / solches auch zu unterschreiben / und darnach in eine Lade beyzulegen / schuldig seyn.

2. Sie sollen auch alle viertel Jahr / oder zum wenigsten des Jahrs zweymahl herumb gehen / vorbenante instrumenta in Augenschein nehmen / und dahin mit allem Fleisse trachten / daß alle Feuer-Leitern / Gabeln / Feuerhaken / Eimer / und andere darzu gehörige Notturfft in gutem Stande und Bereitschafft gehalten /da nötig / zu rechter Zeit / gebessert / an der abgegangenen Stelle neue geschaffet / und jedesmahl an gehörigen Orte verhanden seyn möge.

3. Wir wollen auch einen jeden Haußwirth bey seinen Eyden und Pflichten hiemit ermahnet haben / sich selbsten mit Einen oder Zween / und die des Vermögens seynd / mit mehr Ledernen Eimern / auch mit einer oder mehr Messingen oder höltzern Handsprützen gefast zu halten / damit man sich derselben im Fall der Noht gebrauchen / und einer den andern Nachbarlich beyspringen möge.

4. Und auff daß es im Nothfall nicht an Wasser gebreche / so sollen die in Abgang gerathene Söde und Brunnen / imgleichen Kumme und Seulen / so wol auff den Gassen als in den Häusern befindlich / von dem oder denen / so sie angehören / innerhalb 14. Tagen bey 5. Fl. straffe / wieder angerichtet / repariret und gereiniget werden / welches unsern Feurmeistern zu beobachten hiemit gecommittiret wird.

5. Nicht minder sollen die Kunst- und Brunnen- auch Grabenmeister / da an den Kummen oder Seulen / Wasserröhren / Buchsen / oder sonsten einiger Schade und Mangel sich ereuget / denselben alsofort endern / und so deßwegen nothwendig das Wasser abzuschliessen / auch eines oder mehrer Tage Arbeit erfodert würde / dahin sorgfältig sehen / daß nicht auff einen Tag alles Wasser auff einmahl abgeschlossen / sondern denen /an deren Röhren nichts zu machen / noch würcklich gearbeitet wird / das Wasser bey freyen Lauff gelassen werde.

6. Der beeidigte Kunstmeister sol / damit in besorglichen Nothfällen es bey Winters- Zeit ans Wasser nicht ermangele / so bald nur 2. oder 3. Tage der Frost anhalten wird / das Wasser / durch stellung der Kunst / nicht mehr lauffen lassen / sondern damit einhalten / und so viel an jhm ist / dahin sehen / daß zum wenigsten die grossen Röhren / biß an den Haupt- oder Pfeiffen-Brunnen ledig und gangbar bleiben.

7. Wie imgleichen auch unsere Bürgerschafft / und absonderlich die Brawer / in allen und jeden Röhren dahin sehen sollen / daß ebenmessig dieselbe auff solchen Fall ledig seyn / und nicht mit Eiß voll gefroren erfunden werden mögen.

8. Wofern nun aber solches irgend zubefahren seyn / und das Frost-Wetter continuiren würde / alsdenn sollen unsere Bürger für jhren Häusern die Gossen außhauen / und von allen Eise frey bewahren / damit von besagtem Haupt- und Pfeiffen-Brunnen / durch rennen das Wasser in die Gossen / und darin weiter an den Ort / wo etwa eine Feuers-Brunst entstanden / in schleunigster Möglichkeit geführet / allda gefüllet und geschöpffet werden könne.

9. Weßhalben dann auch die Feurmeistere dahin sehen / und bey Straffe andeuten lassen sollen / daßein jeder die Gossen und Strassen auff den seinen / und so weit er schuldig / rein halte / und von allem Unflaht befreye.

## Caput III.
### Wie die entstehende Feurs-Brunst kund zu machen.

1. Damit dann weiter / so durch Gottes Verhengniß ein unordentlich Feur auffginge / dasselbe zeitig gnug angedeutet und gelöschet werde / so sol# Feuerordnung und Wachpflichten

## Einleitung
zufoderst der Haußwirth / oder die Fraw / bey denen es sich ereuget / dasselbe alsofort / und ohne einigen Vorzug beschreien und Hülffe ruffen / und wo es alsdann gedämpffet wird / es sey denn eine Verwahrlosunge dabey mit untergeloffen / ohngestaffet bleiben. So aber jemand es heimblich zuhalten / sich unterfangen würde / alsdann sol derselbe / nach bewandten Umbstenden und Beschaffenheit der Sachen / ob es gleich gerettet würde / dennoch willkührlich / ohne Ansehen der Personen / gestraffet werden.

## Pflichten der Wächter
Dann sollen auch die Thurm- und Gassen-Wächtere jhres Ambts fleissig abwarten / jene so bey Tage als bey Nacht / diese aber bey Nacht sich auff der Wache alle Stunden / jhren Pflichten und Eyden zu folge / ohnnachlässig finden lassen / blasen und ruffen / wie daß jhnen anbefohlen / und da sie etwa einen ungewöhnlichen brandigen Geruch oder Rauch vermercketen / für demselben Hause / da sie dessen gewahr werden / anklopffen / und sich darnach erkundigen / die Leute auffwecken und ermuntern / da sie alsdenn auch einige Gefahr empfunden / zugleich bey den Corporal und Benachbarten alsofort anklopffen / sie auffwecken / imgleichen mit vielfältigen Blasen und Geschrey / nachbarliche Hülffe herbey ruffen.

## Nachbarliche Hilfe
Imgleichen sollen die Nachbaren / wenn sie derogleichen ungewohnten Rauchs und brandigen Geruchs gewahr werden / die Einwohner des Ortes ermuntern / oder nach befindunge den Corporal und die benachbarte Feurmeister dazu ziehen / das Hauß / so gut sie können / eröffnen / auch auff bedürffenden Fall / dem negsten Küster es vermelden / und die Glocken rühren lassen.

## Wachtpflichten an den Türmen
Die Wächter auff St. Jacobi und Georgij Thurm / wie auch die Thurm-Leute / sollen fleissige Wache halten / und so sie Feuers-Gefahr vermercketen / dieselbe / so bald das Feur sich empor hebet / oder sonst gewiß verhanden / mit dem gewöhnlichen Blasen und Feurglocken schlagen / ruchtbar machen / auch den Ort / oder die gegend des Feurs / des Nachts mit einer an derselben Seite den Thurms auffgehengten Leuchten / und darin brennendem Lichte / des Tages aber / mit niederwerts außgestecketer Fahnen / anzeigen und bedeuten.

## Unachtsamkeit der Wacht-Leute
Solten aber besagte Wacht-Leute / bevorab auff gedachten Thurm / so unachtsam seyn / daß sie des Feurs nicht gewahr würden / alsdann sollen sie jhres Dienstes entsetzet / oder sonsten nach Befindung unnachlässig gestraffet werden.

# Verhalten bei Feuerbrünsten

## Einberufung des Rates
So bald nun ein Feuer durch die Glocken / Trummel / oder andere Gestalt ist kund geworden / sollen und wollen Bürgermeister / Raht und Geschworne / ausser denen, so bey den Feur würcklich zuschaffen haben und hernach benennet werden / sich stündlich zu Rathause anfinden / damit sie desto besser von dem Zustande des Feurs Nachricht einziehen / sich berahtschlagen / und desto bessere Ordre stellen / auch durch einige jhres Mittels dem Feuer näher treten lassen können.

## Mobilisierung der Bürgerschaft
Unsere Bürgerschafft aber sol sich alsofort mit jhren Unter- und Ober-Gewehr / welches sie derobehueff allezeit fertig zu halten / ein jeder für seinesFendrichs Thür sich anfinden / und ohne eintziges Geschrey und unnöthigen Tumult von dem Haubtman / welcher von einer Compagnie zu der andern zu gehen hat / in guter Ordnung stellen lassen / die von der Weissen Fahne an der Osterstrasse / die von der Rothen an der Marcktstrasse / die von der Grünen oder Kömelung Strasse an das freye Marckt / die von der Gelben aber oder Leinstrasse an das Holtzmarckt / auch allda von uns / durch unsern Haubtman / Riede- und Baumeister Ordre erwarten.

## Einsatz der Corporalschafften
Die vier Corporalschafften aber / so dem Feuer am negsten / als eine zur rechten / die ander zur lincken / eine forne / und eine hinten / sollen gerade zum Feuer eilen / und zur helffte den Ort an beyden Seiten des Zutritts besetzen / daß kein unnützes / viel weniger unbekantes verdächtiges Gesindel / zu und eindrenge / die andere helffte aber den Ort öffnen / und das Feuer in guter Ordnung dämpffen / biß andere von fernen Orten auff unser Befehl werden dazu kommen / und sie verstärcken oder ablösen.

## Unterstützung durch die Wache
Allermassen dann ein Corporal sambt 2. Mußquetirern vom Steinthor / so die Wache haben / imgleichen 2. Mußquetirer von Ægidien Thor und 2. vom Leinthor alsofort zu dem Feuer sich sollen wenden / und imfall es von der Bürgerschafft noch nicht geschehen / daselbsten posto fassen / biß der Lieutenant / sambt andern Stadt-Soldaten / so die Wache nicht haben / wird dazu kommen / derobehueff / dann diese letztere / nach dem das Feuer kund worden / ohngesäumet an des Lieutenants Thür / bey ernstlicher Straffe sich sollen einfinden / und seiner Ordre folgen / welcher dann / nach gestalt der Sachen / die von den Thören heran genäherte Stadt-Soldaten entweder hinwieder zu.# Feuerbekämpfung und Nachbarschaftshilfe

Es sol sich auch bey schwehrer Straffe niemand der Nachbaren alsofort auffs außtragen und außreumen jhrer Häuser begeben / sondern vielmehr jhrem nothleidenden Nachbarn getreulich beystehen / und dahin trachten / damit das Feuer / ehe es Krafft gewinne / gelöschet und grösseres Unglück verwehret werde.

# Aufgaben der Feuermeister

Die zwey Feuermeistere / so dem Rathhause am negsten wohnen / und bey der Hand sind / sollen ohne eintzige säumnuß fürs erste viertzig Lederne Feuer Eimer sambt einigen Haken und Leitern vom Rathhause durch bekante Leute lassen an das Feuer tragen / und daselbst unter bekanten Leuten außtheilen / darneben die grosse Wassersprütze unterm Rathhause herauß führen / damit / so es nöthig / dieselbe eiligst an gehörigen Orte könne gebracht und gebrauchet werden.

# Unterstützung durch Bürger

Derobehueff dan diesen zweien Feuermeistern / ohngesäumet sechs Bürger / die sie zuerst ansichtig werden / mit jhrem Gewehr sollen assistiren zur Wache / und von den also genanten Zwantzig Männern / zum außfahren / Eymer tragen / und andern Diensten / biß andere darzu werden kömmen oder commandiret seyn / imgleichen zwey Bürger oder Stadt-Soldaten / die mit Sprützen wissen umzugehen.

# Vorbereitung der Feuermeister

Deßgleichen sollen die 2. Feuermeister / so zu negst der Mühlen wohnen / mit den Feuerhaken / Leitern und der andern Sprützen / so in jhrem viertheil / sich fertig halten. Die Zwey Feuermeister aber / so dem Feuer am negsten wohnen / sambt den zweyen andern / sollen alsofort an das Feuer gehen / nach allen Umbständen auffs genauste es besichtigen / so an vorgedachter Geretschafft etwas mangelt / schleunigst befehlen herbey zu bringen.

# Ordnung und Sicherheit

Unsere mit Raths Freunde / der Herr Hauptmann / Riedemeister unnd die beede Bawmeistere wollen und sollen gleicher gestalt / sofort sie der Gefahr innen werden / nach dem Feuer eilen / und fleissige acht haben / damit alle confusion und Dieberey verhütet / auch alles / was außgetragen wird / in gute und gewisse Verwahrunge gebracht / dem unnöthigen und schädlichen Zulauff gewehret.

# Besetzung des Brandortes

Derobehueff dan / im fall über alles vermuthen / die negsten Corporalschafften oder der Lieutenant sambt den Stadt Soldaten / den Ort / da das Feuer entstanden / noch nicht besetzet / sie durch gewisse / getreue / fleissige und behertzte Männer von allen oder einer Compagnie / nach dem sie werden bey der Hand seyn / denselben / biß die andern herzu kommen / besetzen / und den unordentlichen Zulauff verwehren sollen.

# Maßnahmen des Brunnenmeisters

Der Kunst- und Brunnenmeister sol / sofort die Sturmglocke geschlagen oder sonst die Feuersbrunst jhm kund geworden / das Rohrwasser lauffen lassen / und an dem Orte oder auff die Gassen stellen / da das Feuer verhanden / darneben durch jemand der seinigen dem Grabenmeister oder negstwohnenden Feurmeister anzeigen / ob und wo des Ortes verdeckte Nothbrunnen verhanden / damit dieselbe in Zeiten geöffnet und gebrauchet werden.

# Verpflichtungen der Bürger

Imgleichen sol ein jeder bey schwerer unaußbleiblicher Straffe verpflichtet seyn / dem andern mit öffnung der Hahnen an den Brunnenständern in solchen Fällen zu willfahren / und den Zugang zum Wasser durch sein Hauß oder Thorweg zu verstatten / auch seine Kuffen und Baljen zu leihen.

# Wasserzufuhr und Unterstützung

Die Broihan Führer sollen bey Verlust jhres Dienstes je Zwey und Zwey für eines der negst beym Feuer verhandenen Wasser-Kuffen jhre Pferde spannen und Wasser zuführen / biß von dem Riede- Baw- und Feuermeistern mehr Pferde herbey geschaffet werden.

# Organisation der Wasserbeschaffung

Und haben der Haubtman / Riede- Baw- und Feuermeister / welcher unter jhnen wird zugegen seyn / alsofort etliche Personen / so für der Hand / bey dem Nothbrunnen zu verordnen / welche das Wasser schöpffen und Ballien herbey bringen / auch darauff zu achten / wer zu erst mit seiner Wasser Ballie zum Feuer kompt / damit demselben eine Verehrung von uns gereichet werde.

# Beteiligung der Handwerker

Die Zimmerleute / Tachdecker / Maurer / Leimenthierer / Zwantzig Männer und andere Raths- und Stadt Bediente / so zur Hand-arbeit umb Lohn bestellet seynd# Feuerordnung und Rettungsmaßnahmen

## Einleitung zur Feuerbekämpfung
und gebrauchet werden / sollen für alle andere ohngesäumet zum Feuer eilen / alle andere Arbeit liegen lassen / und bey willkührlicher Straffe / so viel möglich / retten helffen.

## Pflichten der Handwerker
Deßgleichen sollen die Rademacher / Schmiede / Tischer / Bötticher und Brauer Knechte / so eben zu der Zeit mit den Brauen nicht nothwendig zu verrichten haben / sich herzu machen / und der Feuerherrn Ordre / wie ehrliche Leute / getreulich außrichten.

## Verhalten von Fremden und Frauen
Frembde aber / Kinder oder Weibspersonen / auch andere / so zum retten untaulich / sollen daheim bleiben / und dem lieben GOTT umb Abwendung der Feuersgefahr anruffen / auch daselbst auff allem Nothfall Wasser in Kummen / Kuffen und Ballien zum Vorrath samblen und sonsten gute Anstalt machen.

## Sicherheit und Ordnung während des Feuers
Damit auch in der Stadt alsdan aller Diebstall / Auffruhr und Mordbrennen möge bester massen verhütet werden / sol die Patroll Wache des Nachts fleissig gehen / die verdächtige Personen / so sie auff der Gassen findet / mit sich wegnehmen und nachgehends dem Gerichte überantworten.

## Überwachung der Feuerstelle
Eben das haben zu beobachten die bey dem Feuer befindliche Rathsverwandte / der Stadt Lieutenant und die Feuermeister / welche ein gar wachsames Auge zu werffen auff die / so etwas aus dem Hause / da das Feuer verhanden / tragen / wer sie seynd / und was sie tragen.

## Verhalten bei mehreren Bränden
Wenn denn das Feuer grösser würde / oder mehr als ein Feuer auffginge / welches Gott in gnaden verhüten wolle / so sollen die jenige / so zu dem ersten Feuer verordnet / mit dessen Rettung nicht ablassen / noch davon lauffen / sondern beständig dabey bleiben.

## Maßnahmen bei nächtlichem Feuer
Falß auch ein solches Unglück bey Nacht Zeiten sich zutrüge / so sollen nicht alleine an den Ecken einer jedweden Gassen / oder nahe bey der Feuers-Brunst / sondern auff allen Gassen durchgehends für den Thüren brennende Liechter in Laternen außgehenget werden.

## Einsatz der Feuerspritzen
Als auch höchst nöthig / daß die Feuersprützen am allerforderlichsten zu dem Feuer gebracht werden / so befehlen allen unsern Bürgern / so Gespan halten / insonderheit aber unsern Wagen-Knechten / daß sie so Tages als Nachtes auff solchen Fall alles verlassen und die Sprützen / auff gutachten der Feuer-Herren / eilend zum Feuer bringen.

## Nach der Rettung: Ordnung und Verantwortung
Was nach geschehener Rettung zu thun / und wie der eine oder ander nach befindung zu belohnen oder zu straffen.

## Nachsorge nach dem Feuer
Wann nun das Feuer durch Gottes gnädigen Beystand gedämpffet / und nach Notturfft scheinet gelöschet zu seyn / so sollen oberwehnte 4. Personen unsers Mittels und die Feuermeister nicht alsofort davon eilen / sondern fleissige acht haben.

## Wiederherstellung der Ausrüstung
Nach völliger Rettunge aber sollen die Feuermeister die Eimer / Leiter / Feurhaken und andere hergegebene Notturfft wieder zusammen bringen / und ein jedes alsofort am gehörige Orte verschaffen.

## Verantwortung für Schäden
Was aber daran zubrochen oder verdorben / oder gar abhanden kommen / ohngesäumet / und ehe es beygeleget wird / bessern oder wieder anschaffen / auch was es gekostet / von dem / durch dessen Fahrlessigkeit das Feuer außgekommen / oder die Beschädig- und Entwendung geschehen / bezahlen lassen / bey willkührlicher Straffe.# Verordnung über Feuerlöschwesen

nicht nachgelebet. Allermassen denn die Mauer- und Zimmerleute / Tachdecker / und die / so in Stadt Diensten begriffen / so ferne sie zu späte ankommen oder gar zurücke geblieben / unvermeidlich jhrer Dienste und Arbeit entsetzet / auch nach befindung darüber mit Gefängnüß oder anderer harter Straffe beleget werden sollen.

## Entschädigung bei Schäden

Würde aber jemand über dem löschen und retten an seinem Leibe und Kleidern unverschuldeter Weise beschädiget / oder gar umbs Leben kommen / dafür sol jhm nach Gelegenheit der Person und des Schadens billigmässige Erstattung / auch eine ehrliche Begräbnüß wiederfahren.

## Belohnung für mutige Helfer

Denjenigen / so sich erst bey dem Feuer gefunden / und treulich gerettet / insonderheit / die so mit jhren Pferden die erste Sprütze oder das erste Kufen mit Wasser / imgleichen die erste Fuhr oder Dracht mit Feur-Leiter / Haken und Eimer gebracht / wie auch / die zum ersten die Feur-Leiter zum Löschen und Retten angeschlagen / sol auch gestalten Sachen nach danckbarlich begegnet / und darneben alle Beforderung in vorfallenden Gelegenheiten erzeiget werden.

## Kostenverteilung bei Schäden

Gestalt dann die negste vier Nachbarn / deren Häuser vor andern in grosser Gefahr gestanden / 3. Thl. aus dem Hause und anderthalb Rthl. aus der Bude / so aber der / durch dessen Verwahrlosung das Feuer entstanden / zuzahlen hat / alle Kosten alleine erlegen / und so ein Mietsman in dem Hause wohnet / dieses Geld zur helffte von dem Mietling und die ander helffte von den Eigenthümer entrichtet werden sol.

## Strafen für Diebstahl und Sabotage

Da jemand befunden und überwiesen würde / daß er Lederne Eimer oder ewas von andern Geretschafft gestohlen oder aber bey der Feuers-Brunst den nothleidenden und beängstigten Leuten etwas entwand / oder dazu Rath und That gegeben / und es verholen oder verparthieren geholffen / der sol ohne Ansehen der Person vor einen Dieb gehalten / aus Ambt und Gilde / wenn er darinnen ist / verstossen / und noch dazu / nachgestalten Sachen / an Leib und Leben oder sonsten ernstlich gestraffet werden.

## Bekanntmachung der Verordnung

Auff daß nun schließlichen diese Unsere wolgemeinete Verordnung zu Jedermannes Wissenschafft und Beobachtunge möge gerathen / auch niemand mit der Unwissenheit sich zu entschuldigen habe / So ist fůr gut befunden / dieselbe durch den Druck gemein zumachen / und hat davon ein jeder Bůrger und Haußwirth zum wenigsten ein Exemplar jhm an die Hand zu schaffen. Wobey wir doch uns vorbehalten haben / Hinfůro nach Gelegenheit der Zeit / diese Ordnung zu verändern / zu mindern / zu mehren und zu verbessern.

Relectum & Decretum in pleno den 1. Julij Anno 1681.