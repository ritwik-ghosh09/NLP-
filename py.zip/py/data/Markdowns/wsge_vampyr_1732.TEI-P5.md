# Curieuse und sehr wunderbare Relation

## Einleitung
Und sehr wunderbare Relation, von denen sich neuer Dingen in Servien erzeigenden Blut-Saugern oder VAMPYRS, aus authentischen Nachrichten mitgetheilet, und mit Historischen und Philosophischen Reflexionen begleitet von W. S. G. E.

## Zitat
Quodcunque eligas, nostra parum interest, modo ne rem certam faciat ignorantia nostra dubiam, Joh. Clericus in Pnevmat. Sect. II. C. W. de malis Angelis, eorumque ministeriis & potestate, p. 83.

## Jahr
ANNO 1732.

## Faktenspezies
I. Relation. ANno 1725. wurde das erste mahl unterm 31. Jul. von Wien in den öffentlichen Zeitungen folgendes geschrieben. Man siehet alhie einen Bericht, welchen der Keyserl. Provisor in dem Gadisker-District in Ungarn an die Keyserl. Administration zu Belgrad wegen einer besondern Begebenheit ergehen lassen, folgenden Innhalts: Nachdem bereits vor 10. Wochen ein in dem Dorf Kisolova, Rahmer-District geseßener Unterthan, Nahmens Peter Plogojoviz, mit Tod abgangen, und nach Räzischer Manier zur Erden bestattet worden, hat sichs in ermeldetem Dorff Kisolova geäußert, daß innerhalb 8. Tagen 9. Personen, sowol alte als junge, nach überstandener 24. stündiger Kranckheit also dahin gestorben, daß als sie annoch auf dem Todtbett lebendig lagen, sie öffentlich außgesagt, daß obgemeldter Plogojoviz zu ihnen im Schlaf gekommen, sich auf sie geleget, sie gewürget, daß sie nunmehr den Geist aufgeben müsten. Gleichwie denn hierüber die übrige Unterthanen sehr bestürtzt in solchem noch mehr bestärcket worden, da des Verstorbenen sein Weib, nachdem sie zuvor ausge-
sagt, daß ihr Mann zu ihr gekommen, und seine Schuhe begehret, von dem Dorff Kisolova weg, und sich in ein anders begeben. Sinte-
mal aber bey dergleichen Personen, so sie Vampyrs nennen, verschiedene Zeichen, als daß ein Cörper unverweset, Haut, Haar, Barth und Nägel an ihm wachsend zu sehen seyn müssen; als haben sich die Unterthanen einhellig resolvirt, das Grab des Peter Plogojoviz zu öfnen und zu sehen, ob sich wircklich obgemeldete Zeichen an ihme befinden. Zu welchem Ende sie sich denn hieher zu mir gefüget, und nebst Andeutung vorerwehnten Casus mich samt dem hiesigen Geistlichen ersuchet, der Besichtigung.# Einleitung

beyzuwohnen. Und ob ihnen schon solches factum reprobirt, mit Meldung, daß ein sol-
ches vorher an eine Löbl. Administration un-
terthänigst gehorsamst berichten, und derselben
hohe Verfassung hierüber vernehmen müßte:
haben sie sich doch keineswegs hiezu bequemen
wollen, sondern vielmehr diese kurtze Antwort
von sich gegeben: ich möchte thun, was ich
wolte; allein, wofern ich ihnen nicht verstat-
ten würde auf vorherige Besichtigung und
rechtliche Erkäntniß mit dem Cörper nach ih-
rem Gebrauch zu verfahren, müsten sie Hauß
und Gut verlassen, weil biß zur Erhaltung ei-
ner gnädigsten Resolution von Belgrad wol
das gantze Dorff (wie schon unter Türckischen
Zeiten geschehen seyn solte) durch solchen üblen
Geist zu Grund gehen könte, welches sie nicht
erwarten wolten.

# Die Besichtigung des Körpers

Da nun solche Leute weder mit guten Worten noch Bedrohungen von ih-
rer gefaßten Resolution abhalten konte, habe
ich mich mit Zuziehung des Poppen in ge-
meldtes Dorff begeben, den bereits ausgegra-
benen Cörper des Peter Plogojoviz besichti-
get und befunden, daß erstlich von solchem
Cörper und dessen Grab nicht das mindeste
sonst der Todten gemeinen Geruch verspüret;
der Cörper, ausser der Nasen, welche etwas
abgefallen, gantz frisch; Haar und Barth, ja
auch die Nägel, wovon die alten hinweg ge-
fallen, an ihm gewachsen; die alte Haut, wel-
che etwas weißlicht war, hat sich hinweg gesche-
let, und eine neue frische darunter hervor ge-
than; das Gesicht, Händ und Füße, und der
gantze Leib waren so beschaffen, daß sie in seinen
Lebzeiten nicht hätten vollkommener seyn kön-
nen; in seinem Munde habe nicht ohne Er-
staunen einiges frisches Blut erblicket, welches,
der gemeinen Aussage nach, er von denen durch
ihn umgebrachten gesogen hatte. In Sum-
ma, es waren alle indicia vorhanden, welche
dergleichen Leute an sich haben solten.

# Die Reaktion der Bevölkerung

Nach-
dem nun sowol der Popp als ich dieses Specta-
cul gesehen, der Pöbel aber mehr und mehr er-
grimmter und bestürtzter wurde, haben sie ge-
samte Unterthanen in schneller Eil einen Pfeil
gespützet, mit solchem den todten Cörper zu
durchstechen, an das Hertz gesetzet, da denn bey
solcher Durchstechung nicht nur allein häuffi-
ges Blut, so gantz frisch, auch durch Ohren und
Mund geflossen, sondern noch andere wilde
Zeichen (penis erectio) fürgegangen. End-
lich haben sie gemeldten Cörper dem in hoc ca-
su gewöhnlichen Gebrauch nach zu Aschen ver-
brant.

# Schlussfolgerung

c.ꝛ                                               II. Relation.
Wien den 4. Febr. 1732.
VOn den Blut-Saugern, so bekantlich
nach ihrem Tod umher gehen, und denen
Leuten das Blut aus ihren Brüsten bis zum
Sterben saugen, und dergleichen Begebenheit
schon von alten Zeiten her in Mähren, Ungarn
und andern angräntzenden Provincien gar offt
passirt seyn solle, ist jüngstens wieder ein um-
ständlicher Bericht, so von vielen Zeugen un-
terschrieben war, welche dem Process mit bey-# Bericht über die Vampyr-Angriffe in Servien

gewohnet, und die Sache untersuchen helffen, aus Servien alhier angelangt. Dieser Bericht lautet in Extenso von Wort zu Wort folgender Gestalt:

## Die Anzeige und erste Ermittlungen

NAchdem die Anzeige geschehen, daß in dem Dorff Medvegya in Servien an denen Türkischen Gräntzen die so genannte Vampyrs einige Personen durch Aussaugung des Bluts umgebracht haben sollen: als bin ich auf hohe Verordnung eines alhiesigen Löbl. Ober-Com-mando, um die Sache vollständig zu untersu-chen, nebst dazu commandirten Herrn Offi-ciers und 2. Unter-Feldscherern dahin abge-schickt, und gegenwärtige Inquisition in Bey-seyn des der Stallater Heyducken Compagnie Capitain Gorschiz, Hadnuck, Baijactar und ältesten Heyducken des Dorfs, folgender maßen fürgenommen und abgehöret worden:

## Die Aussagen der Zeugen

Welche denn einhellig aussagen, daß vor un-gefähr 5. Jahren ein hiesiger Heyduck, Namens Arnont Parle, sich durch einen Fall von einem Heu-Wagen den Halß gebrochen. Dieser hat bey seinen Lebzeiten sich offters verlauten lassen, daß er bey Gossova in dem Türckischen Servien von einem Vampyr geplagt worden seye, dahero er von der Erden des Grabs des Vampyrs gegeßen, und sich mit deßen Blut geschmieret habe, um von der erlittenen Plage entlediget zu werden. In 20. oder 30. Tagen nach seinem Todfall haben sich einige Leute ge-klaget, daß sie von dem gedachten Arnont Parle ge-plagt würden, wie denn auch würcklich 4. Per-sonen von ihme umgebracht worden.

## Die Exhumierung und die Entdeckung

Um nun dieses Ubel einzustellen, haben sie auf Ein-rathen ihres Hadnucks (welcher schon vorhin bey dergleichen Begebenheiten gewesen) diesen Arnont Parle in beyleuffig 40. Tagen nach sei-nem Tod außgegraben, und gefunden, daß er gantz volkommen und unverwesen seye, auch ihme das frische Blut zu denen Augen, Nasen, Mund und Ohren heraus gefloßen; Das Hembd, Ubertuch und die Trügel gantz blutig gewesen, die alte Nägel an Händ und Füßen samt der Haut abgefallen, und dagegen andere neue gewachsen seyen.

## Die Tötung des Vampyrs

Weilen sie nun dar-aus gesehen, daß er ein würcklicher Vampyr seye, so haben sie demselben nach ihrer Ge-wohnheit einen Pfahl durch das Hertz geschla-gen, wobey er einen wol vernehmlichen Gräch-zer gethan, und ein häuffiges Geblüt von sich gelaßen. Worauf sie den Cörper noch selbi-gen Tages zu Aschen verbrant, und solche in das Grab geworffen.

## Die Folgen der Vampyr-Angriffe

Ferner sagen obgedachte Leute aus, daß alle diejenige, welche von denen Vampyrs geplaget und umgebracht würden, ebenfals zu Vampy-ren werden müsten, also haben sie die obbe-rührte 4. Personen auf gleiche Art exequirt. Deme fügen sie auch hinzu, daß dieser Arnont Parle nicht allein die Leute, sondern auch das Vieh angegriffen, und ihnen das Blut außge-sauget habe, weilen die Leute das Fleisch von solchem Vieh genützet. Es zeiget sich auch aufs neue, daß sich wiederum einige Vampyrs alhier befinden. Allermaßen in Zeit dreyer# Vampirgeschichten und übernatürliche Phänomene

## Unheimliche Todesfälle

Monathen 17. junge und alte Personen mit Tode abgegangen, worunter einige ohne vorher gehabte Kranckheit in 2. oder längstens 3. Tagen gestorben. Dabey meldet der Heyducke Joviza, daß seine Schwieger-Tochter Stanjoicka vor 15. Tagen frisch und gesund sich schlafen gelegt, um Mitternacht aber ist sie mit einem entsetzlichen Geschrey, Furcht und Zittern aus dem Schlaf aufgefahren und ge- klaget, daß sie von einem vor 9. Wochen verstorbenen Heyducken Sohn, Nahmens Milloe, seye um den Halß gewürget worden; worauf sie grosse Schmertzen auf der Brust empfun- den, und von Stund zu Stund sich schlechter befunden, bis sie endlich den 3ten Tag gestor- ben.

## Verdächtige Gräber

Hierauf seynd wir denselben Nachmittag auf den Frey-Hof, um die verdächtige Gräber eröffnen zu laßen, nebst denen offtgemeldten ältesten Heyducken des Dorfs außgegangen, die darinn sich befindliche Gräber zu visitiren, wo- bey nach samtlicher Secirung sich gezeiget:

1. Ein Ehweib, Nahmens Stana, 20. Jahr alt, so vor zwey Monathen nach dreytägiger Kranckheit ihrer Niederkunfft gestorben, und vor ihrem Tode selbsten ausgesagt, daß sie sich mit dem Blut eines Vampyrs gestrichen hätte, folglich sowol sie, als ihr Kind (welches gleich nach der Geburt gestorben, und durch leichtsinnige Begräbniß von denen Hunden bis auf die Helffte verzehret worden) ebenfals Vampyren werden müßten) ware gantz vollkom- men und unverwesen. Nach Eröfnung des Cörpers zeigte sich in cavitate pectoris eine quantität frisches extravasirtes Geblüt, die vasa, als arteriæ & venæ, nebst denen ventriculis cordis, waren nicht (wie sonst gewohn- lich) mit coagulirtem Geblüt implirt; Die samtliche viscera, als pulmo, hepar, stoma- chus, lien & intestina, waren dabey gantz frisch, gleich wie bey einem gesunden Menschen; der Uterus aber befande sich gantz groß und externe sehr inflammirt, weilen placenta und Lochiæ bey ihr geblieben, dahero selbiger in putredine war; die Haut an Händen und Füssen samt denen alten Nägeln fielen von sich selb- sten herunter; herentgegen zeigten sich nebst einer frischen und lebhafften Haut gantz neue Nägel.

2. War ein Weib, Nahmens Miliza, bey- läuffig 60. Jahr alt, welche nach 3. monath- licher Kranckheit gestorben, und vor etlich und 90. Tagen begraben worden. In der Brust befande sich vieles liquides Geblüt; die andere viscera waren gleich der vorgemeldeten in einem guten Stand. Es haben sich bey der Secirung die umstehende samtliche Heyducken über ihren fetten und vollkommenen Leib sehr verwundert, einhellig aussagende, daß sie das Weib von ihrer Jugend auf wol gekennet, und Zeit ihres Lebens gantz mager und ausgedorrt gewesen, mit nachdrücklicher Vermeldung, daß sie erst in dem Grab zu eben dieser Verwun- derungs-würdigen Fettigkeit gelanget seye, auch der Leute Aussag nach, solle sie jetziger Zeit den Anfang der Vampyren gemacht haben; Zu-# Vampyren und ihre Erscheinungen

mahlen sie das Fleisch von den Schafen, so von den vorhergehenden Vampyren umgebracht worden, gegeßen hat.

## Das Kind im Grab

Befande sich ein 8. tägiges Kind, welches 90. Tag im Grab gelegen, gleichermaßen im Vampyren Stand.

## Der Heyducken Sohn Milloe

Wurde ein Heyducken Sohn, Nahmens Milloe, 16. Jahr alt, außgegraben, so 9. Wochen im Grabe gelegen, und nach 3. tägiger Kranckheit gestorben, und gleich den andern Vampyren gefunden.

## Joachim und seine Krankheit

Ist der Joachim, gleichfals eines Heyducken Sohn, 17. Jahr alt, nach 3. tägiger Kranckheit gestorben: nachdem er 8. Wochen und 4. Tage begraben gelegen, befand sichs bey der Section gleicher gestalten.

## Das Weib Rusche

Ein Weib, Nahmens Rusche, welche nach 10 tägiger Kranckheit gestorben, und vor 6. Wochen begraben worden; bey welcher auch viel frisches Geblüt nicht allein in der Brust, sondern auch in fundo ventriculi gefunden habe, gleichfals bey ihrem Kind, so 18. Tag alt war, und vor 5. Wochen gestorben, es sich gezeiget hat.

## Das Mägdlein von 10 Jahren

Nicht weniger befande sich ein Mägdlein von 10. Jahren, welche vor 20. Monaten gestorben, in ob angezogenem Zustand gantz vollkommen und unverwesen, und hatte in der Brust vieles frische Geblüt.

## Hadnucks Weib und Kind

Hat man des Hadnucks Weib samt ihrem Kind außgraben lassen, welche vor 7. Wochen, ihr Kind aber, so 8. Wochen alt war, und vor 21. Tagen gestorben, dabey aber gefunden, daß sowol die Mutter als das Kind völlig verwesen, obwol sie gleich der Erden und Gräbern der nächst gelegenen Vampyren waren.

## Der Knecht Rhade

Ein Knecht des hiesigen Heyducken Corporals, Nahmens Rhade, 23. Jahr alt, ist in 3. monathlicher Kranckheit gestorben, und nach 5. Wochentlicher Begräbniß völlig verwesen gefunden worden.

## Die Baijactars Familie

Des hiesigen Baijactars sein Weib samt ihrem Kind, so vor 5. Wochen gestorben, waren gleichermaßen völlig verwesen.

## Stancko und das Ge-blüt

Bey dem Stancko, ein Heyduck, 60. Jahr alt, so vor 6. Wochen gestorben, habe ich ein häufiges, gleich denen andern liquides Geblüt in der Brust und Magen gefunden; und der gantze Leib war in offt benanten Vampyren Stand.

## Milloe und seine Entdeckung

Milloe, ein Heyduck, 25. Jahr alt, so 6. Wochen in der Erden gelegen, fande sich gleichmäßig in mehrgemeldten Vampyren Stand.

## Stanjoicka und ihre Merkmale

Stanjoicka, eines Heyducken Weib, 20. Jahr alt, ist an dreytägiger Kranckheit gestorben, und vor 18. Tagen begraben worden. Bey der Secirung habe ich gefunden, daß sie in dem Angesicht gantz roth und lebhaffter Farbe war, und wie oben gemeldet, sie von des Heyducken Sohn, Nahmens Milloe, seye um Mitternacht um den Halß gewürget worden, sich auch augenscheinlich gezeiget, daß sie rechter Seiten unter dem Ohr einen blauen mit Blut unterloffenen Fleck eines Fingers lang gehabt.

## Frisches Geblüt und die Viscera

Bey Eröfnung ihres Sargs floße eine quantität frisches Geblüts aus der Nasen. Nach der Secirung fande ich (wie schon offt gemeldet) ein rechtes balsamisches Geblüt, nicht allein in der Höle der Brust, sondern auch in ventriculo cordis. Die samtliche viscera befanden sich in volkommenem gesunden und gutem statu; die Unter-Haut des gantzen Cör-# Vampyr-Prozesse und ihre Folgen

pers, samt denen frischen Nägeln an Händen
und Füßen, waren gleichfals gantz frisch. Nach geschehener Visitation
seynd denen
samtlichen Vampyrs die Köpfe durch dasige
Zigeuner herunter geschlagen, und samt denen
Cörpern verbrant, die Asche davon in den Fluß
Morava geworffen; die verwesene Leiber aber
wieder in ihre vorher gehabte Gräber geleget
worden. Welches hie samt denen mir zugegebenen
2. Unter-Feldscherern bekräfftige. Med-
vegya in Servien, den 7. Jan. 1732.
(L. S.) Joh.
Flickinger/ Regiments-
Feldscherer Löbl. Baron Fürsten-
busch. Regiments zu Fuß.
(L. S.) Js. Siegel/ Feldscherer
Löbl. Maragl. Regiments.
(L. S.) Joh. Fried. Baumgärtner/
Feldscherer Löbl. Obrist Baron
Fürstenbusch. Regiments zu
Fuß.

# Bestätigung der Ereignisse

Wir Ends-Unterschriebene attestiren hie-
mit, wie daß alles dasjenige, so der Regiments-
Feldscherer vom Fürstenbusch. Löbl. Regiment
samt beeden neben unterzeichneten Feldscherers-
Gesellen hieroben, die Vampyrs betreffend, in
Augenschein genommen, in allem und jeden
der Wahrheit gemäß, und in unserer selbs eige-
nen Gegenwart vorgenommen, visitirt und exa-
minirt worden. Zu Bekräfftigung deßen ist
unsere eigenhändige Unterschrifft und Ferti-
gung. Belgrad den 26. Jan. 1732.
(L. S.) Güttner/ Obrist-
Lieuten.
Löbl. Alexandr. Regiments.
(L. S.) Joh. von Lindenfelß/
Fähndr.
Löbl. Alexandr. Regiments.

# Anmerkungen zur Relation

DIese vorstehende unterthänigste Rela-
tion, ist zu Anfang dieses Jahrs an
Seine Hoch-Fürstliche Durchleucht,
Printz CARL ALEXANDER zu Wür-
temberg, der Röm. Keyserl. Majest. würck-
lich Geheimden, Rath, Gouverneur der Fe-
stung Belgrad und des gantzen Bannats von
Servien. c. c. nach höchst Deroselben eini-ꝛ     ꝛ
ge Zeit her genommenen Hof-Lager zu Stut-
gart im Würtembergischen eingesendet, und
von Sr. Durchleucht hie und da gnädigst com-
municirt worden. Nachdeme nun von denen
häufig abgeschriebenen authentischen Copien
auch in hiesige Lande ein Exemplar gekommen,
und, wie es bey neuen Zeitungen durch Corres-
pondenzen gehet, bald dem einen, bald dem
andern erzehlet worden: so erweckte diese aben-
theurliche und bey uns sonst unerhörte Begeben-
heit allenthalben grosse Verwunderung. Es
war dieses wo nicht ein pomum Eridos, doch
eine fruchtbare Veranlassung zu Discursen bey
allerley Zusammenkünfften Hoher und niede-
rer Personen. Auch die Dames fiengen an mit
raisoniren darüber ihre Klugheit zu beweisen.
Niemand aber war übeler daran, als die Herrn
Medici, die der eine da, der andere dort beym
Ermel kriegte, und von ihnen wissen wolte,
was sie selbs bekennten, noch nicht genugsam
erforschet zu haben. Bey welchen prodigio-
sen mündlichen und brieflichen Disputen ge-
scheudte Leute unter uns ein neues Wunder-# Einleitung

Werck anmercken wolten, nemlich daß die Herrn Geistliche auf ihren Predigt-Stühlen dißmalen so still schweigen konnten. Sie gemahnten uns mit dieser ihrer ungewohnlichen, und darum desto löblichern contenance an jenes artige Emblema, da einer Loths Weib als eine Saltz-Säule gemahlet, und darüber geschrie- ben hat: Mulier tacens! Welch ein Wunder über Wunder! hie siht man auch einmal ein Weib, das schweigen kan! Ich wünschete mir hundert mahl auf eine Zeitlang unter diesem glückseligen Orden zu seyn; Weiß aber nicht, warum man mich nicht schweigen lassen wolte. Wie sehr mich excusirte, wie offt auch mein altes Studenten-Sprüchlein allegirte: Si tacuisses, Philosophus mansisses: so nöthigte man mir doch hie und da ein Denckmahl mei- ner Unwissenheit ab, und zuletzt fanden Personen, die sich über mich etwas heraus zu nehmen wußten, Mittel, zu machen, daß ich der Marter abzukommen, zusammen schrieb, was ich hin und her zerstreuet discuriret hatte. Und ich warfs ins Feur, und siehe, es ist ein Kalb daraus worden! z. B. Mos. XXXII, 24. Aber kein güldenes, welches zu seiner Resolution so einen künstlichen Chimicum, als Moses war, bedarf; sondern ein gut grob fleischernes, quod pingue quiddam sapit. Wenn es aber doch die Leute nicht anders haben wollen, so mögen sie es haben.

# Zur Sache

Wir wollen aber zur Sache selbs schrei- ten. Wenn ich nun zurück gehe, auf was man mich quæstionirt hat, so entsinne mich, daß der eine alsobald ist hangen geblieben in dem Umstand von denen unverwesenen Cör- pern; Der andere hat bey dieser Gelegenheit zeigen wollen, daß er in historia naturali auch etwas verstehe, und wärmte das Gesag von denen Schwätzern im Grabe auf; Der dritte war klüger, und wolte, man solte den Vampyrs recht nahe auf den Leib gehen, und sa- gen, was doch aus ihrem Blutsaugen zu ma- chen seye? Und der vierte erinnerte sich des klugen Raths jenes Beamten, welcher, als die Bauren über den grossen Schaden der Feld- Mäuße an denen Früchten klagten, rathete, man solte sie allesamt fangen. Und so meynten auch einige, wenn man nur beyzeiten diesen Blut-Igeln ihr Handwerck niederlegte, ehe sie die Lust, auch das deutsche Blut zu versuchen, ankäme. Nach diesen unterschiedlichen Köpfen muß ich nun wol auch den meinen richten, und also etwas sagen.

# Von den Cörpern

I. Von denen Cörpern/ welche nicht sollen verwesen seyn.

§. I. Denn dieses ist das erste Zeichen eines Vampyrs, wie die oben gesetzte Historie umständlich ausweiset. Wenn man nun bloß nach der Historie überhaupt fragt, ob das schon mehrers geschehen seye, daß ein menschlicher Cörper (denn von andern will ich Kürtze wegen nichts melden) nach der Trennung der Seelen, etliche Tage, Wochen, Jahre und Secula, unverwesen seye erhalten worden, so muß man in alweg mit einem Ja darauf antworten. Und# Körper und ihre Erhaltung

zwar versteht sich solches nicht von solchen Cör-
pern, die nichts als ihr äusserliche Gestalt be-
halten haben, an sich aber schon zu Staub und
Aschen worden, und in solche alsobald zerfal-
len sind, wo sie an freye Lufft gebracht, und
starck beweget wurden. Dergleichen man ei-
nem ohne Zweifel in vielen Grufften zeigen kön-
nte, und ich dahero nicht viel besonders sehe an
dem, was an dem Cörper Caroli V. nach 98.
Jahren auf solche Weise ist wahrgenommen
worden. Denn hie ist nicht die Frage von
denen Mumien, noch Cörpern, die durch Ein-
balsamirungen lange Zeit in besagtem Zustand
können conservirt werden: sondern von Cör-
pern, die ohne Kunst gelassen werden, und doch
in keine putrefaction gehen, keinen Todten-
Geruch von sich lassen, Haut, Fleisch und
Säffte, sonderlich das Blut, unversehrt, frisch
und flüßig behalten haben. Dergleichen er-
zehlen die Alten etwas von Hectore und Alexan-
dro Magno. Wenn bißweilen manche in Berg-
Wercken oder andern Erd-Fällen verschüttet
worden sind, hat man einiger Cörper offt lan-
ge Jahr hernach, auch halbe oder gantze Secu-
la, noch unversehrt gefunden.

# Beispiel aus der deutschen Geschichte

Unsere deutsche Acta Erudit. erzehlen uns ein noch frisches Ex-
empel, so ein Würtembergischer Pfarrer,
M. Georg Christoph Ludwig, in einer Schrifft,
die er Rothenackers Trauer-Tag betitelt, be-
schreibet. Es seyen nemlich im Winter des
Jahrs 1709. etlich und viertzig Männer sei-
ner Gemeinde auf einen Eyß-gang von der
Donau hingenommen, und 24. darunter auf
allerley Weise jämmerlich verdorben worden.
Nachdem man nun die Cörper algemach zu-
sammen gesucht, in eine warme Stube ge-
bracht, und mit warmen Wein gewaschen habe,
seye geschehen, daß bey einigen, die 4. 5. 6. 7. bis
acht Wochen unter dem Wasser gelegen waren,
das helle klare Blut starck aus der Nasen her-
fürgefloßen, so daß nicht nur ein Tropf den an-
dern geschlagen, sondern auch bey einigen die
Leilach, darinnen sie eingenähet gewesen, mit
Blut angefüllet worden, welches zum theil gar
durch die Todten-Bahr gedrungen seye, p. 26.
65.

# Heilige und ihre Wunder

So armselig und traurig es hie bey die-
sen verunglückten Leuten hergieng, daß gedach-
ter beredter Prediger es nicht kläglich genug
fürzustellen weiß: so kostbar und ungemein
prächtig und frölich ging es hingegen vor 9.
Jahren bey der endlich erlangten Canonisa-
tion des eben auch aus dem Wasser gezogenen
Heiligen Johannis Nepomuceni ab.
Dieser Johannes hat bißher auch unter den
Protestanten viel Redens gemacht. Er war
aus dem Städtlein Nepomuck in Böhmen
gebürtig, und daher heißt er Nepomucenus.
Ist gebohren um das Jahr 1320. Seine
Gabe zu predigen brachte ihn an den Hof des
Keysers Wenceslai zu Prag, und damit, wie
es schon mehrers unterdessen geschehen ist, in
sein Unglück; aber eben damit auch wieder zu
seiner grösten Ehre und Erhöhung. Zu sei-
nem Unglück gereichte das besondere Vertrauen# Die Gefangenschaft des Johannes

der Keyserl. Gemahlin gegen diesen Hof-Predi-
ger, und das argwöhnische Gemüth des un-
ordentlichen Wenceslai. Denn dieser wolte
wissen, was seine Gemahlin gebeichtet hätte,
und Johannes wolte es nicht sagen. Dar-
über kam es mit ihm ins Gefängnis, und da
dieses noch nichts verfangen wolte, so wurde
er heimlich bey Nacht den 16. May An. 1383.
in die Muldau geworffen. Der redliche und
getreue Johannes war kaum ertruncken, so ver-
trocknete das Wasser des Flusses drey gantzer
Tage lang; es erschienen allerhand helle Lichter
an dem Ort, wo sein Cörper liegen geblieben
war, und dieser signalirte sich sogleich durch
allerhand Wunder-Wercke, die in seiner Ge-
genwart fast so häuffig geschahen, als man eben
jetzund von dem Grabe des Paris zu Paris er-
zehlet.

# Die Wunder und die Erhebung

Warum wir aber seiner alhie geden-
cken, ist die Ursache, weilen bey dessen neulicher
Erhebung aus dem Grabe nach 338. Jahren
der übrige Leib zwar als ein Sceleton, die ver-
schwiegene Zunge aber gantz frisch, und am
Kopf und an der Seiten zwey frische Wun-
den, woraus Eyter geflossen, gefunden wor-
den. Die Acta dieser Canonisation, zu Prag
und Rom zusammen getragen, sind wol zu le-
sen; wenn nur das Weibliche Geschlecht das
drey und achzigste Blat überschlägt. Doch ist
der vierfache Gruß an diese Zunge noch an-
dächtiger unter den Römischen, dessen Anfang
lautet: O liebwerthester Heiliger Johannes!
ich bin nicht fähig mehrers außzusprechen, als
diese Worte: Ich habe gesündiget; und dar-
um mit Vertrauen dich anruffe: Du wollest
auflösen meine Zunge, damit ich erstlich meine
Sünden hertzlich bereue, alsdenn deine heilige
Zunge würdiger verehren und ehrerbietiger
grüßen möge. c. c.

# Die Erinnerung an die Gewalt

Endlich könte man sichꝛ  ꝛ
auch hie einiger maßen errinnern des Blutens
der gewaltthätig umgebrachten Cörper, wenn
der Thäter zu ihnen hingeführet wird. Unter
so vielen, was hievon geschrieben, ist fürnehm-
lich ein remarquables Exempel bey dem an-
muthigen Harßdörffer im Schau-Platz jäm-
merl. Mord-Gesch. c. 129. Aber ein weit
liquiderers, und alle forensische Folterungen
durchpassirtes Exempel von Grypswalden
weiß ich denen Ephemerid. N. C. aber nimmer
wo, gelesen zu haben, bin auch so ungeschickt,
es vor lauter Eilen jetzund nicht in denen vielen
Bänden finden zu können. Conf. inter. Jos.
Mar. Maraviglia Pseudomuntia veterum &
recentior. explosa.

# Die Unverweßlichkeit der Körper

Fragt man nun jetzt nach der Ursa-
che/ wo diese Unverweßlichkeit der Cörper
herzuleiten seyn möchte, so siehet man hier-
an vorderist eine Probe, wie wir Menschen die
uns fürkommende Dinge durch gantz ungleiche
Brillen sehen, und deßwegen gantz ungleiche,
ja recht contraire Gestalten an ihnen erblicken.
Kurtz, einerley Ding sieht der eine für eine Ra-
nam, der andere für eine Dianam; der eine für
eine Cervam, der andere für eine Minervam
an, damit ich aus meinem alten Schul-Säck-# Die Unverweslichkeit der Körper

Die gute Leute in Servien an denen noch Barbari-
schen Gräntzen der Türckey, halten die unver-
wesene Cörper der Begrabenen für ein Anzei-
gen eines fürchterlichen Vampyrs, Plag-Gei-
stes, Würg-Engels, Blut-Saugers und
grausamen Mörders ihrer Nachbarn und
Brüder, oder doch Geschwister-Kinder;

# Die griechische Perspektive

Die Griechen führen die Unverweßlichkeit eines
Cörpers zum Beweißthum eines ansteckenden
Ketzers, oder eines verruchten, verfluchten,
verbannten und unter dem Bann gestorbenen
Missethäters an.

# Die katholische Sichtweise

Die Herrn Catholiquen haben eine gantz gegenseitige Einsicht, und er-
blicken daran ein deutliches Merckmahl eines
begrabenen grossen Heiligen. Dergleichen
Meynung neben dem Johanni von Nepomuck
dem berühmten Indianer Apostel Francisco
Xaverio und der Heil. Catharina von Bono-
nien zu gut gekommen ist, und ohne Zweifel
auch dem Röm. Keyser Carolo V. wiederfah-
ren wäre, wenn er sich in seinen letzten Stun-
den nicht heimlicher Ketzerey verdächtig gemacht
hätte.

# Die protestantische Auffassung

Unter denen Protestanten theilen sich,
wie es bey ihnen gern zu geschehen pflegt, nach
der mehrern Freyheit zu dencken, auch hie die
Meynungen. Einige nehmen daran ein Pfand
einer in der Ewigkeit lieblich grünenden und
florirenden Seelen.

# Ein bemerkenswerter Fall

Denn so habe ich erst
diese Woche, zu meiner nicht geringen Vergnü-
gung, in einem neuen Journal, unter deßen Au-
ctoribus ein gelehrter Medicus mit ist, folgende
merckwürdige Pieçe gelesen: Eine Wittwe von
76. Jahren, die von früher Jugend an einen
Ernst zum Christenthum empfangen hatte, wur-
de vor ihrem Ende mit 2. lieblichen Träumen
gestärcket, und starb in denen heißen Hunds-
Tagen an der Wassersucht, daß man wegen der
Brand-Blasen und Flecken eine baldige Fäul-
niß besorgte.

# Ein unerwartetes Ereignis

Allein am dritten Tage, da man
zur Beerdigung eilete, sahe man etwas gantz
unvermuthetes. Ihr vor hohem Alter und lan-
ger Kranckheit verruntzeltes Gesicht und Ge-
stalt des Leibes klärete sich in einer Stunde auß,
wie einer Person von 30. Jahren. Die Füße
blieben in dem Brand ohne Geruch und Auf-
bruch.

# Der Sieg des Lebens über den Tod

So läßt ein zum Leben durchbrechen-
der und eindringender Geist auch in seiner Hüt-
ten ein Denck-Mahl seines Sieges nach sich!
Alle Anwesende bekamen ein Hertzens-Siegel,
es seye das Looß auf das liebliche gefallen! So
ist also ein munterer Todes-Kampf besser als
ein todtes Leben!

# Ein weiteres Beispiel

Andere rathen, um der jetzigen Zei-
ten willen mit solcherley Urtheilen, wenig-
stens vor dem Publico, ein wenig an sich zu
halten. Denn man weiß ein noch merckli-
cheres Exempel von dem unruhigen Eisen-Beißer
Alexandro M. dessen verblichener Leib lag in
dem brennheißen Mesopotamien, weil seine
Generals mit Einrichtung ihrer eigenen Ab-
sichten so viel zu thun hatten, daß sie sich nicht
nach ihm umsehen konten, 7. Tage lang gantz
verlassen; endlich da man weder an ihn den-# Ungewöhnliche Erhaltungszustände

cken konte (o wie seynd große Herrn offt bey Leben und im Sterben so schlecht bedient!) er- gab sichs, daß man nicht die geringste Spur ei- niger Fäulniß an ihm bemerckete, sondern die lebhaffte Farbe seines Angesichts blühete wie eine Rose, und es schiene, als wenn er noch ath- mete, daß die ärtzte sich aus Ehrerbietung nicht getrauten, ihn sobald anzurühren und zu bal- samiren, Curt. L. X. c. IV. §. 9. sqq.

# Natürliche Ursachen der Unverweslichkeit

Dahe- ro wollen einige von keinen andern, als bloß na- türlichen Ursachen, wißen. Sie erzehlen uns ein halb Dutzen Mittel, wodurch ein Cörper vor der Verwesung könne verwahrt werden. Als da sind 1. Frigus. 2. Calor. 3. Ventilatio. 4. Aêris. exclusio. 5. Salina & adstringentia. 6. Pinguia. Und welches mir 7. zur Zugabe noch beygeht, spirituosa.

# Künstliche und natürliche Konservierung

Einige hierunter ge- hören zur künstlichen præservation: Einige aber, sonderlich aêris exclusio, dienen zu un- serm Fürhaben. So gewiß eine Mauß, Vo- gel, u. d. g. Thier sterben muß, wenn mit der Antlia Pnevmatica die Lufft aus dem Gefäß, worin es gesperret ist, hinaus gepumpet wird: so wenig wird dieser erstickte Cörper riechen oder faulen, so lang kein Lufft zu ihm gelassen wird.

# Beispiele aus der Geschichte

Wenn nun auch ein menschlicher Cörper in solche Lage gerathet, so muß sich auch ein glei- cher effectus der Unverweßlichkeit ergeben. Kan die Lufft von einem Cörper abgehalten werden: so werden auch die in der Lufft steckende spicula salina abgehalten, daß sie in dem an sich selbs zwar zur corruption geneigten Cörper keine würckliche Bewegung, fermentation und Auf- lösung der Theile verursachen können.

# Erstaunliche Überlebensgeschichten

Was die oben erwehnte in der Donau viel Wo- chen lang frisch gebliebene Cörper betrifft, so hat der Herr Auctor des Buchs ein gutes Ju- dicium Medicum angehängt, welches l. c. p. 27. nachgelesen werden kan. Ich gedencke bey dieser Waßer-Geschicht an andere, welche zwar gleicher maßen eine kalte, aber doch glückliche- re und gesündere Herberge in diesem Element gefunden haben.

# Rettung aus der Kälte

Denn da erzehlet Herr D. Joël Langelott, Hertzoglicher Holsteinischer Leib- Medicus, wie ein gewißer Gärtner in Schwe- den, der einen andern retten wolte, mit demsel- ben ins eißkalte Waßer versunken, alsobald erstarret, 16. Stunden lang darinnen auf- recht geblieben, endlich heraus gezogen, mit Tüchern umhüllet, an einem gelinden Feuer erwärmet, und also wieder zum Leben gebracht worden seye, daß er hernach noch gar viele Jahr gelebet habe.

# Weitere Überlebensfälle

Darauf erwehnet er eines Wei- bes, welches drey gantzer Tag also unterm Was- ser lebendig geblieben, und auf vorige Weise er- rettet worden seye. Beede Exempel sind ge- ring gegen das dritte, da ein Jüngling von 17. Jahren, Burmann, ins Wasser gefallen, und erst in der siebenden Woche gefunden, und auf oben beschriebene Weise wieder zum Leben ge- bracht worden seye.

# Wissenschaftliche Erörterungen

Uber welche Casus aller- ley gelehrte Medici in denen Ephem. Nat. Cur. Decad. I. ad Ann. V. ihre Gedancken eröfnet haben, wie fern es möglich seye, daß ein Mensch# Wasser und seine Geheimnisse

so lang unterm Wasser erhalten werden möge.
Da sie denn bey dieser Gelegenheit noch mehrere Exempel beybringen, und insonderheit Herr D. Sal. Reisel eines einschaltet, das unserm Vorhaben nahe kommt, wie der Cörper eines erschossenen Jünglings öffters Blut geschweisst, und unbegraben 7. Wochen ohne einigen Geruch und Fäulniß in seiner Farbe geblieben seye, wie man deßen unzweifliche Versicherung habe. Hingegen will man dem Herrn Baronen von Herberstein in Comment. rerum Moscovit. nicht allerdings Glauben beymeßen, wenn er von denen Leuten in Lucomorien debitirt, als wenn ihnen die Nase von dem Eyß zugefriere, daß sie den Winter über wie todt da liegen, alle Frühling aber gleichsam wieder lebendig würden.

## Die Frage nach der Wahrheit

Die Personen, mit welchen ich zu thun hatte, merckten meistens, daß ich mit diesen Umwegen nur durchzuschlupfen suchete. Darum faßeten sie mich genauer, und fragten, was denn endlich meine Meynung hievon wäre? Ich gab sie dahin, daß alle diese Exempel, wenn sie auch alle ihre Richtigkeit hätten, bey weitem noch nicht hinreicheten an die Begebenheit der Vampyrs, da ihrer so viel auf einmal nicht nur unversehrt bleiben, sondern auch so eine Menge helles Blut in sich behalten, ja nach dem Tod vollblütiger und sonst vollkommener werden, als sie bey Leb-Zeiten gewesen; Da von denen Ursachen, welche sonst die Physici anfüh-ren, hie keine anzuschlagen scheint; da sie von keiner dicken und tiefen Erden verschlagen, oder von der aufliegenden Last des Wassers gedrückt sind; da andere neben ihnen liegen, und verzehret werden, welche und dergleichen Umstände alle uns nöthigen, hiebey an etwas weiters zu gedencken.

## Die Ungewissheit der Naturgesetze

Es ist noch gar kein sicherer Schluß zu machen: Es hat etwa hie oder da ein so seltener und ungefährer Zusammenschluß natürlicher Ursachen sich begeben können, daß todte Cörper eine Zeitlang unversehret geblieben sind: Darum ist solches auch bey diesen Cörpern, zu dieser Zeit, in dieser Erden, unter diesem Himmel, bey diesen Umständen, also bloß natürlich geschehen. Aber es ist von denen oben angezogenen anderwärtigen Exempeln eben auch noch eine ziemliche Frage, ob man bey allen Ursache habe, blos die natürliche Gesetze allein zu supponiren.

## Der Glaube an das Übernatürliche

Zum Exempel, wenn die Erzehlung von der Zunge Johannis Nepomuceni ihre Historische Gewißheit hat, so weiß ich nicht, ob nicht der die Gräntzen seines Verstandes sich zu groß einbildete, der diese Begebenheit in die enge Gräntzen der bloß natürlichen, und durch einen hazard so zusammen treffenden Ursachen einschrencken wolte. Es wäre mir leyd, wenn ich für keinen guten Protestanten passiren solte. Aber das sage ich ungescheuet: wenn ich die Historie von Nepomuceno glaube, so glaube ich auch zugleich, daß eine höhere Ursach mit darunter zu suchen seye. Also nun auch mit denen Vampyrs. Da ich die Relation davon als wahr annehme, daneben gewiß weiß, daß ein# Einleitung zur Korruption der Körper

jeder Cörper, von welchem die Seele geschieden ist, nothwendig zur Corruption sich neiget, und daß dieses die algemeine Erfahrung in der gantzen Welt ist, und daß es sich auch ordentlicher Weise zu Medvegya in Servien so verhalte; und nur selten bey einigen sich so etwas ereigne, was sich da ereignet: so bekenne ich meine Einfalt vor Herren und Frauen, daß ich dabey über die gewohnliche Gesetze der Natur hinausdencke. Ja ich schäme mich nicht zu bekennen, wenn auf hiesigem Kirch-Hofe nur ein einiger Cörper ausgegraben würde, der etliche Wochen oder Monathe neben andern Verweßten unverweßlich gelegen, ohne Todten-Geruch, ohne Fäulniß, mit frischem Fleisch, und flüßigem klaren Blut geblieben wäre, so könte ich mich nicht enthalten, über die tägliche und gewohnliche Ordnung der Natur hinaus zu sehen, und auf eine dazwischen laufende fremde und höhere Ursache zu gedencken. Welches ist aber dieselbe fremde und höhere Ursache? da bit-te ich mir ein wenig Gedult aus, biß uns die Ordnung dahin führet.

# Historie der unversehrten Toten

Wenn ich nun dieses mein Glaubens-Bekäntniß von solcher Art Leu-te gethan hatte: so fielen mir andere in die Rede, welche hatten sagen hören, daß nicht nur gewiße Todten unversehrt blieben, sondern daß sie auch in den Gräbern schmatzeten/ oder vielleicht mit ihrem Nachbar schwatzeten. Und da muß ich nun

§. I. HJe will ich erstlich die Historie erzehlen. 2. die fürnehmste Meynungen berühren. Und 3. meinen Außschlag geben. Weil doch die Sach einige Verwandschafft mit den Vampyrs hat, so will ich vorderist die Historie davon kürtzlich erzehlen mit denen ungeänderten Worten derer, die davon geschrieben: Es ist schon lang, daß sich hin und her in der Welt bis noch auf unsere Zeiten geäußert hat, daß man aus den Gräbern heraus die eingescharr-te Todten hat hören schmatzen, wie die Schwei-ne, wenn sie eßen; oder batschen, klopffen, und ein ander Geräusch machen. Hat man nun sie ausgegraben, so hat man gefunden, daß die Leiche sich entweder die Finger, oder die Hän-de, oder einen Arm, u. d. g. abgenagt, oder die umgeschlagene Leilache und Hembder halb oder gantz verschlungen, oder noch blutig im Rachen stecken gehabt haben.

# Praktiken gegen die Schmatzer

Weil man nun die Anmerckung haben will, daß auf solches Schmatzen entweder die Pest folge, oder doch wenigstens die nächsten Anverwandten nachsterben müssen, daher diese Schmatzer auch Nach-fresser genennet werden: so pflegt man solchen Todten mit einem Grab-Scheit den Kopf abzustossen; andere aber beym Begräbniß einen Wasen unter das Kinn, oder einen Stein in den Mund zu legen, damit ihnen die Näsche-rey vergehen möge.

§. 2. häuffigen Auctoribus keine anziehen, als folgende wenige, Lutherum in Tisch-Reden, f. m. 151. Er. Franc. Höll. Prot. c. 28. D. Hörnig im Würg-Engel qu. 71. Sam. Frid. Lauterbach, Prediger zu Frau-# Pest-Chronik und alte Bräuche

enstadt in Polen, der erst A. 1710. eine kleine Pest-Chronic edirt, redet auch von dieser Materie, und setzt hinzu: Man will sagen, als ob dergleichen Aufgraben auch jetzo hie in der Nähe an einem Römischen Ort fürgenom- men worden, und hätten sich einige Leichen gantz blutig und befressen gefunden, de- nen man die Köpfe abstossen lassen. p. 26. Ich weiß nicht, muß sich dergleichen etwas schon bey den alten Juden erzeiget haben, weilen der gelehrte Calvôr in seinem fast gantz unsichtbar gewordenen Rituali Evangel. von ihnen schrei- bet, sie hätten gebotten, man solle zusehen, daß den Todten nichts von leinwandenen Zeug in den Mund komme, es sey sonst große Gefahr dabey.

# Upiers und Vampyrs

Sonderlich werden die Upiers in Polen fast be- schrieben, wie die Vampyrs in Servien. Wenn P. Gabr. Azaczynsky Historia Nat. Curiosa re- gni Poloniæ bey Handen wäre, Sandom. 1721. in 4. ed. könten wir uns daraus viel guten Be- scheids erhohlen. So aber müßen wir uns der- malen mit den Excerptis Actor. Lips. begnü- gen lassen, die also lauten: Sectione II. de cru- entationibus cadaverum agens mira profert Auctor de mortuis in tumulis adhuc voraci- bus, & vicinos viventes spectrorum modo trucidantibus, a Polonis speciali nomine U- piers & Upierzyca appellatis, de quibus quæ producit authentica documenta, ulteriorem fortasse disquisitionem merentur, ad Ann. 1722. mens Jan. p. 17.

# Historische Glaubwürdigkeit

Zeit zu ersparen, will ich besondere Historien nicht außschreiben. Viel lieber fragt es sich §. 3. Was halten gelehrte Leute von diesen aben- theurlichen Erzehlungen? Ihre Antworten seynd theils eben so abentheurlich, ut dignas habeant labra lactucas. Etliche führen sich auf gut Machiavellisch auf in regno literario, und sagen: Historie hin, Historie her, es ist al- les nicht wahr, was man hievon sagt. Das wäre freylich der kürtzeste Weg, auch mit un- sern Vampyrs aus dem Felde zu kommen.

# Philosophie und Ignoranz

Sed indignus est Philosopho sermo, ubi causa re- rum ignoratur, rem ipsam negare potius, quam ignorantiam suam profiteri, denck ich mit dem unvergleichlichen Plinio, den einige für eine halbe, einige für eine gantze Biblio- theque æstimiren, in Hist. Nat. c. 4. Ich avancire diese Regel bey Zeit, weil ich wünsche, daß sie auch bey folgenden Materien in frischem Angedencken bleibe.

# Verschiedene Erklärungen

Andere machen sich ein Gewißen, den fidem historicam so zu durch- löchern, und erkennen die Glaubwürdigkeit der Erzehlungen. Aber der eine gibt zur Raison an das unter-irrdische Feuer; der andere die un- ter-irrdische brausende Winde; der dritte das Einfallen des Sargs; der vierte die Hyenam: und ich weiß nicht, was uns hie Juden und Türcken bald von einer Mauß, bald von einem Engel, vorschwatzen wollen. Der Herr Au- ctor, der vor 4. Jahren de Masticationibus mor- tuorum geschrieben, meynt, er habe es bey de- nen zischenden Schlangen und freßigen Wür- mern ertappet, die sich sonderlich bey denen fet-# Die Mahlzeit der Lebenden und die Klänge der Toten

ten und wohl gemästeten ihre Mahlzeit so saff-
tig schmäcken ließen, daß man ihr behagliches
Schmatzen oben auf der Erden höre. Hingegen
finden andere hieran keinen gousto, und wol-
len lieber in die Tieffe fahren, und es den Teu-
fel bezüchtigen. Doch wissen sie nicht recht,
wie sie es auf ihn bringen sollen. Etliche mey-
nen, Satanas mache ein fallaciam acusticam,
so ein leeres Geräusch vor denen Ohren der Le-
bendigen; etliche, es seye zwar ein wahrhaffti-
ges Geräusch, aber nicht von den Todten, son-
dern von dem Teufel im Grabe angerichtet. So
hat D. Lutherus decidirt, wie mans ausführ-
lich lesen kan in Tisch-Reden c. IX. f. 151. und
nach ihm die meisten Theologi. Man sehe
nur Duntem in Cas. Consc. c. XXII. S. 1.
Qu. 19. fürnemlich aber den ehmals sehr curio-
sen und gelehrten Prediger zu Laubach, Mart.
Bohemum, der unter seinen XXIII. Predigten
von denen 3. grossen Land-Plagen in der 17den
austrücklich diese Materie behandelt, und aus un-
terschiedlichen Gründen dieses Schmatzen dem
Teufel zuschreibt, und eben auch dahin ziehet,
daß der Kayserin Eudoxia, die den Chrysosto-
mum so verfolgt hatte, ihr Sarg, als sie solte
begraben werden, sich ohne Menschen-Hände
so hin und her beweget habe, nach Niceph. Be-
richt Hist. Eccl. L. XIII. c. 36. So haben sich
auch Pabst Sylvesters II. der insgemein für ei-
nen Schwartz-Künstler gehalten wird, Gebei-
ne lange Zeit nach seinem Tode im Sarg be-
weget, daß sie geklappert, auch wol geschwitzet,
wenn ein Pabst hat sterben sollen, wie Bonifac.
Simoneta L. V. c. 50. schreibet.

## Die Vermutung der Lebendig-Begrabenen

Es ist nicht nöthig, mit meiner Meynung
lang hinter dem Berg zu halten. Ich bekenne
mich mit kurtzem zu denen, welche muthmaßen,
daß dieses Schmatzen, Klatschen und Geräusch
von denen Begrabenen selber gemacht werde.
Ich sage nicht, von denen Todten; sondern
von denen Begrabenen, die nemlich für todt
gehalten lebendig begraben wurden. Daß die-
ses malheur Unschuldigen nicht nur wiederfah-
ren könne, sondern besorglich nur gar zu offt
schon wiederfahren seye, achte nicht, daß bey
jemand ein Zweifel walte. Denn 1. hat man
unterschiedliche, deren Gräber man ungefähr,
oder sonst um Ursachen willen geöffnet, in ei-
nem solchen Zustand angetroffen, woraus
man überzeugt werden konte, daß wie sie da-
hin gebracht worden, sie noch nicht müsten
seyn gestorben gewesen, indem etliche im Sarg
umgewendet gelegen, etliche aufrecht gesessen,
etliche auch gleich nach ihrem Begräbniß durch
ihr erbärmliches Gewinsel zu verstehen gegeben,
daß sie noch lebten, indeßen wegen nicht so
bald erfolgter Rettung endlich verderben müs-
sen, etliche aber noch zeitlich errettet worden
sind, siehe des nun seel. Herrn Paul Christ. Hil-
schers, beliebten Predigers zu Alt-Dreßden,
der sich mit etlichen curieusen Pieçen bekant ge-
macht, Nachricht von der aus ihrem Grab wie-
der auferstandenen Goldschmids Frau zu Dreß-
den A. 1723. da er zwar diese Sache widerlegt,# Die Unordnung der Begräbnisse in der Vergangenheit

hingegen die Sache an sich selbs mit andern
Exempeln bestätiget. 2. Muß man sich andere
Länder und die vorige Zeiten nicht wie unsere
einbilden, als wenn man überall und allezeit so
gute Vorsicht und Ordnung wegen der Be-
gräbniße getragen hätte, als etwa jezund. An
vielen Orten scharrete man die Todten nur ein
wenig mit Erden zu, daher sie leicht heraus ge-
worffen, von Hunden und andern Thieren miß-
handelt werden konten. Insgemein hat man
gar zu sehr mit den Leichen unter die Erde geei-
let. Wie tumultuarisch und unordentlich es
damit müße hergegangen seyn, kan man genug
daraus schließen, daß noch zu unserer Väter
Zeiten oder drüber der gottselige Churfürst Au-
gustus eine Verordnung machen muste, daß
man einen Verstorbenen zum wenigsten zwölff
Stunden lang im Hause behalten solle, s. Kir-
chen-Ordn. General-Artic. n. 15.                   §. 5.

# Erstaunliche Begebenheiten nach dem Tod

Was manchen auf dem Schragen, man-
chen noch auf dem Kirch-Hof bey dem Grab
wiederfahren ist, das hat andern im Grabe erst
wiederfahren können, nemlich daß sich ihr noch
nie verloschenes Leben wieder geoffenbahret hat.
Gedachter Herr Hilscher erzehlet von seiner ei-
genen Gemeinde, daß A. 1719. eine Christ-
liche Witwe begraben worden, welche als A.
1680. in der damaligen Contagion ihr Mann
nebst 25. Personen aus einem Hause verstor-
ben, und sie selbs auch von der Pest hefftig an-
gegriffen worden seye, habe man sie den andern
Leichen zugesellet. Indem aber des Abends,
da sie solte begraben werden, noch jemand an ihr
etwas zu recht machen wolte, hat sie darüber die
Augen aufgethan, und sich beschweret, daß man
sie in ihrer Ruhe gestöhret habe, da sie dem Him-
mel schon so nahe gewesen seye. So wurde auch
A. 1698. aus Coppenhagen geschrieben, daß
ein gewisser Schif-Capitain nach langer Kranck-
heit von den Anwesenden für todt gehalten wor-
den. Nachdem er aber etliche Stunden gele-
gen, und ihn der Tischer, so das Maaß zum
Sarg nehmen wollen, etwas zu unsanfft ange-
rühret, hat er jenen beym Kopf gekriegt, wel-
cher sich dermassen darüber entsetzet, daß er
plötzlich kranck worden, und bald gestorben seye.
Noch mehr ist, was in eben selbigem Jahr aus
London gemeldet wurde, daß in der Graffschafft
Yorck ein Prediger, Henr. Weats, vor todt
angesehen, und nach der Kirchen zur Begräb-
niß gebracht worden seye. Indeme man ihm
aber die Leichen-Predigt gehalten, habe er in
dem Sarg ein solches Gepolter gemachet, daß
man selbigen eröfnet, und ihn zu aller Ver-
wunderung lebendig gefunden habe, so gar, daß
er etliche Tage hernach wieder vor denen gepre-
diget, welche seinem Begräbniß beygewohnet
hatten. Und wie sehr man immer noch auch
bey uns in dieser Sache anstosse, weiß man in
dieser Stadt, wo ich schreibe, aus einem noch
ziemlich frischen Exempel, noch wol. Eine krei-
stende Frau arbeitete sich über der Geburt so
müde, daß sie vermuthlich in eine tieffe Schwä-
che und Ohnmacht sanck, und für todt gehalten.# Die Geburt und der Tod

wurde, ehe sie die Frucht von sich gebracht hatte. Man wickelte sie ein, und legte sie hinaus in ein kaltes Zimmer. Nach etlichen Stunden kam der Tischer, und wolte das Maaß nehmen zur Bahr. Man fande aber mit Bestürzung, daß nicht nur inzwischen das Kind von ihr getrieben worden war: sondern daß sie auch das Leilach über sich zerzaplet und von sich geschafft hatte: welches wenigstens bey vielen einen Verdacht erweckte, als wäre damals noch ein Leben in ihr gewesen.                          §. 6.

# Krankheiten und der Zustand des Körpers

Und so ist es auch bey andern Arten der Kranckheiten, als Schlag-Flüssen, Ohnmach­ten, fallender Sucht, Gichtern, Erstickung durch Rauch oder starcken Geruch, mancherley weiblichen Beschwerungen, u. d. g. leichtlich geschehen, daß die Seele aus dem Stand ihrer ordentlichen Bewegungen gesetzet, und so denn der Leib vor eine Leich, ehe er eine ist, angesehen werden kan. Vid. Paræus L. 23. c. 46. de hysterica pro mortua habita, quæ ad cultri anatomici applicationem vitæ superstitis signa præbuit; Borell. Cent. 1. Obs. 2. de carbonum fumo suffocatis vitæ restitutis. Theod. Kirchmaj. Diss. de hominibus apparenter mortuis, Witteb. 1669. Valvassors Ehre des Herzogthums Crain L. XI. p. 715. 717. Die übrige kan man gantze Schocken-weiß angezogen finden, bey P. Hilschern, l. c. p. 10. und D. Mich. Alberti Diss. Memento mori §. 12. & in Diss. de Resuscitatione semi-mortuorum medica, §. 5.

# Theologische Überlegungen zum Tod

Ich setze nur noch zwey hinzu, die der Fleiß dieser Männer nicht mitgenommen hat, nemlich Hieron. Jordan. de eo, quod divinum est in morbis humani corporis, c. 42. welches anfangt: multos morbos naturaliter mortem mentiri notum est, p. 154. b. Fürnehmlich aber den gründlichen Theologum, D. Ph. jac. Spenerum, der in seinen Consil. Lat. eine weitläufftige Antwort einem fürneh­men Herrn gibt, der ihn Raths gefraget hatte über das öfftere Klopffen in den Gräbern, welches von einem Jahr her an seinem Ort ge­höret werde. Daraus ich das meiste mitthei­len will, weilen doch die wenigsten ein Buch nachlesen können oder wollen, wenn es nur citirt wird. Er sagt: wenn auch nur das gering­ste Geräusch gehöret werde, solle man alsobald das Grab eröfnen.

# Lebendige Begräbnisse

Ich habe meinen Bekannten schon oft gesagt, man begrabe weit mehr Lebendige, als etwa jemand glauben dörffte. Die Medici sollen gute Kennzeichen haben, daran man die wahrhafftig gestorbene von den vermeintlich gestorbenen, sonderlich in gewissen Affecten, unterscheiden kan (von welchen betrieglichen und wahrhafftigen Kennzeichen eines Todten nebst P. Zachia in QQ Medic. Legal. l. 4. tit. 1. qu. 11. n. 26–29. auch ein Theologus, P. Hilscher, handelt, l. c. p. 21. sqq.) Ja ich habe ehdessen den Rath dahin gegeben, daß keine Frau, welche hystericis passionibus unterworffen gewesen, vor dem fünfften Tag als für gewiß todt solle gehalten und begraben werden; wo er sich denn auf ein paar Exempel be-# Über das Leben nach dem Tod

Er selber habe einen Oncle gehabt, der 70. Jahr alt worden, den man aber im 16ten Jahr als an den Gichtern gestorben von früh morgens an bis in die folgende Nacht für todt gehalten, und zur Bestattung beschicket habe, da er in dem wieder zu sich selbs gekommen seye. Mehrere solche Exempel erzehle Sebizius in einem Brief an D. Danhauern, welchen er seinem Scheid- und Absag-Brief einverleibet habe p. 232. Deßwegen wo die geringste Vermuthung eines Schalles in dem Grab seye, solle man zu-eilen, und solches eröfnen. Unterlasse man solches, so verschulde man sich eben so schwer, als wenn man sonst aus seiner Schuld den Neben-Menschen umkommen lasse.

# Die Bedeutung des Lebens

Er sehe keine Ur-sache, warum man sich ein Bedencken machen solte. GOtt habe solches nirgend verbotten. Es möchte endlich zu einigem Aberglauben Anlaß geben. Aber diese Gefahr seye nicht so groß, als wenn unter vielen nur eines einigen Leben, der hätte auf solche Weise salvirt werden kön-nen, versäumet würde. Ja er wolte wünschen, daß, ehe ein Sarg eingesencket werde, man den selben jedesmahl zuvor eröfne, und versuche, ob bey der neuen Anwehung freyer Lufft sich nicht am Gesicht oder sonsten auch nur das geringste Zeichen eines noch übrigen Lebens entdecken lasse, wozu man erfahrne Männer nehmen müßte.

# Die Sorgfalt um die Toten

Das Leben des Menschen seye so pretios, daß es sich wol solcher Sorgfalt belohne. Wol-te man aber dieses Klopffen und Rauschen für ein Wunder-Werck ansehen, so gehöre grosse Fürsichtigkeit dazu, damit wir nicht einer andern Ursache zuschreiben, was die Natur vermocht hat. Ja wenn auch der Teufel hie und da sein Spiel mit darunter menge, so schade es doch nichts, den Cörper aufzugraben, und nachzusehen, was denn geschehen seye.

# Praktische Überlegungen

Bishier der vernünfftige D. Spencer Part. III. p. 120. sq. Noch fält mir ein, daß Herr D. Alberti sich irgendwo auch auf die Herrn Juristen beruffet, welche schon mehrers es denen Medicis verweisen, daß sie wo nicht gleich den ersten, doch den andern Tag promiscue ihre Sectiones fürnehmen c. Weil diese Sache in praxi ge-nutzet werden kan, so habe mich ein wenig län-ger, als meinem Vorhaben gemäß, dabey aufgehalten.

# Ein Epitaph für die Verstorbenen

Ehe wir aber von unsern bißher durchkrochenen Gräbern hinweg gehen, wol-len wir zum Angedencken unserer gethanen Wal-fahrt auch eine Grab-Schrifft hinterlas-sen. Das solle des subtilen Scholastici, Jo-hannis Duns Scoti seyn, welcher ehrliche Mann eben auch die bißher beklagte Fatalität erlitten, und deßwegen folgendes Epitaphium verdienet hat.

Quod nulli unquam homini accidit, Via-tor, Hic Scotus jaceo semel sepultus, Et bis mortuus, omnibus Sophistis Argutus magis atque captiosus. Kormann. de Mirac. mort. P. VI. c. 56. §. 7. So dreißt stellete mich zwar, so raisonir-# Einleitung

te ich mit Gründen, so schmückte ich mich mit Auctoritatibus aufs schönste; und etliche admirirten auch meine Lumieres. Aber ich kriegte auch so kluge Leute vor mich, welche sich damit noch nicht wolten abfertigen lassen. Sie hielten mir entgegen, ein anders seye klopffen, rufen, seinen Situm umkehren c. welches dieꝛ apparenter mortui und lebendig begrabene wol thun könten; ein anders aber seye masticiren, sich Händ und ärm abessen, und zwar so, daß die Anverwandten nachsterben, so lang, bis man einem solchen Nachfresser den Kopf abge-stossen habe; Denn dieses bezeugen so viele Historien, die man nicht so schlecht weg leugnen dörffe. Ferner so habe man offt solches Geräusch viel Tage oder auch Wochen hinter einander gehöret, da ohnmöglich die Begrabene so lang hätten leben können. Wiederum, wie doch ein geschwächter Leib im Grab bey so grossem Mangel der Lufft sich Händ und Aerm, die gemeiniglich fest eingebunden sind, abbeissen, wie er bey so schwachem Athem holen grosse Stücke von Leinwand in sich schlucken könne, da er sich damit das Athmen noch mehr intercludire. Zu geschweigen, wie die famose Masticanten gemeiniglich ziemlich exsangues und ausgetrock-net in die Gruben kommen, und aber daselbsten mit animalischen Feuchtigkeiten auf eine erstaunliche Weise angefüllet gefunden werden. ꝛc. Wenn wir nun davon in die Länge und in die Quere ein paar Stündgen raisoniret hatten, so war der Beschluß, wie er noch offt bey wichtigern Versammlungen zu seyn pfleget: Und ein jeder gieng also heim, unverrichteter Sachen, Joh. VII. 52.

# Der III. Versuch

§. 1. DJese Scharmützel seynd nur kleine Zu-bereitungen gewesen auf das Feuer und Rauch unter den Vampyrs in Ser-vien. Wer die obige Historie gelesen hat, oder jetzt wiederholet, muß bekennen, daß dieses erstaunliche Kräfften und verwickelte Wirckun-gen untereinander seyen. Wer sie demeliren, und ihren nexum causalem zeigen kan, erit orbi magnus Apollo, den wollen wir für so klug halten, als den Daniel. Bey diesem Bengel nun, welchen GOtt denen Gelehrten hingeworffen hat, führen die Leute, die mir bekant worden sind, eine unterschiedliche Con-duite. Etliche suspendiren ihr judicium. Und die thun wol am klügsten. Aber es profitiret niemand nichts von ihrer gravitätischen Weißheit. Wenns bey allen Knoten alle Menschen so machen wolten, wie schlecht wäre bißher der Welt gerathen worden! Nihil sapienter fit, quod si ab omnibus fiat, inutile est ac malum, schreibet unvergleichlich der Christliche Cicero, Lactantius in Instit. L. 3. c. 22. Etliche wagen sich ihren Kram auß-zulegen; doch erwehlen sie unterschiedliche Mit-tel. Einige wollen diese Wasche allein aus der Philosophie außwaschen. Und da war schon, nisi fallor, Anno 1725. oder 1726. vornen draus Herr M. Michaêl Ranftius, V. D. M. welche literæ initiales ohne Zweifel bedeuten:# Verbi Divini Minister

Man würde es aber auch ohne diesen Zusatz leicht errathen haben, daß der Auctor ein Geistlicher seyn müsse, so bald man seine 2. Dissertationes de Masticatione mortuorum in tumulis gelesen hätte. Nicht zwar, als wenn er so bigotisch mit der Schrifft und Theologischen Waffen stritte; denn diese hält er für zu stumpf gegen seine Philosophie: sondern weilen die Arbeit eben sonst so gerathen ist, wie sie gemeiniglich zu gerathen pfleget, so offt Theologi philosophi ren wollen. Wenn es diesen Herren niemand sonst vertraut hätte, als der cordate Thomas, so solten sie zum Nachdencken gebracht worden seyn. Sed æthiops non dealbatur.

# Mechanismus und Materie

Nun unser Herr M. Ranft hat sich fürgenommen, alle diese oben beschriebene wunderliche Begebenheiten aus der Natur der bloßen Materie, und Operatione corporis in corpus zu erklären, ohne einen Göttlichen, oder Menschlichen, oder Englischen, oder Teuflischen Geist dabey nöthig zu haben. Es gehet alles aus dem heut zu Tag so sehr beliebten Mechanismo und communicatione motus non nisi per materias possibili. Welchen Künstlern unser Herr D. Alberti in seinem Specimine Theologiæ Medicæ einen scharffen Text lieset, p. 90. sqq. dessen mich nicht weiter annehme.

# Vitalität der Materie

Doch supponirt Herr M. Ranft keine materiam inertem & passivam, sondern infinitis potentiis & vitalitatibus fœcundam & gravidam. Diese neue Notion der Materie beweiset Herr Auctor daher, weil GOtt materiam primam nicht anders als voller Leben und Actuosität habe erschaffen können, indem Er kein todter und müßiger, sondern ein lebendiger und actuo ser GOtt in actu creationis gewesen seye. Wol gezielt, aber schlecht getroffen. So werden wir denn eine ewige, allmächtige, unendliche, allweise, allgütige, geistliche c. Materie von nun an haben.

# Eigenschaften der Materie

Das bekümmert Herrn Ranftium wenig, sondern nachdem er demonstrirt hat, wie der Erden-Kloß, daraus Adams Leib gebildet worden, so voll unendlicher vitalitatum gewesen, ehe ihm GOtt der HErr den lebendigen Athem in die Nasen eingeblasen, so macht er nunmehr vitalitatem zur eigentlichen proprietate materiæ, welche wieder 2. andere proprietates an sich habe, 1. Vegetantiam, daß wenn schon vita hominis tanquam compositi im Tod aufhöre, so bleibe doch vita corpori specifica noch übrig, und durch dieses können die zwar gestorbene Menschen, aber doch lebende Cörper sich unverwesen erhalten, schmatzen, Blut lassen, an Haaren wachsen, penem erigiren. c. 2. Sensationem; aus dieser leitet er die operationem nocivam corporum in vivos her, dabey es auf die Sympathie und Antipathie der Cörper, auf die Magiam Nat. auf die Imagination der Hinterlassenen, und die effluvia der Verstorbenen hinaus laufft.

# Unerwiesenes und Herausforderungen

Wie sich nun der Mann hie mit viel Unerwiesenes heraus nimmt: also muß er sich noch weit mehr zwergen, wenn er seine# Prinzipien und Hypothesen

Es grauet einem vor dem Zwang, wie er sich drehen, und hundert Umstände fingiren muß, diese effectus aus seiner, obwol lebhafftigsten, Materie heraus zu drechseln. Ich sehe also wol, man muß hie ein principium vitale haben, man mag es nun einen Geist, oder Archeum, oder balsamum corporum, oder Materiam infinitis potentiis vitalibus refertam, oder anders nennen. Warum eckelt man doch so den Nahmen eines Geistes, und bildet sich lieber tausenderley schwerere Dinge ein, wie es möchte zugehen können, als daß man συνέργειαν spiritus zulassen will? Muß denn auch diß Kennzeichen der ersten Welt an uns eintreffen: Die Menschen seynd Fleisch!

# Enthusiasmus und menschliche Natur

Ich hatte wenige Zeit zuvor in des Engelländers Chambers Lexico Univers. Artium & Scientiarum, Lond. 1728. gelesen, daß er meynt, der Enthusiamus seye denen Artificibus und Inventoribus wie artium, also auch Systematum, ja dem gantzen Menschlichen Geschlecht so eigen, daß der Mensch besser könne beschrieben werden, er seye ein Animal enthusiasticum, als wie vulgo, ein Animal rationale. Das hat sich aufs wenigste an dem Hn. Auctore verificirt. Gewiß, er muß in einem starcken raptu enthusiastico gewesen seyn, da er ein solches Systema von so lebvoller Materie, von so unerweißlichen suppositionibus, von so chimerischen Einbildungen, daß der Haß die Imagination der Verstorbenen dermassen anflamme, daß sie solche Tragœdie unter den Lebenden spielen können, ersonnen hat.

# Alternative Erklärungen

Hac non successit, alia aggrediamur via, dachten andere, welchen Molliers Maladie imaginée eingefallen ist. Denn diese weitsehende dencken, es könte diese gantze Sache eine Ungarische Kranckheit, und eine Wirckung der corrupten Phantasie seyn. Was die morbi ideales für stupendos effectus produciren können, quibus non solum spiritus, sed ipsa anima ad varios & inordinatos motus concitentur, hisque mediantibus variæ corpori impressiones & noxæ inferri queant, wissen die Medici am besten.

# Fallstudien und medizinische Erklärungen

Wenn einer weiter nichts lieset, als die Acta privata, betreffend diejenige Kranckheit, womit Personen unterschiedlichen Geschlechts und Alters zu St. Annenberg vom Jahr 1713. bis An. 1719. überfallen worden, edirt von Herrn D. Chr. Höpner in 4. Leipz. 1720. so kan er sich genug ersehen, quam graves morbi & incredibiles effectus, die auch etliche Medici einer übernatürlichen Ursache zugeschrieben, doch bloße causas naturales zu ihrem Ursprung öffters haben, die zwar Anfangs sehr schwer zu eruiren seynd, gleichwohlen endlich, und bißweilen auch nach dem Tode noch, offenbar werden, vid. D. Wedels Diss. de morbis ex fascino, c. 5. Ich will aus besagten Actis einen einigen §. hersetzen, womit sich manche hoch tragen unter uns, da unter andern es also lautet: Anlangend die Er-# Die Seelen und ihre Erscheinungen

scheinungen, so ist der Seelen nebst andern uns nicht allezeit begreiflichen Kräfften von GOTT auch diese mitgetheilet worden, daß sie bey ihrem natürlichen Zustand dasjenige, so sie einmal gesehen oder gehöret, denen äusserli- chen Sinnen bey Gelegenheit allemal wieder vorstellen kan. Wer glaubet, es seyen in dem Gehirn des Menschen gewisse örter anzutref- fen, welche auf diese oder jene Art afficirt aller- hand Bildungen, die sich ausser uns in der That nicht befinden, erregen und verursachen, daß der Mensch, dessen Gehirn auf dergleichen Art af- ficirt wird, festiglich davor hält, er sehe derglei- chen Bildungen wircklich vor sich, als Men- schen-Gestalten, Geld, Vogel, Engel c.ꝛ Er fühle eine kalte Hand, u. s. w. Wer sage ich, dieses glaubet, der wird auch nicht vor ohnmöglich halten, daß ohne Beytrag des Teufels oder seiner Werck-Zeuge ein Mensch an denen gewissen örtern des Gehirns dergleichen Impression empfinden könne, welche nach denen Regeln der Natur mit ei- nem Schein jetzterwehnter und anderer Dinge verknüpfet, in der That aber nichts wirckliches ist, siehe Bayle Dict. art. Hobbes. lit. M. Dieses leugnet man nicht, daß denen Krancken, wie sie es selber aussagen, diese oder jene Gestalten fürkommen; Daß aber supernaturale quid hiebey unterlauffe, und daß die Gestalten wircklich die angegebene Personen seyen, wird man nimmermehr behaupten können.

# Die Erscheinungen einer Jungfer

ei- ner Jungfer erfordert, sie hatte Hitze, Hertzens- Angst, weinete immer c. nach paar Tagen er- fuhr ich von ihr, daß sie in des vor einigen Ta- gen verstorbenen Haußwirths Bette lag, und gab vor, sie sähe den verstorbenen Haußwirth stets vor sich sitzen, dahero sie sich einbildete, sie müßte sterben. Ich verordnete sie sogleich in ein ander Bett, und an einen andern Ort zu le- gen, sie nicht allein zu lassen, und gab ihr eini- ge Artzneyen, worauf sich die falsche Bildung nebst dem Fieber und andern Zufällen gar bald verlohren, p. 45. §. 9. Man könte noch weit wunderlichere Exempel anführen, was eine verrückte Imagination für Spiele anrichten könne. Doch ist mir immer unter allen das lustigste von der Herrn Schweitzer ihrem be- schriebenen Heimweh fürgekommen. Diese Leu- te werden kranck vor Verlangen. In der Kranckheit phantasiren sie beständig, und spre- chen immer von denen, welche sie verlassen müs- sen. Bißweilen stellen sie sich in der Ihrigen Platz, und bekümmern sich, wie ihre Hinter- lassene um ihrentwillen sich betrüben. Sie bilden sich ein, wie die Ihrigen öffters zu ihnen, oder sie zu jenen kämen. Und dieses setzt sich so fest in die Einbildungs-Krafft, daß wenn ein solcher auch wieder gesund wird, läßt er sich dennoch nicht mehr davon abtreiben, daß er nicht zu Hause, oder die Seinen bey ihm hie ge- Wesen seyen. §. 3.

# Überlegungen zu Servien

es könte sich dergleichen etwas auch in Servien begeben?

# Reflexionen über den Sommer

Im vergangenen Sommer wurde ich zu

# Fragen der Gedanken

Wie? wenn einer gedächte,# Die unbändige und ungehaltene Einwohner

Die unbändige und ungehaltene Einwohner dorten könten aus Verlangen, Verdruß, Liebe, Zorn, Rachgierigkeit, Unversöhnlichkeit, und dergleichen Affecten kranck werden? in der Kranckheit könten sie sich einbilden, die ge- liebten, oder die beleidigten Personen kämen zu ihnen, und embrassirten sie, es seye, aus welchem Affect es wolle? Das sagen die Patienten aus; der aberglaubische und schon præoccu- pirte Pöbel glaubet es Himmel-feste; die An- verwandten fürchten sich, und erkrancken auch; die Nachbarn erschrecken, und vor Schrecken stirbt einer nach dem andern dahin. Wer denn so von einem vermeynten Vampyr gestor- ben ist, wird auch ein Vampyr, dadurch sich das Ubel in kurtzer Zeit fast ins unendliche auß- breiten kan. Wie leicht können schlaue Köpfe, deren es auch unter der Bauerschafft nicht we- nige gibt, solcher persuasion, die einmal unter einem Volck herrschet, zu allerhand bösen Ab- sichten mißbrauchen! Es kan leicht Hanß ein Körbgen von der Gretha empfangen haben, so kan er sich nach Art des dortigen rachgierigen Volcks fürnehmen, solche verschmähte Liebe aufs empfindlichste zu rächen!

# Ein Volck auf Erden

Es ist ein Volck auf Erden,
Hoffärtig von Geberden,
Heimtückisch von Gemüthe,
Rachgierig von Geblüte,
Beschoren wie die Affen,
Gekleidet wie die Pfaffen,
Beschlagen wie die Pferd,
Ist keiner drey Heller werth!

Welche Verslein ich von einem vertriebenen Ungarischen wackern Theologo über seine Lands-Leute in meiner Jugend gelernet habe. Wie leicht kan ein solcher drohen, er wolle von einem durch einen Vampyr außgesogenen Schaaf essen, er wolle auch ein Vampyr wer- den, er achte nicht, wenn er nächstens sterbe, er wolle sich aber revengiren, sie solle nach sei- nem Tod ihren Eigensinn, Hochmuth, Untreu c.ꝛ theuer genug bezahlen müssen! Es ist möglich, daß ein solcher aus anderer Ursachen willen zeitlich stirbt, wie der Heyducke Parle von einem Heu-Wagen herab gefallen ist.

# Die Folgen des Aberglaubens

Das Weibs- bild fangt sich an Gedancken zu machen, aus Gedancken werden Grillen, aus Grillen der verstorbene arme Courtisan, der macht eine schreckhaffte Einbildung; der Schrecke bringt den Tod; der Tod zieht die geängstigte Eltern, Geschwister; Diese die Nachbarn, und solche das gantze Dorf nach sich! das seynd mögliche Dinge; und wer weiß, wenn einer in Servien käme, ob er sie nicht als würckliche Sachen anträfe! Denn ich weiß nicht, traumt es mir, oder habe ichs wahrhafftig irgendwo ge- lesen, daß die Leute selbiger Revieren von alten Zeiten her glauben, wenn einer un- versöhnlich sterbe, oder es verspreche einer ei- nem Mägden die Ehe, führe sie aber an, und sterbe drüber, so komme er nach seinem Tod, besuche seinen alten Schatz, und sauge ihr das Blut aus, worauf sie in etlichen Tagen sterben müsse. Wenn es diesem so ist, so kan man# Einleitung in die Thematik der Krankheiten und Einbildung

leicht rechnen, wie manche Fälle entstehen kön-
nen, die einem sich übel bewusten zum Schre-
cken gereichen müssen. Schrecken aber ver-
ursachet nicht nur Kranckheiten und Sterben,
sondern auch Seuchen und Pest. Erst jüng-
stens hat davon historice & philosophice ge-
handelt der accurate Medicus, Herr D. Georg
Dethardinus zu Rostock in Scrutinio Medico
de morbis a spectrorum apparitione (vel ve-
ra vel imaginaria) oriundis An. 1729. &
D. Lentilius in Misc. Med. Pr. P. I. p. 130.
febris malignæ ex mera imaginatione prælu-
dia.                                                §. 4.

# Die Rolle der Einbildung in der Krankheitsbehandlung

noch nicht, wo die-
ser Discurs hinaus will? So will ich dir also-
bald mit näherer Nachricht aufwarten. Ist
die Ursache der Kranckheit eine Einbildung;
besteht die gantze Kranckheit selbs in einer Ein-
bildung: so gibts Vernunfft, Kunst und Er-
fahrung, daß sie auch mit Einbildung muß cu-
rirt werden. Jener, der sich Frösche im Lei-
be zu haben einbildete, wurde curirt, da man Frö-
sche in seine excrementa practicirte, als wären
sie von ihm ausgegangen. Der sich einbildete,
keinen Kopf zu haben, wurde ein bleyerner Hut
aufgesetzt, den er wol fühlte, und nun glaubte,
daß er seinen Kopf drücke. Der nicht sitzen wol-
te, weil er sein gläsern Gesäß zu zerbrechen
fürchtete, wurde mit Gewalt hingesetzt auf ei-
ne Banck, darauf ein Glaß lag, welches er
zerbrach, und damit gesund wurde. Einer
hielte sich für gestorben, und wolte nichts mehr
essen und trincken; man legte Leute neben ihn,
die sich stelleten, als wären sie todt; man wi-
ckelte sie in Leilache ein, man ließ sie aber essen
und trincken, daß der Patient sahe, wie die Ver-
storbene dennoch essen und trincken, das that er
nach, und wurde curirt; und dergleichen fast
unzehliche Exempel, vid. D. Salzmanni Diss.
de Phantasiæ actionibus §. 21.

# Die Bedeutung der moralischen Therapie

Die Herrn
Naturæ Curiosi haben in ihren Ephemerid.
zerschiedene andere Exempel, welche mit meh-
reren, und was sonst von dieser Materie ge-
sagt werden kan, der fleißige und Christliche
Herr D. Alberti zusammen getragen hat in sei-
nen 2. Diss. de Valetudinariis, Imaginariis,
& de Therapia imaginaria, wo er auch eine
Therapiam moralem fürschlägt in einer eige-
nen Diss. für diejenigen Imaginaires, deren viel
sind, die sich immer einbilden, es seye ihnen
nicht wol; und indem sie sich dergleichen ein-
bilden, und immer daran gedencken, verderben
sie sich erst, oder noch mehrers, und werden zu-
letzt fast gar unbrauchbar.

# Aberglaube und medizinische Intervention

Wie wäre es nun,
wenn wir sagten, was wider die Vampyrs für-
genommen werde in Servien, seye eine kluge
Invention eines geschickten Medici? wer weiß,
ob man sich nicht nach dem Aberglauben der ein-
fältigen Leute accommodirt, die angegebene
Aussauger ausgräbt, und ihnen die Schaufel
durch die Brust stößt, um durch diese Impres-
sion den Leuten die Furcht zu benehmen, und
sie also von ihrer Kranckheit zu befreyen.
5.                  Das leuchtet mir wol ein, sprichst du; nur

# Unvollständige Gedanken

Sprichst du: ich sehe# Unverweste Leiber und das Terrain

möchte ich vollends wissen, wie es zugienge, daß die Leiber solcher angegebenen Personen so viel Wochen lang können unverwesen geblieben seyn, daß man eine solche Execution an ihnen vornehmen kan? Hierauf könte man sagen, es bringe vieleicht dieses die Art des dortigen Terrains mit sich, daß die Cörper sich lange ohne Verwesung halten können. Gleichwie die sogenannte terra Neapolitana die Eigenschafft hat, daß sie die Feuchtigkeit aus denen Cörpern an sich ziehet, und sie desto mehr vor der putredine verwahret. Also dörffte auch dorten ein Erdreich an manchen Orten von dieser Art seyn. Wenigstens hat der gelehrte Engelländer Rob. Boyle in seiner Diss. de admirandis Hungariæ aquis viel wunderbare Dinge angemercket, z. E. daß das Wasser theils Orten das Holtz so hart mache, daß man mit keinem Eisen ihm etwas abgewinnen könne: Findet sich aber das beym Wasser, so dörffen wir wol auch dergleichen von der Erden vermuthen. Und was vermuthen? Wir wissen ja so viel, daß wenn die Hungarische Bauren zu Kriegs-Zeiten öffters fliehen, und ihre Speisen in die Erde vergra-
ben, sie solche nach langer Zeit frisch und wol conditionirt noch antreffen. Und auf diese Weise könte diese prodigios und fürchterlich scheinende Sache eine raisonable Erklärung bekommen, ohne daß man einen andern Schlüssel suchen dörffte.

# Die Macht der Phantasie

Gleichwie es Leute gibt, die solche Dinge erdichten dörffen: also zweifle nicht, es wer-
den auch Leute seyn, die solches begierig ergreif-
fen werden. Sie wollen alles in die efficaciam phantasiæ resolviren. Und gewiß, wie ge-
schäfftig und mächtig die Phantasie zu allerhand ungeheuren Mißgeburten seye, können sie kei-
nen bessern Beweißthum als eben sich selbsten in diesem Gespenst anziehen. Sie bilden sich in dieser Sache eine Menge Dinge ein, und beweisen keine einige. Es ist dieses res facti; sie bringen aber nicht nur kein documentum historicum auf, sondern bilden sich Begebenheiten ein, welche der historischen Relation schnur gerad entgegen seyn: Es folgt ja nicht: vieleicht kan dieses so seyn, Ergo ists würcklich also. Die corrupte Phantasie hat schon solche und solche Kranckheiten gebohren: Ergo liegen diese Leute in Servien alle an der Phan-
tasie kranck. Wo findet man in der histori-
schen Relation, daß alle an einer acuten Kranck-
heit in gar kurtzer Zeit sterben? Findet man nicht auch solche darunter, die etliche Wochen und Monathen an verzehrenden Kranckheiten algemach gestorben sind? Wo ist doch die allergeringste Spur in der Specie Facti von denen erdichteten Liebes-Händeln, die den An-
fang sollen gemacht haben? Stehet nicht aus-
trücklich num. 2. daß ein sechzigjähriges Weib Miliza den Anfang zu dermaligen Vampyren gegeben, nicht, da sie einem Buhler ungetreu geworden, sondern da sie von einem Vampyri-
schen Schaaf gegessen habe? Es sterben auch Kinder von 8. Tagen an dieser Vampyrischen# Kranckheit und Phantasie

## Einleitung zur Phantasie der Kinder
Kranckheit num. 3. Seynd diese kleine Kinder auch schon so grosse Phantasten? Und wer hat wol diesen klugen Einfall gehabt, Einbildung durch Einbildung zu curiren?

## Die Rolle der Administration
Die Beschreibung des Kayserlichen Provisoris, seine Tergiversation es denen andringenden Bauren zu erlauben, seine unterthänigste Anfrage bey Löb-licher Administration, dieser hohen Administration selber mancherley Anstalten, zeigen handgreiflich an, daß Sie um dieses geheime Kunst-Stücklein nichts wissen müssen.

## Gräber und unverwesene Körper
Gesetzt aber, man wolte eine solche Spiegelfechterische Cur fürnehmen, würde es sich gerad zu-tragen, daß man an lauter Gräber geriethe, darinnen unverwesene Cörper liegen, wie hie, bis auf ein paar, arrivirt ist?

## Die Frage der Verwesung
Mit welchem Schein will man nur probable machen, daß die Erde zu Medvegya sonsten alle Cörper verzehre, nur jetzund nicht? daß einerley Kirch-Hofs-Erde die eine Cörper verwesen lasse, andere nicht, und zwar die nächst an ihnen gelegen?

## Die Phantasie der Vampyre
num. 8. Ist es um nichts zu thun, als denen phantasirenden Vampyrs mit Destruction der Leiber ein Blendwerck für zu machen: Was bedarfs dieser mühlichen Secirungen?

## Das Geheimnis des Blutes
und warum schweigt man doch von dem häuffigen flüs-sigen und balsamischen Blut in denen ausge-grabenen Cörpern so stille? Woher kommts, daß eine im gantzen Leben magere und ausge-dorrete Person hernach im Grabe so fett, voll-blütig und vollkommen wird?

## Die Frage der Haut im Grab
num. 2. Bringts die Erde auch mit sich, daß die alte Haut im Grab abgehet, und eine frische und lebhaffte dagegen wächset?

## Über die Grenzen der Phantasie
c.ꝛ §. 7. Diese Sache ist über den Schertz, den ich sonst wol auch verstehe. Soll man die Gräntzen der Phantasie so weit extendiren?

## Die Kritik an der Vorstellungskraft
Soll man vi-res imaginationis supra Naturæ Æquatorem erheben, nur damit man auch bey denen entsetz-lichsten Zufällen alle causas-præter-trans- & supra-naturales gäntzlich ausschliessen möge?

## Klagen der Medici
Bescheidene Medici klagen selbsten über solche Ausschweifungen.

## Der Einfluss des Aberglaubens
Ja wol, indem man unter dem verhaßten Nahmen des Aberglaubens keine Ehrerbietung vor die Heil. Schrifft und derselben Lehren haben will, verfält man in die gröste Bigotterie, und macht lieber bald die Natur, bald die Phantasie zu einem Idolo, als daß man auf den wahren GOtt aufsehen mag!

## Erstaunen über den Naturalismus
Ist es aber nicht mit Erstaunen zu betrachten (sind Worte eines Christlichen Medici) daß bey der Sonnen-hellen Klarheit und Felsen-festen Warheit des geoffenbahrten göttl. Worts so viele Christen, Theologi, Politici und Medi-ci, durch die Beckerische und andere Schwarm-Grillen also verblendet worden, daß sie durch einen adæmonistischen Naturalismum entwe-# Die Macht der Gnade

der die Geister und Teufel gäntzlich leugnen, oder doch Satans Klauen also verbergen, und abgeschnitten fürstellen, daß sie wenig, oder gar keine Macht wider den klaren Inhalt göttlichen Worts mehr bey den Menschen übrig behalten! c. Diese epidemische Seelen-Seucheꝛ wird durch kein Einbildungs-Mittel gehoben. Natur reicht nicht zu. Gnade muß den ganzen Grund des innerlichen Menschens umkehren und ausheilen, vid. D. A. Rechenb. Disp. Pract. de efficacia gratiæ quoad imaginationis in mentem corpusque imperium. Das schöne Wort Socratis in der Natur wird noch schöner, wenn es auf die Gnade und übernatürliche Wirckung des Heil. Geistes in der Seelen gezogen wird, da er sagte: Oculus sine toto capite, caput sine toto corpore, corpus sine tota anima sanari non potest, apud Maxim. Disp. 18. Ja wol ist das Flicken kein nü-tze! Soll dem Menschen von seinen geistlichen Kranckheiten, sonderlich der πολλῆς φαντασίας innerlich und äusserlich geholffen werden, so muß die gantze Seele wiedergebohren werden!

# Der Weg der Religion

Da man sich vor dem præcipitio des vorigen Wegs billig zu scheuen hat, so seynd einige auf die Gedancken gerathen, ob man nicht einen ebenern und richtigern Weg in dem Statu Religionis selbigen Volcks finden könne. Man möchte doch nicht nur wissen, woher dieses Ubel komme; sondern auch warum es sich in dortigen und den benachbarten Gegenden allein, oder mehrers finde, als in andern? Und da dünckete es einen oder den andern unter uns, man könne die erste Spur und gleichsam den Saamen dieser wunderbaren Begebenheit am besten in der dortigen Religion aufsuchen. Wir supponiren, daß diese Leute der Griechischen Kirche anhangen. In dieser finden wir aber, welches zu diesem phænomeno, und dessen modification, leichtlich einen Anlaß hat geben können.

# Die Exkommunikation und ihre Folgen

Ich deute auf die Art ihrer Excommunication. Wenn diese Kirche jemand in den Bann thut, so fliessen nebst anderm auch diese Flüche in die Formul ein: Dein Theil seye mit dem Teufel, und mit dem Verräther Juda! ja nach deinem Tod solt du in E- wigkeit nicht zu Aschen werden, sondern wie Stein und Eisen unverweßlich liegen. Und da glaubt man beständig, wenn ein solcher verbannter Mensch vor seinem Ende nicht wieder die Absolution erhalte, er keineswegs verfaulen könne, sondern wie eine Drommel aufschwelle, und als Stahl und Eisen unverweßlich bleibe, bis ihn der Bischoff von dem Bann loß zehle, da denn der Cörper auf einmal zu Aschen werde. Eines der ansehnlichsten solcher Exempeln ist wol dieses, so sich unter Mahomet II. der Constantinopel eingenommen, zugetragen hat. Dieser Kayser hatte gehöret, daß die, welche in dem Bann gestorben, nicht verwesen könten, und ließ sich die Curiosität ankommen, hievon eine Probe zu nehmen. Daher befahl er dem Patriarchen, daß er einen solchen Cörper aufsuchen, und wie# Die Geschichte der Priesterwitwe

gewöhnlich, absolviren solte. Die Clerisey erinnerte sich auch, daß vor vielen Jahren der Patriarch Gennadius eine Priesters Witwe in den Bann gethan, die auch darinnen ohne Absolution gestorben wäre. Als man nun dieses Grab öffnete, fand man einen greulichen Anblick, nemlich einen Cörper, der wie eine Trommel aufgeschwollen, und so hart als Stahl und Eisen war. Denselben legte man in einen Sarg, welcher zur Verhütung alles Betrugs mit dem Kayserlichen Siegel verwahret wurde, und trug ihn in die Kirche. Daselbst hielte der Patriarch das Amt, zehlte die verstorbene Frau von dem Bann loß, und verlaß das hierüber ausgefertigte Diploma. So bald dieses geschahe, hörte man ein gewaltiges Geprassel in dem Sarge, und als man denselben eröfnete, fand man nichts anders, als wenige Knochen, welche unter der Asche zerstreuet lagen. Siehe D. Joh. Mich. Heineccii Abbild. der Griechischen Kirche P. III. p. 419.

# Ein weiteres Beispiel der Absolution

alwo er sich auf mehrere Exempel in seiner Disput. de Absolutione mortuor. tympaniticor. in Eccles. Gr. berufft. Ein neues Exempel erzehlet Maudrell, Prediger der Engelländischen Compagnie zu Aleppo in seiner Reiß-Beschreibung des Heil Landes 1696. p. 204. Ein Griechischer Prediger versicherte mich bey Priesterlichem Glauben (er war aber ein aufrichtiger und verständiger Mann) es seye etwa vor 15 Jahren ein gewisser Griech gestorben ohne vorher empfangene Absolution, welcher ein Laster, so der Excommunication würdig gewesen, obwol die Kirche nichts darum gewußt, begangen hatte. Er wurde begraben als ein Christ. Zehen Jahr aber hernach stirbt einer seiner Söhne. Man macht ihm ein Grab nahe an des Vaters seinem. Hie nun fand man seinen Leib noch gantz, als wie er bey dem Begraben war, das Leich-Tuch vermodert, der Leichnam gantz nacket und schwarz, ohne die geringste Anzeige einer Verwesung. Als es der Bischoff erfahren, zweifelte er Anfangs selbs an der Ursache einer so ungemeinen Begebenheit; schickte etliche Priester, unter welchen auch dieser Referens war, hin, um GOtt für die Sünde des Abgeleibten zu bitten, und ihme die Absolution im Grab zu geben. Dieses war so bald nicht geschehen, so zerfiel der Leib in Staub.

# Die Kraft der Exkommunikation

ꝛc. Ich weiß noch, wie dieses der Griechische Prälat, welcher vor einigen Jahren hiesige Lande passiret, mit grosser Parrhesie bestätiget, und solches nicht allein für ein besonders Wunder, sondern absonderlich auch für eine augenscheinliche Bekräfftigung der Bischöfflichen Gewalt bey ihnen angegeben hat. Ich weiß aber auch noch gantz eigentlich, wie wir damalige muntere Studiosi ihm entgegen gehalten, nach diesen Kennzeichen seye der Vorzug zwischen der Griechischen und Römischen Kirche immer noch sehr zweiffelhafft. Denn habe der Griechischen Kirche Bann so eine Krafft auf die menschliche Cörper, auch bis nach ihrem Tod, zu wircken: so habe hingegen der Römischen Kirche Excommunication solche Krafft, die auch bis auf die unvernünfftige Thiere dringe, und sie auf der Stelle angreiffe. Als er hierüber stutzte, zeigten wir ihm des Eisenachischen Medici, D. Christ. Franc. Paulini, curieuse Dissertation de Corvo excommunicatio.

# Die Geschichte des Abts und des Raben

Der Abbt Cunradus des Closters Corbey, gegen das Ende des XII. Seculi, legt, da er die Hände waschen wolte, seinen Ring von sich an das Fenster. Der Rab, welchen der Abbt zu seiner Lust in der Stuben hielte, sahe den Ring gläntzen und nimmt ihn hinweg, daß es niemand merckte. Der Abbt misset seinen pretiosen Ring, den ihm Kayser Cunradus zur Bestätigung vieler Privilegien verehret hatte. Man sucht ihn in allen Winckeln, kan ihn aber nirgend finden. Die Bedienten werden examinirt, einige kommen in Verdacht; keiner will nichts gestehen. Endlich gibt einer den Rath, man solle den unbekanten Dieb in Bann thun. Es geschicht unverzüglich. Aber von Stund an versteckt sich der Rabe, wird traurig, da er sonsten so lustig war, bleibt in seinem Nest sitzen, frißt nichts, nimmt ab, und wird sehr schwächlich. Endlich fällt's einem Bedienten ein, der sagt: Was gilts, der schwartze Schelm hat den Ring gestohlen, und liegt deßwegen unter dem Bann. Man visitirt sein Nest, und findet darinnen den gesuchten Ring. Der Abbt hebt den Bann auf, der Rabe frißt wieder, wird munter und fröhlich. Diese Geschicht hat gedachter Paulini nicht nur mit häuffigen Zeugnissen belegt, sondern sie auch in die Ephemer. Nat. Cur. gegeben, in Dec. II. ad Ann. V. in Append. p. 78. sqq.

# Vampyre und Exkommunikation

§. 9.                   Aber wieder zu unsern Vampyrs umzukehren, so zwar zwischen ihnen und denen Griechischen Excommunicatis tanquam tympaniticis ein grosser Unterscheid. Gleichwol kommen sie in aliquo tertio der Fürdaurung nach dem Tod mit einander überein. Wo nun in einer Kirche öffentlich gelehret und geglaubet wird, daß die von Christo verliehene Gewalt zu binden auf Erden, auch auf den# Leib und Seele

Leib und zwar bis unter die Erde sich erstrecke, daß nicht nur die Seelen dem Teufel übergeben, sondern auch der Leib um gewisser Sünden willen, also gebunden werde, daß er nicht verwesen könne ewiglich, und daß diese Nicht-Verwesung ein gewisses Kennzeichen eines lasterhafften verbannten Menschen seye: wie leicht hat dieses algemachAnlaß und Gelegenheit zu allerley Meinungen von den fatis der Leiber nach dem Tod, zu aberglaubischen und fürchterlichen Einbildungen der Einfältigen, oder andern uns hie zu Landen unbekanten Mißbräuchen unter einem ohne hin ziemlich ruden Volck geben können!

# Der Teufel und die Griechische Kirche

Welcher Gemüths-Disposition der Leute sich freylich hernach der Teufel als einer bequemen Gelegenheit bedienet hat, eine würckliche und wahrhafftige Comœdie zu spielen, deren Invention aus etwas der Griechischen Kirche genommen, aber mit seinen Zusätzen, Veränderungen und Verkleidungen ist aufgeführet worden. Fast auf die Weise, wie die Gelehrten insgemein dafür halten und beweisen, daß er es mit den Geschichten der Schrifft selbs unter den Heyden gemacht, woraus er sie gestohlen, und hernach in seine façon eingekleidet hat.

# Die Rolle des Teufels

Ja ich wolte eben den gar nicht auslachen, der sich den Teufel auch hie, wie sonst unzehlich offt, als einen Affen Gottes fürstellet. Rühmete nun die Griechische Kirche die Gegenwart und kräfftige Beweisung JEsu Christi so sehr an denen unverwesend bleibenden excommunicirten Cörpern: so hat dieser Affter-König und Fürst der Finsterniß nicht geringer seyn, wol aber es Christo noch bevor thun wollen, indem er sein Reich und Gewalt auch unter denen Todten auf eine so ausser-ordentliche und erstaunliche Weise zu exerciren suchte.

# Der verkappte Teufel

Indem wir aber algemach darauf gekommen sind, unter diesem Trauer-Spiel den verkapten Teufel zu suchen, und aber nur die erste Anregung davon der heutigen Welt so verächtlich und widrig ist: so müssen wir uns hierüber ein wenig deutlicher erklären. Man siehet verhoffentlich aus dieser meiner bißherigen gantzen Aufführung, daß ich keiner von denen seye, die sub quocunque lapide scorpium, und unter einem jeden phænomeno den Teufel mit ihren clair voianten Augen erblicken.

# Die Gesellschaft der Skeptiker

Aber ich mag auch kein Mitglied der grossen Gesellschafft seyn, in deren Statutis die erste Regel ist, keinen Geist und Teufel zu glauben. Beede Theile gefallen mir so wenig, als die zwey andere Secten unter uns, deren die eine gar keinen Pabst sehen wollen, ob er schon hie und da in Lebens-Grösse sich præsentirt, die andere hingegen, wie Thomasius und seine Jünger, sehen nichts als lauter Päbste.

# Der Einfluss von Gelehrten

Es ist aber dem sonst wolverdienten Mann ergangen, wie jenem Menschen, dessen Lockius de Intell. Hum. gedencket, weiß nicht wo. Den hatte ein Medicus zwar curirt, aber durch ein scharffes und beschwerliches Mittel. So offt nun dieser hernach den Medicum sahe, so offt empfand er den Eckel seiner eingenommenen widerwärtigen Artzney und seines erlittenen Schmertzens.

# Die Wahrnehmung von Thomasius

Thomasius ist in seinen ersten Jahren zu unsanfft von einem oder anderm Theologo angerühret worden; Dieses setzte sich bey ihm so fest, daß so offt er in seinem gantzen Leben solche Leute sahe oder hörte, so sahe, hörte, fühlte, riechte er nichts, als lauter Päbste. Ich begehre ja kein Haaß zu seyn, der auf diesem todten Löwen herum springe. Der Mann hat mir nichts Leyds, und viel Guts erwiesen in meinem Leben.

# Die Gefahr der falschen Zuschreibung

Aber ich sehe es an so vielen Exempeln, wie auch grosse Gelehrten sich in eine gewisse Meynung verbilden, oder an derselben eckeln können, ohne daß sie dessen eine wahre Ursache hätten. Wenn ich aber glaube, daß bey dieser aus Servien beschriebenen Begebenheit der Teufel sein Werck mit habe: so muß ich mich vorderist in thesi legitimiren, und sagen, man habe grosse Ursache fürsichtig zu fahren, wenn man bey offenbaren Wirckungen die unbekante Ursache dem Satan zuschreiben will.

# Die Existenz des Teufels

Das kan leicht ein Asylum ignorantiæ & ignaviæ abgeben. Es kan die sonst unwidersprechliche Warheit von der Existenz und Operation des Teufels manchen muthwilligen Gemüthern exponirt werden, wenn heut aus natürlichen Ursachendemonstrirt wird, was man gestern noch allein dem Teufel zugeschrieben hat. Und was dergleichen Bedencklichkeiten mehr seyn mögen.

# Die Medici und ihre Schriften

Gleichwol glaube ich auch daneben, man könne bey vielen phænomenis nicht hinaus kommen, wie gelehrt, geschmeidig, subtil und spitzig man sich auch mache, wo man nicht einen Geist, und zwar den bösen Geist, und dessen concursum mit zu Hülffe nehme. Es seynd gerade zu dieser Zeit drey Medici berühmt, (ich weiß nicht, warum mir immer diese Herrn am meisten in die Feder kommen) an welchen einer seine sonderbare Lust sehen kan. Herr D. Alberti zu Hall schrieb eine Dissert. de Potestate diaboli in corpus humanum, 1725. sein Herr Collega D. Hoffmann schrieb auch eine de Potentia diaboli in corpus humanum, 1723. und Herr Doctor Dethardinus zu Rostock eine de Obessione spuria. Alle drey tractiren fast zu gleicher Zeit einerley argumentum; aber aus unterschiedlichen Gründen und Systematibus.# Einleitung in die Thematik

Cosmicus, und kan sich mit seinem Geist leicht und überal helffen. Bey Hn. D. Hofmanns hypothesibus mechanicis gehet es schwer, doch noch erleidentlich daher. Aber Herr D. Dethardinus unter dem Zwang nach der summa ἀκριβεία Methodi mathematicæ allenthalben,und auch in dieser Materie, zu procediren, und dem Teufel fast lauter ferias und müßige Zeit zu machen, macht er sich desto mehr Mühe und Arbeit, und, ohne Verletzung des Respects, einen Hauffen unnöthiger Bedencklichkeiten. Die Sache läßt sich hie nicht in ihrer Extension tractiren. Genug, den Zustand der Gelehrten, und ihrer zerschiedenen hypothesium berühret zu haben.

# Auswahl der Mitler

Aus diesen will ich, nur ad hominem, den Mitlern heraus wehlen, der nicht gar zu Pfäffisch, und nicht gar zu profan scheinet. Er gibt unter andern 2. Canones, I. Perspiciendum est, ne nimium, & ne nihil, tribuamus diabolo; videndum, quid valcat & non valeat, & an omni tempore & in omnibus subjectis id præstare possit, d. i. man muß wol darauf sehen, daß wir dem Teufel nicht zu viel, aber auch nicht gar nichts zuschreiben; man muß forschen, was er vermöge, und was er nicht vermöge, und ob er solches zu allen Zeiten, und bey allen Personen ausrichten könne?

# Übernatürliche Ursachen

2. Non esse sub examine morborum (& aliorum phænomenorum) ad causas supernaturales transiliendum, quamdiu causarum naturalium nexus ad phænomena explicanda sufficit, d. i. wenn man Kranckheiten und andere Begebenheiten untersuchen solle, so muß man nicht zu übernatürlichen Ursachen fliehen, so lange manzeigen kan, daß diese Wirckung aus natürlichen Ursachen entstehen könne. Beede Reglen seynd raisonables. Bescheidene Politici werden so wenig der ersten Regel ablegen, als vernünfftige Theologi sich Bedencken machen möchten, der zweyten zu unterschreiben.

# Erläuterung der Regeln

Aufs wenigste haben wir oben von dem bedächtlichen D. Spener angeführt, daß er eben dieses im Mund oder Sinn gehabt, da er sagte: Es bedörffe grosse Fürsichtigkeit, damit wir nicht einer andern Ursache zuschreiben, was die Natur vermocht habe. Dennoch, düncket mich, bedörffe diese zweyte Regel noch einige Erläuterung und Limitation. Man muß unterscheiden inter causam totalem & partialem, solitariam & sociam. So lang man nemlich etwas aus natürlichen Ursachen resolviren kan, solle man den Teufel nicht mit hinein ziehen als eine causam solitariam, als hätte ers allein gethan; wol aber etwa doch als eine causam partialem, als einen, der dazu geholffen, und zum effectu mitgewircket hat.

# Der Teufel in der Natur

Und weiß ich demnach gar nicht, warum man den Teufel endlich nur da noch zu suchen haben solle, wo Sachen vorgehen, die die gewöhnliche Ordnung und Kräfften der Natur übersteigen? da der Bößwicht viel öffter seine behende Kräfftenauch in die natürliche wirckende Ursachen mit hinein spielet. Wenn wir ausser der Schrifft solten die Einfälle der Araber und Chaldæer in die Güter Hiobs analysiren, so würden wir perfectissime alles aus natürlichen Ursachen her leiten können, und bliebe uns noch übrig. Dennoch zeuget die Schrifft, daß der Teufel darunter gesteckt seye.

# Moralische und physische Aspekte

Wie es in moralibus ist, daß der Teufel dem David ins Hertz gegeben, er solte das Volck zehlen lassen, welches ihm eben so gut auch natürlich Fleisch und Blut hätte eingeben können: so gehets ohne Zweifel auch in rebus mere physicis. Ich glaube, daß zu den Zeiten Christi bey den meisten Gebrechlichen, μογιλάλοις, Stummen, Tauben c. vitia naturalia in derselben Organis sich gefunden haben,ꝛ und daß also ihre beschwerliche Sprache, Taubheit c. aus natürlichen Ursachenꝛ hat können gezeiget werden: Dennoch steckte der Teufel dahinter, und bediente sich dieser natürlichen Indisposition der Menschen.

# Kooperation von Geist und Natur

Wie sich unsere Seele ministerio spirituum animalium in exequendis motibus coproris naturalibus gebrauchet, welche weder der Seele allein, noch dem Leib allein, sondern beeden als ein ἀποτέλεσμα können zugeschrieben werden: also kan sich dieser Geist auch mit den viribus rerum naturalium vereinigen, und entweder einen gewöhnlichen oder etwas ungewöhnlichen effectum produciren,der weder dem Teufel allein, noch z. E. dem Menschen allein, sondern beeden zugeschrieben werden muß, ob er auch gleich von dem Menschen allein hätte producirt werden können.

# Schlussfolgerung

Kurtz, es ist ja die Frage nie allein von der Operatione, sondern von der Cooperatione, συνεργεία und Mitwirckung des Teufels. Welcher Unterscheid in denen mancherley Consiliis der Medicorum über die oben angezogene Annenbergische Händel niemalen ist beobachtet worden. Das ists, was ich von einem meiner Herrn Præceptorum in folgendem Canone gelernet habe: Quodcunque principium analysin horum vel illorum phænomenorum physico-mathematicum non modo non turbat vel impedit, sed potius confirmat atque illustrat, imo expeditiorem & evolutiorem reddit, illud principium à bono Philosopho quà tali negligi aut fastidiri nicht debet. Atqui principium de συνεργεία alicujus spiritus vel boni vel mali analysin c. Ergo.# Einleitung zur Thematik der Teufelsdarstellung

Sic demum sua Scripturæ S. illibata constabit Virginitas. Qui autem contra hanc observationem supercilio suo philosophico indulget, ille vel profano affectu in historiam S. Scripturæ infectus est, vel insigni fastu ingenii laborat, quod ideas rerum grandes, & subtilitates vulgo haud obvias, nec facile extricabiles, impotentius affectat.                                            §. 11.

# Der Teufel und die Vampyre

Und damit ist der Weg von der Thesi zur hypothesi wircklich geöfnet. Wer die Schrifft respectirt, sie als eine Præsidem Philosophiæ verehret, und noch einen Teufel erkennet (denn mit keinen andern wollen wir zu thun haben) der wird keinen Anstand haben, den Teufel unter denen Vampyrs nicht nur zu vermuthen, sondern auch in seiner groben Gestalt gleichsam mit Händen zu greifen. Wenn hie der Teufel, der Fürst der Finsterniß, der in der Finsterniß dieser Welt zu agiren gewohnt und befugt ist, der Feind des menschlichen Geschlechts, der Würg- Engel, der umhergehende brüllende Löwe, der Mörder von Anfang, in dieser Mord- Gruben nichts zu thun hat, so weiß ich nicht, wo er mehr etwas zu thun haben sollte. Hiezu fehlt es ihme nicht am Willen, und nicht am Vermögen. Nicht am Willen, wie bekandt. Denn er ist ein überaus feuriger, hitziger, hungeriger, grimmiger und unruhiger Geist, der dürre Stätte durchwandelt, und wider sein inwendiges Zorn-Feuer Ruhe suchet, fürnehmlich aber Ruhe und Abkühlung in denen Leibern, nach welchen er eine unsägliche Begierde hat, Matth. XII, 43. Kan er keine lebendige Leiber haben, so sucht er die todten Cörper in den Gräbern. Darum hält er sich so gern indenen Gräbern auf, wie das bedenckliche Exempel Matth. VIII, 28. seq. uns anweiset, und welches weiters Nachsinnen verdienet. Ja wenn er keine menschliche Cörper haben kan, so hält ers doch noch für ein Wohl, wenn er nur Säu-Cörper erlangen, und in sie fahren kan: Hingegen schreyet er, als über seine grosse Quaal, wenn er ohne Leib herum fahren muß, Matth. VIII. 29. sqq. welches alles bedenckliche Wincke der H. Schrifft sind.

# Die Macht des Teufels über die Toten

Es fehlet ihm aber auch nicht am Vermögen. Denn daß er in lebendige Leiber fahren, und wunderbare Bewegungen, ungewöhnliche Wercke c. durch sie thun könne, istꝛ aus der Historie der Besessenen offenbar. Er kan aber auch todte Cörper ohne Zweifel eben so leicht bewegen und führen, als andere leblose Dinge, Holtz, Stein, u. d. g. Was hat er nicht für Gauckeley getrieben mit dem Leibe Samuels, I. Sam. 28. Wäre es auf Zulassung GOttes der wahre Leib Samuels gewesen, so wäre das ein pertinentes Exempel, wie er die Cörper der Menschen auch lange nach der Begräbniß noch so sehr mißbrauchen könne. Ists aber nicht der wahre Leib Samuels gewesen, so sehen wir doch, wie dieser Tausend-Künstler sich unter die Gestalt der menschlichen Leiber zu verkappen, und in solchen zu erscheinen pflege, die in denen ehmalslebenden gleich sehen. Und was meynen wir, was für eine Art Muthwillens er mit dem Leichnam Mosis müsse fürgehabt haben, daß der Ertz-Engel Michael dagegen so hat streiten müssen Jud. v 9. Es ist dieses aufs wenigst die Meynung unsers schon mehr belobten Hof- und Consistorial-Raths, Herrn D. Alberti, der austrücklich schreibet: Sicut diabolus potestatem habet in corpus hominis animatum: ita perinde perditissimam suam vim in corpus exanimatum æque ac in alias naturales & materiales substantias permissu Dei derivare, suaque glaucomata & fraudulenta artificia prodere potest, qualia multis speciminibus, fide auch dignis, Kormannus & Garmannus in suis Tract. de miraculis mortuorum, confirmant.

# Skeptizismus gegenüber dem Teufelsglauben

Quare illi in pertinaci scepticismo hærere nobis videntur, qui talia phænomena in cadaveribus hum. obvia, indiscriminatim nudis naturalibus processibus & contingentiis adsignant, & diaboli influxum atque concursum negant, cum hæc potestas diaboli in corpora in dubium vocari nequeat c. alwo er sich auf Tob. Andreæ pec. Tract. de malorum angelorumꝛ potentia in corpus beziehet, den ich aber nie gesehen habe, in spec. Theol. Med. p. 466. conf. p. 550. Und hie muß ich nur aufrichtig gestehen, daß ich diezwey Tractät de Mirac. mort. welche am meisten hieher gehören, auch nie gelesen habe, doch soviel von Kornmanno weiß, daß er viel Fabelhafftes eingemenget. Im übrigen ist die quæstio præjudicialis, ob und wie ein Geist überhaupt in einem Leib wircken könne, von mir hie überal zum voraus gesetzet worden.

# Lokale Überlieferungen und historische Bezüge

§. 12.                   Nur will ich noch erwehnen, wie die Leute dortiger Gegenden selber diese Avanture einem solchen principio zuzuschreiben scheinen. Denn bey der 1ten Nachricht A. 1725. sagten sie aus, daß ihr Dorf schon einmal vor diesem durch solchen übeln Geist zu Grund gegangen seye. Worinnen wir noch mehr können bestärcket werden, wenn wir abermal die Griechische Historie für uns nehmen, darinnen wir folgendes finden: Von einigen dergleichen excommunicirten Cörpern, davon wir oben geredet, welche sie Brucolaccas nennen, geben sie für, daß sie von dem Teufel eingenommen und gleichsam belebet würden, und daher den Menschen.# Nachtgeister und ihre Auswirkungen

viel Schaden zufügten. Denn sie giengen öffters in der Nacht auf den Strassen herum, klopften an die Thüren, und rufften einen von den Hauß-Genossen mit Nahmen. Wenn nun derselbe antworte, so müsse er des andern Tags sterben. Daher ist in der Insul Scio die Gewohnheit, daß die Leute, wenn man sie des Nachts ruffet, das erste mahl nicht antworten, aus Beysorge, daß es vielleicht ein solches Gespenst seye. Bißweilen sollen dergleichen Cörper am hellen Mittag in den Weinbergen und andern einsamen örtern herum gehen, und die Leute tödten. Wenn man nun an einem Ort von plötzlichen Todes-Fällen höret, so schreibt man es alsbald diesen excommunicirten Cörpern zu. Darum graben die Bauren dieselben aus, lassen sie von dem Priester absolviren, und werffen sie ins Feuer, Leo Allat. ad Paul. Zachiam §. 12. Ricant Ottomann. Pforte p. 60.

# Die Parallelen zu Vampiren

Wer siehet aber hieraus nicht, daß die unter den Griechen excommunicirte und nach dem Tod herumwandlende und tödtende Cörper eine fast völlige ähnlichkeit mit denen Vampyrs in Servien haben, und auf gleiche Weise mit Ausgraben und Verbrennen tractirt werden? Wer siehet nicht hieraus, was die Lehre von einer solchen Excommunication für wunderliche Folgen unter den einfältigen Leuten nach sich ziehe? Wie die Absolution (und vielleicht auch die Excommunication) diesem nach nicht mehr ein Werck nur des Patriarchen, sondern einesjeden Priesters geworden? Was da für geistliche Boßheiten können gespielet werden?

# Aberglaube und Furcht

Wie die Leute voll Furcht, Argwohns und Einbildung seyen, sie müsten sterben? Wie sie jeden schnellen Todes-Fall einem solchen Cörper zuschreiben? Wie sich insonderheit die Bauren mit diesen Gespenstern tragen? Wie sich solche Cörper nicht an öffentlichen und Volckreichen Plätzen, oder in Städten und fürnehmen Häusern, sondern in Weinbergen und einsamen örtern sehen lassen? und wie ohne Zweifel viel unrichtiges und phantastisches Wesen sich mit einmenge? u. d. m.

# Der Einfluss des Teufels

Nicht als wolte ich damit wieder aufbauen, was ich oben abgebrochen; nicht als wolte ich die gantze Sache zuletzt in ein Gauckel-Spiel der Imagination verwandlen, oder die dort herrschende Superstition zu einer alleinigen und vollkommenen Mutter aller dieser angegebenen phænomenorum machen, in præjudicium veritatis historicæ: Sondern nach meinem propos zu erweisen, wie der Teufel bey so gestalten Sachen ein gewonnen Spiel habe, seinen Rendesvous an solchen Orten zu nehmen, wo wenig Wort GOttes, wenig Erkäntniß, wahren Glaubens, rechten Gebets; und hingegen desto mehr Aberglauben ist.

# Historische Perspektiven

Das wissen wir schon aus der Historie aller Zeiten, je mehr Unwissenheit und Aberglauben, je mehr teuflischen Rumorens; je mehr aber jene vertrieben werden, je weniger kan sich dieser mainteniren. Man sehe nur die Zeiten vor und nach der Reformation, Catholische und Protestirende Länder an. Nicht als wenn man hernach zufahren und sagen dörffte: O! es ist also der Teufel nirgend, als im Glase, oder in dem Hirn præoccupirter Leute, u. d. g. sondern weilen der Teufel nach dem Zeugniß der Schrifft in der Finsterniß, leiblicher und geistlicher Weise, herrschet, und also beym Licht sein Werck und Reich nicht haben kan.

# Quacksalber und Aberglaube

Wenn ein Quack-Salber und Marckt-Schreyer sein Theatrum wo aufrichtet, so lauft ihme eben der unwissende Pöbel mit Hauffen zu, und vergaffet sich an seinen Großsprechereyen, Bullen und Attestatis, wenn diese verlaufen sind, ist unter den besser Berichteten seines Bleibens nimmer lang. Und je mehr man dem Satan auf seine Künste und geschwinde Gaucklers-Hände sehen kan, je bälder hat sein Taschen-Spielen ein Ende.

# Der Wunsch nach mehr Wissen

Ohne Zweifel wenn jemand aus unsern Landen in selbige Gegenden käme, und nach denen Gesetzen der Historie, Philosophie und Theologie nach allen Dingen forschen könte, wir solten bald sehen, wie Zihim und Ohim hie einander begegneten, ich will sagen, wie arme, blinde, unwissende, irrende, aberglaubische und gottlose Menschen, und böse, feindselige und arglistige Geister untereinander liefen, Esa. XIII. 21. Und eben dieses leitet uns noch auf das, was gemeiniglich das Letzte war in unsern Discursen.

# Der Wunsch nach einer tiefergehenden Untersuchung

Nemlich wir wünschten eine ausführlichere und profundere Nachricht zu bekommen, als wir dermalen haben. Auch so gar das Wort Vampyr ist uns nicht bekant, was es für ein Wort seye, was es bedeute, woher es komme. Mehr aber wäre uns an einer Historie dieses phænomeni gelegen. Denn es hat sich solches nicht erst seit gestern erhoben, sondern vor etlich 100. Jahren sich schon je und je geäussert beedes unter Christen, und unter Türcken. Und deßwegen könte man von dem ersten Anfang, Hergang, Aufhören und wieder Anfangen, längerer oder kürtzerer Dauer und Erstreckung, Veranlassungen, Begebenheiten, Mitteln, und dergleichen Dingen dieses Mali schon ziemlich vollständige Acta und Documenta haben; sonderlich da man sich in dem unterth. Bericht auf ihren sogenanten Hadnack (welches man hie auch nicht verstehet) beziehet, der schon vorhin bey dergleichen Begebenheiten.# Historische Berichte über Kisolova

gewesen seyn solle. Und da nach dem Bericht Anno 1725. das Dorf Kisolova noch
ehmals unter Türckischer Bottmäßigkeit von diesem Ubel zu Grundgerichtet, und
nun vor 7. Jahren wieder damit befallen worden, so wäre zu untersuchen, ob bey
dem Ort oder dessen Einwohnern nicht etwa besondere Beschaffenheiten physice
& moraliter könten entdecket werden, die als Spuren uns weiter leiten
könten. Auch so gar eine Historia Natur. von Ungarn und Servien, wie der oben
belobte Autor von Polen, und andere von andern Ländern gestellet haben, käme uns
wol zu statten. Es gehet aber mit Ungarn und denen benachbarten örtern besonders
schwer her in diesem Stück. Ein gewisser Observator in denen Ephemer. Nat. Cur.
schreibet davon, es seye zu beklagen, daß der gröste Theil von Ungarn, welches
doch so ein fruchtbares und mit allerhand natürlichen Schätzen erfültes Land
seye, theils unter eigener, theils unter Türckischer Barbarey liege, und nach
seinen Merckwürdigkeiten nicht mit gnugsamer Sicherheit könne erforschet werden.

# Schwierigkeiten bei der Erforschung

Denn wenn die Einwohner curiose und der natürlichen Dingen begierige
Nachforscher antreffen, so begegnen sie denselben feindselig, und tractiren sie
für Spionen. Dazu komme, daß die Deutschen die Ungarische Lufft so gar nicht
ertragen können, und nach dem Sprichwort insgemein ihren Kirch-Hof dorten
finden, welches mit etlichen Exempeln gelehrter Männer beleget,und dabey
erzehlet wird, wie eine und andere gesammlete Hungarische Histor. Nat. seye
unterbrochen, oder sonst, weiß nicht mit welcher Fatalität, wieder zerstreuet
worden, welches ich niemand zu nahe aus gedachten privilegirten Ephemer. bona
fide will nachgeschrieben haben, Decad. I. ad Ann. II. p. 56. Wenn demnach durch
unsere jetzt viel dahin gehende Deutschen, sonderlich durch hohe Anstalten der
Grossen in der Welt diesem Mangel kan abgeholffen werden, wird es deroselben
gloire so viel erhöhen, als es den Nutzen des Publici vermehren wird.

# Der Beitrag von Graf von Marsigli

Doch davon hat vieles schon præstirt der gelehrte und berühmte Herr Graf von Marsigli in
seinem magnifiquen Werck von der Beschreibung der Donau c. Und wie viel auf dieꝛ
Beschaffenheit der Lufft, Erde und des Wassers ankomme, kan man aus des
gelehrten und gottseligen Ritters Rob. Boyle Diss. de admirandis Hungariæ aquis
schliessen.

# Geistlicher und leiblicher Zustand der Inwohner

Ferner hat man bessere Information zu wünschen von dem leiblichen und geistlichen Zustand der
Inwohner selbst. Und zwar von ihrem geistlichen Zustand, wie die Religion dorten
beschaffen, ob sie Griechisch, Mahomedanisch, Catholisch oder vermengt seye? Was
die Priester vor Leut seyen, ob sie auch eine Literatur und Philosophie, und
was für eine, haben? Ob sie auch eine gute Theologische Erkäntniß besitzen? Ob sie
ihre Leute in der Erkäntniß GOttes und seines Reichs auch gründlich
unterrichten? Ob sie auch geistliche Mittel hiebey anwenden? Oder ob sie die
Leute in Unwissenheit, Aberglauben c. stecken lassen?

# Fragen zu den Verstorbenen

Was die Verstorbene fürꝛ ein Leben geführet? Ob sie wegen fürwitziger Künsten, Zaubereyen oder anderm
ruchlosen Leben berüchtiget gewesen seyen? In was für einer Gemüths-Bewandniß,
Affecten, Zorn, Feindschafft, Unversöhnlichkeit, sie gestorben? Ob sie auch
gebeichtet, und das Sacrament empfangen? Besonders ob der Arnont Parle, der von
einem Vampyr geplaget worden und gewußt hat, daß er nach seinem Tod ebener
massen ein Vampyr werden müsse, nicht auch bey Lebzeiten dafür Sorge getragen,
oder sich sonst bey dem Priester Raths erholet habe, was die Priester, was
fürnehme Personen, was Medici, was kluge Leut sonsten an selbigen Orten hievon
sentiren? u. d. g.

# Weitere Informationen über den leiblichen Zustand

Endlich hat man auch mehrers zu wissen von ihrem leiblichen Zustand, als wessen Temperaments sie gewesen? Welches Todes sie gestorben, eines
natürlichen oder gewaltsamen, und warum dieses letztern? Von ihrer Kranckheit,
wie zwar in dem unterth. Berichtziemlich geschehen, ob sie langwirig oder kurtz,
absonderlich aber ob sie hectisch oder acut. c. gewesen? Ob ihnen dieꝛ
Aussaugung allein bey Nacht und im Schlaff wiederfahre, oder auch bey Tage und
wachend? Zu was für Leuten die Vampyrs kommen, allein zu ihren Verwandten, oder
Feinden, zu Frommen oder Gottlosen, oder ob da kein Unterscheid zu observiren
seye? Denn es ist eben doch etwas rares, daß der Teuffel solte wahre Christen
äusserlich und in sichtbarer Gestalt durch Gespenster oder andere Erscheinungen
angreiffen dörffen, judice ex Nostris D. Spenero, in Glaubens-Lehre, p. 312. ex
Reform. H. Voëtio de Magia P. III. Sel. Disp. Man könte auch die Materiam
medicam zu Rath ziehen de sugillatione vel effusione sanguinis in substantiam
cutis, vel ab incubis & spectris prætensis, vel aliunde oriunda, vid.
Horstii Observ. L. 4. P. 2. Obs. 11. Es dörffte auch noch besser gethan seyn,
wenn zu denen Herrn Regiments- und andern Feld-Scherern auch gelehrte Medici,
Philosophi, Juristen und Theologi gezogen, die Cörper in allen Theilen aufs
genaueste durchsucht, sonderlich die, welche fürgeben, daß sie gesauget worden,# Die Angst vor Vampiren

alsobald nach ihrem Tod secirt und besichtiget würden, ob ihnen denn wahrhafftig das Blut entzogen worden,und sie aus Mangel desselben gestorben, oder ob es eine Art eines Ephialtes gewesen? Ob aus Furcht und apprehension ihnen nur meatus sanguinis intercludirt worden? Ob, wenn solche, die angezeiget haben, sie seyen gesaugt worden, nach der Secirung nicht begraben, sondern liegen gelassen würden, ob sie nicht putrescirten, ob sie wieder mit Blut angefüllet werden, und zu andern kommen würden? Ja wenn man die im Grab so lang unverwesen gelegene und hernach ausgegrabene Cörper ohne Section, Durchstossung und Verbrennung an der freyen Lufft liegen liesse, ob sie eben auch nicht faulen würden, ob man bey einer genauen Verwachung derselben, nichts mit ihnen fürzugehen, würde beobachten können? Ob nur die Schaafe oder auch andere Thiere diesen Vampyrs unterworffen seyen? und viel andere Umstände mehr, die Erfahrnere an die Hand geben könten. Ich habe mich aber fast müde mit dieser Art Leute geschwatzet, und werde demnach mit einem nur kurtzen Wort die IV. Gattung Leute bescheiden.

## Die ängstlichen Frauen

DAs sind die ängstliche Frauen, die mich fast um GOttes Willen gebetten haben,ich solte ihnen doch sagen, was ich meynte, ob diese entsetzliche Gäste und grausame Vampyrs nicht auch algemach zu uns kommen möchten? Ich tröstete sie, so gut ich konte, der liebe GOtt werde uns mit dieser fremden Peitschen nicht auch heimsuchen; dieses Ubel seye immer von so vielen Jahren her in selbigen Gräntzen verblieben; das deutsche Blut werde diesen Todten so wenig schmäcken als der Francken- und Neccar-Wein und das Sächsische Bier denen Lebendigen geschmäckt gegen ihrem Ungarischen Wein. Aufs wenigste, wenn sie ja Lust bekämen, uns eine Visite zu geben, so dörffte es doch die armen Bauren nicht treffen, wie in Servien, als welchen an theils Orten Deutschlands sonsten so fleißig zu Ader gelassen werde, daß diese Vampyrs fast keinen Tropffen Blut auszusaugen bey manchem finden möchten: Wie es aber andern vollblütigen gehen möchte, könte ich nicht gewiß sagen. Es merckten aber die klugen Frauen bald, daß ich schertzen wolte; und baten mich demnach, ich solte ihnen ernstlich sagen, wie und mit welchen Mitteln man solches Ubels loß zu kommen suchen könne, es möchte hie oder in Servien seyn. Und das will ich nun auch mit aller geziemender Ernsthafftigkeit thun.

## Die Methoden gegen Vampire

Von denen Leuten in Servien wissen wir, daß sie solchen aufgegrabenen Cörpern einen Pfahl durchs Hertz stossen, oder den Kopff abhacken, ihn zu Aschen verbrennen, und glauben, daß sie hiedurch der Plage loß werden. Dieses procedere aber wollen einige weder medice, noch politice, noch theologice gut heissen. Nicht medice, um der schädlichen Dämpffe willen, so aus dem eröffneten Grab aufsteigen, und leicht eine Seuche erwecken können. Nicht politice, weilen die Gräber bey allen cultivirten Völckern der unzerstöhrlichen Ruhe gewiedmet unversehrlich und Gewalt-frey, das ist, heilig geachtet werden. Nicht theologice, weil dadurch der Aberglaube gemehret; der verstorbenen Leumund, da es auch Unschuldige treffen kan, gekräncket; unter den hinterlassenen Verwandten, und denen, die auf das Ausgraben dringen, Bitterkeit und Feindschafft erreget, und der Teuffel mehr als GOtt gefürchtet werde, welches alles mit noch mehrerm ausführet, und mit Exempeln beleget der oben belobte Prediger Mart. Bohemus in seiner hievon gehaltenen Predigt, aus welchem es Er. Francisci in seinem Höll. Proteo c. 28. gantz scheinet genommen zu haben, ohne der Quelle, daraus er geschöpffet, zu erwehnen; wie mehrers geschiehet.

## Über die Natur der Geister

Ich lasse diese Gedancken in ihren Würden. Meyne aber mit dem oben angezogenen D. Spener, daß dieser besondere Casus eine billige Exception von der gemeinen Regel leyde. Erstlich weilen in physicis auf die beständige Erfahrung (die ich hie supponire) sonderbar zu reflectiren ist, ob man schon den Modum nicht zeigen kan. Darnach weilen man dem Teuffel auch mit natürlichen Mitteln widerstehen darff. Denn da ein Geist nicht wircken kan in die Natur, als durch Hülffe der Natur; und aber der böse Geist sich dieser natürlichen Cörper zu der Menschen Schaden mißbraucht: So bekenne ich, daß ich nicht so enggewißig seye, ihme die natürliche Dinge zu entziehen, und seine Werckstatt und hoffärtiges Theatrum zu zerstören; zumalen das Mittel, nemlich die Verbrennung der Cörper nichts unrechts an sich selbsten ist. Wenn demnach jüngstens ein gelehrter und dabey sehr Christlicher Medicus irgendwo geschrieben: Actio diaboli in naturalia est certa; reactio vero naturalium in diabolum incerta, imo nulla est; so ist es entweder ein Absolutismus medicus, oder muß von der unmittelbaren reactione naturalium in diabolum erkläret werden. Denn das weiß man wol, daß kein leiblich Artzney-Mittel, cujuscunque generis, unmittelbar den Teuffel, einen Geist, berühren, und in ihm agiren kan: So fern aber der Satan sich natürlicher Dingen,# Einleitung
Kräfftenund Dispositionen gebrauchet, uns zu schaden, so fern kan auch wider dieselbe gestritten, und also mediate in diabolum agirt werden. Ich könte mich weit besser erklären und legitimiren, wie ich Königs Anmerckungen über Muralts Chirurgische Wercke an der Hand hätte, als worinnen solche Zeugniße angeführet werden, die gewißlich unverwerfflich seynd, sonderlich was er von einem Schäfer in Mähren selbs gesehen hat. Der Würtenb. berühmte Leib-Medicus, Herr Doct. Rosin. Lentilius hat ein Compositum gegen Zufälle, die der Zauberey zugeschrieben werden, welches in denen Ephemerid. N. C. nicht nur einmal, als was fürtreffliches, allegiret wird.

# Phantasien und ihre Behandlung
Solte man bey morbis acutis Phantasien, entetirte impressiones auf gewisse Personen, örter c. spüren, so kan ich wiederum nichts sträffliches absehen, ꝛ wenn man auch da mit klugen natürlichen Mitteln zu begegnen suchte, z. E. den Zulauff des Volcks abhalten; nicht zugeben, daß die Abwartenden aus des Patienten Fürgeben groß Werck machten, sie in ihren Einbildungen stärckten c. ꝛ Ja man könte die Krancken gar aus ihren Wohnungen in andere Häuser, und wol auch aus dem Dorff sonst wohin bringen, wiewol mir die Beschaffenheitder Leut und örter nicht bekant ist. Wir haben oben schon ein Exempel gehört, wie eine ängstliche und zagende Jungfer durch Veränderung des Bettes ist curirt worden. Und in eben selbigen Actis wird von einem Mann erzehlet, der in seiner Kranckheit viel Erscheinungen und Ansprache zu haben vermeynte. Nach seiner Genesung gieng ihm dieser Affect so nach, daß er bißweilen Bildungen zu sehen vermeynte, die ihme etwas ansagen wolten. Darwider hatte er kein besser Mittel, als die Veränderung des Orts. So bald er aus der Stadt gieng, so bald wurde er von allen Zufällen frey.

# Die Macht des Teufels
Gedächte aber jemand wider obigen §. 1. Was hilffts, einen solchen Cörper zu verbrennen? Kan doch der Teufel, wie man oben beweisen wolte, in viel andere fahren! So ist die Antwort nicht schwer. Der Teufel kan nicht thun, was er will; und er darf auch nicht alles thun, was er könte. Er stehet unter der Regierung GOttes, der seine ihm allein bewußte Ursachen hat, warum er ihm über den einen Cörper etwas zu erlauben für gut befindet, hingegen aber über den andern nicht: wie es ja auch so mit ihme gegen die lebendige Cörper gehalten wird, sonsten kein Mensch lebendig bliebe. Ich habe aber kein Bedencken zu sagen, daß man den Grund, warum Satanas offt über einen Leib mehr Macht hat, als über den andern, in einem solchen Menschen selber suchen dörffe, bißweilen aus seiner Schuld, bißweilen ohne seine Schuld. Das getrauete ich mir zu behaupten, daß der Teufel nirgend nistern könne, als in einer verderbten Natur. Wie viele Exempel wir von denen Besessenen zu Christi Zeiten lesen, so ist allemal zuvor entweder ihr Leib durch böse Constitution, verdorbenes Blut, verwirrtes Hirn c. oder ꝛ ihre Seele durch Sünden und Laster corrumpirt gewesen. Da nun durch solche corruptionem vel physicam vel moralem vel utramque simul der eine Leib dem Satan eine bequemere Bad-Stuben, so zu reden, abgibt, als der andere: so ist auch leicht zu erkennen, warum er seine Wohnung und Tyranney in dem einen besser haben kan, als in dem andern. Wolte also jenes Mittel nicht gar verwerffen.

# Geistliche Waffen im Kampf gegen den Teufel
Aber man solle es dabey nicht bewenden lassen, sondern die Leute auch unterrichten, wie sie dieses recht nehmen sollen; und fürnemlich auch mit geistlichen Waffen wider diesen Feind streiten, welche sind heiliger und fleißiger Gebrauch des göttlichen Worts, Unterricht aus demselben wider den Aberglauben und schreckhaffte Einbildungen, Erweckung eines festen Vertrauens auf den Schutz und Beystand des Allmächtigen GOttes, ohne dessen Zulassung der Satan über keine Säu-Borst Macht hat, andächtiges und absonderlich auch gemeinschafftliches Gebet. Wie die erste Christen die Besessene zu den Gräbern der heiligen Märtyrern geführet, und daselbsten gebetet haben, daß die Teufel schrien, brülleten und ausfuhren, beschreibet Cyprian. de dupl. Martyr. p. 515. Und Lutherus in der oben angezogenen Stelle seiner Tisch-Reden hat auch auf diesen Schlag gerathen, und setzet hinzu: Der Teufel will kurtzum gefürchtet, geehrt und angebetet seyn, wie GOtt. Er ist ein sehr hefftiger und stoltzer Geist, kan nicht leyden, daß man ihn will verachten. Darum soll man ihm hierinnen nicht fügen, sondern in der Kirche zusammen gehen, und GOtt bitten, er wolle uns unsere Sünden vergeben um Christi Willen, und den Teufel zu Schanden machen, f. 151. Sonderlich redet auch lieblich davon der anmuthige Scriver und sagt: In der Lebens-Beschreibung des grossen Kirchen-Lehrers Basilii wird berichtet, daß der Satan einem bußfertigen Sünder, der im eifrigen Gebet begriffen war, erschienen seye, und habe zu ihm gesagt: Laß mich mit frieden, so will ich dich auch mit frieden lassen. Wenndem so ist, so bezeuget es klärlich,# Gebet und Gottes Macht
daß man dem Feind nicht weher thun kan, als durch ein eifriges und emsiges Gebet, dadurch GOttes Macht und Güte gleichsam erwecket wird, daß er etwa einen Engel sendet, der diesen Hund wegpeitschen, und ein Kind GOttes von seinem Anlauffen und Anbellen erretten muß. S. Schatz. P. IV. Pr. 17. §. 40.

# Versöhnung mit Gott und Menschen
§. 5. Endlich ist auch beedes bey denen Sterbenden und Hinterbleibenden auf eine gründliche und aufrichtige Versöhnung, wie vorderist mit GOtt, also auch mit dem Neben-Menschen, zu dringen. Christus führet hiezu gar einen tiefen Grund an, wenn er sagt: Sey willfährig deinem Wiedersacher bald, alweil du noch bey ihm auf dem Wege bist, auf daß dich der Wiedersacher nicht dermahleins überantworte dem Richter, und der Richter dem Diener, und du wirst in den Kercker geworffen, Matth. V, 25. Was heißt das? Der abgeschiedene Wiedersacher überantwortet dich dem Richter? der Richter dem Diener oder Teufel? Ich sorge, wir haben in der gemeinen Homiletic die volle Krafft dieser Worte noch nicht erreichet. Diese Worte gehen gewißlich in ein geheimes Gericht der Geister-Welt hinein, und zeigen nicht undeutlich an, daß ein abgeschiedener zorniger Geist noch viel Recht und Macht über den hinterlassenen ungerecht zürnenden habe, denselben zu binden, und dem Gerichte GOttes, und durch dasselbe der Hand des Teufels zu überliefern. Wir sind freylich hospites und Fremdlinge in dem unsichtbaren Reich der Geister: allem Ansehen aber nach haben die abgeschiedene Geister mit den unsern manche Communication, sonderlich was auf die Liebe und Versöhnlichkeit ankommt. Davon eine curieuse pieçe in dem III. Stück der geistlichen Fama fürkommt, alwo von einem Eysenachischen Ministro, einem beredten und Christlich-gesinnten Herrn, mit welchem ich in seinen letztern Jahren erbaulich umzugehen Gelegenheit gehabt, erzehlet wird, daß sein Geist nach dem Tod einem Beleidigten für das Bett gekommen, und ihne noch um Vergebung des fürgegangenen gebeten habe. Doch ich muß nicht zuviel von dem Teufel reden, damit ich nicht denen Herrn Theologis in ihr Amt greiffe, denen zukommt, daß sie seyen agminis infernalis exploratores, wie der seel. D. Fecht ihnen diese geistliche Wacht-Meisters-Stelle zugeschieden hat.

# Schlussfolgerung
Beschluß. ICh beschliesse also meinen Discurs, und dancke allen denen respectueusement, welche die Gedult gehabt haben, denselben biß hieher zu lesen. Es ist dieses überflüßige Ehre genug; weiter wolle sich meinet wegen Niemand keine Mühe geben. Auf deren Verlangen ich geschrieben habe, die kennen mich freylich wol. Aber sie haben ein Sigillum auf sich, es Niemand zu sagen. Und ausser ihnen wird es sonst Niemand erfahren. Bißweilen habe so geschrieben, daß manche meynen werden, ich hätte mich deutlich entdecket. Ich versichere aber, wenn sie dencken werden, sie hätten mich in Händen, so werde ich am weitesten entfernet seyn. Vielweniger wolle sich jemand Mühe machen, mich zu widerlegen. Es ist wahr, was ich Eingangs ohne Schema gesagt habe, was hie stehet, seynd zusammen gestoppelte Discurse. Es ist nicht nach der Schärffe der Methodischen Gesetze raisonirt; es solte populariter nach dem Gousto gewisser Personen geschrieben werden, die mit subtilen Demonstrationen nicht wollen ermüdet werden; es ist eine schwere und verborgene Materie an sich selbs; hatte noch keinen Fürgänger; habe keinen einigen Menschen beleidiget noch angestochen, ausser was etwa mehr aus gutem Humeur als bitterm Gemüth über den Herrn Autorem Diss. de Masticatione mortuorum der elenden Feder entfallen seyn möchte; wäre aber der Boge nicht so gleich aus meiner Hand viel Meil wegs weit über Lande zur Truckerey fortgeschicket gewesen, ich hätte solches zehenmal für einmal wieder geändert. Es wird also an mir wenig Ehre aufzuheben seyn. Mein gantzes Absehen war, andern Gelegenheit zu geben, mit ihren bessern Gedancken mich zu unterrichten, und die hiesige aufmercksame Gemüther zu vergnügen. Wenn ihrer etliche ihre Meynung bescheidentlich sagen, kan es zur Erkäntniß der Warheit desto mehr gereichen. Doch will ich auch nicht alzu niederträchtig um schön Wetter bitten, sondern getrost erwarten, was da kommen möchte, versichernd, daß ich nicht alle Charten ausgeworffen, sondern noch eine zum Stich-Blat übrig in der Hand behalten habe. Allein diß sind eitel Thorheiten, wenn sie nicht gar gesparsam und wie auf der Flucht mehr berühret als behandelt werden. In Erniedrigung seines Sinnes zur demüthigen Bekäntniß unserer Unwissenheit mit Absicht auf die Erbauung mag man ja von diesen abstrusen Dingen ein Wort sagen; aber man muß kein Werckdaraus machen, sich in seinen idealischen Gedancken nicht erheben, und aus diesem Teufels-Dreck sich kein Gold zu eigener Ehre in anderer Verachtung sammlen wollen. Der allein weise GOtt hat einen Greuel an denen menschlichen Allwissern, die sich für klüger halten als Daniel, und meynen, daß# Der Geist des Lebens

ihnen nichts verborgen seye, Ezech. 28. Der Geist unsers HErrn JEsu Christi, der einsten unsere sterbliche Leiber lebendig machen wird, dringet allenthalben auf das Leben aus GOtt, und will nicht, daß wir über der Beschäfftigung mit fremden Todten unser einig wahres, nöthiges und bleibendes Leben aus dem Glauben an den Hertzogen des Lebens JEsum Christum versaumen sollen. Die Welt hat freylich in ihrem vergänglichen Dienst viele Todten-Gräber. Aber die Stimme des Sohnes GOttes solle mehr bey uns gelten: Laß die Todten ihre Todten begraben; du aber komme, und folge mir nach, Matth. 8.

# Die Bekehrung des Augustinus

Busse thun von den todten und unfruchtbaren und stinckenden Wercken ist besser, und unendlich mahl besser, als tausend Vampyrs anatomiren, und bey der Welt mit seinem gelehrten Discurs und erstaunlicher Geschicklichkeit mehr Verwunderung als die Vampyrs selber erwecken. Ich will also meine Todten-Historie mit einer lebhafften und sehr erwecklichen Erzehlung des frommen Mayl. Bischoffs Ambrosii von der Bekehrung des hernach gewordenen Kirchen-Vaters Augustini, serm. 94. de Baptism. August. beschliessen, die also lautet: Ante conversionem Augustinus versutiis, contentionibus & astutiis maxime erat versatus – – tanta etiam interdum pertinacia & Disputationis suæ acrimonia ac vehementia nos urgebat, ut inter supplicationes nostras, quod Deus abejus captionibus nos averteret, rogare coactisimus.

# Der Unterschied zwischen unbekehrtem und bekehrtem Augustinus

Post conversionem autem quantis lacrymis errorem professus est suum! quanto luctu conversionis diuturnitatem conquestus est! quibus verbis & quo dolore seram pœnitentiam damnavit! c. Welch ein Unterscheid war dochꝛ zwischen dem unbekehrten und bekehrten Augustino! Ehe Augustinus bekehret ward, war er ein scharfer Disputator, er wußte alle Fechter-Streich volkommen, er war in allen Räncken und Künsten zu zancken exercirt! Er machte dem heiligen Bischoff Ambrosio mit seiner Hartnäckigkeit viel zu schaffen; er trieb mit seinem spitzfindigen raisoniren und mit der Schärffe seines disputirens mich so ein, (sagt er) daß ich in meinem Gebet GOtt anruffen mußte, er solle uns doch vor dessen verfänglichen und scheinbaren Netzen bewahren.

# Die Tränen der Bekehrung

Aber da dieser Philosophus bekehret wurde, heißt es, habe sich dieses alles geändert. Mit wie vielen Thränen hat er nicht seine Irrthume bekennet! Mit welchem Leyd hat er die Langsamkeit seiner Bekehrung beklaget! Mit welchem Schmertzen hat er seine spate Busse verdammet! Ob sich dieses Exempel gar zu wol hieher schicke, oder nicht, hat nicht viel zu bedeuten. Ich weiß am Besten, was ich mit meyne. Seine eigene Irrthume bußfertig bekennen, ist besser, als der gantzen Welt ihre Irrthum und Fehler zeigen können. Besser ist es, über die Schande seiner eigenen Thorheit vor GOtt weinen, als über anderer Leute prostitution lachen.

# Die Demut vor Gott

Besser ists endlich auch von den Höhen seiner schwulstigen Vernunfft und widersetzlichen Eigenwillens in den Staub herunter gebeuget zu werden, als in seiner Erhebung wider die Erkäntniß Christi und den einfältigen Gehorsam seiner Warheit fortzufahren. Der zur Herrlichkeit des Vaters erhabene Heyland beweise sich an allen, die diese Bogen mit mir unter seinem Angedencken beschliessen, mit seiner lebendigmachenden Krafft, und trette hingegen den Satan mit seinen groben und subtilen Kräfften unter unsere Füsse in kurtzem.                            ENDE.

# Supplementum

ICh muß noch einmal erinnern, daß das vorstehende keine philosophische Deduction ex Principiis internis, sondern mehr ein historischer und oratorischer Discurs von herbey gezogenen argumentis externis seye, nach den Umständen, worin der Verfasser sich geworffen sahe. Wäre auch der aus der Feder geflossene Entwurff nicht so weit verschicket gewesen, ich würde ihn nimmermehr aus der Hand gelassen haben. Inzwischen da mir einige zur Erläuterung dienende Dinge beygegangen sind, habe ich solche hiemit nachhohlen wollen.

# Der I. Punct

HAndelte von denen lange Zeit unverwesen bleibenden Cörper. Dahin gehören zwey curieuse, obschon an sich ungleiche Stücke aus der Historie. Das erste ist aus einem Wercklein genommen, welches ein Würtembergischer Pfarrer, Herr M. Fried. Wilh. Breuninger vor wenigen Jahren geschrieben, und Sr. Kayserl. und Catholischen Majestät allerunterthänigst dedicirt hat, unter dem Titul: Die Urquelle des weltberühmten Donau-Stroms, in 8. Tübingen An. 1719. Denn nachdem der Autor in Beschreibung des Closters St. Georgen auf dem Schwartzwald auch an das nahgelegene Dörfflein Peterzell gekommen ist, so mercket er in dortiger Revier ein besonders Erdreich an, von welchem die eingegrabene Cörper verwunderlich bald verzehret werden. Seine eigene Worte lauten so: Zu Buchenberg bey Peterzell Nordwärts trifft man auf einem Kirch-Hof etwas besonders an. Dieser hanget Berg ab, und ist in seiner Erde von solcher Beschaffenheit, daß die ob der Kirche, so darauf stehet, eingesenckte Cörper, mit Haut, Fleisch und Bein innerhalb 3. biß# Die Unversehrtheit der Leichname

4. Wochen gäntzlich verzehret seynd, der Sarg aber verschlossen und unversehrt bleibet, worinnen, wann er geöffnet wird, nicht das geringste mehr von einiger Materie anzutreffen ist. Unterhalb dem Kirchlein solle nach wenigen Tagen weder Sarg noch Leichnam mehr zu finden, sondern alles versuncken seyn, und sich, wenn man aufgräbt, nichts als ein Wasser zeigen. Ich ließ dieses, ob es wahr seye, allezeit dahin gestellt seyn, biß An. 1717. die Beschaffenheit der Sache zu erfahren der Amtmann zu St. Georgen, und der Stadtschreiber zu Hanberg, wie auch der Pfarrer in Tennenbronn, und ein Land-Renovator, sich dort eingefunden, und zwey Gräber, so die neueste waren, eines unter das andere über der Kirchen, in deren einem ein Kind bey 4. Wochen, in dem andern ein Mann bey einem Viertel-Jahr gelegen, öffnen lassen, und in keinem, wie man vorgegeben, nur Wasser, sondern in beyden die annoch unversehrt und geschlossene Särge gefunden, welche man aufgemacht, da dann von dem Kind nichts, als nur noch ein klein wenig von der Hirnschal, von dem Cörper des Mannes aber gar nichts mehr, sondern nur noch ein geringes Stücklein des Leinwands, worein der Leib gewickelt gewesen, zu sehen war. Der Herr Autor setzet billig hinzu: Gewiß, eine Sache, die eine genauere Untersuchung meritirte! l. c. p. 378. seq.

# Das Beispiel aus Bremen

Das zweyte Exempel ist von Bremen, und diesem gerad entgegen. Denn dorten vertrocknen zwar in dem so genanten Bley-Keller die Cörper, verwesen aber nicht, sondern bleiben in ihrer gantzen Consistentz. Es hat mir dieses ein gelehrter Mann erzehlet, der es nicht nur selbsten mit Augen gesehen, sondern auch einen solchen Cörper an den Haaren aufgezogen hat, die so fest hielten, daß kein einiges davon heraus gieng. Aus solchen Exempeln erhellet nochmehr, was wir im I. Punct anmerckten, wie aus vielerley natürlichen Ursachen geschehen könne, daß die Cörper offt lange Zeit nicht in die Verwesung gehen. Gleichwie es gewisses Erdreich gibt, so auch die im Sarg verschlossene Cörper schnell verzehret: Also gibt es hingegen anderes Erdreich, so dieselbe lange Zeit erhält. Dergleichen auch von der Lufft gesagt werden kan.

# Die Vampyrischen Cörper

Bey unsern Vampyrischen Cörpern kommt das Haupt-Werck auf das frische und flüßige Geblüt an. Daß corrumpirtes Geblüt sich lang halten könne, ist so wunderlich nicht. Hie aber soll es gutes und balsamisches Geblüt seyn, so etwas mehrers sagen will. Gleichwol hat man auch davon Exempel, daß ein oder mehrere Tage nach dem Tod in den Hertz-Cammern oder in der Höle der Brust, sich noch dermassen frisches Blut gefunden, daß wenn solches durch die oder jene Veranlassung in Jährung gebracht wurde, es durch Mund, Nasen c. herausꝛ gedrungen. Bleibt aber das Blut noch frisch und flüßig, so bleiben auch die übrigen und festen Theile verwahret vor der Fäulniß, als welche von denen flüßigen Theilen anfänget. Die gröste Schwierigkeit bey den Vampyrs machet die lange und sonst unerhörte Zeit.

# Mögliche Ursachen der Unverweslichkeit

Nun kan man endlich auf allerhand Ursachen rathen, die dieses möglich machen können. Man kan sich solche Arten von Kranckheiten bey diesen Leuten fürstellen, welche das Geblüt zu einer langsamen Jährung, und daher rührenden Flüßigkeit disponiren. Oder man besinnet sich auf die Art der Begräbniß. Vielleicht eylt man mit denen noch innerlich warmen Cörpern allzu schnell unter die Erden; vielleicht werden diese gemeine Leute ohne Sarg eingescharret und mit Erden so dick umschüttet, daß sie in ihrer mäßigen Wärme erhalten werden; vielleicht werden sie gar nicht tief eingegraben, daß die Wärme der Sonnen-Stralen auf den Leib dringen, und ihn noch mehrers in seiner Wärme conserviren können; vielleicht entstehet daraus eine almähliche Jährung, folglich eine Aufblehung, und mithin ein Ausdringen des Bluts in die äusserliche Theile des Cörpers, und daraus ein so volles Ansehen derselben?

# Fragen zur Unverweslichkeit

Oder man erholt sich Raths bey der Beschaffenheit der Leiber selber. Sie können ein besonders Sulphur und Salz bey sich haben, welches sie erhält. Wer weiß, was in ihnen für eine gewisse vis elastica zurück geblieben ist? Wie nun dieses und dergleichen mehr, auf eine scheinbare Weise ausgeführet werden kan: Also befreyet es doch den curieusen Leser noch nicht von aller formidine oppositi. Man zeigt wol, daß es also seyn könte, aber man kan nicht versichern, daß es würcklich also seye, biß man etwa mehrere historische Nachrichten bekommt. Die abgegangene alte Nägel, die neugeschobene Nägel, die frisch gewachsene Haut, können fast nicht unter jene Analysin gebracht werden. Es möchte einer eigentlicher wissen, warum diese Unverweßlichkeit nur etlichen, und nicht allen Cörpern begegne, die doch auf einerley Weise werden begraben werden? Deßgleichen warum nicht zu allen Zeiten, sondern nur selten, und etwa alle 100. Jahr nur einmal? Vielleicht seynd die Kranckheiten (denn es ist nicht einerley Kranckheit, daran die Vampyrs sterben) nicht von solcher Gattung, wie man sie# Einleitung
oben supponirte; vielleicht gehet es mit der Begräbniß und andern Umständen nicht so her; vielleicht ist die Erde und Lufft von so keiner Beschaffenheit; vielleicht findet sich in diesen Cörpern kein solches Sulphur, Sal und Elater; vielleicht producirten alle diese Ursachen, wenn sie gleich da wären, keine solche effectus; vielleicht lassen sich diese Dinge leichter einbilden, als beweisen? Man muß also noch auf bessere Urkunden warten, oder neben der Natur mit einem Auge noch weiter hinaus sehen.

# Historische Erzählungen
Indeme man nun auf solche Weise bey allen Zusammenkünfften von diesen unverwesenen Vampyrs discurirt, so ergibt sich, daß man alle alte Histörichen, die einige Verwandschafft mit jenen haben, gleichsam aus ihrem Grab herfür suchet und wieder lebendig darstellet. Wie dann eben diesen Nachmittag in einer gewissen Gesellschafft ein belesener Politicus eine lustige Geschicht, die uns hertzlich lachen machte, fürbrachte, wie schlecht es vor jetzt 100. Jahren zu Erfurt abgelauffen seye, da man zwey Cörper, die etlich hundert Jahr lang für unverweßlich sind geglaubet worden, ausgraben wolte.

# Die Bischöfe von Erfurt
Der in Historia Eccles. unvergleichlich geübte Kirchen-Rath zu Gotha, Herr D. Ernst Salomo Cyprian erzehlet solches aus einer Epistola Msta. M. Wallenbergers unterm 10. Febr. An. 1634. aus Erfurt an D. Andream Kesler zu Gotha folgender Gestalt: Die zwey Bischöffe Adalarius und Eobanus, derer Leiber die Catholiquen bey fast etlich hundert Jahr lang unverweßlich zu seyn die Leute beredet hatten, sind dieser Tagen ex officio publici Magistratus, publice durch Chirurgos, Medicos und andere Beamten aus dem Grab genommen, aber höltzern also befunden worden in præsentia procerum pontificiorum, daß der Hirnschedel und etliche ossa ins Holtz versetzet gewesen.

# Der Betrug der Pontificii
Also, daß die Pontificii solchen alten Betrugs sich selber müssen schämen, und selber mit Augen sehen, es wären nicht unverweßliche Leiber, wie sie in ihrem offnen Gesang-Buch singen: Sondern Holtz mit Todten Knochen versetzet, in Gestalt eines Menschen. Das mag mir E. Ehrwürd. kühnlich nach sagen, immassen denn der Herr Reichs-Cantzler, beneben dem Fürsten von Weymar, solche auch selber gesehen hat, und den Decanum gefragt: Haltet ihr es noch für ein groß Wunder der unverweßlichen Leiber? da er still geschwiegen und schamroth worden; ferner gesagt: Sed, qui vult decipi, decipiatur, und mit Lachen sie bey ihren unverweßlich höltzernen Patronen stehen lassen, siehe D. E. S. Cyprian Vorrede über den 1. Theil Wilhelm Ernst Tenzels historischen Berichts vom Anfang und ersten Fortgang der Reformation Lutheri, Leipzig 1717.

# Vampyrgeschichten und Aberglaube
Der III. Punct TRieb das Haupt-Werck in dieser Frage, von denen erstaunlichen Würckungen dieser Vampyrs, wie sie bey Nacht in die Häuser kämen, das Blut von den Lebendigen aussaugten, sie damit tödteten, solche wieder zu Vampyrs machten c. Ich desiderirte dabey vollständigere Information, vermutheteꝛ unfehlbar mit unterlauffendem starcken Aberglauben, eingewurtzelte Einbildung, fürchterliche Impressionen c. meynte aber, daß der Teufel sich dieserꝛ Gelegenheit mit bediene, seine Gauckeley zu treiben.

# Zweifel an der Wahrheit
Seit deme bin ich mit allerley Personen zu sprechen gekommen. Einige zweiffeln an der Wahrheit dieser Geschichten, erklären solcherley Erzehlungen vor lauter Fabeln, die man nur von hören sagen habe, oder wann auch einige prætendiren, es selber erfahren zu haben, so haben sie doch die Eigenschafften gültiger Zeugen nicht an sich c.ꛜ Und freylich wenn fides historica manquirte, wenn alles nichts als ein Rumor adespotus, ungewisses und vages Gesag wäre, welches durch so viel Mäuler, und weit entfernte Meilen sich immerdar vergrösserte, wie die Schneeballen: So belohnte es sich nicht der Mühe, daß wir hieroben in Deutschland über dem Meditiren nur einen Nagel abbissen, geschweige den Kopff zerbrächen.

# Argwöhnische Gemüter
So aber ist es uns ergangen, wie es auch sonsten pfleget, ehe wir uns auf die Füsse machen, und nach Servien lauffen, es gewiß zu erforschen, ehe haben wirs glauben wollen, theils um des deponirten Zeugnisses willen, theils weilen die angegebene obwohl ausserordentliche Würckungen nichts in sich halten, welches als absolut unmöglich, quocunque respectu, schlechterdings müste verworffen werden. Darnach gab es auch argwöhnische Gemüther unter uns hie, die auf die soupçon fielen, ob nicht gar eine Schelmerey darunter stecke.# Vampyr-Mythen und ihre Auswirkungen

und es An. 1725. wieder gefürchtet haben: Sondern sie meynten sich insonderheit fundirt zu finden, als jüngstens eine zuverläßige Feder aus W. schrieb, wie ein gewisser Vampyr wieder gekommen seye, nicht nur seine Schuh zu hohlen, wie An. 1725. da das Weib den Flecken geraumet hat; auch nicht eben, wie andere seine Cameraden, Blut aus zu saugen: Sondern vielmehr andern seine Krafft mit zu theilen. Denn er habe sich so vertraulich zu seiner hinterlassenen Frauen gethan, daß sie von dieser freundschafftlichen Besuchung sich gesegneten Leibes befunden, und ein Kindgebohren habe, welches ein halber Geist gewesen seye, das ist, lauter Fleisch, und kein Bein gehabt habe.

# Aberglaube und Tradition

Aber als wir kaum anfiengen unsere Glossen hierüber zu machen, und das Frauenzimmer zu fragen, ob sie sich noch so greulich vor den Vampyrs fürchteten? sie könten doch mancher ehrlichen Frauen aushelffen! so wurde uns ein ernsthafftes Stillschweigen hievon aufgelegt c. Indessenꝛ versichert man, daß man hiebey nichts fingire; sondern ein wahrhafftiges Angeben ohne Schemate erzehlet habe. Die allermeisten aber drungen auf die Kräfften, einer durch Aberglauben, liederliche Erziehung, eingewurtzelte Tradition, manche andere Zufälle, sonderlich aber durch Kranckheiten erhabene, forcirte, oder sonst troublirte Phantasie, von deren Arlequins-Art sie viel lustiges, historisches und philosophisches zu sagen wußten, welches wir hie übergehen.

# Die Rolle der Einbildung

Gleichwie nun dieses eine gewisse Land-Kranckheit seye, zu welcher sich aus dem einmahl eingeführten Wahn solche Furcht und Einbildung schlage, als geschähe dieses würcklich, was diese Patienten aussagen: Also seye auch die Cur durch Abschlagung der Köpffe der ausgegrabenen von diesem Fund herzuleiten, und so wenig weiter daraus zu machen, als aus dem Probatum est, da ein gewisser Parisischer Professorüber Rami Logic laß, und, sich über die Modos figurarum etwa moquirend, sagte, wann man die Worte Barbara Celarent auf ein Zettulein schrieb, und in einem neu gebackenen stücklein Brod einnähme, käme man so gleich des Fiebers ab, welches ein deutscher Edelmann vor gut Geld annahm, seinem febricitirenden Laquayen solches eingab, der zur Stunde gesund wurde, und nachdem solches weiter auskam, an so vielen glückliche Proben that, als das China immer.

# Chinesische Weisheiten und ihre Anwendung

So bald aber der Professor seinen Schertz offenbahrete, so bald verlohr sich alle bißherige Krafft dieser Artzney. Tausend dergleichen Experimenten zu geschweigen, die auch in denen bewährten Ephemer. N. C. vorkommen. Nur kan ich, sagte einer, die heut zu Tag so sehr denen Europæern recommendirte Weißheit der Tschineser nicht gar vorbey gehen. Denn da bey denen Ungarischen Phænomenis unsere auch zu theuerst Wolfische Philosophie noch nicht völlig zurecht kommen kan, so suchte ich das Geheimniß in Tschina, und fehlte nicht viel, ich hätte überlaut das ἕυρηκα geruffen, als ich so manches lustiges von denen abentheurlichen Würckungen bey denen Krancken und Sterbenden von der dort geglaubten Wanderung der Seelen aus einem Leib in den andern lasse.

# Die Vorstellung vom Leben nach dem Tod

Ich werde (welches mir leyd ist) meine Leser desobligiren, daß ich aus Fleiß der Kürtze diese angenehme Historien hie weglasse, was sich doch die Sterbende für artige Dinge figuriren, wann sie nun in diesen oder jenen Leib fahren werden, wie sie sich freuen, jetzund ein edles Pferd zu werden, um dem, der ihnen bey Lebzeiten einen guten Ritter-Dienst gethan, nun wieder durch ihren muthigen Lauff und sichern Schritt einen desto grössern Gefallen erweisen zu können; wie ihre Priester, und absonderlich andere arglistige Köpffe, sich diesen Glauben so trefflich zu Nutz zu machen wissen u. d. g. wie man solches alles gedruckt lesen kan in Louis le Comte heutigem China P. II. p. 118. seq.

# Die Kraft der Einbildung und der Teufel

Wenn nun, macht man den Schluß, die zweyäugige Tschineser so artig traumen können aus ihrer vorgefaßten Lehre: Warum solten es die ohnehin halbäugigte Raitzen nicht eben so gut können, aus ihrer eben auch hegenden Einbildung. Aufs wenigst scheinet der Heyducke Joviza von seiner Söhnerin Stanjoicka allzu unbedächtlich gebeichtet zu haben. Wieviel man aber von der Krafft der Einbildung haranguirte, so wurde man doch bißweilen gegen den dabey seyenden Geistlichen so complaisant, daß man den Teufel nicht gar verbannen wolte, sondern zugabe, daß er sich mit einmengen könne (womit man doch gemachthun müsse) er könne etwa wol einen Leib von Lufft, oder Mengung des Lichts und Schattens, formiren, und ihme die Gestalt der verstorbenen Person geben.

# Gespenster und ihre Täuschungen

Auf solche Weise könne (NB. könne) er als ein Gespenst die Leut erschrecken, betriegen, ihre Einfalt und Leichtglaubigkeit auf tausenderley Weiß mißbrauchen, und seine Versuchungs-Kräfften darunter einführen. Ohnmöglich aber seye, daß er warhafftig solche Wercke thue, die man erzehle, sonderlich was die oben gedachte Zeugung eines halben Geistes betreffe: Welches letztere man einhellig eingestanden hat.# Der Discurs über die Vampyre

Inzwischen wurde der Discurs immer ernsthaffter, da ein wohl versuchter und weit gereißter Herr der gantzen Sache auf einmal abhelffen wolte, indem er, da er sonst kein Schul-Fuchs ist, fast in forma logica argumentirte und sagte: Wenn diese angegebene Würckungen und Verrichtungen der Vampyrs würcklich sich zutrügen, so müßten sie herkommen entweder von dem Leib, oder von der Seele derselben, oder von GOtt, oder von dem Teufel. Nun kan man keines von diesen vieren sagen; Ergo können sie nicht würcklich geschehen. Ergo müssen sie nur Geburten der krancken Phantasie seyn.

# Argumente gegen die Existenz von Vampiren

Was aber dieser Herr sagte, das bewieß er auch so gleich. Nam Philosophus nihil sine ratione. Erstlich sagte er, können solcherley Wercke nicht herkommen von dem Leibe. Dann wie kan der Leib agiren ohne die Seel? wie kan er heraus gehen, aus dem Grab, worin er verschlossen ist? wie kan er todt seyn, und doch solche actus vitales & animales exeriren? Das laß ich wol bleiben, daß ich einem lebendig Todten glauben solte! Vors andere können sie nicht herkommen von der Seelen. Dann wie kan diese ausgehen von dem Ort, wohin sie eine höhere Macht gesetzet hat?

# Der Glaube an die Seele

Hierinnen bin ich gut Protestantisch, und glaube, daß die Seele weder aus dem Himmel noch der Hölle wieder kommen könne; und von keinem Feg-Feuer weiß ich nichts. Gesetzt aber, es wäre diß die Seele, gesetzt, es gieng diesen Seelen, wie der Seel des Hermontini Clazomenii, die bißweilen die Lust angekommen ist, den Leib zu verlassen, und hie und da in der Welt eine Visite abzulegen, und mit einem Sack voll neuer Zeitungen zurück zu kehren, biß es endlich seine Feinde gemercket, und der abermal verreiseten Seele inzwischen ihren Leib niedergemacht haben, adeoque remeanti animæ vaginam ademerunt, wie Plutarchi und Plinii Worte lauten;

# Die Unmöglichkeit der Blutentnahme

Gesetzt, daß hie auch dergleichen etwas vorgienge, was hätte aber diese Seele nöthig Blut zu saugen, da sie ein Geist ist? und wenn sie es auch saugte, in welchem Geschirr könte sie das Blut aus den Leibern der Lebendigen in das Grab, und in die Cörper in dem Grab bringen. Drittens können diese Wercke nicht herkommen von GOtt, denn wem zu Gefallen solte doch GOtt die Regel der Natur ändern wollen, wenn er es auch könte? So seynd auch einige Dinge hierunter, die man ohne Gotteslästerung dem heiligsten GOtt nicht beymessen kan.

# Der Teufel und seine Grenzen

Aber auch viertens sie nicht dem Teufel zuschreiben. Denn die angegebene Wercke gehen schlechterdings über das Vermögen des Teufels. Warlich, wenn der Teufel das alles, was man sagt, mit den Cörpern thäte, so wäre dieses eine eigentliche Aufferstehung; zur Aufferweckung der Todten aber gehöret eine allmächtige Schöpffers-Krafft, die hat aber der Teufel als ein endlicher Geist nicht.

# Philosophische Überlegungen

Als ich hierauf zu antworten gedrungen wurde, so entschuldigte mich zwar, daß ich, wie man sehe, in der Schul-Methode nicht viel vergessen habe, und also nicht wüßte, ob die Enumeratio partium sufficient seye; ob die Consequentz bey jeglichem Membro keine Instantz leyde; ob man absonderlich bey dem dritten medio termino von GOtt nicht etwa auch an seine wunderbarliche Straffen und verborgene Gerichte bey so bedencklichen Fällen gedencken dörffte u. s. f. Doch wolle ich den letzten Punct, mit welchem auf mich gestichlet werde, vor mich nehmen.

# Der Einfluss von Cartesius und Leibniz

Es ist aber nicht nöthig, mich bey der Thesi aufzuhalten, daß ein Geist, und also auch der Böse, in einem Leib würcken könne. Der absurden Grund-Regel Cartesii, daß GOtt die unmittelbare und nechste Ursach aller Bewegung in den Cörpern, hat man allbereits zu Grab geleutet. Die Philosophi Harmonici machen auf der einen Seiten eben dieses auch wieder schwer, auf der andern aber auch leicht.

# Die Lehre von den Geistern

Jenes ist aus ihrem Systemate bekandt. Dieses erhellet daher, weilen Leibnitzius wieder auf ein neues die Lehre angenommen, daß ein jeder endlicher Geist einen Leib, gröbern oder subtilern, haben müsse, in Theodic. §. 124. Der heilige Kirchen-Lehrer Hieronymus hat dieses zwar unter die Ketzer-Stücke des Origenis mit gesetzet, daß er gelehret, es sey denen bösen Geistern zur Straffe ihrer Sünden ein Leib umgeben worden.

# Die moderne Sicht auf Geister

Bey dem heutigen Licht aber muß man es nicht mehr für so fürchterlich ansehen, weil man nicht nur weiter gehet, als Origenes, und dieses aus der Natur des endlichen Geistes an sich selbs herführet, daß ein jeder Geist nothwendig einen Cörper umhaben müsse, sondern solches auch frey und öffentlich lehret. Man sehe nur die Würtenbergische Duumviros, Herrn Georg Bernh. Bülffinger in Dilucid. philos. §. 245. & 366. in Commentat Hypoth. de H. Pr §. 264. und Herrn Israel Gottlieb Canzen de civit Dei p. 156. sqq. an.

# Schlussfolgerung

Wenn aber dem so ist, so ist die Würckung eines Geistes in dem Leib um ein Gutes leichter zu begreiffen. Wenigstens wäre nicht nöthig gewesen, daß man noch vor wenigen Jahren in einer gewissen Inaugural-Disputation zu Basel, die viel curioses, aber auch zimlich luxurirendes in sich hat, und also kein Wunder ist, daß dem alten und redlichen Theologo D. Werenfelsen die Feder gestanden ist, als er ein Carmen.# Einleitung zur Diskussion über den Teufel und die Naturgesetze

# Philosophische Überlegungen zu Geist und Körper

# Die Rolle des Teufels in der menschlichen Existenz

# Die Unmöglichkeit, die Macht des Teufels zu bestimmen

# Die Frage der Auferstehung und der Teufel

# Schlussfolgerungen und offene Fragen# Einleitung zur Diskussion über Hiobs Leiden
auch heute mancher nicht erkennen, daß Satanas zu den Schwären Hiobs etwas conserirt habe! Ingentia Hiobi ulcera non nisi tono fibrarum laxato, indeque subsecutæ seri & lymphæ stagnantis putrefactioni adscribenda, adeoque ad causas naturales, omni Diabolo ademta potestate, rejicienda videntur, schrieb vor 9. Jahren ein hertzhaffter Medicus. Ich gestehe, daß ich mich von dieser Weißheit sehr entferne; und zwar gern geschehen liesse, wenn man bey Hiobs Kranckheiten auch das natürliche dabey zeigete, aber es bloß aus lauter natürlichen Ursachen herführen, und austrücklich alle Brösamlein-Macht dem Teufel abzusprechen, ist eine weitaussehende Sache. Bey mir gilt das Wort des HErrn noch mehr: Er seye in deiner Hand? Und so glaube ich, daß es in vielen 100. Exempeln mehr geschehe, die man ziemlich aus natürlichen Ursachen der præsumtuosen Philosophie herleiten könte.

# Zweifel an der Rolle des Teufels
Auf den fernern Einwurff, wenn der Teufel diese Dinge thäte, könne man nicht begreiffen, warum sie alsobald nachliessen, wenn man die gewöhnliche Execution an den Cörpern fürnehme? haben wir oben geantwortet. Es mag auch hie gelten, was sonsten die Medici sagen: Inventis & destructis signis fascini destruitur ipsum fascinum. Und noch ein Zweifel: Der Teufel könnte solches Spiel aller Orthen anrichten, nicht in Servien allein; läßt sich auch leicht heben. Denn man hat ja dergleichen Erfahrung freylich auch von andern Orten in Ungarn, wie auch in Mähren und Böhmen, und d.g. Wie man sich denn auf eine merckliche Relation in Balbini Historia Bohemica beziehet, welche ich aber hie nicht erfragen konte.

# Unterschiede in der Teufelswahrnehmung
Und die Polnische Upiers seynd zwar nicht die Ungarische Vampyrs: Doch sehen sie ihnen gleicher, als einer Ofen-Gabel. Es findet auch der Satan ohne Zweifel die Menschen dorten physice & moraliter disponirter, als an andern Orten, sich ihrer als Masquen zu dieser Tragœdie zu gebrauchen. Der Satan spielt an einem Ort so, am andern anders, je nachdem er Leute antrifft. Ich weiß nicht, wie treulich es ein neuer Scribent, der sich ziemlich vom Teufel degagirt hat, meynt, wenn er schreibt: Multum ad operationem Diaboli quoque conferunt climata & vitæ genera.

# Regionale Unterschiede im Teufelsglauben
Itali quippe, Hispani, & qui propiores torridæ solis plagæ sind, item ii, qui generosioribus vinis, cibis salubribus utuntur, neque spectra neque sagas, rariores saltem, nobis narrant; cum e contrario septentrionales, Lappi, Finni, aliæque gentes quasi intimius mit Dæmoniis coalescentes (si fides itinerariis) videantur. Und doch hat diese Anmerckung bey einem nüchternen Gemüth etwas ex vero. Und was erinnert uns nicht die Stelle bey Marco Cap. V. I. seqq. als der Teufel aus einem Besessenen, der sich viel in den Gräbern aufhielte, durch JEsum solte ausgetrieben werden, bath er sehr, daß Christus ihn und die bey sich habende Legion nicht auß derselben Gegend treiben möchte.

# Die geografische Verteilung des Bösen
Sehen wir nicht hieraus deutlich, daß die Teufel sich in einer Gegend lieber aufhalten, als in der andern? Daß sie ihren Muthwillen in einem gewissen Strich Landes besser treiben können, als in dem andern? Das hat ohne Zweifel seine causas physicas & morales, ob wir sie gleich nicht gäntzlich verstehen, aber doch einen solchen notablen Finger-Zeig der Schrifft nicht so superciliose verachten solten. Vid. Petri Thyræi Dæmoniacum c. 56. Ich weiß zwar wohl, daß manche in ihrem Sinn die Schrifft nicht höher achten, als diesen in hoc passu angezogenen Jesuiten: Aber ich schäme mich der Pnevmatic in der Schrifft so wenig, als des Evangelii darinnen.

# Berichte über unvergängliche Körper
In diesem III. Punct Erzehle ich auch, wie sich der vor etlichen Jahren hiedurch reysende Griechische Prælat so breit gemacht mit denen unverwesenden Cörpern, die unter dem Bann der Griechischen Kirche stürben. Ich habe inzwischen einen gleichen Effect auch von der Römisch-Catholischen Excommunication gelesen, welchen ich treulich hieher setzen will. Sueno, Rex Daniæ, tyrannidis causa diris devotus a Libentio Episcopo Hamburgensi per 70. Annos in sepulcro integer repertus est. Diris solutusconfestim in cineres abiit ex Cranzii L. III. c. 42. & 48. Metropol. refert Zwingerus in Theatro vitæ hum. Vol. II. L. VII. p. 566.

# Mittel gegen das Böse
Bey der IV. Frage; Da von denen Mitteln wider dieses Ubel gehandelt wird, will ich ein paar bewährte Recepte aus Herrn David Märcky Diss. 2. de Oeconomia Spirituum eorumque in corpora humana potestate hieher setzen, die mir und vielen andern wohlgefallen haben. Das erstere dienet zur Præservation, und lautet mit einem kleinen Zusatz also: Nos optimum & tutissimum contra omnia penitus fascina (spectra & ἐνεργήματα diabolica) credimus illud Hier. Cardani: serva cor sincerum erga Deum, & ille te tuebitur. Ut & Mercurii Trismegisti: una & sola custodia hominum ab astu dæmonis pietas est; pium enim hominem nec dæmon malus, nec fatum tenet. Tam luculenta Christi cognitio. Valet enim auch noch illud antiquum:# Einleitung
Nos puer hebræus divos. c.ꝛ
Sedibus ergo dehinc taciti discedite vestris.
Porro sobrictas, vigilantia, labor, castitas hominis phantasiam a multis perversis imaginationibus immunem præstabit; familiaritas cum eruditis optimis & prudentibus quærenda; studiorum cultu præjudicia innata extirpanda, omneque sodalitium suspectum evitandum: quantum enim hic bona educatio a fabulis nutricum & anicularum anilibus defæcata commodi per totam vitam perennaturi præstet, nemo non videt. Verum est illud Dionysii Ægyptii Musici: Magiæ in rudes & male moratos est vis aliqua, in Philosophiæ studiosos nulla (quæ cum grano salis condita recte se habent.) Contemnendus ergo est diabolus, non profana illa & sceptica ἀδαιμονεστία, sed generosa ex Verbo divino concepta fiducia in JEsum Christum. Curiorisitas insuper Juveni quantocyus adimatur, illique Plutarchi de curiositate tractatus aureus (prudenter) legendus, relegendus inculcetur. Ante omnia turpe otium profligetur, quod & hic jure diaboli pulvinar audit; candentibus prunis & ferventibus ollis non insident muscæ, non phantasmata animo occupato.

# Gebet
Das andere Recipe begreifft die Cur selbsten, und enthält ein Gebet, welches dem Kirchen-Lehrer Nazianzeno zugeschrieben wird:
Pectore cede meo, confestim cede dolose!
Vita cede mea, corpore cede meo,
Fur, Serpens, Ignis, Belial, Draco, Bellua, Hiatus,
Mors Vitium, Rabies, Nox, Chaos, Insidiæ,
In fluctus fugito, Christus jubet ipse, marinos,
In scrophulas re graves, in pecudesque suum,
Ut Legio quondam impia, sic tu, perdite, cede,
Ad quem cuncta tremunt, ne cruce te feriam.
Membra crucem gestant, mea crux in pectore fixa est,
Crux pedibus præit, Crux decus omne meum.

# Epilog
Zum Epilogo gehörig. WIr hatten uns bißher müde geschwatzet, als mein Sohn, der mich von der Universität auf etliche Wochen besuchte, fragte, ob er nicht Erlaubniß hätte, ein Wort anzuhängen. Da es ihm nun alle leicht verwilligten, sprach er: es habe ihn die besondere Modestie des Peterburgischen Academici und Würtemberg. Theologiæ & Philosophiæ Professoris Bulfingers einsten in einer gewissen Materie so charmirt, daß er gewünschet, die Gelehrten möchten viel 100. Parodien nach derselben machen. Denn da dieser hochberühmte Mann die schwere Materie de transformatione animalium in seinen Dilucid. Philos. §. 368. mitgenommen hatte, so machte er aus deren Gelegenheit noch allerley Fragen darüber, und beantwortete sie alle mit einem cordaten Ich weiß nicht. Unde novum corpus? Nescio. Ubi delituit? Nescio. Quomodo eductum est? Nescio. Quantum est? Nescio. Quale est? Nescio. Perdurabitne illud c. Nescio. Num insensibilis est nobisꝛ machina c.? Nescio. Quomodo status sequitur ex statu c.? Nescio. Nescio illaꝛ ꝛ sane & longe adhuc plura, specialiter ac determinate. Multum ergo, inquis? plus, plurimum ignorantiæ! Ita est: sed innoxiæ. Quid enim nostra refert, nosse statum corporis physicum post hanc vitam? Sufficit, nosse statum Animæ nostræ moralem. Hic enim est, qui ad mores pertinet, & momentum in Religione trahit, c. Es köntenmit den grösten über die Vampyrische fremde Leiber eben so꛵ viel Fragen formirt, und vielleicht nicht besser beantwortet werden, als mit diesem billigen, erbaulichen und gelehrten Nescio. Lasset uns die verborgene Dinge fremder und uns nichts angehender Leiber nicht also forschen, daß wir darüber unsere eigene unzweifentlich gewisse Seele versaumen. Denn es hat doch jener Philosophus unserer Zeiten nicht unrecht geurtheilet, es könte der Mensch noch eher zweiflen, ob er einen Leib, als ob er eine unvergängliche Seele habe. ꝛc. Ich erschracke über diesen moralischen Discurs dieses Jungen, nicht nur weil ich mich heimlich bey mir selbsten schämte, sondern weil derselbe einen verborgenen Verweiß für die abwesende ansehnliche Freunde in sich zu halten schiene. Sie waren aber darüber so gar nicht empfindlich, daß sie ihm vielmehr applaudierten, und wünscheten, daß von diesem schönen Bulfingerischen Original viel 1000. wohlgerathene Copien mögen genommen werden. Nur ich gab ihme noch eine Väterliche Lection zurück, wie er diese rühmliche Modestie mit der unvergleichlichen Gründlichkeit dieses Hochgelehrten Mannes verpaaren müste. Denn ohne diese würde jene nichts anders werden als ein schöner Rahme, der eine häßliche Trägheit undschändliche Niederträchtigkeit und Verzagtheit bedeckete. Und so hatte unser Discurs von den Vampyrs ein Ende.Seneca:
Utrumque vitium est, &amp; omni-
bus credere velle, &amp; nulli: sed al-
terum honestius vitium est, alte-
rum tutius.                              Ast felix, mediam qui
scit
inire viam!