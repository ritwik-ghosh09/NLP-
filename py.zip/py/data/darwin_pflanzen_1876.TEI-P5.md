# Insectenfressende Pflanzen
von Charles Darwin

## Übersetzung
Aus dem Englischen übersetzt von J. Victor Carus. Mit dreiszig Holzschnitten.

## Verlag
STUTTGART. E. Schweizerbart’sche Verlagshandlung (E. Koch). 1876.

## Frühere Veröffentlichungen
In demselben Verlage erschienen früher:
Ch. Darwin, Reise eines Naturforschers um die Welt. Aus dem Englischen von J. V. Carus. Mit 14 Holzschnitten. 1875. Mark 10. — gebd. Mk. 11. —
Ueber die Entstehung der Arten durch natürliche Zuchtwahl oder die Erhaltung der begünstigten Rassen im Kampfe um’s Dasein. Aus dem Englischen von H. G. Bronn. Nach der sechsten englischen Auflage wiederholt durchgesehen und berichtigt von J. Victor Carus. Sechste Auflage. Mit dem Portrait des Verfassers. 8. 1876. Mark 10. — gebunden Mk. 11. —
Die Abstammung des Menschen und die geschlechtliche Zuchtwahl. Aus dem Englischen von J. Victor Carus. Dritte gänzlich umgearbeitete Auflage. 2 Bde. mit 78 Holzschn. gr. 8. 1875. Mark 18. — gebd. Mk. 20. —
Das Variiren der Thiere und Pflanzen im Zustande der Domestication. Aus dem Englischen übersetzt von J. Victor Carus. 2 Bde. mit 43 Holzschnitten. Zweite Auflage. gr. 8. 1873. Mark 20. — gebd. Mk. 22. —
Der Ausdruck der Gemüthsbewegungen bei dem Menschen und den Thieren. Aus dem Englischen von J. V. Carus. Zweite Auflage. Mit 21 Holzschnitten und 7 heliographischen Tafeln. gr. 8. 1874. Mark 10. — gebunden Mk. 11. —
Ueber die Einrichtungen zur Befruchtung britischer und ausländischer Orchideen durch Insecten und über die günstigen Erfolge der Wechselbefruchtung. Aus dem Englischen übersetzt von Dr. H. G. Bronn. Mit 34 Holzschnitten. gr. 8. 1862. Mark 4. 40.

## Weitere Werke
Jäger, Dr. Gustav, In Sachen Darwin’s insbesondere contra Wigand. Ein Beitrag zur Rechtfertigung und Fortbildung der Umwandlungslehre. 1875. Mark 5. —
Dub, Dr. Julius, Kurze Darstellung der Lehre Darwin’s über die Entstehung der Arten der Organismen. Mit 38 Holzschnitten. gr. 8. 1870. Mark 6. —

## Inhalt
Erstes Capitel.# Drosera rotundifolia, oder der gemeine Sonnenthau

## Erste Kapitel
Grosze Zahl Insecten gefangen. — Beschreibung der Blätter und ihrer Anhänge oder Tentakeln. — Vorläufige Skizze der Functionen der verschiedenen Theile und der Art, auf welche Insecten gefangen werden. — Dauer der Einbiegung der Tentakeln. — Beschaffenheit der Absonderung. — Die Art, auf welche die Insecten in die Mitte des Blattes geschafft werden. — Beweis, dasz die Drüsen die Fähigkeit haben aufzusaugen. — Die geringe Grösze der Wurzeln.

## Zweites Kapitel
Die Bewegung der Tentakeln bei der Berührung mit festen Körpern. Die Einbiegung der äuszeren Tentakeln in Folge der Reizung der Drüsen auf der Scheibe durch wiederholtes Berühren oder durch Gegenstände, die in Berührung mit ihnen gelassen werden. — Die Verschiedenheit in der Wirkung von Körpern, welche lösliche stickstoffhaltige Substanz geben, und solchen, welche dergleichen nicht geben. — Die Einbiegung der äuszeren Tentakeln direct verursacht durch Gegenstände, die mit ihren Drüsen in Berührung gelassen werden. — Zeitliche Verhältnisse der beginnenden Einbiegung und der nachfolgenden Streckung. — Die auszerordentliche Kleinheit der Theilchen, welche Einbiegung verursachen. — Wirkung unter Wasser. — Die Einbiegung der äuszeren Tentakeln, wenn ihre Drüsen durch wiederholtes Berühren gereizt werden. — Fallende Wassertropfen verursachen keine Einbiegung.

## Drittes Kapitel
Zusammenballung des Protoplasma in den Zellen der Tentakeln. Beschaffenheit des Inhalts der Zellen vor der Zusammenballung. — Die verschiedenen Ursachen, welche eine Zusammenballung veranlassen. — Der Procesz fängt in den Drüsen an, und geht die Tentakeln hinunter. — Beschreibung der zusammengeballten Massen und ihrer unwillkürlichen Bewegungen. — Ströme von Protoplasma entlang den Wänden der Zellen. — Wirkung von kohlensaurem Ammoniak. — Die Körnchen in dem Protoplasma, welches den Wänden entlang flieszt, verschmelzen mit den centralen Massen. — Die äuszerst geringe Quantität kohlensauren Ammoniaks, welche Zusammenballung verursacht. — Wirkungsart andrer Salze von Ammoniak, — andrer Substanzen, organischer Flüssigkeiten etc., — des Wassers, — der Wärme. — Wiederauflösung der zusammengeballten Massen. — Nähere Ursachen der Zusammenballung von Protoplasma. — Zusammenfassung und Schluszbemerkungen. — Supplementäre Beobachtungen über Zusammenballung in den Wurzeln der Pflanzen.

## Viertes Kapitel
Die Wirkung der Wärme auf die Blätter. Art der Versuche. — Wirkungen kochenden Wassers. — Warmes Wasser verursacht rapide Einbiegung. — Wasser auf höherer Temperatur verursacht nicht sofortige Einbiegung, tödtet aber die Blätter nicht, wie ihr späteres Wieder-ausbreiten und das Zusammenballen des Protoplasma zeigt. — Eine noch höhere Temperatur tödtet die Blätter und coagulirt den eiweiszhaltigen Inhalt der Drüsen.

## Fünftes Kapitel
Die Wirkungen nicht-stickstoffhaltiger und stickstoffhaltiger organischer Flüssigkeiten auf die Blätter. Nicht-stickstoffhaltige Flüssigkeiten. — Lösungen von arabischem Gummi. — Zucker. — Stärke. — Verdünnter Alkohol. — Oliven-Oel. Aufgusz und Abkochung von Thee. — Stickstoffhaltige Flüssigkeiten. — Milch. — Harn. — Flüssiges Eiweisz. — Aufgusz von rohem Fleisch. — Unreiner Schleim. — Speichel. — Lösung von Hausenblase. — Verschiedenheit in der Wirkung dieser beiden Gruppen von Flüssigkeiten. — Abkochung von grünen Erbsen. — Abkochung und Aufgusz von grünem Kohl. — Abkochung von Grasblättern.

## Sechstes Kapitel
Die Verdauungskraft des Secrets der Drosera. Die Absonderung wird durch directe oder indirecte Reizung der Drüsen sauer. — Natur der Säure. — Verdauliche Substanzen. — Eiweisz, seine Verdauung durch Alkalien unterbrochen, durch Zusatz einer Säure wiederbegonnen. — Fleisch. — Fibrin. — Syntonin. — Zellgewebe. — Knorpel. — Faserknorpel. — Knochen. — Schmelz und Zahnbein. — Phosphorsaurer Kalk. — Fibröse Grundlage des Knochens. — Gallerte. — Chondrin. — Milch, Casein und Käse. — Leim.# Inhaltsverzeichnis

## Sechstes Kapitel
Legumin. — Pollen. — Globulin. — Haematin. — Unverdauliche Substanzen. — Epidermoide Bildungen. — Fibroelastisches Gewebe. — Mucin. — Pepsin. — Harnstoff. — Chitin. — Cellulose. — Schieszbaumwolle. — Chlorophyll. — Fett und Oel. — Stärke. — Wirkung des Secrets auf lebende Samen. — Zusammenfassung und Schluszbemerkungen S. 76

## Siebentes Kapitel
Die Wirkungen von Ammoniaksalzen. Art die Versuche auszuführen. — Wirkung destillirten Wassers im Vergleich mit den Lösungen. — Kohlensaures Ammoniak, von den Wurzeln absorbirt. — Der Dampf von den Drüsen absorbirt. — Tropfen auf den Blattscheiben. — Minutiöse Tröpfchen auf einzelne Drüsen gebracht. — Blätter in schwache Lösungen eingetaucht. — Auszerordentliche Kleinheit der Dosen, welche Aggregation des Protoplasma herbeiführen. — Salpetersaures Ammoniak, analoge Versuche damit. — Phosphorsaures Ammoniak, analoge Versuche. — Andre Ammoniaksalze. — Zusammenfassung und Schluszbemerkungen über die Wirkung der Ammoniaksalze S. 120

## Achtes Kapitel
Die Wirkungen verschiedener Salze und Säuren auf die Blätter. Natron-, Kali- und andere alkalische, erdige und metallische Salze. — Zusammenfassung über die Wirkung dieser Salze. — Verschiedene Säuren. — Zusammenfassung über ihre Wirkungen S. 156

## Neuntes Kapitel
Die Wirkungen gewisser alkoloider Gifte, andrer Substanzen und Dämpfe. Strychninsalze. — Schwefelsaures Chinin unterbricht nicht bald die Bewegung des Protoplasma. — Andere Chininsalze. — Digitalin. — Nicotin. — Atropin. — Veratrin. — Colchicin. — Theïn. — Curare. — Morphium. — Hyoscyamus. Inhalt. — Das Gift der Cobra beschleunigt dem Anscheine nach die Bewegungen des Protoplasma. — Campher, ein kräftiges Reizmittel, seine Dämpfe narcotisch. — Gewisse ätherische Oele erregen Bewegung. — Glycerin. — Wasser und gewisse Lösungen verzögern oder verhindern die spätere Wirkung des phosphorsauren Ammoniaks. — Alkohol unschädlich, sein Dampf narcotisch und giftig. — Chloroform, Schwefel- und Salpeter-Äther, ihre reizenden, giftigen und narcotischen Eigenschaften. — Kohlensäure narcotisch, nicht schnell giftig. — Schluszbemerkungen S. 179

## Zehntes Kapitel
Über die Empfindlichkeit der Blätter und über die Übermittelungsbahnen des motorischen Impulses. Die Drüsen und Spitzen der Tentakeln allein empfindlich. — Übermittelung des motorischen Impulses die Stiele der Tentakeln hinab und quer durch die Blattscheibe. — Zusammenballung des Protoplasma eine Reflexthätigkeit. — Erste Entladung des motorischen Impulses plötzlich. — Richtung der Bewegungen der Tentakeln. — Motorischer Impuls durch das Zellengewebe übermittelt. — Mechanismus der Bewegungen. — Natur des motorischen Impulses. — Wiederausbreitung der Tentakeln S. 208

## Elftes Kapitel
Recapitulation der hauptsächlichsten Beobachtungen an Drosera rotundifolia S. 238

## Zwölftes Kapitel
Über den Bau und die Bewegungen einiger anderen Arten von Drosera. Drosera anglica. — Drosera intermedia. — Drosera capensis. — Drosera spathulata. — Drosera filiformis. — Drosera binata. — Schluszbemerkungen S. 252

## Dreizehntes Kapitel
Dionaea muscipula. Structur der Blätter. — Empfindlichkeit der Filamente. — Rapide Bewegung der Lappen, durch Reizung der Filamente verursacht. — Drüsen, ihr Absonderungsvermögen. — Langsame Bewegung durch Absorption animaler Substanz verursacht. — Beweis der Aufsaugung in dem zusammengeballten Zustand der Drüsen. — Verdauende Kraft des Secrets. — Wirkung von Chloroform, Äther und Blausäure. — Die Art und Weise, wie Insecten gefangen werden. — Nutzen der randständigen Spitzen. — Arten der Insecten, die gefangen werden. — Die Übermittelung des motorischen Impulses und der Mechanismus der Bewegungen. — Wiederausbreitung der Lappen S. 259# Fängt Krustenthiere
— Structur der Blätter im Vergleich mit denen der Dionaea.
— Aufsaugung der Drüsen, der viertheiligen Fortsätze und der Spitzen an den nach innen gefalteten Rändern.
— Aldrovanda vesiculosa, var. australis — Fängt sich Beute.
— Aufsaugung thierischer Substanz.
— Aldrovanda vesiculosa, var. verticillata.
— Schluszbemerkungen S. 290

# Inhalt
Fünfzehntes Capitel.
Drosophyllum. — Roridula. — Byblis. — Drüsige Haare anderer Pflanzen. — Schluszbemerkungen über die Droseraceen.
Drosophyllum. — Structur der Blätter. — Natur des Secrets. — Art und Weise, Insecten zu fangen. — Vermögen der Absorption. — Verdauung animaler Substanzen. — Zusammenfassung über Drosophyllum. — Roridula. — Byblis. — Drüsige Haare anderer Pflanzen, ihr Absorptionsvermögen. — Saxifraga. — Primula. — Pelargonium. — Erica. — Mirabilis. — Nicotiana. — Zusammenfassung über drüsige Haare. — Schluszbemerkungen über die Droseraceen S. 300

# Sechszehntes Capitel
Pinguicula.
Pinguicula vulgaris. — Bau der Blätter. — Grosze Zahl der gefangenen Insecten und anderer Gegenstände. — Bewegung der Blattränder. — Nutzen dieser Bewegung. — Absonderung, Verdanung und Aufsaugung. — Wirkung des Secrets auf verschiedene animale und vegetabilische Substanzen. — Die Wirkungen von Substanzen, welche keine löslichen stickstoffhaltigen Substanzen enthalten, auf die Drüsen. — Pinguicula grandiflora. — Pinguicula lusitanica, fängt Insecten. — Bewegung der Blätter, Absonderung und Verdauung S. 332

# Siebenzehntes Capitel
Utricularia.
Utricularia neglecta. — Structur der Blase. — Der Gebrauch der verschiedenen Theile. — Anzahl der gefangenen Thiere. — Art und Weise des Fanges. — Die Blasen können animale Substanz nicht verdauen, aber absorbiren die Producte ihres Zerfalls — Versuche über die Aufsaugung gewisser Flüssigkeiten durch die viertheiligen Fortsätze. — Aufsaugung durch die Drüsen. — Zusammenfassung der Beobachtungen über Aufsaugung. — Entwickelung der Blasen. — Utricularia vulgaris. — Utricularia minor. — Utricularia clandestina S. 357

# Achtzehntes Capitel
Utricularia (Fortsetzung).
Utricularia montana. — Beschreibung der Blasen an den unterirdischen Wurzelstöcken. — Beute, welche die Blasen bei Pflanzen im Culturzustande und im Naturzustande fangen. — Absorption durch die viertheiligen Fortsätze und durch die Drüsen. — Knollen, weiche als Wasserbehälter dienen. — Verschiedene andere Arten von Utricularia. — Polypompholyx. — Genlisea: verschiedene Natur der Falle zum Fangen von Beute. — Verschiedenartige Methode, nach welcher Pflanzen ernährt werden S. 388

# Ein „Minim‟
das kleinste Flüssigkeitsmasz der englischen Apothekermasze, ist \frac {1}{60} Masz-Drachme, entspricht also etwa 1 Gran (0,91 Gran Wasser, Brit. Pharmaco- paea, 1867, p. 402), dem Gewicht nach, oder einem „Tropfen‟. Da jedoch Verf. halbe Minims, halbe-Minim-grosze und selbst \frac {1}{20} Minim-grosze Tropfen erwähnt, schien es am sichersten, den Ausdruck einfach beizubehalten. Der Uebersetzer.

# Erstes Capitel
Drosera rotundifolia oder der gemeine Sonnenthau.
Grosze Zahl Insecten gefangen. — Beschreibung der Blätter und ihrer Anhänge oder Tentakeln. — Vorläufige Skizze der Functionen der verschiedenen Theile und der Art, auf welche Insecten gefangen werden. — Dauer der Einbiegung der Tentakeln. — Beschaffenheit der Absonderung. — Die Art, auf welche die Insecten in die Mitte des Blattes geschafft werden. — Beweis, dasz die Drüsen die Fähigkeit haben aufzusaugen. — Die geringe Grösze der Wurzeln.
Ich war während des Sommers 1860 erstaunt zu finden, was für eine grosze. Anzahl Insecten von den Blättern des gewöhnlichen Sonnen-# Einleitung zur Drosera rotundifolia

# Historische Aufsätze und Beobachtungen

# Die Lebensweise der Drosera

# Reaktionen auf Reize und Insektenfang

# Merkwürdige Ergebnisse und Empfindlichkeiten der Drüsen

# Weitere Forschungen und Vorträge# Einleitung zur Beschreibung der Pflanze

# Abbildungen und Zeichnungen

# Beschreibung der Blätter

# Tentakeln und Drüsen

# Färbung und chemische Zusammensetzung

# Schlussfolgerung über die Tentakeln# Bau der Tentakeln und Drüsen

Gefäszbündeln in der Scheibe des Blattes ab und laufen durch alle Tentakeln hinauf in die Drüsen. Mehrere bedeutende Physiologen haben die homologe Natur dieser Anhänge oder Tentakeln erörtert, das heiszt, ob sie als Haare (Trichome) oder Verlängerungen des Blattes betrachtet werden sollten. Nitschke hat bewiesen, dasz sie alle die Elemente, welche zu der Scheibe des Blattes gehören, in sich schlieszen; und die Thatsache, dasz sie Gefäszgewebe enthalten, ward früher für ein Beweis gehalten, dasz sie Verlängerungen des Blattes wären; jetzt aber ist es bekannt, dasz Gefäsze zuweilen in wahre Haare eintreten. Dr. Nitschke hat diesen Gegenstand in der Botan. Zeitung, 1861, p. 241 u. folgende, erörtert, s. auch Dr. Warming (Sur la Différence entre les trichomes etc. 1873), welcher Verweisungen auf mehrere Publicationen mittheilt; s. auch Groenland und Trécul, Annal. Seiene. natur. Botan., 4. Sér. Tom. 3, 1855, p. 297 und 303. Die Fähigkeit sich zu bewegen, welche sie besitzen, ist ein starkes Argument gegen die Ansicht, dasz sie Haare sind. Die Folgerung, welche mir die wahrscheinlichste zu sein scheint, wird im 15. Kapitel gegeben werden, nämlich, dasz sie ursprünglich als drüsige Haare oder blosze Epidermis-Bildungen existirten und dasz ihr oberer Theil noch als eine solche zu betrachten ist; dasz aber ihr unterer Theil, welcher allein der Bewegung fähig ist, aus einer Verlängerung des Blattes besteht; von diesem Theil aus haben sich Spiralgefässe bis in den obersten Theil hinein erstreckt. Wir werden nachher sehen, dasz die endständigen Tentakeln der getheilten Blätter von Roridula sich noch in einem intermediären Zustande befinden.

# Drüsenstruktur und Funktion

Die Drüsen, mit Ausnahme der von den äuszerston randständigen Tentakeln getragnen, sind oval und von nahezu gleicher Grösze, nämlich ungefähr \frac {4}{500} Zoll Länge. Ihr Bau ist merkwürdig und ihre Functionen sind complicirt, denn sie sondern ab, sangen auf und werden von verschiedenen Reizmitteln beeinfluszt. Sie bestehen aus einer äuszeren Schicht von kleinen polygonalen Zellen, welche eine purpurne körnige Substanz oder Flüssigkeit enthalten und dickere Wände als die Stielzellen besitzen. Innerhalb dieser Zellenschicht liegt eine innere, aus anders geformten Zellen bestehend, welche gleichfalls mit purpurner Flüssigkeit, aber von einer unbedeutend verschiedenen Färbung gefüllt sind und sich auch gegen Gold-Chlorid verschieden verhalten. Diese beiden Schichten sind zuweilen gut zu sehen, wenn eine Drüse zerdrückt oder in Ätzkali gekocht worden ist. Der Angabe Dr. Warming’s zufolge ist noch eine andere Schicht von viel verlängerteren Zellen vorhanden, wie in dem beistehenden, aus seinem Werke copirten Durchschnitt (Fig. 3), dargestellt ist. Diese Zellen wurden weder von Dr. Nitschke noch von mir gesehen. In der Mitte ist eine Gruppe verlängerter cylindrischer Zellen von ungleicher Länge, welche stumpf zugespitzt an ihren oberen, und abgestutzt oder abgerundet an ihren unteren Enden, dicht an einander gedrückt und dadurch merkwürdig sind, dasz sie von einer Spirallinie umgeben werden, welche als eine besondere Faser abgetrennt werden kann.

# Zusammenhang mit Spiralgefäßen

Diese letzteren Zellen sind mit einer klaren Flüssigkeit erfüllt, aus welcher sich nach langem Eintauchen in Alkohol viel braune Substanz niederschlägt. Ich vermuthe, dasz sie mit den Spiralgefässen, welche in den Tentakeln hinauflaufen, factisch zusammenhängen; denn bei mehreren Gelegenheiten wurde gesehen, wie die Letzteren sich in zwei oder drei äuszerst dünne Zweige theilten, welche bis dicht an die spiralfadenhaltenden Zellen verfolgt werden konnten. Ihre Entwickelung ist von Dr. Warming beschrieben worden. Zellen derselben Art sind auch in andern Pflanzen beobachtet worden, wie ich von Dr. Hooker höre, und wurden von mir in den Rändern der Blätter der Pinguicula gesehen. Was auch ihre Function sein mag, sie sind weder nothwendig für die Absonderung der verdauenden Flüssigkeit, noch für die Aufsaugung, noch für die Mitteilung eines Bewegungsreizes an andere Theile des Blattes, wie wir aus# Bauart der Drüsen

der Bauart der Drüsen bei einigen andern Gattungen der Droseraceen schlieszen können. Die äuszersten randständigen Tentakeln sind unbedeutend verschieden von den andern. Ihre Basen sind breiter und auszer ihren eignen Gefäßen erhalten sie noch einen schönen Zweig von denen, welche auf jeder Blatthälfte in die Tentakeln eintreten. Ihre Drüsen sind sehr verlängert und liegen auf der oberen Fläche des Stengels eingebettet, anstatt an der Spitze zu stehen. In andrer Hinsicht sind sie nicht wesentlich verschieden von den ovalen und in einem Exemplar fand ich jeden möglichen Uebergang zwischen den beiden Formzuständen. In einem andern Exemplar waren keine langköpfigen Drüsen vorhanden. Diese randständigen Tentakeln verlieren ihre Reizbarkeit eher als die andern, und wenn ein Reiz auf die Mitte des Blattes gebracht wird, werden sie erst nach den andern zur Thätigkeit erregt. Wenn abgeschnittene Blätter in Wasser eingetaucht werden, werden sie oft allein gebogen.

# Papillen der Blätter und Stiele

Die purpurne Flüssigkeit oder körnige Substanz, welche die Zellen der Drüsen erfüllt, ist bis zu einem gewissen Grade verschieden von der in den Zellen der Stengel. Denn wenn ein Blatt in heiszes Wasser oder gewisse Säuren gethan wird, werden die Drüsen ganz weisz und undurchsichtig, während die Zellen der Stengel hellroth werden, mit Ausnahme derer dicht unter den Drüsen. Diese letzteren Zellen verlieren ihre blasze rothe Färbung; und die grüne Substanz, welche sie ebensowohl wie die basalen Zellen enthalten, wird heller grün. Die Stiele tragen viel vielzellige Haare, wovon, der Angabe Nitschke’s zufolge, einige der Scheibe nahe von einigen wenigen runden Zellen überragt werden, welche rudimentäre Drüsen zu sein scheinen. Beide Flächen des Blattes, die Stiele der Tentakeln, besonders die untere Seite der äuszeren, und die Blattstiele sind mit kleinen Papillen (Haare oder Trichome) besetzt, welche eine conische Basis haben und an ihrer Spitze zwei und gelegentlich auch drei oder selbst vier abgerundete Zellen tragen, die viel Protoplasma enthalten. Diese Papillen sind gewöhnlich farblos, aber manchmal enthalten sie ein wenig purpurne Flüssigkeit. Sie sind verschieden in ihrer Entwicklung und gehen wie NitschkeNitschke hat diese Papillen ausführlich beschrieben und abgebildet, in Botan. Zeitung, 1861, p. 1234, 253, 254. angibt und ich zu wiederholten Malen beobachtet habe, allmälig in die langen vielzelligen Haare über; die letzteren sowohl als die Papillen sind wahrscheinlich die Rudimente von früher vorhanden gewesenen Tentakeln.

# Funktion der Papillen

Um nicht noch einmal auf die Papillen zurückkommen zu müssen, will ich hier hinzufügen, dasz sie nicht absondern, aber leicht von verschiedenen Flüssigkeiten durchdrungen werden; so dasz, wenn lebende oder todte Blätter in eine Auflösung von einem Theil Gold-Chlorid oder salpetersauren Silber auf 437 Theile Wasser eingetaucht werden, sie schnell schwarz werden und die Entfärbung sich bald bis in das umgebende Gewebe ausbreitet. Die langen vielzelligen Haare werden nicht so schnell angegriffen. Nachdem ein Blatt zehn Stunden lang in einem schwachen Aufgusse von rohem Fleisch liegen gelassen war, hatten die Zellen der Papillen augenscheinlich thierische Substanz aufgesaugt; denn anstatt der klaren Flüssigkeit enthielten sie nun kleine zusammengehäufte Massen von Protoplasma, welche langsam und unaufhörlich ihre Form änderten. Ein ähnliches Resultat ergab sich, nachdem ein Blatt nur 15 Minuten lang in eine Lösung von einem Theil kohlensaurem Ammoniak in 218 Theilen Wasser getaucht wurde; die benachbarten Zellen der Tentakeln, auf welchen die Papillen saszen, enthielten jetzt gleichfalls zusammengeballte Massen von Protoplasma. Wir können daraus schlieszen, dasz, wenn ein Blatt ein gefangenes Insect in der sofort zu beschreibenden Weise dicht umfangen hält, die Papillen, welche von der oberen Fläche des Blattes und der Tentakeln vorspringen, wahrscheinlich etwas von der thierischen Substanz aufsaugen, welche in der Absonderung aufgelöst wird. Dies kann aber mit den Papillen am Rücken der Blätter oder an den Blattstielen nicht der Fall sein.

# Vorläufige Skizze der Function

Vorläufige Skizze der Function der verschiedenen Theile und der Art, auf welche Insecten gefangen werden.# Einleitung zur Drosera rotundifolia

Wenn ein kleiner organischer oder unorganischer Gegenstand auf die Drüsen in der Mitte des Blattes gelegt wird, so übertragen diese einen motorischen Reiz auf die randständigen Tentakeln. Die nächststehenden werden zuerst afficirt und neigen sich langsam nach der Mitte hin, dann die entfernteren, bis sie zuletzt alle über dem Gegenstand dicht zusammen gebogen sind. Dies findet in einer Stunde bis zu vier oder fünf oder noch mehr Stunden statt. Die Verschiedenheit in der hierzu erforderlichen Zeit hängt von vielen Umständen ab, nämlich von der Grösse des Gegenstandes und dessen Beschaffenheit, das heiszt, ob er auflösliche Substanz der richtigen Art enthält, von der Lebenskraft und dem Alter des Blattes, ob es kürzlich in Thätig-keit gewesen ist, und der Angabe Nitschke’sBotan. Zeitung, 1860, p. 216. zufolge von der Temperatur des Tages, was auch mir der Fall zu sein schien. Ein lebendes Insect ist ein wirksamerer Gegenstand als ein totes, da es beim Sichsträuben die Drüsen vieler Fühler drückt. Ein Insect, wie z. B. eine Fliege, mit dünner Haut, durch welche die thierische Substanz in Auflösung leicht in die umgebende dicke Absonderung dringen kann, ist viel wirksamer, eine verlängerte Einbiegung zu verursachen, als ein Insect mit einer dicken Haut wie ein Käfer. Die Einbiegung der Tentakeln findet ohne Unterschied im Licht und in der Dunkelheit statt, und die Pflanze bietet keine nächtliche Bewegung eines sogenannten Pflanzenschlafes dar.

# Reaktion auf Berührung

Wenn die Drüsen auf der Blattscheibe wiederholt berührt oder bestrichen werden, wenn auch kein Gegenstand auf ihnen liegen gelassen wird, so biegen sich die randständigen Tentakeln doch einwärts. Ferner, wenn Tropfen von verschiedenen Flüssigkeiten, von Speichel oder einer Auflösung von irgend einem Ammoniaksalz auf die mittelsten Drüsen gebracht werden, so tritt schnell dasselbe Resultat ein, zuweilen in weniger als einer halben Stunde.

# Bewegung der Tentakeln

Die Tentakeln durchlaufen einen weiten Raum im Acte der Einbiegung; so bewegt sich ein randständiger Tentakel, welcher in einer Ebene mit der Blattscheibe ausgestreckt war, durch einen Winkel von 180°; und ich habe die stark zurückgebognen Tentakeln eines Blattes, welches aufrecht stand, sich durch einen Winkel von nicht weniger als 270° bewegen sehen. Der sich biegende Theil ist beinahe gänzlich auf einen kurzen Raum in der Nähe der Basis beschränkt; aber eine im Ganzen grössere Partie der verlängerten äusseren Tentakeln wird unbedeutend gebogen; die der Spitze nähere Hälfte bleibt in allen Fällen gerade. Die kurzen Tentakeln in der Mitte der Scheibe werden, wenn sie direct gereizt werden, nicht eingebogen, sind aber einer Einbiegung fähig, wenn sie durch einen motorischen Reiz erregt werden, welchen sie von andern Drüsen in einer gewissen Entfernung erhalten.

# Einfluss von Reizstoffen

Wenn z. B. ein Blatt in einen Aufguss von rohem Fleisch oder in eine schwache Auflösung von Ammoniak (wenn die Auflösung nur ein wenig stark ist, wird das Blatt paralysiert) eingetaucht wird, so biegen sich alle die äusseren Tentakeln nach innen, ausgenommen die nahe der Mitte, welche gerade aufrecht stehen bleiben; es biegen sich aber dieselben nach irgend einem reizenden Gegenstand hin, der auf die eine Seite der Blattscheibe gelegt wird. Die Drüsen bilden, wie man sehen kann, einen dunklen Ring um die Mitte herum, und dies ist eine Folge davon, dass die äusseren Tentakeln in einem richtigen Verhältnis an Länge zunehmen, je nachdem sie dem Blattrande näher stehen.# Die Biegung der Tentakeln

Die Art der Biegung, welcher die Tentakeln unterliegen, zeigt sich am Besten, wenn die Drüse eines der langen äuszeren Tentakeln auf irgend eine Art gereizt wird; denn die umgebenden bleiben dabei unberührt. In der beifolgenden Umriszzeichnung (Fig. 6) sehen wir einen Tentakel, auf welchen ein Theilchen Fleisch gethan worden war, dadurch nach der Mitte des Blattes zu gebogen, mit zwei anderen, welche ihre gewöhnliche Stellung beibehalten. Eine Drüse kann einfach dadurch, dasz man sie drei- oder viermal berührt, gereizt werden, oder durch länger andauernde Berührung mit organischen oder unorganischen Gegenständen und verschiedenen Flüssigkeiten. Ich habe durch die Loupe ganz deutlich gesehen, wie ein Tentakel anfieng, in zehn Secunden sich zu biegen, nachdem ein Gegenstand auf seine Drüse gebracht worden war, und ich habe oft eine deutlich ausgesprochene Einbiegung in kürzerer Zeit als einer Minute eintreten sehen. Es ist überraschend, was für kleine Theilchen irgend einer Substanz, solche wie ein Stückchen Faden oder Haar oder ein Splitter Glas, wenn sie in thatsächliche Berührung mit der Oberfläche der Drüse gebracht werden, genügen, den Tentakel zum Biegen zu veranlassen. Wenn der Gegenstand, welcher durch diese Bewegungen in die Mitte geschafft worden ist, nicht sehr klein ist, oder wenn er auflösliche stickstoffhaltige Substanzen enthält, so wirkt er auf die mittleren Drüsen und diese theilen den äuszeren Tentakeln einen motorischen Impuls mit, welcher sie veranlaszt, sich nach innen einzubiegen.

# Die Reaktion der Blattscheibe

Nicht nur die Tentakeln, sondern oft auch die Scheibe des Blattes, aber durchaus nicht immer, wird stark eingebogen, wenn irgend eine stark reizende Substanz oder Flüssigkeit auf die Scheibe gebracht wird. Tropfen von Milch und von einer Auflösung von salpetersaurem Ammoniak oder Natron sind besonders geneigt, diese Wirkung hervor-zubringen. Die Scheibe wird so in eine kleine Schale verwandelt. Die Art, auf welche sie sich biegt, variirt sehr. Manchmal wird blosz die Spitze, manchmal die eine, manchmal beide Seiten eingebogen. Ich that z. B. Stückchen eines hartgekochten Eies auf die Blätter; eins hatte die Spitze nach der Basis zu gebogen, das zweite hatte beide entgegengesetzten Ränder sehr eingebogen, so dasz es beinah dreieckig im Umrisz wurde, und dieses ist vielleicht der gewöhnlichste Fall, während die dritte Scheibe durchaus gar nicht afficirt wurde, obgleich die Tentakeln genau so dicht eingebogen waren, wie in den beiden vorhergehenden Fällen. Gewöhnlich erhebt sich auch oder biegt sich die ganze Scheibe aufwärts und bildet so einen kleineren Winkel mit dem Stiel als vorher. Dies erscheint auf den ersten Blick als eine bestimmte Art von Bewegung, aber sie geht aus der Einbiegung des Theils des Randes hervor, welcher an den Stiel befestigt ist, wodurch die Scheibe als ein Ganzes sich zu krümmen oder nach oben zu bewegen veranlaszt wird.

# Einfluss der äußeren Bedingungen

Die Länge der Zeit, während welcher die Tentakeln sowohl als die Scheibe über einen auf der letztern liegenden Gegenstand zusammen gebogen bleiben, hängt von verschiedenen Umständen ab; nämlich von der Lebenskraft und dem Alter des Blattes, und der Angabe Dr. Nitschke’s zufolge, von der Temperatur, denn während kaltem Wetters, wenn die Blätter unthätig sind, strecken sie sich in einer früheren Zeit wieder aus, als wenn das Wetter warm ist. Aber die Beschaffenheit des fremden Körpers ist bei Weitem der wichtigste Umstand; ich habe wiederholt gefunden, dasz die Tentakeln eine durchschnittlich viel längere Zeit über Gegenständen zusammen geschlagen bleiben, welche auflösliche, stickstoffhaltige Substanzen darbieten, als über solchen, mögen es nun organische oder unorganische sein, welche keine solche Substanz hergeben. Nach einer von einem bis zu sieben Tagen variirenden Periode strecken sich die Tentakeln wieder aus und sind dann bereit, von Neuem in Thätigkeit zu treten.# Absonderung der Drüsen

Die Absonderung der Drüsen ist auszerordentlich klebrig, so dasz sie in lange Fäden aufgezogen werden kann. Sie erscheint farblos, aber färbt kleine Kugeln von Papier blasz rosa. Ein Gegenstand irgend welcher Art verursacht, wie ich glaube, wenn er auf die Drüse gelegt wird, eine noch reichlichere Absonderung; aber schon die blosze Anwesenheit des Körpers macht es schwierig, dies festzustellen. In einigen Fällen jedoch war die Wirkung deutlich bemerkbar, so wenn Teilchen von Zucker dazu gethan wurden; das Resultat ist aber in diesem Falle wahrscheinlich eine Folge der Exosmose. Stückchen von kohlen-sauren und phosphorsaurem Ammoniak und einigen andren Salzen, z. B. schwefelsaurem Zink, vermehren gleichfalls die Absonderung.

# Reizung durch Lösungen

Das Eintauchen in eine Lösung von einem Teil Gold-Chlorid oder einigen andren Salzen auf 437 Teile Wasser reizt die Drüse zu einer bedeutend verstärkten Absonderung an; auf der andern Seite bringt weinsteinsaures Antimon keine solche Wirkung hervor. Das Eintauchen in viele Säuren (ein Teil auf 437 Teile Wasser, stark) verursacht ebenfalls eine wunderbare Menge Absonderung, so dasz, wenn die Blätter herausgenommen werden, lange Fäden von auszerordentlich zäher Flüssigkeit von ihnen herabhängen. Andrerseits wirken einige Säuren nicht auf diese Weise. Die verstärkte Absonderung hängt nicht nothwendigerweise von der Einbiegung der Tentakeln ab, denn Teilchen von Zucker und schwefelsaurem Zink verursachen keine solche Bewegung.

# Einfluss der Tentakeln

Es ist eine viel merkwürdigere Thatsache, dasz wenn ein Gegenstand, wie ein Stückchen Fleisch oder ein Insect auf die Scheibe des Blattes gelegt wird, sobald die umgebenden Tentakeln beträchtlich eingebogen werden, ihre Drüsen eine verstärkte Menge von Absonderung ergießen. Ich vergewisserte mich dieser Thatsache dadurch, dasz ich Blätter mit gleich großen Tropfen auf beiden Seiten auswählte und Stückchen Fleisch auf die eine Seite der Scheibe that; sobald als die Tentakeln auf dieser Seite sehr eingebogen wurden, aber noch ehe die Drüsen das Fleisch berührten, wurden die abgesonderten Tropfen größer. Dies wurde wiederholt beobachtet, aber nur dreizehn Fälle wurden protokolliert; in neun derselben wurde verstärkte Absonderung deutlich bemerkt; dasz vier Versuche misslangen, daran war Schuld, entweder, dasz die Blätter im Ganzen torpid, oder dasz die Stückchen Fleisch zu klein waren, um eine starke Einbiegung zu verursachen. Wir müssen daher schließen, dasz die mittleren Drüsen, wenn sie stark gereizt werden, einen gewissen Einfluss auf die Drüsen der randständigen Tentakeln äußern, welcher dieselben veranlasst, reichlicher abzusondern.

# Veränderung der Absonderung

Es ist eine noch bedeutungsvollere Thatsache (wie wir noch ausführlicher sehen werden, wenn wir die verdauende Kraft des Secrets behandeln), dasz, wenn die Tentakeln eingebogen werden, in Folge davon, dasz die mittleren Drüsen mechanisch oder durch Berührung mit thierischer Substanz gereizt worden sind, die Absonderung nicht nur an Menge zunimmt, sondern auch ihre Beschaffenheit verändert und sauer wird; und zwar findet dies statt, ehe die Drüsen den Gegenstand auf der Mitte des Blattes berührt haben. Diese Säure ist von einer andern Art als die, welche in dem Gewebe der Blätter enthalten ist. So lange die Tentakeln dicht zusammen gebogen bleiben, fahren die Drüsen fort, abzusondern, und die Absonderung ist sauer, so dasz sie, wenn sie durch kohlensaures Natron neutralisiert wird, nach wenigen Stunden wieder sauer wird. Ich habe beobachtet, dasz dasselbe Blatt, mit den Tentakeln über ziemlich unverdauliche Substanzen, wie chemisch präpariertes Casein, dicht eingebogen, acht aufeinander folgende Tage lang saure Absonderung ergoss, und zehn aufeinander folgende Tage lang über Stückchen Knochen.# Antiseptische Kraft der Drosera

Ich brachte während sehr warmen Wetters zwei gleich grosze Stückchen rohen Fleisches dicht neben einander, eins auf ein Blatt der Drosera, das andere in feuchtes Moos eingewickelt. Sie wurden 48 Stunden so gelassen und dann untersucht. In dem Stück im Moos schwärmten zahllose Infusorien; es war so verwest, dasz die queren Streifen der Muskelfasern nicht mehr deutlich unterschieden werden konnten; während das Stück auf dem Blatt, welches in die Absonderung eingetaucht war, von Infusorien frei war und seine Querstreifen in dem mittleren unverdautem Theil völlig deutlich erkennen liesz.

# Wirkung der Drosera auf Eiweiß und Käse

In gleicher Weise wurden kleine würfel-förmige Stückchen Eiweisz und Käse in feuchtem Moos von Schimmel-fäden überzogen, und ihre Oberfläche wurde leicht entfärbt und zer-setzt, während die auf den Blättern der Drosera rein blieben, wobei gleichzeitig das Eiweisz in durchsichtige Flüssigkeit verwandelt wurde.

# Verhalten der Tentakeln

Sobald Tentakeln, welche mehrere Tage über einem Gegenstand dicht eingebogen gewesen sind, anfangen, sich wieder auszustrecken, sondern ihre Drüsen weniger reichlich ab, oder hören ganz auf, abzu-sondern und bleiben trocken: in diesem Stadium werden sie von einem Häutchen von weiszlicher halbfasriger Substanz überzogen, welches durch die Absonderung in Auflösung erhalten worden war.

# Trocknen der Drüsen

Das Trocknen der Drüsen während des Actes des Ausstreckens ist von einem kleinen Nutzen für die Pflanze; denn ich habe oft beobachtet, dasz Gegenstände, die an den Blättern klebten, dann mit einem Luftzug fortgeblasen werden konnten; auf diese Weise bleiben die Blätter un-belästigt und frei für künftige Functionirung.

# Zerstörung von Insekten

Demohngeachtet geschieht es oft, dasz sämmtliche Drüsen nicht vollständig trocken werden und in diesem Falle werden oft zarte Gegenstände, wie zerbrech-liche Insecten, durch das Ausstrecken der Tentakeln in Stückchen zer-rissen, die dann über das ganze Blatt verstreut liegen bleiben.

# Wiederaufnahme der Absonderung

Nach vollständigem Wiederausstrecken fangen die Drüsen schnell wieder an abzusondern, und sobald Tropfen von gehöriger Grösze gebildet sind, sind die Tentakeln fähig, einen neuen Gegenstand zu umfassen.

# Fangmechanismus der Drosera

Wenn ein Insect sich auf der mittleren Scheibe niederläszt, so wird es augenblicklich von der klebrigen Absonderung verwickelt und die umgebenden Tentakeln fangen nach einiger Zeit an, sich zu biegen und umschlingen es endlich von allen Seiten. Gewöhnlich werden In-secten, wie Dr. Nitschke angibt, in einer Viertelstunde getödtet und zwar in Folge davon, dasz ihre Tracheen durch die Absonderung verschlossen werden.

# Transport der Beute

Wenn ein Insect nur einigen Drüsen der äuszeren Tentakeln anklebt, so werden diese bald eingebogen und bringen ihre Beute zu den Tentakeln, die ihnen am Nächsten nach innen folgen; diese biegen sich dann einwärts und so geht es fort, bis das Insect endlich durch eine sonderbare Art von rollender Bewegung in die Mitte des Blattes geschafft worden ist.

# Überraschende Effizienz

Es ist über-raschend, ein wie kleines Insect schon genügend ist, diese Handlung zu verursachen; z. B. habe ich eine der kleinsten Arten Mücken (Culex) gesehen, die sich gerade mit ihren auszerordentlich zarten Füszchen auf die Drüsen der äussersten Tentakeln gesetzt hatte; diese fiengen schon an, sich nach innen zu biegen, obgleich noch keine ein-zige Drüse bis jetzt den Körper des Insects berührt hatte.

# Anziehung durch Absonderung

Wäre ich nicht dazwischen gekommen, so würde diese kleine Mücke ganz gewisz in die Mitte des Blattes gebracht und von allen Seiten sicher um-schlungen worden sein. Wir werden späterhin sehen, was für auszer-ordentlich kleine Dosen von gewissen organischen Flüssigkeiten und salzigen Lösungen eine stark ausgesprochene Einbiegung verursachen.

# Ungewissheit über Anziehung

Ob die Insecten sich nun durch bloszen Zufall auf den Blättern niederlassen, als auf einem Ruheplatz, oder ob sie durch den Geruch der Absonderung angezogen werden, weisz ich nicht. Ich vermuthe wegen der groszen Anzahl Insecten, die von den englischen Species der Drosera gefangen werden, und nachdem, was ich an tropischen# Beobachtungen im Gewächshaus

Species, die in meinem Gewächshaus gehalten wurden, beobachtet habe, dasz der Geruch anziehend ist. In diesem letzten Fall können die Blätter mit einer Köder enthaltenden Falle verglichen werden, in dem ersten Fall mit einer Falle, die auf einen, vom Wild häufig besuchten Weg gelegt ist, aber ohne Köder.

## Aufsaugung der Drüsen

Dasz die Drüsen die Kraft der Aufsaugung besitzen, wird dadurch bewiesen, dasz sie beinahe augenblicklich dunkelfarbig werden, wenn man ihnen eine kleine Quantität kohlensaures Ammoniak gibt; die Farbenveränderung ist hauptsächlich oder ausschlieszlich Folge der rapiden Zusammenballung ihres Inhalts. Wenn gewisse andere Flüssig- keiten dazu gethan werden, so werden sie blasz gefärbt. Ihr Absorp- tionsvermögen zeigt sich jedoch am Besten in den verschiedenen Resul- taten, welche sich ergeben, wenn man Tropfen verschiedener stickstoff- haltiger und nicht stickstoffhaltiger Flüssigkeiten, von derselben Dichte auf die Drüsen der Scheibe, oder auf eine einzige Drüse bringt; eben- so auch durch die sehr verschiedene Länge der Zeit, während welcher die Tentakeln über den Gegenständen, welche lösliche stickstoff haltige Substanzen darbieten, oder nicht enthalten, gebogen bleiben. Dieser selbe Schlusz könnte in der That auch aus der Structur und den Bewegungen der Blätter, welche so bewunderungswürdig zum Fangen der Insecten eingerichtet sind, gezogen werden.

## Ernährung der Drosera

Die Aufsaugung animaler Substanz aus den gefangenen Insecten erklärt es, wie die Drosera in auszerordentlich armem torfigen Boden gedeihen kann, in einigen Fällen da, wo nichts als Sphagnum-Moos wächst; und Moose hängen überhaupt in Bezug auf ihre Nahrung nur von der Atmosphäre ab. Obgleich die Blätter auf einen flüchtigen Blick nicht grün erscheinen, was eine Folge der purpurnen Färbung der Tentakeln ist, so enthalten doch die obere und untere Fläche der Scheibe, die Stiele der mittleren Tentakeln und die Blattstiele Chlorophyll, so dasz die Pflanze ohne Zweifel von der Luft Kohlensäure aufnimmt und assimilirt. Demohngeachtet würde, wenn man die Art des Bodens bedenkt, worauf sie wächst, die Zufuhr von Stickstoff auszerordentlich beschränkt, oder ganz ungenügend sein, wenn die Pflanze nicht die Fähigkeit hätte, dieses wichtige Element aus den gefangnen Insecten zu entnehmen. Wir können hiernach verstehen, wie es kommt, dass die Wurzeln so dürftig entwickelt sind. Diese bestehen gewöhnlich aus nur zwei oder drei leicht getheilten Zweigen, von einem halben bis einen Zoll Länge, welche mit aufsaugenden Haaren ausgestattet sind. Danach scheint es, als ob die Wurzeln nur zum Aufsaugen von Wasser dienten; obgleich, wenn solche sich im Boden fände, sie ohne Zweifel auch nährbare Substanz aufsaugen würden; denn wie wir später sehen werden, absorbiren sie eine schwache Lösung von kohlensaurem Ammoniak. Von einer Drosera-Pflanze, an welcher die Ränder der Blätter nach innen gerollt sind, so dasz sie einen zeit- weiligen Magen bilden, und an welcher die Drüsen der dicht einge- bognen Tentakeln ihre sauere Absonderung ergieszen, welche animale, später zum Aufsaugen bestimmte Substanz auflöst, kann man sagen, dasz sie sich wie ein Thier ernährt. Aber verschieden von einem Thier trinkt sie mit ihren Wurzeln; und sie musz viel trinken, um die vielen Tropfen der zähen Flüssigkeit, die um die Drüsen herum liegen, manchmal bis zu 260, und welche während des ganzen Tages der brennen- den Sonne ausgesetzt sind, erhalten zu können.

# Zweites Capitel

Die Bewegung der Tentakeln bei der Berührung mit festen Körpern. Die Einbiegung der äuszeren Tentakeln in Folge der Reizung der Drüsen auf der Scheibe durch wiederholtes Berühren oder durch Gegenstände, die in Berührung mit ihnen gelassen werden. — Die Verschiedenheit in der Wirkung von Körpern, welche lösliche stickstoff haltige Substanz geben, und solchen, welche dergleichen nicht geben. — Die Einbiegung der äuszeren Tentakeln direct verursacht durch Gegenstände, die mit ihren Drüsen in Berührung gelassen.# Einleitung
werden. — Zeitliche Verhältnisse der beginnenden Einbiegung und der nachfolgenden Streckung. — Die auszerordentliche Kleinheit der Theilchen, welche Einbiegung verursachen. — Wirkung unter Wasser. — Die Einbiegung der äuszeren Tentakeln, wenn ihre Drüsen durch wiederholtes Berühren gereizt werden. — Fallende Wassertropfen verursachen keine Einbiegung.

# Experimente und Beobachtungen
Ich werde in diesem und den folgenden Capiteln einige der vielen von mir angestellten Experimente mittheilen, welche am Besten die Art und die Schnelligkeit der Bewegungen der Tentakeln, wenn sie verschiedenartig gereizt werden, illustriren. Nur die Drüsen allein sind in allen gewöhnlichen Fällen für Reizung empfänglich. Wenn sie gereizt werden, bewegen sie sich und verändern sie ihre Form nicht selbst, sondern übermitteln einen motorischen Reiz dem sich biegenden Theil ihrer eignen und der nahe stehenden Tentakeln, wodurch sie nach der Mitte des Blattes gebracht werden. Genau gesprochen, sollten eigentlich die Drüsen reizbar genannt werden, da der Ausdruck empfindlich gewöhnlich mit der Idee eines Bewusztseins verbunden wird; aber Niemand vermuthet, dasz die empfindliche Pflanze (Sinnpflanze) bewuszt ist, und da ich den Ausdruck bequem gefunden habe, so werde ich ihn ohne Bedenken benutzen.

# Indirekte Reizung der Tentakeln
Ich will mit der Bewegung der Tentakeln anfangen, wenn sie indirect durch Reizmittel, welche auf die Drüsen der kurzen Tentakeln gebracht sind, gereizt werden. Die äuszeren Tentakeln werden in diesem Falle, wie man sagen kann, indirect gereizt, weil nicht direct auf ihre eignen Drüsen eingewirkt wird. Der Reiz, welcher von den Drüsen auf der Scheibe ausgeht, wirkt auf den sich biegenden Theil der äuszeren Tentakeln in der Nähe ihrer Basis und geht nicht erst (wie später bewiesen werden soll) die Stiele hinauf zu den Drüsen, um von da nach der sich biegenden Stelle zurück gesandt zu werden. Demohngeachtet geht doch ein gewisser Einflusz hinauf zu den Drüsen, welcher dieselben veranlaszt, reichlicher abzusondern, und welcher die Absonderung sauer macht. Diese letztere Thatsache ist, glaube ich, ganz neu in der Physiologie der Pflanzen; es ist in der That erst neuerdings ermittelt worden, dasz im Thierreich den Nerven entlang ein Reiz Drüsen übermittelt werden kann, welcher deren Kraft abzusondern unabhängig von dem Zustande der Blutgefäsze modificirt.

# Reizung der Drüsen
Die Einbiegung der äuszeren Tentakeln in Folge der Reizung der Drüsen auf der Scheibe durch wiederholtes Berühren oder durch Gegenstände, die in Berührung mit ihnen gelassen werden. Die mittleren Drüsen eines Blattes wurden vermittelst eines kleinen steifen Pinsels von Kameelhaaren gereizt und in 70 Minuten waren mehrere der äuszersten Tentakeln eingebogen; am nächsten Morgen waren sie nach einer Zwischenzeit von 22 Stunden wieder vollständig ausgestreckt. In allen folgenden Fällen wird die Periode von der Zeit der ersten Reizung an gerechnet. Ein anderes Blatt, welches auf die gleiche Art behandelt wurde, hatte in 20 Minuten einige wenige Tentakeln eingebogen; in vier Stunden waren alle dem Rande nahe stehenden und einige der äuszersten randständigen Tentakeln sowohl als der Rand des Blattes selbst eingebogen; in 17 Stunden hatten sie ihre gewöhnliche gestreckte Stellung wieder erlangt.

# Weitere Experimente
Ich legte dann eine todte Fliege auf die Mitte des zuletzt erwähnten Blattes, und am nächsten Morgen war sie dicht umfaszt. Fünf Tage später war das Blatt wieder ausgebreitet und die Tentakeln mit ihren von Absonderung umgebenen Drüsen waren von Neuem zu handeln bereit. Stückchen von Fleisch, todte Fliegen, Stückchen Papier, Holz, getrocknetes Moos, Schwamm, Kohle, Glas u. s. f. wurden wiederholt auf Blätter gelegt und alle diese Gegenstände waren in verschieden langer Zeit, von 1 Stunde bis zu 24 Stunden, ordentlich umfaszt und in einem oder zwei bis zu sieben oder selbst zehn Tagen, je nach der Natur des Gegenstandes, wieder frei gelassen und das Blatt wieder vollständig ausgebreitet. Ich legte auf ein Blatt, welches in natürlicher Weise zwei Fliegen gefangen und sich daher schon ein oder# Beobachtungen über die Bewegung von Pflanzen

## Einleitung
wahrscheinlicher zwei Mal geschlossen und wieder geöffnet hatte, eine frische Fliege: in 7 Stunden war sie mäszig und in 21 Stunden durchaus fest umfaszt, wobei die Ränder des Blattes eingebogen waren.

## Reaktion auf Insekten
In zwei und einem halben Tag hatte sich das Blatt beinahe ganz wieder ausgebreitet; da der reizende Gegenstand ein Insect war, so war diese ungewöhnlich kurze Periode der Einbiegung ohne Zweifel Folge davon, dasz das Blatt erst kürzlich in Thätigkeit gewesen war.

## Experimentelle Beobachtungen
Ich gestattete diesem selben Blatt, nur einen Tag auszuruhen und that dann eine andere Fliege darauf; es schlosz sich wieder, aber jetzt sehr langsam; demohngeachtet gelang es ihm, in weniger als zwei Tagen die Fliege vollkommen zu umfassen.

## Einfluss der Position
Wenn ein kleiner Gegenstand auf die Drüsen der Scheibe auf der einen Seite des Blattes und so nahe wie möglich seiner Peripherie ge-
bracht wird, so werden die Tentakeln auf dieser Seite zuerst afficirt, die auf der andern Seite viel später oder gar nicht, wie es häufig vor-
kommt.

## Weitere Experimente
Dies wurde wiederholt durch Versuche mit Stückchen Fleisch bestätigt; aber ich will hier nur den Fall von einer kleinen Fliege anführen, die auf natürlichem Wege gefangen und noch lebendig war, und die ich mit ihren zarten Füszen an den Drüsen auf der äuszersten linken Seite der mittleren Scheibe ankleben fand.

## Reaktion auf verschiedene Substanzen
Wenn junge und lebendige Blätter ausgesucht werden, so ver-
ursachen zuweilen unorganische Theile, nicht gröszer wie ein Steck-
nadelkopf, wenn sie auf die mittleren Drüsen gethan werden, eine Bie-
gung der äuszeren Tentakeln nach innen.

## Ungewöhnliche Beobachtungen
Aber dies erfolgt viel sich-
rer und schneller, wenn der Gegenstand stickstoffhaltige Substanz ent-
hält, welche durch die Absonderung aufgelöst werden kann.

## Vergleich von Substanzen
Bei einer Gelegenheit beobachtete ich den folgenden ungewöhnlichen Umstand. Kleine Stückchen rohen Fleisches (welches viel energischer wirkte als irgend eine andere Substanz), Stückchen Papier, getrocknetes Moos und Schnittchen von einem Federkiel wurden auf mehrere Blätter ge-
legt und sie waren sämmtlich in zwei Stunden gleich gut umfaszt.

## Einfluss von Kohlenasche und anderen Materialien
Ferner wurden Theile von Kohlenasche (welche etwas mehr wogen als die Fliegen, die im letzten Experiment angewandt worden waren) auf die Mitte von drei Blättern gethan: nach Verlauf von 19 Stunden war eines der Theilchen ziemlich fest umfaszt, das zweite von sehr wenig Tentakeln und das dritte von gar keinem.# Einleitung zu den Experimenten

die Theilchen von den zwei letzten Blättern und that frisch getödtete Fliegen darauf. Diese waren nach 7½ Stunden ziemlich fest umfaszt und nach 20½ Stunden ganz ordentlich; die Tentakeln blieben viele Tage lang eingebogen. Auf der andern Seite war das eine Blatt, welches in der Zeit von 19 Stunden das Stückchen Asche mäszig gut umfaszt hatte und welchem keine Fliege gegeben worden war, nach 33 weiteren Stunden, (d. h. in 52 Stunden von der Zeit an, wo die Asche aufgelegt worden war) vollständig wieder ausgebreitet und zu neuer Thätigkeit bereit.

# Ergebnisse der Experimente

Aus diesen und zahlreichen anderen Experimenten, die des Erwähnens nicht werth sind, läszt sich als gewisz ableiten, dasz unorganische Substanzen oder solche organische Substanzen, die von der Absonderung nicht angegriffen werden, viel weniger schnell und wirksam reizen als organische Substanzen, welche lösliche Substanz hergeben, die aufgesaugt wird.

# Tentakeln und organische Substanzen

Auzerdem bin ich sehr wenigen Ausnahmen von der Regel begegnet, dasz die Tentakeln eine viel längere Zeit über organischen Körpern von der eben erst angeführten Art geschlossen bleiben, als über denjenigen, auf welche die Absonderung nicht wirkt oder über unorganischen Gegenständen, und diese Ausnahmen hiengen augenscheinlich davon ab, dasz das Blatt erst vor kurzer Zeit in Thätigkeit gewesen war.

# Ziegler und die Wirkung von Substanzen

Wegen der auszerordentlichen, von Ziegler vorgebrachten Ansicht (Comptes rendus, Mai, 1872, p. 122), dasz eiweiszhaltige Substanzen die Eigenschaft, die Tentakeln der Drosera zur Zusammenziehung zu bringen, dadurch erlangen, dasz sie einen Moment lang zwischen den Fingern gehalten werden, während nicht so gehaltene Substanzen diese Fähigkeit nicht besitzen sollen, stellte ich einige Experimente mit groszer Sorgfalt an; die Resultate bestätigten aber diese Ansicht nicht.

# Versuche mit verschiedenen Materialien

Rothglühende Kohlenstückchen wurden aus dem Feuer genommen, Stückchen von Glas, baumwollenem Garne, Löschpapier und dünne Scheibchen Kork wurden in kochendes Wasser getaucht; dann wurden solche Theilchen (und jedes Instrument, womit sie berührt wurden, war vorher in kochendes Wasser getaucht worden) auf die Drüsen von mehreren Blättern gelegt und sie wirkten in genau derselben Weise wie andere Theilchen, welche absichtlich eine Zeit lang berührt worden waren.

# Einfluss von Gerüchen und Dämpfen

Ich athmete länger als eine Minute auf einige Blätter und wiederholte dies zwei oder drei Male, wobei ich meinen Mund dicht an ihnen hielt, brachte aber keine Wirkung hervor. Ich will hier noch als Beweis, dasz die Blätter nicht durch den Geruch stickstoffhaltiger Substanzen beeinfluszt werden, hinzufügen, dasz Stückchen rohen Fleisches auf Nadeln so dicht als möglich an mehreren Blättern, aber ohne wirkliche Berührung befestigt wurden, dasz dies aber durchaus gar keine Wirkung hervorbrachte.

# Wirkung von flüchtigen Substanzen

Andererseits verursachen, wie wir später sehen werden, die Dämpfe gewisser flüchtiger Substanzen und Flüssigkeiten, so z. B. kohlensaures Ammoniak, Chloroform, gewisse ätherische Oele, Einbiegung. Ziegler macht in Bezug auf die Wirkung animaler Substanzen, welche dicht an, aber nicht in Berührung mit schwefelsaurem Chinin gelassen wurden, auf diese Substanz noch auszerordentlichere Angaben.

# Weitere Untersuchungen zu Chininsalzen

Die Wirkung von Chininsalzen wird in einem spätern Capitel geschildert werden. Seit dem Erscheinen des oben erwähnten Aufsatzes hat Ziegler ein Buch über denselben Gegenstand veröffentlicht unter dem Titel: „Atonicité et Zoicité‟, 1874.

# Einbiegung der äuszeren Tentakeln

Die Einbiegung der äuszeren Tentakeln durch Gegenstände, die mit ihren Drüsen in Berührung gelassen werden, direct verursacht. Ich machte eine ungeheure Menge Versuche, indem ich vermittels einer feinen Nadel, die mit destillirtem Wasser angefeuchtet war, und mit Hülfe einer Loupe Theilchen von verschiedenen Substanzen auf die zähe Absonderung der Drüsen der äuszeren Tentakeln legte.

# Experiment an Drosera rotundifolia

Ich experimentirte sowohl an den ovalen als an den langköpfigen Drüsen. Wenn ein Theilchen in dieser Weise auf eine einzige Drüse...# Einleitung

# Bewegung der Tentakeln

# Einfluss von Fleischstückchen

# Beobachtungen mit Fliegen

# Versuch mit Papierkugeln

# Kohle und ihre Bewegung

# Weitere Experimente mit verschiedenen Substanzen# Einleitung zur Untersuchung

# Drosera rotundifolia

# Experimentelle Methodik

# Ergebnisse der Versuche

# Beobachtungen zur Tentakelnbewegung

# Schlussfolgerungen und Ausblick# Kleinheit der Theilchen und ihre Wirkung

Kleinheit der Theilchen, welche eine Bewegung verursachten, sondern auch dadurch, wie sie möglicherweise auf die Drüsen wirken konnten; denn man musz sich erinnern, dasz sie mit der gröszten Sorgfalt auf die convexe Oberfläche des Secrets gelegt wurden. Zuerst dachte ich — aber irriger Weise, wie ich jetzt weisz —, dasz Theilchen von solch geringem specifischem Gewicht, wie Kork, Faden und Papier, nie mit der Oberfläche der Drüsen in Berührung kommen würden. Die Theil- chen können nicht einfach dadurch wirken, dasz ihr Gewicht dem des Secrets zugefügt wird, denn kleine Wassertropfen, die viel Mal schwe- rer als die Theilchen waren, wurden wiederholt hinzugethan und brach- ten niemals irgend eine Wirkung hervor. Ebenso wenig bringt die Störung der Absonderung irgend eine Wirkung hervor; denn mit einer Nadel wurden lange Fäden herausgezogen und an einem sich in der Nähe befindlichen Gegenstand befestigt und Stunden lang so gelassen; aber die Tentakeln blieben bewegungslos.

# Experimente mit Drüsen und Licht

Ich entfernte auch sorgfältig mit einem scharf zugespitztem Stück Löschpapier das Secret von vier Drüsen, so dasz sie eine Zeit lang nackt der Luft ausgesetzt waren; aber dies verursachte keine Bewegung, und doch waren diese Tentakeln in einem functionsfähigen Zustand; denn nachdem 24 Stunden vorüber waren, wurden sie mit Stückchen Fleisch versucht und alle wurden schnell eingebogen. Es kam mir dann der Gedanke, dasz Theilchen, welche auf der Absonderung schwäm- men, Schatten auf die Drüsen werfen könnten, welche gegen den ge- hemmten Einflusz des Lichts empfindlich sein könnten. Obgleich dies sehr unwahrscheinlich schien, da äuszerst kleine und dünne Splitter von farblosem Glas mächtig wirkten, so that ich doch, nachdem es dunkel war, beim Lichte eines einzigen Talglichts so schnell als mög- lich Theilchen Kork und Glas auf die Drüsen von einem Dutzend Drosera rotundifolia. Cap. 2. Tentakeln, ebenso wie Stückchen Fleisch auf andere Drüsen und be- deckte sie so, dasz kein Lichtstrahl eindringen konnte; aber am näch- sten Morgen, nach Verlauf von 13 Stunden, waren alle Theilchen nach dem Centrum der Blätter hingeschafft worden.

# Weitere Experimente und Beobachtungen

Die negativen Resultate führten mich dazu, noch viele andere Experimente anzustellen, indem ich Theilchen auf die Oberfläche der Tropfen der Absonderung legte und dabei so sorgfältig, als ich konnte, beobachtete, ob sie durchdrangen und die Oberfläche der Drüsen be- rührten. Das Secret bildet in Folge seines Gewichts gewöhnlich eine dickere Lage auf der unteren als auf der oberen Seite der Drüsen, was auch immer die Stellung der Tentakeln sein mag. Kleine Stück- chen trocknen Korks, Faden, Löschpapier und Kohle wurden versucht, ähnlich den vorher angewendeten, und ich beobachtete nun, dasz sie im Verlaufe weniger Minuten viel mehr von der Absonderung auf- saugten, als ich für möglich gehalten haben würde; da sie auf die obere Fläche der Absonderung, wo sie am dünnsten ist, gelegt wor- den waren, so wurden sie oft nach einiger Zeit herunter gezogen und mit wenigstens einem Theil der Drüse in Berührung gebracht. In Bezug auf die kleinen Glassplitterchen und Haartheilchen beobachtete ich, dasz die Absonderung sich langsam ein wenig über ihre Ober- fläche ausbreitete, wodurch sie gleichfalls herunter oder seitwärts ge- zogen wurden; und so kam ein Ende oder irgend eine kleine Hervor- ragung dazu, die Drüse früher oder später zu berühren.

# Einfluss von Schwingungen und Experimentelle Ergebnisse

In den vorausgehenden und folgenden Fällen ist es wahrschein- lich, dasz die Schwingungen, welchen die Möbeln jedes Zimmers be- ständig ausgesetzt sind, dazu helfen, die Theilchen in Berührung mit den Drüsen zu bringen. Aber da es manchmal in Folge der Strahlen- brechung der Absonderung schwer war, darüber sicher zu sein, ob die Theilchen in Berührung waren, so stellte ich folgendes Experiment an. Ungewöhnlich minutiöse Theilchen Glas, Haar und Kork wurden sanft auf die Tropfen an mehreren Drüsen gelegt und sehr wenig Tentakeln bewegten sich. Die, welche nicht afficirt waren, wurden eine halbe Stunde ruhig gelassen; dann wurden die Theilchen gestört, oder mit einer feinen Nadel unter dem Mikroskop mehrere Male umgedreht, wobei die Drüsen nicht berührt wurden. Und nun fiengen im Laufe# Experimentelle Beobachtungen der Tentakelnbewegung

von wenig Minuten alle bis dahin bewegungslosen Tentakeln an, sich
zu bewegen; und dies wurde ohne Zweifel dadurch verursacht, dasz
ein Ende oder irgend ein hervorragender Punkt der Theilchen in Be
rührung mit der Oberfläche der Drüsen gekommen war. Aber da die
Theilchen gewöhnlich klein waren, so war auch die Bewegung gering.
Zuletzt wurde etwas dunkelblaues in feine Splitter gestosznes
Glas benutzt, damit die Spitzen der Theilchen, wenn sie in die Ab-
sonderung eingetaucht würden, besser unterschieden werden könnten;
und dreizehn solcher Theilchen wurden in Berührung mit dem unter-
hängenden und daher dickeren Theil der Tropfen von ebenso vielen
Drüsen gebracht. Fünf der Tentakeln fiengen nach Verlauf von weni-
gen Minuten an, sich zu bewegen, und in diesen Fällen sah ich deut-
lich, dasz die Theilchen die untere Oberfläche der Drüsen berührten.
Ein sechster Tentakel bewegte sich nach 1 Stunde 45 Minuten und
das Theilchen war nun in Berührung mit der Drüse, was zuerst nicht
der Fall war. So war es auch mit dem siebenten Tentakel, aber seine
Bewegung fieng nicht eher an, als bis 3 Stunden 45 Minuten verflossen
waren. Die übrigen sechs Tentakeln bewegten sich, so lange sie beob-
achtet wurden, gar nicht; die Theilchen kamen augenscheinlich niemals
mit der Oberfläche der Drüsen in Berührung.

# Schlussfolgerungen aus den Experimenten

Aus diesen Experimenten lernen wir, dasz Theilchen, die nicht-
lösliche Substanz enthalten, wenn sie auf die Drüsen gethan werden,
oft die Tentakeln veranlassen, im Laufe von einer bis zu fünf Minuten
anzufangen, sich zu biegen; und dasz in solchen Fällen die Theilchen
von Anfang an in Berührung mit der Oberfläche der Drüsen gewesen
sind. Wenn die Tentakeln erst nach einer viel längeren Zeit, näm-
lich von einer halben Stunde bis zu drei oder vier Stunden anfangen,
sich zu biegen, so sind die Theilchen langsam in Berührung mit den
Drüsen gekommen, entweder durch Aufsaugen der Absonderung durch
die Theilchen selbst, oder durch das allmähliche Ausbreiten des Se-
crets über sie, in Verbindung mit ihrer damit in Verbindung stehen-
den schnelleren Verdunstung. Wenn sich die Tentakeln gar nicht
bewegen, so sind die Theilchen nie mit den Drüsen in Berührung ge-
kommen, oder in einigen Fällen mögen die Tentakeln nicht in einem
activen Zustand gewesen sein. Um Bewegung zu erregen, ist es un-
erläszlich, dasz die Theilchen thatsächlich auf den Drüsen ruhen, denn
eine Berührung mit einem harten Körper, ein, zwei oder selbst drei
Mal wiederholt, ist nicht genügend, Bewegung zu erregen.

# Weitere Experimente mit kleinen Teilchen

Ein anderes Experiment, welches zeigt, dasz auszerordentlich kleine
Theilchen auf die Drüsen wirken, wenn sie unter Wasser getaucht
sind, soll hier angeführt werden. Ein Gran schwefelsaures Chinin
wurde zu einer Unze Wasser gethan, welches nachher nicht filtrirt
wurde; als ich nun drei Blätter in 90 Tropfen der Flüssigkeit that,
war ich sehr überrascht zu finden, dasz in 15 Minuten alle drei
Blätter stark eingebogen waren; denn ich wuszte von früheren Ver-
suchen her, dasz die Auflösung selbst nicht so schnell wirkt, wie hier
die Wirkung eintrat. Es kam mir sofort der Gedanke, dasz die
Theilchen des unaufgelösten Salzes, welche so leicht waren, dasz sie
umher schwammen, in Berührung mit den Drüsen gekommen sein
und diese schnelle Bewegung verursacht haben könnten. Demgemäsz
fügte ich zu etwas destillirtem Wasser eine Prise einer ganz un-
schuldigen Substanz, nämlich präcipitirten kohlensauren Kalk, welcher
ein unfühlbar feines Pulver bildet; ich schüttelte das Gemisch und
bekam so eine Flüssigkeit ähnlich dünner Milch. Zwei Blätter wur-
den darein getaucht und in 6 Minuten war beinahe jeder Tentakel
stark eingebogen. Ich that eins dieser Blätter unter das Mikroscop
und sah zahllose Atome von Kalk an der äusseren Fläche der Ab-
sonderung ankleben. Einige jedoch waren durchgedrungen und lagen
auf der Oberfläche der Drüsen; und es waren diese Theilchen ohne
Zweifel, welche die Tentakeln sich zu biegen veranlassten. Wenn ein
Blatt in Wasser getaucht wird, so schwillt das Secret augenblicklich
sehr auf, und ich vermuthe, dasz sie hier und da durchbrochen wird,# Einleitung

so dasz kleine Wasserströmchen hinein stürzen. Wenn dies der Fall ist, so können wir verstehen, wie die Atome Kreide, welche auf der Oberfläche der Drüsen lagen, die Absonderung durchdrungen hatten.

# Eigenschaften des Kreidestaubs

Jedermann, welcher präcipitirte Kreide zwischen seinen Fingern gerieben hat, wird bemerkt haben, wie auszerordentlich fein das Pulver ist. Es musz ohne Zweifel eine Grenze da sein, über welche hinaus die Theilchen zu klein sein würden, um auf die Drüse zu wirken; aber welches diese Grenze ist, weisz ich nicht.

# Einfluss von Staub und Fasern

Ich habe oft gesehen, dasz Fasern und Staub, die aus der Luft auf die Drüsen der Pflanzen gefallen waren, die in meinem Zimmer gehalten wurden, nie irgend eine Bewegung hervorriefen; aber dann lagen solche Theilchen auf der Oberfläche der Absonderung und erreichten nie die Drüse selbst.

# Motorische Impulse und ihre Ursachen

Endlich ist es eine auszerordentliche Thatsache, dasz ein kleines Stückchen weichen Fadens \frac {1}{50} Zoll lang und \frac {1}{8197} Gran schwer, oder von einem menschlichen Haar \frac {8}{1000} Zoll lang und nur \frac {1}{78740} Gran schwer (0,000822 Milligr.) oder Theilchen präcipitirter Kreide, nachdem sie kurze Zeit auf einer Drüse geruht haben, eine Veränderung in ihren Zellen hervorbringen, diese dazu reizen, einen motorischen Impuls durch die ganze Länge der Stiele, die aus ungefähr 20 Zellen bestehen, bis nah an die Basis zu schicken, wo sie diesen Theil zu biegen und den Tentakel durch einen Winkel von 180° zu schwingen veranlassen.

# Einfluss der kleinsten Teilchen

Dasz der Inhalt der Drüsenzellen und später auch der der Stiele in einer deutlich sichtbaren Weise durch den Druck der kleinsten Theilchen afficirt wird, dafür werden wir vollauf Beweise erhalten, wenn wir die Zusammenballung des Protoplasma behandeln.

# Merkwürdige Beobachtungen

Aber der Fall ist viel merkwürdiger, als wie bis jetzt angegeben ist, denn die Theilchen werden von der zähen und dichten Absonderung getragen; trotzdem wirken auch selbst noch kleinere als die von welchen die Masze angegeben wurden, wenn sie mit einer unmerkbar langsamen Bewegung auf die oben angeführte Weise mit der Oberfläche der Drüse in Berührung gebracht werden, auf dieselbe und der Tentakel biegt sich.

# Der Druck und seine Auswirkungen

Der Druck, der von einem Haartheilchen ausgeht, welches nur \frac {1}{78740} Gran wiegt und von einer dichten Flüssigkeit getragen wird, musz unfaszbar gering gewesen sein. Wir können muthmaszen, dasz er kaum einem Milliontel eines Grans gleich gewe- sen sein kann, und wir werden später sehen, dasz weit weniger als ein Milliontel eines Grans von phosphorsaurem Ammoniak in Auf- lösung, wenn es von einer Drüse aufgesaugt wird, auf dieselbe wirkt und Bewegung verursacht.

# Vergleich von Haar und Teilchen

Ein Stückchen Haar \frac {1}{50} Zoll lang und daher viel gröszer als diejenigen, die in den oben erwähnten Experimenten gebraucht wurden, wurde nicht gefühlt als es auf meiner Zunge lag, und es ist auszerordentlich zweifelhaft, ob irgend welcher Nerv in dem menschlichen Körper, selbst wenn derselbe in einem entzündeten Zustand ist, in irgend einer Weise durch solch ein Theilchen afficirt werden würde, welches von einer dichten Flüssigkeit getragen und langsam mit dem Nerv in Berührung gebracht würde.

# Reizung der Drüsenzellen

Jedoch werden die Zellen der Drüsen der Drosera auf diese Weise dazu gereizt, einen motorischen Impuls nach einem entfernten Punkt hinzusenden und dort Bewegung zu veranlassen. Es scheint mir, als ob kaum eine noch merkwürdigere Thatsache in dem Pflanzenreiche beobachtet worden wäre.

# Einbiegung der Tentakeln

Die Einbiegung der äuszeren Tentakeln, wenn ihre Drüsen durch wiederholtes Berühren gereizt werden. Wir haben schon gesehen, dasz wenn die centralen Drüsen durch sanftes Pinseln gereizt werden, sie einen motorischen Impuls zu den Drosera rotundifolia.

# Berührung der äußeren Tentakeln

äuszeren Tentakeln schicken, welcher verursacht, dasz sich dieselben biegen; und wir haben nun die Wirkungen zu betrachten, welche erfolgen, wenn die Drüsen der äuszeren Tentakeln selbst berührt werden. Bei mehreren Gelegenheiten wurde eine grosze Anzahl Drüsen nur einmal mit einer Nadel oder einem feinen Pinsel berührt, der# Einleitung

stark genug war, um den ganzen biegsamen Tentakel zu biegen; und obgleich dies einen tausendfach gröszeren Druck als das Gewicht der oben beschriebenen Theilchen verursacht haben musz, so bewegte sich nicht ein Tentakel.

# Experimente mit Drüsen

Bei einer andern Gelegenheit wurden fünf und vierzig Drüsen an elf Blättern ein-, zwei- oder selbst dreimal mit einer Nadel oder einen steifen Borste berührt. Dies wurde so schnell wie möglich gethan, aber mit genügender Kraft um die Tentakeln zu biegen; doch wurden nur sechs derselben gebogen, — drei deutlich und drei in einem unbedeutenden Grade.

# Überprüfung der Tentakeln

Um mich zu versichern, dasz sich diese Tentakeln, welche nicht afficirt waren, in einem lebenskräftigen Zustande befänden, wurden Stückchen Fleisch auf zehn von ihnen gelegt, und bald waren alle stark eingebogen.

# Einfluss der Berührungen

Auf der andern Seite wurde, wenn eine grosze Anzahl Drüsen vier-, fünf- oder sechs-mal mit derselben Kraft wie vorher mit einer Nadel oder einem scharfen Glassplitter berührt wurde, ein viel gröszeres Verhältnis der Tentakeln gebogen; aber das Resultat war so unsicher, dasz es capriciös erschien.

# Empfindlichkeit der Drüsen

Die Thatsache, dasz eine einzige Berührung oder selbst zwei oder drei Berührungen keine Einbiegung verursachen, musz der Pflanze von Nutzen sein, da während stürmischen Wetters die Drüsen es nicht vermeiden können, gelegentlich von hohen Grashalmen oder von andern nahe wachsenden Pflanzen berührt zu werden; und es würde ein groszer Schaden sein, wenn die Tentakeln auf diese Weise in Thätigkeit gebracht würden, denn der Act der Wiederausstreckung erfordert eine beträchtliche Zeit, und ehe die Tentakeln nicht wieder ausgestreckt sind, können sie keine Beute fangen.

# Einbiegung der äußeren Tentakeln

Auf der andern Seite ist die auszerordentliche Empfindlichkeit gegen leichten Druck für die Pflanze von höchstem Nutzen. Denn wenn, wie wir gesehen haben, die zarten Füsze eines kleinen sich wehrenden Insects, noch so leicht auf die Oberfläche von zwei oder drei Drüsen drücken, so rollen sich die Tentakeln, welche diese Drüsen tragen, bald nach innen und tragen das Insect mit sich nach der Mitte zu, und verursachen, dass nach einiger Zeit alle umgebenden Tentakeln es umschlingen.

# Umgang mit nicht nahrhaften Objekten

Dem-ohngeachtet sind die Bewegungen der Pflanze ihren Bedürfnissen nicht vollkommen angepaszt, denn wenn ein Stückchen trocknes Moos, Torf, oder andrer Abfall auf die Scheibe geweht wird, wie es oft vorkommt, so umschlingen es die Tentakeln unnöthiger Weise. Sie entdecken jedoch bald ihren Irrthum und entlassen solche nicht nahrhafte Gegenstände.

# Einfluss von Wassertropfen

Es ist auch eine merkwürdige Thatsache, dasz Wassertropfen, die von einer Höhe fallen, gleichviel ob unter der Form von natürlichem oder künstlichem Regen, die Tentakeln nicht zu biegen verursachen; doch müssen die Tropfen auf die Drüsen mit beträchtlicher Kraft aufschlagen um so mehr, wenn die Absonderung durch starken Regen ganz weggewaschen ist; und dies kommt häufig vor, obgleich die Absonderung so zähe ist, dasz sie durch Schwingen der Blätter in Wasser blosz mit Mühe entfernt werden kann.

# Schlussfolgerung

Wenn die fallenden Wassertropfen klein sind, so kleben sie an der Absonderung an, deren Gewicht dadurch in viel höherem Grade vermehrt wird, wie schon vorher bemerkt, als durch die Hinzufügung kleiner Theilchen von solider Substanz; und doch verursachen die Tropfen niemals, dasz sich die Tentakeln einbiegen. Es würde augenscheinlich ein groszer Schaden für die Pflanze gewesen sein (wie im Fall von gelegentlichen Berührungen), wenn die Tentakeln durch jeden Regenschauer zum Biegen erregt würden; aber dieser Schaden ist dadurch vermieden worden, dasz die Drüsen, entweder durch die Gewohnheit fühllos ge-# Einleitung
gen die Schläge und den Druck der Wassertropfen geworden sind, oder von vorn herein nur empfindlich gegen die Berührung mit soli- den Körpern gemacht waren. Wir werden später sehen, dasz die Filamente auf den Blättern der Dionaea gleichfalls unempfindlich sind gegen die Einwirkung von Flüssigkeiten, aber auszerordentlich empfindlich gegen momentane Berührung von irgend einem soliden Körper.

# Experimente mit Tentakeln
Wenn der Stiel eines Tentakels mit einer scharfen Scheere dicht Drosera rotundifolia. Cap. 2. unter der Drüse abgeschnitten wird, so wird der Tentakel gewöhnlich gebogen. Ich versuchte wiederholt dieses Experiment, da mich die Thatsache sehr in Erstaunen setzte; denn alle andern Theile der Stiele sind unempfindlich gegen jedweden Reiz. Diese kopflosen Tentakeln streckten sich nach einiger Zeit wieder aus; aber ich werde auf diesen Gegenstand später zurückkommen. Auf der andern Seite erreichte ich es gelegentlich, eine Drüse zwischen einer Pincette zu zerdrücken, aber dies verursachte keine Einbiegung. In diesem letzten Falle erschienen die Tentakeln paralysirt, wie es ebenfalls durch die Einwir- kung von einer zu starken Auflösung gewisser Salze und durch zu grosze Hitze geschieht, während schwächere Auflösungen derselben Salze und eine geringere Wärme Bewegung verursachen.

# Beobachtungen über Protoplasma
Mein Sohn Francis findet, angeregt durch die Beobachtungen des Dr. Burdon Sanderson an Dionaea, dasz, wenn zwei Nadeln in die Blattscheibe einer Drosera gesteckt werden, die Tentakeln sich nicht bewegen; wenn aber zwei ähnliche, mit der secundären Rolle eines Dubois’schen Inductions-Apparates in Verbindung stehende Nadeln eingesteckt werden, so biegen sich die Tentakeln im Laufe weniger Minuten nach innen. Mein Sohn hofft seine Beobachtungen bald veröffentlichen zu können.

# Drittes Kapitel: Zusammenballen des Protoplasma
Zusammenballen des Protoplasma in den Zellen der Tentakeln. Beschaffenheit des Inhalts der Zellen vor der Zusammenballung. — Die verschied- nen Ursachen, welche eine Zusammenballung veranlassen. — Der Procesz fängt in den Drüsen an, und geht die Tentakeln hinunter. — Beschreibung der zu- sammengeballten Massen und ihrer unwillkürlichen Bewegungen. — Ströme von Protoplasma entlang den Wänden der Zellen. — Wirkung von kohlen- saurem Ammoniak. — Die Körnchen in dem Protoplasma, welches den Wän- den entlang flieszt, verschmelzen mit den centralen Massen. — Die äuszerst geringe Quantität kohlensauren Ammoniaks, welche Zusammenballung verur- sacht. — Wirkungsart andrer Salze von Ammoniak, — andrer Substanzen organischer Flüssigkeiten etc., — des Wassers, — der Wärme. — Wieder- auflösung der zusammengeballten Massen. — Nähere Ursachen der Zusammen- ballung von Protoplasma. — Zusammenfassung und Schluszbemerkungen. — Supplementäre Beobachtungen über Zusammenballung in den Wurzeln der Pflanzen.

# Beschreibung der Zusammenballung
Ich will hier meine Schilderung der Bewegungen der Blätter unterbrechen, und die Erscheinung der Zusammenballung beschreiben, auf welchen Gegenstand ich schon hingedeutet habe. Wenn die Tentakeln eines jungen aber vollständig ausgewachsenen Blattes, welches nie gereizt oder gebogen worden ist, untersucht werden, so sieht man, dasz die Zellen, welche die Stiele bilden, mit einer homogenen pur- purnen Flüssigkeit gefüllt sind. Die Wände sind mit einer Schicht von farblosem, circulirendem Protoplasma ausgekleidet; doch kann dies mit viel gröszerer Deutlichkeit als vorher gesehen werden, wenn der Procesz der Zusammenballung theilweise eingetreten ist. Die pur- purne Flüssigkeit, welche aus einem zerdrückten Tentakel austritt, ist etwas zähe und vermischt sich nicht mit dem umgebenden Wasser; sie enthält viel flockige oder körnige Substanz. Aber diese Substanz kann dadurch entstanden sein, dasz die Zellen zerdrückt worden sind,# Zusammenballung des Protoplasma

da ein gewisser Grad der Zusammenballung hierdurch beinahe augenblicklich verursacht worden ist.
Darwin, Insectenfressende Pflanzen. (VIII.) 3
Drosera rotundifolia. Cap. 3.

Wenn ein Tentakel einige Stunden, nachdem die Drüse durch wiederholtes Berühren, oder durch unorganische oder organische Teilchen, welche darauf lagen, oder durch die Aufsaugung von gewissen Flüssigkeiten gereizt worden war, untersucht wird, so bietet er ein gänzlich verändertes Ansehen dar. Die Zellen, anstatt mit homogener purpurner Flüssigkeit angefüllt zu sein, enthalten nur verschiedentlich geformte Massen von purpurner Substanz, in einer farblosen oder beinahe farblosen Flüssigkeit suspendiert. Die Veränderung ist so augenfällig, dass sie durch eine schwache Loupe sichtbar ist, und manchmal sogar mit bloßem Auge; die Tentakeln haben nun ein geflecktes Ansehen, sodass ein in dieser Weise affizierter, mit Leichtigkeit von den andern unterschieden werden kann. Dasselbe Resultat erfolgt, wenn die Drüsen auf der Scheibe auf irgend eine Weise gereizt werden, sodass die äußeren Tentakeln gebogen werden; denn ihren Inhalt wird man dann in einem zusammengeballten Zustande finden, obgleich ihre Drüsen noch keinen Gegenstand berührt haben. Aber Zusammenballung kann unabhängig von Einbiegung vorkommen, wie wir bald sehen werden. Durch welche Ursachen auch der Prozess nur immer angeregt worden sein mag, er fängt innerhalb der Drüsen an, und geht dann die Tentakeln hinunter. Er kann viel deutlicher in den oberen Zellen der Stiele als in den Drüsen beobachtet werden, da diese etwas undurchsichtig sind. Kurz nachdem die Tentakeln sich wieder ausgestreckt haben, werden alle die kleinen Massen von Protoplasma wieder aufgelöst, und die purpurne Flüssigkeit in den Zellen wird wieder so homogen und durchsichtig wie sie vorher war. Der Prozess der Wiederauflösung geht aufwärts von den Basen der Tentakeln nach den Drüsen hin, und daher in entgegengesetzter Richtung zu der, welche die Zusammenballung einschlug. Es wurden im zusammengeballten Zustande befindliche Tentakeln den Herren Prof. Huxley, Dr. Hooker und Dr. Burdon Sanderson gezeigt, letzterer beobachtete die Veränderungen unter dem Mikroskop und war von dem ganzen Phänomen sehr frappiert.

Die kleinen Massen von zusammengeballter Substanz sind von den allerverschiedensten Formen, oft kuglig oder oval, manchmal sehr verlängert, oder ganz unregelmäßig mit faden-, oder halsbandartigen oder keulenförmigen Vorsprüngen. Sie bestehen aus dicker augenscheinlich zäher Substanz, welche in den äußeren Tentakeln von einer leicht purpurnen, und in den kurzen scheibenständigen Tentakeln von einer grünlichen Färbung ist. Diese kleinen Massen verändern unaufhörlich ihre Form und Stellung, und ruhen niemals. Eine einzige Masse teilt sich oft in zwei, welche sich nachher wieder vereinigen. Ihre Bewegungen sind ziemlich langsam, und gleichen denen der Amöben oder der weißen Blutkörperchen. Wir können daher folgern, dass sie aus Protoplasma bestehen. Wenn ihre Formen in Pausen von wenigen Minuten skizziert werden, so sieht man ausnahmslos, dass sie viele Veränderungen durchgemacht haben; und eine und dieselbe Zelle ist mehrere Stunden lang beobachtet worden. Acht rohe, aber genaue Skizzen derselben Zelle in Pausen von 2 oder 3 Minuten gemacht, werden hier gegeben (Fig. 7) und illustrieren einige der einfacheren und häufigsten Veränderungen. Die Zelle A enthielt, als sie zuerst gezeichnet wurde, zwei ovale Massen von purpurnem Protoplasma die sich berührten. Diese wurden getrennt, wie B zeigt, und dann wieder vereinigt, wie es C darstellt. Nach Verlauf der nächsten 2 — 3 Minuten zeigte sich eine sehr häufig zu sehende Erscheinung — D —,# Protoplasma und seine Bewegungen

nämlich die Bildung eines auszerordentlich kleinen Kügelchens an
einem Ende einer verlängerten Masse. Dieses nahm rapid an Umfang
zu, wie in E gezeigt wird, und wurde dann wieder aufgesaugt, wie
in F, in welcher Zeit sich ein anderes Kügelchen am entgegengesetz-
ten Ende gebildet hatte.
Die oben abgebildete Zelle war von einem Tentakel eines dunkel-
rothen Blattes, welches eine kleine Motte gefangen hatte, und wurde
unter Wasser untersucht. Da ich zuerst dachte, dasz die Bewegungen
der Massen eine Folge der Aufsaugung von Wasser sein könnten,
that ich eine Fliege auf ein Blatt, und als nach 18 Stunden alle
Tentakeln gut eingebogen waren, wurden diese untersucht ohne in
Wasser getaucht zu werden. Die hier dargestellte Zelle (Fig. 8) war
von diesem Blatt, und wurde acht Mal im Lauf von 15 Minuten ge-
zeichnet. Diese Skizzen zeigen einige von den bemerkenswertheren
Veränderungen, welche das Protoplasma durchmacht. Zuerst war an
3*
Drosera rotundifolia. Cap. 3.
der Basis der Zelle 1 eine kleine Masse auf einem kurzen Stiel und
eine gröszere Masse nahe dem oberen Ende vorhanden, und diese bei-
Fig. 8. (Drosera rotundifolia) Schematische Darstellung einer und derselben
Zolle, die verschie-
denen, auf einander folgenden, von den zusammengeballten Protoplasma-Massen
angenommenen
Formen zeigend.
den schienen ganz getrennt zu sein. Demohngeachtet könnten sie
durch einen feinen und unsichtbaren Faden von Protoplasma verbun-
den gewesen sein; denn bei zwei andern Gelegenheiten war ich im
Stande, während die eine Masse schnell wuchs und eine andere Masse
in derselben Zelle schnell abnahm, durch Veränderung des Lichtes
und den Gebrauch einer starken Vergröszerung einen verbindenden
Faden von äuszerster Zartheit zu entdecken, welcher augenscheinlich
als Verkehrscanal zwischen den Beiden diente. Auf der andern Seite
sieht man manchmal, dasz solche verbindenden Fäden reiszen und ihre
Enden werden dann schnell keulenförmig. Die andern Skizzen in Fig. S
zeigen die Formen, welche das Protoplasma nach einander annahm.
Bald nachdem die purpurne Flüssigkeit in den Zellen zusammen-
geballt worden ist, schwimmen die kleinen Massen in einer farblosen
oder beinahe farblosen Flüssigkeit umher und die Schicht weiszen
körnigen Protoplasmas, welche entlang den Wänden flieszt, kann nun
viel deutlicher gesehen werden. Der Strom flieszt mit unregelmäsziger
Schnelligkeit die eine Wand hinauf und die andere wieder hinunter,
gewöhnlich in langsamerem Tempo über die schmalen Enden der ver-
längerten Zellen, und so immer fort rund um. Aber der Strom hört
manchmal auf. Die Bewegung ist oft in Wellen und ihre Gipfel
strecken sich manchmal beinahe über die ganze Breite der Zelle, und
sinken dann wieder nieder. Kleine Kugeln von Protoplasma, augen-
scheinlich ganz frei, werden oft durch den Strom in den Zellen umher
getrieben; an die centralen Massen geheftete Filamente werden hin
und her geschwungen, als ob sie zu entfliehen suchten. Alles zu-
sammen genommen bietet eine dieser Zellen, mit den sich immer ver-
ändernden centralen Massen und mit der den Wänden entlang flieszen-
den Schicht von Protoplasma, ein wunderbares Bild einer lebendi-
gen Thätigkeit dar.
Cap. 3. Zusammenballung des Protoplasma.
Viele Beobachtungen wurden an dem Inhalt der Zellen angestellt,
während sie den Procesz der Zusammenballung durchmachten; ich werde
aber nur einige wenige Fälle unter verschiedenen Gesichtspunkten einzeln
ausführen. Ein kleiner Theil wurde von einem Blatt abgeschnitten, unter
starke Vergröszerung gebracht und die Drüse sehr sanft unter einem
Compressorium gedrückt. In 15 Minuten sah ich deutlich, wie kleine
Kügelchen von Protoplasma sich in der purpurnen Flüssigkeit zusammen-
ballten; diese nahmen zusehends an Umfang zu, sowohl in den Zellen der
Drüsen als in denen der oberen Enden der Stiele. Theilchen von Glas,
Kork und Kohle wurden auch auf die Drüsen von vielen Tentakeln gelegt;# Beobachtungen zur Zusammenballung von Tentakeln

In 1 Stunde waren mehrere derselben gebogen; aber nach 1 Stunde 35 Minuten war noch keine Zusammenballung eingetreten. Andere Tentakeln mit diesen Theilchen wurden nach 8 Stunden untersucht, und nun war in allen ihren Zellen Zusammenballung eingetreten. Dasselbe war in den Zellen der äuszeren Tentakeln der Fall, welche durch den, von den Drüsen der Scheibe, auf welchen die dorthin transportirten Theilchen ruhten, auf sie übermittelten Reiz eingebogen worden waren. Dieses war gleichfalls der Fall mit den kurzen Tentakeln rings um den Rand der Scheibe herum, welche noch nicht eingebogen worden waren. Diese letztere That-sache zeigt, dasz der Procesz der Zusammenballung unabhängig von der Einbiegung der Tentakeln ist, wofür wir in der Tat noch andere und reichliche Beweise haben. Ferner wurden die äuszeren Tentakeln an drei Blättern sorgfältig untersucht und dabei gefunden, dasz sie nur eine homogene purpurne Flüssigkeit enthielten; kleine Stückchen Faden wur-den dann auf die Drüsen von drei derselben gelegt, und nach 22 Stunden war die purpurne Flüssigkeit in ihren Zellen, beinahe bis herunter zu ihren Basen, zu unzähligen kugligen, verlängerten oder fadigen Massen von Protoplasma zusammengeballt. Die Stückchen Faden waren einige Zeit vorher nach der mittleren Scheibe geschafft worden, und dies hatte verursacht, dasz alle die andern Tentakeln etwas eingebogen worden waren; auch war das Protoplasma ihrer Zellen gleichfalls zusammengeballt, jedoch, und dies ist zu beachten, noch nicht hinunter bis zu ihren Basen, es war vielmehr die Zusammenballung nur auf die Zellen dicht unter den Drüsen beschränkt. Nicht nur verursacht wiederholtes Berühren der Drüsen.

# Einfluss von Berührungen auf die Tentakeln

Nach einer Schilderung der Beobachtungen Heckel’s zu urtheilen, welche ich so eben erst in dem „Gardener’s Chronicle, Oct. 10., 1874, citirt gefunden habe, scheint er eine ähnliche Erscheinung in den Staubfäden der Berberis beobachtet zu haben, nachdem sie durch eine Berührung gereizt worden waren und sich bewegt hatten; er sagt nämlich, dasz der Inhalt einer jeden individuellen Zelle sich im Centrum ihrer Höhle angesammelt habe. und der Contact mit kleinen Theilchen Zusammenballung, sondern es bringt auch, wenn Drüsen ohne selbst verletzt zu sein von den Gipfeln der Stiele abgeschnitten werden, dies einen mäßigen Betrag von Zusammenballung in den kopflosen Tentakeln hervor, nachdem sie eingebogen worden sind. Auf der andern Seite scheinen die Tentakeln, wenn die Drüsen plötzlich zwischen einer Pincette zerdrückt worden, wie in sechs Fällen versucht wurde, durch solch einen heftigen Eingriff paralysirt zu werden; denn sie werden weder eingebogen, noch bieten sie irgend welche Zeichen der Zusammenballung dar.

# Wirkung von kohlensaurem Ammoniak

Kohlensaures Ammoniak. — Von allen den Ursachen, welche Zusammenballung hervorbringen ist die, welche, so weit ich gesehen habe, am schnellsten wirkt und die kräftigste ist, eine Auflösung von kohlen-sauren Ammoniak. Was auch ihre Stärke sein mag, die Drüsen werden immer zuerst gereizt, und werden bald ganz undurchsichtig, so dasz sie schwarz erscheinen. Ich that z. B. ein Blatt in wenige Tropfen einer starken Auflösung, nämlich von einem Theil auf 146 Theile Wasser (oder 3 Gran auf 1 Unze) und beobachtete es unter starker Vergröszerung. Alle Drüsen fiengen in 10 Secunden an dunkel zu werden, und in 13 Secunden waren sie merklich dunkler. In einer Minute konnte man ausserordentlich kleine kuglige Massen von Protoplasma in den Zellen der Stiele dicht unter den Drüsen entstehen sehen, ebenso wie in den Kissen, auf welchen die langköpfigen randständigen Drüsen ruhen. In mehreren Fällen verbreitete sich in ungefähr 10 Minuten der Procesz die Stiele hinunter eine Strecke weit, die zwei- oder drei mal so lang war wie die Drüsen. Es war sehr interessant zu beobachten, wie der Procesz momentan bei jeder queren Scheidewand zwischen zwei Zellen aufgehalten wurde, und dann zu sehen, wie der durchsichtige Inhalt der nächst darunter liegenden Zelle in eine wolkige Masse gewissermaszen aufflammte. In den un-teren Theilen der Stiele gieng die Erscheinung langsamer vorwärts, so dasz es ungefähr 20 Minuten dauerte, ehe die Zellen halbwegs die langen randständigen und dem Rande nahe stehenden Tentakeln hinab zusammengeballt wurden. Wir können annehmen, dasz das kohlensaure Ammoniak von den# Einleitung

Drüsen aufgesaugt wird, nicht nur weil seine Wirkung so geschwind ist, sondern weil sie etwas verschieden ist von der andrer Salze. Da die Drüsen, wenn sie gereizt werden, eine Säure, welche zu der Essigreihe gehört, absondern, so wird das kohlensaure Salz wahrscheinlich sofort in ein Salz dieser Reihe verwandelt, und wir werden sogleich sehen, dasz das essigsaure Ammoniak Zusammenballung beinahe oder ganz so energisch ver- ursacht wie das kohlensaure Salz.

# Experimentelle Beobachtungen

Wenn ein paar Tropfen einer Auf- lösung von einem Theile des kohlensauren Salzes auf 437 Theile Wasser (oder 1 Gran auf 1 Unze) zu der purpurnen Flüssigkeit, welche aus zer- drückten Tentakeln ausflieszt, oder auf Papier gebracht wird, welches da- durch, dasz es mit Tentakeln gerieben wurde, gefärbt worden ist, so wird die Flüssigkeit ebenso wie das Papier blosz schmutzig grün. Demohnge-achtet konnte nach 1 Stunde 30 Minuten etwas purpurne Farbe in den Drüsen eines Blattes, welches in einer Auflösung von der doppelten Stärke der oben erwähnten (nämlich 2 Gran auf 1 Unze) liegen gelassen wor- den war, entdeckt werden; und nach 24 Stunden enthielten die Zellen der Stiele dicht unter den Drüsen noch Kugeln von Protoplasma von einer schönen purpurnen Färbung.

# Analyse der Ergebnisse

Diese Thatsachen beweisen, dasz das Ammoniak nicht als. kohlensaures eingetreten war, denn sonst würde die Farbe wohl verdrängt worden sein. Ich habe jedoch manchmal, beson- ders bei den in eine Lösung eingetauchten langköpfigen Tentakeln auf den Rändern sehr blasser Blätter beobachtet, dasz die Drüsen sowohl als die oberen Zellen der Stiele sich entfärbten; und in diesen Fällen ver- muthe ich, dasz das unveränderte kohlensaure Salz aufgesaugt worden war.

# Zusammenballung des Protoplasma

Die oben beschriebene Erscheinung, dasz der Procesz der Zusammen- ballung auf kurze Zeit bei jeder queren Scheidewand aufgehalten wird, macht den Eindruck, als ob eine Substanz von Zelle zu Zelle abwärts gehe. Aber da die Zellen eine unter der anderen einer Zusammenballung des Inhalts unterliegen, wenn unorganische und unauflösliche Theilchen auf die Drüsen gelegt werden, so musz der Procesz wenigstens in diesen Fällen in einer von den Drüsen übermittelten molecularen Veränderung, unabhängig von der Aufsaugung irgend welcher Substanz, bestehen.

# Wirkung des kohlensauren Ammoniaks

Das- selbe kann auch möglicher Weise bei der Wirkung des kohlensauren Ammoniaks der Fall sein. Da jedoch die durch dieses Salz verursachte Zusammenballung die Tentakeln in viel schnellerem Tempo hinunterläuft, als wenn unauflösliche Theilchen auf die Drüsen gelegt werden, so wird wahrscheinlich das Ammoniak in irgend einer Form nicht nur von den Drüsen aufgesaugt, sondern geht auch die Tentakeln hinunter.

# Weitere Experimente

Nachdem ich ein Blatt in Wasser untersucht und den Inhalt der Zellen homogen gefunden hatte, that ich es in ein paar Tropfen einer Auf- lösung von einem Theil des kohlensauren Salzes auf 437 Theile Wasser und achtete auf die Zellen unmittelbar unter den Drüsen, wendete in- zwischen keine sehr starke Vergröszerung an. Nach 3 Minuten war noch keine Zusammenballung sichtbar, aber nach 15 Minuten bildeten sich kleine Kugeln von Protoplasma, ganz besonders unter den langköpfigen randständigen Drüsen; der Procesz jedoch fand in diesem Fall mit unge- wöhnlicher Langsamkeit statt.

# Beobachtungen zur Protoplasma-Bildung

In 25 Minuten waren deutlich bemerkbare kuglige Massen in den Zellen der Stiele in einer beinahe der der Drü- sen gleichen Länge, und in 3 Stunden ein Drittel oder die Hälfte der Länge des ganzen Tentakels hinab vorhanden. Wenn Tentakeln mit Zellen, welche nur sehr blasse rosa Flüssigkeit und augenscheinlich nur wenig Protoplasma enthalten, in ein paar Tropfen einer schwachen Auflösung von einem Theil des kohlensauren Salzes auf 4375 Theile Wasser (1 Gran auf 10 Unzen) gethan, und die äuszerst durchsichtigen Zellen unter den Drüsen unter starker Vergröszerung sorg- fälltig beobachtet werden, so sieht man, wie diese zuerst leicht wolkig werden durch die Bildung von zahllosen nur gerade bemerkbaren Körn- chen, welche sehr geschwind grösser werden, entweder durch Verschmel- zung oder durch das Heranziehen von mehr Protoplasma aus der umge- benden Flüssigkeit.

# Schlussfolgerung

Bei einer Gelegenheit wählte ich ein eigenthümlich blasses Blatt, und gab ihm, während es unter dem Mikroscop lag, einen einzigen Tropfen einer stärkeren Auflösung von einem Theil auf 437 Teile Wasser; in diesem Fall wurde der Inhalt der Zellen nicht wolkig,# Protoplasma und seine Eigenschaften

aber nach 10 Minuten konnten unregelmässige Körner von Protoplasma entdeckt werden, welche bald zu unregelmäszigen Massen und Körnchen von einer grünlichen oder sehr blassen purpurnen Färbung heranwuchsen; aber diese bildeten nie vollkommene Kugeln, obgleich sie unaufhörlich ihre Form und Stellung veränderten. Bei mäszig rothen Blättern ist die erste Wirkung einer Lösung des kohlensauren Salzes gewöhnlich die Bildung von zwei oder drei oder mehreren auszerordentlich kleinen purpurnen Kugeln, welche schnell am Umfang zunehmen. Um einen Begriff von der Geschwindigkeit zu geben, mit welcher solche Kugeln an Umfang zunehmen, will ich erwähnen, dasz einem ziemlich blasz purpurnen Blatt unter einem Glasblättchen ein Drosera rotundifolia. Cap. 3. Tropfen einer Lösung von einem Theil auf 292 Theile Wasser gegeben wurde; in 13 Minuten waren ein paar kleine Kugeln von Protoplasma gebildet; eine derselben war nach 2 Stunden 30 Minuten ungefähr zwei Drittel des Durchmessers der Zelle. Nach 4 Stunden 25 Minuten war sie im Durchmesser der Zelle beinahe gleich; und eine zweite Kugel, ungefähr halb so grosz wie die erste, hatte sich gebildet nebst einigen anderen sehr kleinen. Nach 6 Stunden war die Flüssigkeit, in welcher diese Kugeln schwammen, beinahe farblos. Nach 8 Stunden 35 Minuten (immer von der Zeit an, wo die Lösung zuerst zugesetzt worden war, gerechnet) waren vier neue kleine Kugeln erschienen. Am nächsten Morgen, nach 22 Stunden, waren auszer den zwei groszen Kugeln sieben kleinere da, welche in einer vollständig farblosen Flüssigkeit schwammen, in der et- was flockige, grünliche Substanz suspendirt war.

# Erscheinungen bei der Zusammenballung

Beim Beginn des Processes der Zusammenballung, ganz besonders in dunkel rothen Blättern, bietet oft der Inhalt der Zellen ein verschiedenes Ansehen dar, als ob die Schicht von Protoplasma (der Primordialschlauch), welche die Zellen auskleidet, sich losgelöst hätte, und von den Wänden abgeschrumpft wäre; es hatte sich dabei ein unregelmäszig geformter Sack gebildet. Andere Flüssigkeiten, auszer einer Auflösung des kohlen- sauren Salzes, z. B. ein Aufgusz von rohem Fleisch, bringen dieselbe Wirkung hervor. Aber die Erscheinung der Einschrumpfung des Primordialschlauchs von den Wänden ist jedenfalls falsch. Bei andern Pflanzen habe ich häufig das, was mir eine echte Zusammen- schrumpfung des Primordialschlauchs von den Zellenwänden erschien, durch eine Auflösung in kohlensaurem Ammoniak verursacht gesehen, wie es gleichfalls als Folge mechanischer Verletzungen auftritt.; denn ich sah, ehe ich die Auflösung zugesetzt hatte, bei mehreren Gelegenheiten, dass die Wände mit farblosem, flieszendem Protoplasma ausgekleidet waren, und nachdem die sackförmigen Massen sich gebildet hatten, flosz das Protoplasma noch immer in deutlich sichtbarer Weise den Wänden entlang, selbst noch mehr als vorher. Es schien in der That, als ob der Strom des Protoplasma durch die Einwirkung des kohlensauren Salzes verstärkt sei, aber es war unmöglich zu ermitteln, ob dies wirklich der Fall war.

# Bewegung und Teilung der Protoplasma-Massen

Die sackartigen Massen fangen, wenn sie einmal gebildet sind, bald an langsam in den Zellen rundum zu gleiten; manchmal Fortsätze aussendend, welche sich in kleine Kugeln auflösen; andere Kugeln erscheinen in der die Säckchen umgebenden Flüssigkeit und diese bewegen sich viel schneller. Dasz die kleinen Kugeln getrennt sind, wird häufig dadurch bewiesen, dasz zuweilen eine und dann eine andere sich voraus bewegen, und manchmal drehen sie sich um einander. Ich habe gelegentlich gesehen, wie Kugeln dieser Art sich an derselben Seite der Zelle hinauf und hinab bewegten, anstatt rings herum. Die sackartigen Massen theilen sich gewöhnlich nach einiger Zeit in zwei runde oder ovale Massen und diese machen die Veränderungen durch, welche in Fig. 7 und 8 dargestellt sind. Andere Male erscheinen Kugeln in den Säcken, und diese verschmelzen und theilen sich in einem endlosen Kreislauf von Veränderungen.

# Auswirkungen der kohlensauren Salzlösung

Wenn Blätter mehrere Stunden lang in einer Auflösung des kohlensauren Salzes liegen gelassen worden sind, und vollständige Zusammen- ballung bewirkt worden ist, hört der Strom von Protoplasma an den Wänden derselben auf, sichtbar zu sein; ich beobachtete diese Thatsache.# Protoplasma und seine Bewegung

wiederholt, will aber nur ein Beispiel geben. Ein blasz purpurnes Blatt war in ein paar Tropfen einer Auflösung von einem Theil in 292 Theilen Wasser gelegt worden und in 2 Stunden hatten sich in den oberen Zellen der Stiele einige feine purpurne Kugeln gebildet, während der Strom von Protoplasma rings an ihren Wänden noch ganz deutlich war; aber nach Verlauf von weiteren 4 Stunden, während welcher Zeit sich noch viel mehr Kugeln gebildet hatten, war der Strom, selbst bei der sorgfältigsten Untersuchung, nicht mehr zu unterscheiden; und dies war ohne Zweifel eine Folge davon, dasz die eingeschlossenen Körnchen sich mit den Kugeln vereinigt hatten, so dasz nichts mehr vorhanden war, wodurch die Bewegung des klaren Protoplasma hätte bemerkt werden können. Aber sehr kleine freie Kugeln giengen noch immer die Zellen hinauf und hinab, welche bewiesen, dasz noch immer ein Strom vorhanden war. So war es noch am nächsten Morgen, nach 22 Stunden, in welcher Zeit sich einige neue kleine Kugeln gebildet hatten; diese oscillirten von einer Seite zur andern und veränderten ihre Stellung, wodurch sie bewiesen, dasz die Strömung noch nicht aufgehört hatte, obgleich kein Strom von Protoplasma sichtbar war.

# Einfluss von Kohlensäure

Bei einer andern Gelegenheit sah man jedoch einen Strom um die Zellen-Wände eines lebenskräftigen, dunkelfarbigen Blattes flieszen, nachdem es 24 Stunden in einer etwas stärkeren Auflösung, nämlich von einem Theil des kohlensauren Salzes auf 218 Theile Wasser, gelegen hatte. Dies Blatt war daher nicht sehr oder gar nicht durch ein Eintauchen von dieser Zeit in die oben erwähnte Auflösung von zwei Gran in einer Unze besehädigt; und nachdem es nacher 24 Stunden in Wasser liegen gelassen worden war, hatten sich die zusammengeballten Massen in vielen der Zellen wieder aufgelöst, in derselben Art, wie es vorkommt, wenn Blätter im Naturzustand sich wieder ausstrecken, nachdem sie Insecten gefangen gehabt hatten.

# Untersuchung der Protoplasma-Kugeln

In einem Blatt, welches 22 Stunden in einer Auflösung von einem Theil des kohlensauren Salzes in 292 Theilen Wasser gelassen war, wurden einige Kugeln von Protoplasma (durch die Selbsttheilung einer sack-ähnlichen Masse) sanft unter einem Deckgläschen gedrückt, und dann unter starker Vergröszerung untersucht. Sie waren nun deutlich durch scharf bestimmte strahlenförmige Spalten getheilt, oder waren in verschiedene Fragmente mit scharfen Kanten aufgebrochen; auch waren sie solid bis in die Mitte. In den gröszeren aufgebrochenen Kugeln war der mittlere Theil undurchsichtiger, dunkelfarbiger und weniger zerbrechlich als die äuszeren; nur waren in einigen Fällen die letzteren von Spalten durchdrungen. In vielen Kugeln war die Trennungslinie zwischen den äuszeren und inneren Theilen ziemlich scharf bestimmt. Die äuszeren Theile waren von genau derselben sehr blasz purpurnen Färbung, wie die der zuletzt gebildeten kleineren Kugeln; und diese letzteren schlossen keinen dunkleren mittleren Kern ein.

# Zusammenballung und Teilung von Protoplasma

Aus diesen verschiedenen Thatsachen können wir schlieszen, dasz, wenn kräftige dunkelfarbige Blätter der Einwirkung von kohlensaurem Ammoniak unterworfen werden, sich die Flüssigkeit in den Zellen der Tentakeln oft äuszerlich in zusammenhängende klebrige Substanz zuDrosera rotundifolia. Kleine Kugeln erscheinen manchmal innerhalb dieses Sackes, und das Ganze theilt sich gewöhnlich bald in zwei oder mehr Kugeln, welche wiederholt verschmelzen und sich wieder theilen. Nach einer längeren oder kürzeren Zeit sind die Körnchen in der farblosen Schicht von Protoplasma, welche rings um die Wände flieszt, nach den gröszeren Kugeln hingezogen und mit ihnen vereinigt, oder bilden kleine selbständige Kugeln; diese letzteren sind von viel blässerer Farbe und viel zerbrechlicher als die zuerst zusammengeballten Massen. Nachdem die Körnchen von Protoplasma in dieser Weise angezogen worden sind, kann die Schicht flieszenden Protoplasmas nicht mehr unterschieden werden, wennschon ein Strom von durchsichtiger Flüssigkeit noch rund an den Wänden herumflieszt.

# Reaktion auf starke Lösungen

Wenn ein Blatt in eine starke, beinahe concentrirte Auflösung von kohlensaurem Ammoniak getaucht wird, so werden die Drüsen augenblicklich schwarz und sondern reichlich ab; aber es erfolgt keine Bewe-
gung der Tentakeln. Zwei so behandelte Blätter wurden nach 1 Stunde# Beobachtungen zur Protoplasma-Zusammenballung

schlaff und schienen getödtet zu sein; alle Zellen in ihren Tentakeln ent-
hielten Kugeln von Protoplasma; aber diese waren klein und misfarbig.
Zwei andere Blätter wurden in eine nicht ganz so starke Lösung gelegt
und in 30 Minuten war eine gut markirte Zusammenballung eingetreten.
Nach 24 Stunden wurden die kuglichen oder häufiger länglichen Massen
von Protoplasma undurchsichtig und körnig anstatt wie gewöhnlich durch-
sichtig zu sein; und in den unteren Zellen waren nur unzählige kleine
kugliche Körnchen vorhanden. Offenbar hatte die Stärke der Auflösung
die Vollendung des Processes gestört, wie dies, wie wir sehen werden,
gleichfalls in Folge groszer Hitze eintritt.

# Einfluss von Salzen auf die Tentakeln

Alle die vorangegangenen Beobachtungen beziehen sich auf die
äuszeren Tentakeln, welche von einer purpurnen Färbung sind; aber auf
die grünen Stiele der kurzen mittleren Tentakeln wirkt das kohlensaure
Salz und ein Aufgusz von rohem Fleisch in genau derselben Weise, mit
dem einzigen Unterschied, dasz die zusammengeballten Massen von einer
grünlichen Färbung sind, so dasz also der Procesz in keiner Weise von
der Farbe der Flüssigkeit innerhalb der Zellen abhängt.
Endlich ist die merkwürdigste Thatsache in Bezug auf dies Salz die
auszerordentlich kleine Menge, welche genügt, Zusammenballung zu ver-
ursachen. Ausführliche Einzelnheiten werden im siebenten Kapitel mit-
getheilt werden; hier mag es genügen, wenn ich noch anführe, dasz bei
einem empfindlichen Blatt die Aufsaugung von \frac {1}{134400} eines Grans
(0,000482 Milligr.) durch eine Drüse hinreicht, im Laufe einer Stunde
deutlich bemerkbare Zusammenballung in den Zellen unmittelbar unter der
Drüse zu verursachen.

# Wirkung anderer chemischer Lösungen

Die Wirkungen von gewissen andern Salzen und Flüssig-
keiten. Zwei Blätter wurden in eine Auflösung von einem Theil essig-
sauren Ammoniaks in ungefähr 140 Theilen Wasser gelegt; dies wirkte
ganz so energisch, aber vielleicht nicht ganz so schnell, wie das kohlen-
saure Salz. Nach 10 Minuten waren die Drüsen schwarz und in den
Zellen unter ihnen waren Spuren einer Zusammenballung zu bemerken,
welche nach 15 Minuten deutlich bemerkbar war und sich eine Strecke
weit, so lang wie die Drüsen, die Tentakeln hinab erstreckte.
Nach 2 Cap. 3. Zusammenballung des Protoplasma.
Stunden war der Inhalt von beinahe allen Zellen in sämmtlichen Ten-
takeln in kleine Massen von Protoplasma aufgebrochen. Ein Blatt wurde
in eine Auflösung von einem Theil von oxalsaurem Ammoniak in 146
Theilen Wasser eingetaucht, und nach 24 Minuten konnte eine gewisse,
aber keine deutliche Veränderung in den Zellen unter den Drüsen ge-
sehen werden. Nach 47 Minuten hatten sich viele kuglige Massen von
Protoplasma gebildet, und diese erstreckten sich an den Tentakeln eine
Strecke hinunter beinahe von der Länge der Drüsen. Dieses Salz wirkt
daher nicht so schnell wie das kohlensaure. Was das citronensaure
Ammoniak betrifft, so wurde ein Blatt in ein wenig Auflösung von der
obigen Stärke gelegt; es war auch nicht die Spur von Zusammenballung
zu bemerken, bis 56 Minuten verflossen waren; aber nach 2 Stunden 20
Minuten war sie deutlich zu bemerken. Bei einer andern Gelegenheit
wurde ein Blatt in eine stärkere Auflösung von einem Theil des citronen-
sauren Salzes in 109 Theilen Wasser (4 Gran auf 1 Unze) gelegt und
zu derselben Zeit ein anderes Blatt in eine gleich starke Auflösung des
kohlensauren Salzes. Die Drüsen des letzteren waren in weniger als 2
Minuten geschwärzt, und nach 1 Stunde 45 Minuten erstreckten sich die
zusammengeballten Massen, welche kuglig und sehr dunkelfarbig waren,
alle die Tentakeln hinunter zwischen halb und zwei Drittel ihrer Länge;
während die Drüsen an dem in citronensaurem Salz eingetauchten Blatt
von einem dunkeln Roth und die zusammengeballten Massen in den Zellen
unter ihnen rosa und verlängert waren. Nach 1 Stunde 45 Minuten er-
streckten sich die Massen an den Tentakeln nur ungefähr ein Fünftel
oder ein Viertel der Länge derselben hinunter.

# Zusammenfassung der Ergebnisse

Zwei Blätter wurden jedes in zehn Tropfen einer Auflösung von
einem Theil salpetersauren Ammoniaks in 5250 Theilen Wasser (1 Gran
auf 12 Unzen) gethan, so dasz jedes Blatt \frac {1}{576} eines Grans (0,1124
Milligr.) erhielt. Diese Quantität verursachte, dasz sich alle Tentakeln ein-
bogen: aber nach 24 Stunden war nur eine Spur von Zusammenballung.# Chemische Experimente mit Pflanzen

da. Eins dieser selben Blätter wurde sodann in eine schwache Auflösung des kohlensauren Salzes gelegt und nach 1 Stunde 45 Minuten zeigten die Tentakeln in der Hälfte ihrer Länge einen erstaunlichen Grad von Zusammenballung. Zwei andere Blätter wurden dann in eine viel stärkere Auflösung von einem Theil des salpetersauren Salzes in 146 Theilen Wasser (3 Gran auf 1 Unze) gelegt; an einem derselben war nach 3 Stunden keine bemerkbare Veränderung vorhanden; aber in dem andern war nach 52 Minuten eine Spur von Zusammenballung zu sehen, und nach 1 Stunde 22 Minuten war sie deutlich bemerkbar; aber selbst nach 2 Stunden 12 Minuten war sicherlich nicht mehr Zusammenballung eingetreten, als nach einem 5—10 Minuten dauernden Eintauchen in eine gleich starke Lösung des kohlensauren Salzes erfolgt sein würde. Endlich wurde noch ein Blatt in dreiszig Tropfen einer Lösung von einem Theil phosphorsauren Ammoniaks in 43750 Theile Wasser (1 Gran auf 100 Unzen) gelegt, so dasz es \frac {1}{1600} eines Grans (0,04079 Milligr.) erhielt; dies verursachte, dasz die Tentakeln bald stark eingebogen wurden; und nach 24 Stunden war der Inhalt der Zellen in ovale und unregelmäszige rundliche Massen zusammengeballt, mit einem sichtbaren an den Wänden herumfließenden Strom von Protoplasma. Aber nach Verlauf einer so langen Zeit würde Zusammenballung erfolgt sein, was auch die Einbiegung verursacht haben möchte.

# Wirkung verschiedener Salze

Nur wenig andere Salze auszer denen des Ammoniaks wurden in Bezug auf den Procesz der Zusammenballung versucht. Ein Blatt wurde in eine Lösung von 1 Theil Chlornatrium in 218 Theile Wasser gelegt und nach 1 Stunde war der Inhalt der Zellen zu kleinen unregelmäszigen rundlichen bräunlichen Massen zusammengeballt; nach 2 Stunden waren dieselben beinahe ganz zerfallen und breiig. Es war augenscheinlich, dasz das Protoplasma nachtheilig afficirt worden war; und bald darauf erschienen einige der Zellen ganz leer. Diese Wirkungen weichen gänzlich von denen ab, welche sowohl durch die verschiedenen Ammoniaksalze als durch verschiedene organische Flüssigkeiten und durch unorganische auf die Drüsen gelegte Theilchen hervorgebracht wurden. Eine Auflösung derselben Stärke von kohlensaurem Natron und kohlensaurem Kali wirkte auf beinahe dieselbe Weise wie das Chlorid; und hier wieder hatten sich nach 2 Stunden 30 Minuten die äuszeren Zellen von einigen der Drüsen ihres braunen breiigen Inhalts entleert. Wir werden im achten Capitel sehen, dasz Auflösungen mehrerer Natronsalze von halb der obigen Stärke Einbiegung verursachen, aber die Blätter nicht verletzen. Schwache Lösungen von schwefelsaurem Chinin, Nicotin, Campher, dem Gifte der Cobra u. s. w. bringen bald deutlich bemerkbare Zusammenballung hervor, während gewisse andere Substanzen (z. B. eine Auflösung von Curare) keine solche Tendenz haben.

# Einfluss von Säuren

Viele Säuren, obgleich sehr verdünnt, sind giftig; und obgleich sie, wie im achten Capitel gezeigt werden soll, die Tentakeln einzubiegen verursachen, so erregen sie doch nicht wahre Zusammenballung. So wurden Blätter in eine Auflösung von einem Theil Benzoesäure in 437 Theilen Wasser gelegt, und in 15 Minuten hatte sich die purpurne Flüssigkeit in den Zellen etwas von den Wänden abgezogen; doch war, als sie nach 1 Stunde 20 Minuten sorgfältig untersucht wurden, keine wahre Zusammenballung vorhanden; und nach 24 Stunden war das Blatt augenscheinlich todt. Andere Blätter zeigten, in Jodsäure, in demselben Grade verdünnt, nach 2 Stunden 15 Minuten dasselbe zusammengeschrumpfte Aussehen der purpurnen Flüssigkeit in den Zellen; und bei diesen wurde nach 6 Stunden 15 Minuten unter starker Vergröszerung gesehen, dasz sie mit auszerordentlich kleinen Kugeln von trüb röthlichem Protoplasma gefüllt waren, welche am nächsten Morgen, nach 24 Stunden, beinahe gänzlich verschwunden waren, da das Blatt augenscheinlich todt war. Auch war keine irgend welche wahre Zusammenballung in den Blättern zu sehen, welche in Propion-Säure derselben Stärke getaucht waren; aber in diesem Falle hatte sich das Protoplasma in unregelmäszigen Massen nahe den Basen der unteren Zellen der Tentakeln angesammelt.

# Zusammenballung durch organische Flüssigkeiten

Ein filtrirter Aufgusz von rohem Fleisch bringt starke aber nicht sehr schnelle Zusammenballung hervor. In einem in eine solche Flüssig-# Zusammenballung des Protoplasma

keit eingetauchten Blatt war nach 1 Stunde 20 Minuten, und in einem
andern nach 1 Stunde 50 Minuten ein wenig Zusammenballung zu be-
merken. Bei andern Blättern erforderte es eine beträchtlich längere Zeit:
z. B. zeigte eins, 5 Stunden lang eingetaucht, keine Zusammenballung;
aber nach 5 Minuten schon war eine Einwirkung deutlich bemerkbar, als
es in einige Tropfen einer Lösung von einem Theil kohlensauren Am-
moniaks in 146 Theile Wasser gelegt worden war. Einige Blätter wur-
den 24 Stunden in dem Aufgusz gelassen, und diese boten Zusammen-
ballung in einem wunderbaren Grade dar, so dasz die gebogenen Ten-
takeln dem unbewaffneten Auge ein deutlich geflecktes Ansehn zeigten.
Die kleinen purpurnen Protoplasma-Massen waren gewöhnlich oval oder
perlschnurartig, und nicht halb so oft kuglig wie es bei Blättern der
Fall ist, die der Einwirkung von kohlensaurem Ammoniak ausgesetzt wa-
ren. Sie unterlagen unaufhörlichem Formenwechsel; und der Strom von
farblosem Protoplasma rings um die Wände war nach einem Eintauchen
von 25 Stunden auffallend deutlich. Rohes Fleisch ist ein zu wirksames
Reizmittel und selbst kleine Stückchen verletzen gewöhnlich und tödten
auch manchmal die Blätter, denen sie gegeben werden; die zusammen-
geballten Massen von Protoplasma werden trüb oder beinahe farblos und
bieten einen ungewöhnlich körnigen Anblick dar, wie es ebenso bei Blät-
tern der Fall ist, welche in eine sehr starke Auflösung von kohlensaurem
Ammoniak getaucht worden sind. Ein Blatt, welches in Milch gethan
wurde, hatte in 1 Stunde den Inhalt seiner Zellen etwas zusammen-
geballt. Auf zwei andere Blätter, von denen eins 2 Stunden 30 Minuten
in menschlichem Speichel, und das andere 1 Stunde 20 Minuten in nicht
gekochtem Eiweisz gelegen hatte, hatten diese Flüssigkeiten nicht in die-
ser Weise gewirkt, obgleich dies ohne Zweifel der Fall gewesen sein
würde, wenn man mehr Zeit gelassen hätte. Diese beiden selben Blätter
hatten, nachdem sie später in eine Lösung von kohlensaurem Ammoniak
(3 Gran auf 1 Unze) gelegt wurden, ihre Zellen, das eine in 10 Minu-
ten, das andere in 5 Minuten zusammengeballt.

# Wirkung von Zuckerlösungen

Mehrere Blätter wurden 4 Stunden 30 Minuten lang in eine Lösung
von einem Theil weiszen Zuckers in 146 Theilen Wasser gelegt, und
keine Zusammenballung erfolgte; nachdem sie in eine Lösung derselben
Stärke von kohlensaurem Ammoniak gethan worden waren, hatte diese in
5 Minuten auf sie eingewirkt, wie es gleichfalls bei einem Blatte der
Fall war, welches 1 Stunde 45 Minuten in einer mäszig dicken Lösung
von Gummi arabicum gelassen worden war. Mehrere andere Blätter wur-
den einige Stunden lang in dichte Lösung von Zucker, Gummi und
Stärke gelegt, und der Inhalt ihrer Zellen wurde bedeutend zusammen-
geballt. Diese Wirkung dürfte der Exosmose zugeschrieben werden, denn
die Blätter im Syrup wurden ganz welk und diejenigen im Gummi und
Stärke etwas schlaff und ihre Tentakeln in der unregelmäszigsten Weise
herumgedreht, die längeren wie Korkzieher. Wir werden später sehen,
dasz Lösungen dieser Substanzen, wenn sie auf die Scheiben der Blätter
gebracht werden, keine Einbiegung hervorrufen. Stückchen weichen Zuckers
wurden zu dem Zweck um mehrere der Drüsen herumgelegt und bald auf-
gelöst und verursachten eine bedeutende Steigerung der Absonderung,
ohne Zweifel durch Exosmose; nach 24 Stunden zeigten die Zellen einen
gewissen Grad von Zusammenballung, obgleich die Tentakeln nicht ein-
gebogen waren. Glycerin verursacht in wenig Minuten deutlich bemerk-
bare Zusammenballung, die wie gewöhnlich in den Drüsen anfängt und
dann die Tentakeln hinunter geht; und dies kann, wie ich vermuthe, der
starken Anziehungskraft dieser Substanz für Wasser zugeschrieben wer-
den. Mehrere Stunden langes Eintauchen in Wasser verursacht einen
gewissen Grad von Zusammenballung. Zwanzig Blätter wurden zuerst
sorgfältig untersucht und nachdem sie verschieden lang in destillirtes
Wasser getaucht gelassen worden waren, wieder untersucht, was folgende
Resultate ergab: Man findet selten selbst eine Spur von Zusammenballung,
ehe 4 bis 5 und gewöhnlich noch mehr Stunden verstrichen sind. Wenn
jedoch ein Blatt schnell im Wasser eingebogen wird, wie manchmal be-
sonders bei warmem Wetter vorkommt, so kann die Zusammenballung in# Einleitung
wenig über 1 Stunde eintreten. In allen Fällen werden an Blättern, welche mehr als 24 Stunden im Wasser gelassen worden sind, die Drüsen schwarz, was beweist, dasz ihr Inhalt zusammengeballt ist; und in den Exemplaren, welche sorgfältig untersucht wurden, fand sich ziemlich gut ausgeprägte Zusammenballung in den oberen Zellen der Stiele. Diese Versuche wurden mit abgeschnittenen Blättern gemacht, und es kam mir der Gedanke, dasz dieser Umstand das Resultat beeinflussen möchte, da die Stiele vielleicht Wasser nicht schnell genug aufsaugen würden, um die Drüsen damit zu versorgen, während diese fortführen abzusondern. Aber diese Ansicht stellte sich als irrig heraus, denn eine Pflanze mit unverletzten Wurzeln, welche vier Blätter trug, wurde in destillirtes Wasser 47 Stunden lang eingetaucht, und die Drüsen wurden schwarz, obgleich die Tentakeln sehr wenig eingebogen wurden. In einem dieser Blätter war nur ein leichter Grad von Zusammenballung in den Tentakeln eingetreten; im zweiten etwas mehr, wobei der purpurne Inhalt der Zellen sich etwas von den Wänden getrennt hatte; im dritten und vierten, welche blasse Blätter waren, war die Zusammenballung in den oberen Theilen der Stiele deutlich bemerkbar. In diesen Blättern wechselten die kleinen Massen von Protoplasma, von denen viele oval waren, langsam ihre Form und Stellung, so dasz ein Untertauchen von 47 Stunden das Protoplasma nicht getödtet hatte. Bei einem früheren Versuche mit einer untergetauchten Pflanze waren die Tentakeln nicht im Geringsten eingebogen.

# Hitze und Zusammenballung
Hitze bringt Zusammenballung hervor. — Ein Blatt, dessen Tentakeln in den Zellen nur homogene Flüssigkeit enthielten, wurde 1 Minute lang in Wasser von 54,4°C. (130°F.) herum geschwenkt, und wurde dann so schnell wie möglich unter dem Microscop untersucht, d. h. in 2 oder 3 Minuten. Während dieser Zeit hatte der Inhalt der Zellen einen geringen Grad von Zusammenballung erfahren. Ein zweites Blatt wurde 2 Minuten in Wasser von 51,6°C. (125° F.) geschwenkt und wie vorher schnell untersucht. Die Tentakeln waren stark eingebogen; die purpurne Flüssigkeit war in allen Zellen ein wenig von den Wandungen abgeschrumpft und enthielt viele ovale und längliche Massen von Protoplasma, mit einigen äusserst kleinen Kugeln. Ein drittes Blatt wurde in Wasser von 51,6°C. gelassen, bis es abgekühlt war, und als es nach 1 Stunde 45 Minuten untersucht wurde, zeigten die eingebogenen Tentakeln etwas Zusammenballung, welche nach 3 Stunden deutlicher bemerkbar wurde, aber sich später nicht weiter vermehrte. Endlich wurde ein Blatt 1 Minute lang in Wasser von 48,8°C. (120°F.) geschwenkt, und dann 1 Stunde 26 Minuten lang in kaltem Wasser gelassen; die Tentakeln waren nur wenig eingebogen, und es war nur hie und da eine Spur von Zusammenballung zu bemerken. In allen diesen und andern Versuchen mit warmem Wasser zeigte das Protoplasma viel weniger Neigung sich zu kugligen Massen zusammenzuballen, als wenn sie durch kohlensaures Ammoniak gereizt wurden.

# Wiederauflösung des Protoplasmas
Wiederauflösung der zusammengeballten Massen von Protoplasma. — Sobald Tentakeln, welche ein Insect oder einen unorganischen Gegenstand umschlungen hatten, oder auf irgend eine andere Weise gereizt worden waren, sich vollständig wieder ausgestreckt haben, werden die zusammengeballten Massen von Protoplasma wieder aufgelöst und verschwinden; die Zellen werden wieder mit homogener purpurner Flüssigkeit angefüllt, wie sie es waren, ehe die Tentakeln eingebogen wurden. Der Procesz der Wiederauflösung fängt in allen Fällen bei den Basen der Tentakeln an, und schreitet an ihnen aufwärts fort bis zu den Drüsen. In allen Blättern jedoch, besonders in denen, welche mehrere Male in Thätigkeit gewesen sind, bleibt das Protoplasma in den obersten Zellen der Stiele in einem fortwährend mehr oder weniger zusammengeballten Zustand. Um den Procesz der Wiederauflösung zu beobachten, wurden folgende Beobachtungen angestellt: ein Blatt wurde 24 Stunden lang in ein wenig Lösung von einem Theil kohlensauren Ammoniak in 218 Theilen Wasser gelassen, und das Protoplasma wurde wie gewöhnlich in zahllose purpurne Kugeln zusammengeballt, welche unaufhörlich ihre Form veränderten. Das Blatt wurde dann gewaschen und in destillirtes Wasser gethan, und nach 3 Stunden 15 Minuten fiengen einige der# Wiederauflösung und Protoplasma

Kugeln an, durch ihre weniger klar bestimmten Conturen, Zeichen von Wiederauflösung darzubieten. Nach 9 Stunden waren viele von ihnen verlängert worden, und die umgebende Flüssigkeit in den Zellen war etwas mehr gefärbt, und zeigte deutlich, dasz die Wiederauflösung angefangen hatte. Nach 24 Stunden konnte, obgleich viele Zellen noch immer Kugeln enthielten, hier und da eine gesehen werden, welche mit purpur-ner Flüssigkeit gefüllt war, ohne eine Spur von zusammengeballtem Protoplasma; das Ganze war wieder aufgelöst worden. Ein Blatt mit zusammengeballten Massen, welche durch 2 Minuten langes Schwenken in Wasser von 51,6°C. verursacht waren, wurde in kaltem Wasser gelassen, und nach 11 Stunden zeigte das Protoplasma Spuren von anfangender Wiederauflösung. Als es drei Tage nach seinem Eintauchen in das warme Wasser wieder untersucht wurde, war ein deutlicher Unterschied vorhanden, obgleich das Protoplasma noch etwas zusammengeballt war. Ein anderes Blatt, bei welchem der Inhalt in allen Zellen durch die Einwir-kung einer schwachen Lösung von phosphorsaurem Ammoniak stark ge-ballt war, wurde 3 und 4 Tage lang in einer (als unschädlich bekannten) Mischung von einer Drachme Alkohol auf acht Drachmen Wasser gelassen, und als es wieder untersucht wurde, war jede Spur von Zusammenballung verschwunden, und die Zellen waren nun wieder mit homogener Flüssigkeit angefüllt.

# Einfluss von Zuckerlösungen

Wir haben gesehen, dasz bei Blättern, welche einige Stunden lang in dicken Lösungen von Zucker, Gummi und Stärke eingetaucht waren, der Inhalt ihrer Zellen sich bedeutend zusammenballt, dasz sie selbst mehr oder weniger welk, und ihre Tentakeln unregelmäszig verdreht wurden. Diese Blätter wurden, nachdem sie vier Tage lang in destillirtem Wasser gelassen worden waren, weniger welk, ihre Tentakeln streckten sich theilweise wieder aus, und die zusammengeballten Massen von Protoplasma waren theilweise wieder aufgelöst. Ein Blatt, dessen Tentakeln dicht über einer Fliege geschlossen waren und dessen Zelleninhalt stark zusammengeballt war, wurde in etwas Sherry-Wein gethan; nach 2 Stunden hatten sich mehrere der Tentakeln wieder ausgestreckt, und die andern konnten durch eine blosze Berührung wieder in ihre ordentlich ausgestreckte Stellung gebracht werden; auch waren jetzt alle Spuren der Zusammenballung verschwunden, und die Zellen wieder mit vollkommen homogener rosiger Flüssigkeit angefüllt. Die Wiederauflösung dürfte in diesen Fällen, wie ich vermuthe, der Exosmose zugeschrieben werden.

# Ursachen der Zusammenballung

Ueber die näheren Ursachen des Processes der Zusammenballung. Da die meisten der Reizmittel, welche die Einbiegung der Tentakeln verursachen, gleichfalls Zusammenballung in dem Inhalt ihrer Zellen hervorrufen, könnte dieser letztere Prozesz für das directe Resultat der Einbiegung gehalten werden; dies ist aber nicht der Fall. Wenn Blätter in ziemlich starke Lösungen von kohlensaurem Ammoniak, z. B. von drei oder vier und manchmal selbst von nur zwei Gran in einer Unze Wasser (d. h. ein Theil auf 109 oder 146 oder 218 Theile Wasser) gethan werden, so werden die Tentakeln gelähmt und werden nicht eingebogen; doch bieten sie bald stark ausgesprochene Zusammenballung dar. Ueberdies werden die kurzen centralen Tentakeln eines Blattes, welches in eine schwache Lösung von irgend einem Ammoniaksalz oder in irgend eine stickstoffhaltige organische Flüssigkeit getaucht worden ist, nicht im geringsten gebogen; demohngeachtet bieten sie alle Erscheinungen der Zusammenballung dar. Andrerseits verursachen mehrere Salze stark ausgesprochene Einbiegung aber keine Zusammenballung.

# Einfluss äußerer Reize

Es ist eine wichtige Thatsache, dasz, wenn ein organischer oder unorganischer Gegenstand auf die Drüsen der Scheibe gelegt wird, und die äuszeren Tentakeln hierdurch sich nach innen einzubiegen veranlaszt werden, nicht nur die Absonderung der Drüsen der letzten an Menge zunimmt und sauer wird, sondern der Inhalt der Zellen ihrer Stiele zusammengeballt wird. Der Procesz fängt immer in den Drüsen an, obgleich diese noch nicht irgend einen Gegenstand berührt haben. Es musz daher irgend eine Kraft oder ein Einflusz von den mittleren Drüsen den äuszeren Tentakeln übermittelt werden, erstens# Zusammenballung des Protoplasma

dem Theile nahe ihrer Basis um diesen Theil zum Einbiegen zu veranlassen, und dann zu den Drüsen, um sie zu reichlicherer Absonderung zu veranlassen. Nach einer kurzen Zeit senden oder reflectiren die in dieser Weise indirect gereizten Drüsen einen Einflusz ihre eigne Stiele hinab, welcher eine Zusammenballung in Zelle unter Zelle bis zu ihren Basen hervorruft.

Es erscheint auf den ersten Blick wahrscheinlich, dasz die Zusammenballung eine Folge davon ist, dasz die Drüsen zu reichlicherer Absonderung angeregt werden, so dasz nicht genügende Flüssigkeit in ihren Zellen und in den Zellen der Stiele gelassen wird, um das Protoplasma in Auflösung zu halten. Für diese Ansicht spricht auch die Thatsache, dasz Zusammenballung der Einbiegung der Tentakeln folgt, und dasz während der Bewegung die Drüsen gewöhnlich oder, wie ich glaube, immer reichlicher absondern als vorher. Ferner sondern die Drüsen während der Wiederausstreckung der Tentakeln viel weniger reichlich ab, oder hören ganz auf abzusondern, und dann werden die zusammengeballten Massen von Protoplasma wieder aufgelöst. Wenn überdies Blätter in dicke vegetabilische Lösungen oder Glycerin getaucht werden, so geht die Flüssigkeit in den Drüsenzellen nach auszen, und dann tritt Zusammenballung ein; und wenn die Blätter später in Wasser oder eine unschädliche Flüssigkeit von geringerem specifischen Gewicht als Wasser getaucht werden, so wird das Protoplasma dann wieder aufgelöst, und dies ist ohne Zweifel Folge von Endosmose.

Der Ansicht, dasz Zusammenballung durch den Austritt der Flüssigkeit aus den Zellen verursacht wird, stehen indesz folgende Thatsachen entgegen. Es scheint kein naher Zusammenhang zwischen dem Grad von erhöhter Absonderung und von Zusammenballung zu bestehen. So verursacht ein der Absonderung um eine Drüse hinzugefügtes Stückchen Zucker eine viel gröszere Zunahme der Absonderung und viel weniger Zusammenballung als ein Theilchen von kohlensaurem Ammoniak, welches auf dieselbe Weise gegeben wurde. Es scheint nicht wahrscheinlich zu sein, dasz reines Wasser eine starke Exosmose verursachen wird, und doch folgt häufig Zusammenballung nach Ein-tauchen in Wasser, von zwischen 16 und 24 Stunden, und immer nach Eintauchen von 24 bis 48 Stunden. Noch weniger wahrscheinlich ist es, dasz Wasser von einer Temperatur von 51,6° bis 54,4° C. (125° bis 130° F.) die Flüssigkeit nicht nur aus den Drüsen, sondern aus allen Zellen der Tentakeln bis hinab nach ihren Basen zu auszu-treten veranlassen sollte, und zwar so schnell, dasz Zusammenballung in 2 oder 3 Minuten hervorgebracht wird.

Ein anderes starkes Argument gegen diese Ansicht ist, dasz nach vollständiger Zusammenballung die Kugeln und die ovalen Massen von Protoplasma in einer reichlichen Menge von dünner farbloser Flüssigkeit herumschwimmen, so dasz wenigstens die letzten Stadien des Processes nicht Folge davon sein können, dasz nun Mangel an Flüssigkeit eintritt, welche das Protoplasma hätte gelöst erhalten sollen. Es gibt noch einen stärkeren Beweis dafür, dasz Zusammenballung von der Absonderung unabhängig ist; denn die in dem ersten Capitel beschriebenen Papillen, mit wel-cher die Blätter dicht besetzt sind, sind nicht drüsenartig und sondern nicht ab; und doch saugen sie sehr schnell kohlensaures Ammoniak oder einen Aufgusz von rohem Fleisch auf, worauf dann ihr Inhalt der Zusammenballung unterliegt, welche sich nachher in die Zellen des umgebenden Gewebes ausbreitet. Wir werden später sehen, dasz die purpurne Flüssigkeit in den empfindlichen Filamenten der Dionaea, welche nicht absondern, gleichfalls durch die Einwirkung einer schwa-chen Lösung von kohlensaurem Ammoniak der Zusammenballung unterliegt.

Der Procesz der Zusammenballung ist ein lebendiger; ich meine damit, dasz der Inhalt der Zellen lebendig und unverletzt sein musz, um in dieser Weise afficirt werden zu können, und er musz in einem oxygenirten Zustand sein, um den Procesz mit der gehörigen Ge-# Einleitung

# Zusammenballung des Protoplasma

# Wirkung der Hitze auf die Blätter

# Temperatur und Zusammenballung

# Sauerstoffreicher Zustand der Zellen# Experimentelle Beobachtungen

in demselben Gefäsz zwei Stunden lang ausgesetzt, und eins ihrer Blätter wurde dann in eine Lösung von einem Theil des kohlensauren Salzes in 137 Theilen Wasser gelegt; die Drüsen wurden augenblicklich schwarz, woraus sich ergab, dasz sie aufgesaugt hatten und dasz ihr Inhalt zusammengeballt war; aber in den Zellen, dicht unter den Drüsen, war selbst nach Verlauf von 3 Stunden keine Zusammenballung eingetreten. Nach 4 Stunden 15 Minuten hatten sich einige wenige, äuszerst kleine Kugeln von Protoplasma in diesen Zellen gebildet, aber selbst nach 5 Stunden 30 Minuten erstreckte sich die Zusammenballung nicht eine Drüsen-Länge die Stiele hinunter. Nach zahllosen Versuchen mit frischen Blättern, welche in eine Lösung dieser Stärke getaucht wurden, habe ich niemals die bewirkte Zusammenballung in auch nur annähernd so langsamem Tempo weitergehen sehen. Eine andere Pflanze wurde 2 Stunden in Kohlensäure gelassen, wurde aber dann 20 Minuten der frischen Luft ausgesetzt, während welcher Zeit die Blätter, welche von rother Farbe waren, etwas Sauerstoff aufge- saugt haben dürften. Eins derselben, sowie zum Vergleich ein frisches Blatt wurden nun in dieselbe Lösung gethan, wie vorher. Das erstere wurde wiederholt angesehen, und nach Verlauf von 65 Minuten wurden ein paar Kugeln von Protoplasma zuerst in den Zellen dicht unter den Drüsen aber nur in zwei oder drei der längeren Tentakeln bemerkt. Nach 3 Stunden war die Zusammenballung die Stiele von einigen wenigen Tentakeln eine Drüsen-Länge hinabgegangen. Auf der andern Seite war in dem gleich behandelten frischen Blatt die Zusammen- ballung in vielen der Tentakeln nach 15 Minuten deutlich; nach 65 Minuten hatte sich dieselbe vier, fünf oder noch mehrmals die Länge der Drüsen an den Stielen hinab erstreckt; und nach 3 Stunden waren die Zellen aller Tentakeln ein Drittel oder die Hälfte ihrer ganzen Länge afficirt. Es kann demnach nun kein Zweifel mehr sein, dasz die Thatsache, dasz Blätter der Kohlensäure ausgesetzt werden, entweder für eine Zeit lang den Procesz der Zusammenballung auf- hält, oder die Weiterleitung des gehörigen Einflusses, wenn die Drüsen später durch kohlensaures Ammoniak gereizt werden, hindert; und Cap. 3. Zusammenballung des Protoplasma.

# Protoplasma und Sauerstoff

diese Substanz wirkt schneller und energischer als irgend eine andere. Es ist bekannt, dasz das Protoplasma der Pflanzen seine spontanen Bewegungen nur so lange zeigt, als es sich in einem sauerstoffreichen Zustande befindet; dasselbe ist auch mit den weiszen Blutkörperchen der Fall, sie bewegen sich nur, so lange sie Sauerstoff von den rothen Blutkörperchen empfangen. In Bezug auf Pflanzen s. Sachs, Lehrbuch der Botanik, 4. Aufl. 1874, p. 692. Ueber Blutkörperchen s. Quarterly Journal of Microscopical Science, April, 1874, p. 185.; aber die oben angeführten Fälle sind etwas verschieden hiervon, da sie mit dem Aufschub der Erzeugung oder Zu- sammenballung der Massen von Protoplasma durch die Ausschlieszung von Sauerstoff in Beziehung stehen.

# Zusammenfassung und Schlussbemerkungen

Der Procesz der Zusammenballung ist von der Einbiegung der Tentakeln und von der verstärkten Absonderung der Drüsen unabhängig. Er fängt innerhalb der Drüsen an, gleichviel ob diese direct oder indirect durch einen von andern Drüsen erhaltenen Reiz gereizt sind. In beiden Fällen wird der Procesz von Zelle an Zelle die ganze Länge der Tentakeln hinab fortgeleitet, und eine kurze Zeit an jeder queren Scheidewand aufgehalten. Bei blasz gefärbten Blättern ist die erste, aber nur bei starker Vergröszerung bemerkbare Veränderung das Auf- treten der feinsten Körnchen in der Flüssigkeit innerhalb der Zellen, welche diese leicht wolkig machen. Diese Körnchen ballen sich bald zu kleinen kugligen Massen zusammen. Ich habe eine Wolke dieser Art in 10 Secunden auftreten sehen, nachdem ein Tropfen einer Lösung von kohlensaurem Ammoniak der Drüse gegeben worden war. Bei dunkelrothen Blättern ist die erste sichtbare Veränderung häufig die Verwandlung der äuszeren Schicht der Flüssigkeit innerhalb der Zellen in sackartige Massen. Die zusammengeballten Massen verändern, wie# Entwicklung und Struktur der Zellen

sie sich auch entwickelt haben mögen, fortwährend ihre Form und
Stellung. Sie sind nicht mit Flüssigkeit erfüllt, sondern solid bis in
die Mitte. Endlich verschmelzen die farblosen Körner in dem Porto-
plasma, welches rings an den Wänden flieszt, mit den mittleren Ku-
geln oder Massen; aber es ist noch immer ein Strom von klarer
Flüssigkeit in den Zellen vorhanden. Sobald die Tentakeln sich voll-
kommen wieder ausgestreckt haben, werden die zusammengeballten
Massen wieder aufgelöst und die Zellen füllen sich mit einer homoge-
nen Flüssigkeit, wie sie zuerst waren. Der Procesz der Wiederauf-
lösung fängt in den Basen der Tentakeln an, und schreitet dann auf-
wärts zu den Drüsen fort, daher in entgegengesetzter Richtung zu der
der Zusammenballuug.

# Ursachen der Zusammenballung

Zusammenballung wird durch die allerverschiedensten Ursachen
erregt: — dadurch, dasz die Drüsen mehrere Male berührt werden, —
durch den Druck von Stückchen irgend welcher Art, und da diese von
der dichten Absonderung getragen werden, können sie kaum mit dem
Gewicht eines Milliontel Gran auf die Drüsen drücken. Nach Hofmeister (citirt von
Sachs, Lehrbuch der Botanik, französ.
Uebers. 1874, p. 958) hemmt sehr leichter Druck die Bewegungen des Protoplasma
und veranlaszt sogar seine Lösung von den Zellwänden. Der Procesz der Zu-
sammenballung ist aber eine verschiedene Erscheinung, da er sich auf den Zellen-
inhalt und nur in secundärer Weise auf die Protoplasmaschicht bezieht, welche
den Wänden entlang flieszt, obschon ohne Zweifel die Wirkungen eines Druckes oder
einer Berührung durch diese Schicht übermittelt werden musz., — dadurch,
daz die Tentakeln dicht unter den Drüsen abgeschnitten werden, —
dasz die Drüsen verschiedene Flüssigkeiten oder Substanzen aus ge-
wissen Körpern aufgelöst aufsaugen, — durch Exosmose — und durch
einen gewissen Grad von Wärme. Auf der andern Seite erregt eine
Temperatur von ungefähr 65,5° C. (150° F.) keine Zusammenballung,
noch bewirkt dies das plötzliche Zerdrücken einer Drüse. Wenn eine
Zelle geborsten ist, erleidet weder die ausgetretene Substanz, noch die,
welche noch in den Zellen bleibt, eine Zusammenballung, wenn kohlen-
saures Ammoniak hinzugefügt wird. Eine sehr starke Lösung dieses
Salzes und ziemlich grosze Stückchen rohen Fleisches verhindern, dasz
die zusammengeballten Massen sich ordentlich entwickeln. Aus diesen
Thatsachen können wir entnehmen, dasz die protoplasmatische Flüssig-
keit in den Zellen nicht zusammengeballt wird, wenn sie nicht in
einem lebendigen Zustande sich befindet, und nur unvollkommen, wenn
die Zelle verletzt worden ist. Wir haben auch gesehen, dasz die
Flüssigkeit in einem sauerstoffreichen Zustand sein musz, wenn der
Procesz der Zusammenballung von Zelle zu Zelle in dem richtigen
Tempo fortschreiten soll.

# Einfluss von Flüssigkeiten und Temperaturen

Verschiedene stickstoffhaltige Flüssigkeiten und Salze von Am-
moniak bringen Zusammenballung hervor, aber in verschiedenen Graden
und in verschiedener Geschwindigkeit. Kohlensaures Ammoniak ist
die kräftigste von allen bekannten Substanzen; die Aufsaugung von
\frac {1}{134400} eines Gran (0,000482 Milligr.) durch eine Drüse genügt, in
allen Zellen desselben Tentakels eine Zusammenballung zu verursachen.
Cap. 3. Zusammenballung des Protoplasma.

# Veränderungen der Drüsen

Die erste Wirkung des kohlensauren und einiger anderer Salze des
Ammoniak, ebenso wie einiger anderer Flüssigkeiten besteht in dem
Dunkel- oder Schwarzwerden der Drüsen. Dies erfolgt selbst nach
langem Eintauchen in kaltes destillirtes Wasser. Es hängt augen-
scheinlich hauptsächlich von der starken Zusammenballung des Zellen-
inhalts ab, welcher hierdurch undurchsichtig wird und das Licht nicht
reflectirt. Einige andere Flüssigkeiten machen die Drüsen heller roth,
während gewisse, wenn auch sehr verdünnte Säuren das Gift der Cobra-
Schlange u. s. w. die Drüsen vollkommen weisz und undurchsichtig
machen; und dies scheint von dem Gerinnen ihres Inhalts ohne irgend
eine Zusammenballung abzuhängen. Ehe sie in dieser Weise afficirt
werden, sind sie demohngeachtet fähig, wenigstens in einigen Fällen,
in ihren eigenen Tentakeln Zusammenballung zu erregen.# Zentrale Drüsen und ihre Reaktionen

Dasz die centralen Drüsen, wenn sie gereizt werden, centrifugal einen gewissen Einflusz den äuszeren Drüsen zusenden, welcher diese veranlaszt, einen centripetalen, Zusammenballung verursachenden Reiz zurück zu senden, ist vielleicht die interessanteste Thatsache, die in diesem Capitel angeführt worden ist. Aber der ganze Procesz der Zusammenballung ist an und für sich selbst schon eine auffallende Erscheinung. Wenn das peripherische Ende eines Nerven berührt oder gedrückt und eine Empfindung gefühlt wird, so nimmt man an, dasz eine unsichtbare moleculäre Veränderung von einem Ende des Nerven zum andern übermittelt wird; wenn aber eine Drüse der Drosera wiederholt berührt wird, so können wir wirklich sehen, wie eine molekuläre Veränderung von der Drüse aus die Tentakeln hinunter geht, wenngleich diese Veränderung wahrscheinlich von einer sehr verschiedenen Natur von der in einem Nerven vor sich gehenden ist. Da endlich so viele und so sehr verschiedene Ursachen Zusammenballung erregen, so scheint daraus hervorzugehen, dasz die lebendige Substanz in den Drüsenzellen in einem so unsteten Zustande sich befindet, dasz beinahe jede Störung genügt, ihre moleculäre Natur zu verändern, wie es mit gewissen chemischen Verbindungen der Fall ist. Und diese Veränderung in den Drüsen, mögen diese direct oder durch einen von andern Drüsen empfangenen Reiz erregt worden sein, wird von Zelle zu Zelle weiter geführt und verursacht, dasz Körnchen von Protoplasma entweder wirklich in der vorher klaren Flüssigkeit erzeugt werden oder verschmelzen und so sichtbar werden.

# Supplementäre Beobachtungen über den Prozess der Zusammenballung

Drosera rotundifolia. Cap. 3. Wir werden später sehen, dasz eine schwache Lösung von kohlen-sauren Ammoniak Zusammenballung in den Zellen der Wurzeln der Drosera hervorruft; und dies führte mich dazu, einige Versuche an den Wurzeln andrer Pflanzen zu machen. Ich grub in den letzten Tagen des Oktober das erste Unkraut, das mir in den Weg kam, aus, nämlich Euphorbia peplus, wobei ich mich in Acht nahm, die Wurzeln nicht zu verletzen; diese wurden gewaschen und in ein wenig Lösung von einem Theil kohlensaurem Ammoniak in 146 Theilen Wasser gestellt. In weniger als 1 Minute sah ich eine Wolke von Zelle zu Zelle mit wunderbarer Schnelligkeit die Wurzeln hinauf gehen. Nach 8 bis 9 Minuten wurden die feinen Körner, welche dieses wolkige Aussehen verursachten, nach den Endspitzen der Wurzeln zu in viereckige Massen von brauner Substanz zusammengeballt, und einige derselben veränderten bald ihre Form und wurden kuglig. Einige der Zellen blieben indessen unberührt. Ich wiederholte dieses Experiment mit einer andern Pflanze derselben Species, aber ehe ich das Exemplar in den Focus unter dem Mikroskop bekommen konnte, hatten sich Wolken von Körnchen und viereckige Massen von röthlicher und brauner Substanz gebildet und hatten sich an den Wurzeln weit hinauf verbreitet. Eine frische Wurzel wurde nun 18 Stunden lang in einer Drachme einer Lösung von einem Theil des kohlen-sauren Salzes in 437 Theilen Wasser gelassen, so dasz sie ⅛ Gran oder 2024 Milligr. erhielt. Als sie untersucht wurde, enthielten die Zellen aller Wurzeln in ihrer ganzen Länge zusammengeballte Massen von röthlicher und brauner Substanz. Ehe ich diese Experimente machte, waren mehrere Wurzeln genau untersucht worden und nicht eine Spur von einem wolkigen Aussehen, oder von körnigen Massen, konnte in irgend einer derselben gesehen werden. Es wurden ebenso Wurzeln 35 Minuten lang in eine Lösung von einem Theil kohlensauren Kali in 218 Theilen Wasser getaucht; aber dieses Salz brachte keine Wirkung hervor. Ich will hier hinzufügen, dasz dünne Scheibchen des Stammes der Euphorbia in dieselbe Lösung gethan wurden, und dasz die Zellen, welche grün waren, augenblicklich wolkig wurden, während andere, welche vorher farblos waren, mit braunen Wolken bedeckt wurden, in Folge der Bildung zahlloser Körnchen von dieser Färbung. Ich habe ebenso bei verschiedenen Arten von Blättern, welche einige Zeit in einer Lösung von kohlensaurem Ammoniak gelassen worden waren, gesehen, dasz die Körner von Chlorophyll zusammenliefen und theil-# Zusammenballung des Protoplasma

weise verschmolzen; und dies scheint auch eine Form der Zusammenballung zu sein. Pflanzen der Wasserlinse (Lemna) wurden zwischen 30 und 45 Minuten in einer Lösung von einem Theil dieses selben Salzes in 146 Theilen Wasser gelassen; dann wurden drei oder vier ihrer Wurzeln untersucht. In zwei derselben umschlossen die Zellen, welche vorher nur klare Flüssigkeit enthalten hatten, jetzt kleine grüne Kugeln. Nach 1½ bis 2 Stunden erschienen ähnliche Kugeln in den Zellen an den Rändern der Blätter, aber ob das Ammoniak die Wurzeln hinauf gegangen, oder direct von den Blättern aufgesaugt worden war, kann ich nicht sagen. Da eine Art, Lemna arrhiza, keine Wurzeln hervorbringt, ist die letztere Alternative vielleicht die wahrscheinlichste. Nach ungefähr 2½ Stunden waren einige der kleinen grünen Kugeln in den Wurzeln in kleine Körner zerbrochen, welche Brown’sche Bewegung zeigten. Einige Wasserlinsen wurden auch 1 Stunde 30 Minuten lang in einer Lösung von einem Theil kohlensaurem Kali in 218 Theilen Wasser gelassen; hier konnte aber keine bestimmte Veränderung in den Zellen der Wurzeln bemerkt werden; als indesz dieselben Wurzeln 25 Minuten lang in einer Lösung von kohlen-sauren Ammoniak derselben Stärke gelegt worden waren, bildeten sich kleine grüne Kugeln. Eine grüne See-Alge wurde einige Zeit in dieser selben Lösung gelassen; sie war aber nur in sehr zweifelhafter Art afficirt. Auf der anderen Seite zeigte eine rothe See-Alge mit gefiederten Blättern eine starke Einwirkung. Der Inhalt der Zellen ballte sich zu gebrochenen Ringen zusammen, die noch von rother Färbung waren und sehr langsam und unbedeutend ihre Form veränderten; die mittleren Räume in diesen Ringen wurden wolkig von rother körniger Substanz. Die hier mitgetheilten That-sachen (ob sie neu sind, weisz ich nicht) deuten an, dasz vielleicht interessante Resultate durch Beobachtung der Wirkung verschiedener salziger Lösungen und andrer Flüssigkeiten auf die Wurzeln der Pflanzen gewonnen werden können.

# Die Wirkung der Wärme auf die Blätter

Art der Versuche. — Wirkungen kochenden Wassers. — Warmes Wasser verursacht rapide Einbiegung. — Wasser auf höherer Temperatur verursacht nicht sofortige Einbiegung, tödtet aber die Blätter nicht, wie ihr späteres Wieder-ausbreiten und das Zusammenballen des Protoplasma zeigt. — Eine noch höhere Temperatur tödtet die Blätter und coagulirt den eiweiszhaltigen Inhalt der Drüsen. Bei meinen Beobachtungen über Drosera rotundifolia schienen die Blätter während sehr warmen Wetters schneller über thierische Substanzen eingebogen zu werden und längere Zeit eingebogen zu bleiben, als während kalten Wetters. Ich wünschte daher festzustellen, ob Wärme allein eine Einbiegung veranlassen würde, und welche Temperatur die wirksamste wäre. Es bot sich noch ein anderer interessanter Punkt dar, die Frage nämlich: bei welchem Hitzegrade das Leben vernichtet würde, denn Drosera bietet in dieser Beziehung ungewöhnliche Leichtigkeit der Beobachtung dar, und zwar nicht wegen des Verlustes des Vermögens sich einzubiegen, sondern wegen des der späteren Wiederausbreitung und ganz besonders in dem Ausbleiben des Zusammenballens des Protoplasma, wenn die Blätter, nachdem sie erwärmt waren, in eine Lösung von kohlensaurem Ammoniak eingetaucht werden. Als meine Experimente über die Wirkungen der Wärme angestellt wurden, wuszte ich nicht, dasz der Gegenstand von mehreren Beobachtern sorgfältig untersucht worden war. So ist z. B. Sachs überzeugt (Lehrbuch der Botanik, 4. Aufl., 1874. p. 698, 701), dasz die allerverschiedensten Pflanzen sämmtlich umkommen, wenn sie 10 Minuten lang in Wasser von 45° bis 46°C. gehalten werden; und er gelangt zu dem Schlusse, dasz das Protoplasma in ihren Zellen, im feuchten Zustand, bei einer Temperatur von zwischen 50° und 60°C. coagulirt. Max Schulze und Kühne „fanden (citirt von Dr. Bastian in „Contemporary Review, 1874, p. 528‟), dasz das Protoplasma der Pflanzenzellen, mit dem sie experimentirten,# Kapitel 4: Versuche über die Wirkung der Wärme

## Versuchsanordnung und Methodik

## Ergebnisse der Experimente

## Beobachtungen zu den Tentakeln und Drüsen

## Vergleich mit anderen Pflanzen und Organismen

## Erste Experimente mit Drosera rotundifolia# Temperaturversuche und deren Auswirkungen

Das Blatt, welches der Temperatur von 43,3°C. (110° F.) ausgesetzt worden war, wurde in 15 Minuten stark eingebogen, und in 2 Stunden umfaszte jeder einzelne Tentakel dicht das Fleisch. Dasselbe trat, wenn gleich nach etwas längerem Intervallen, mit den andern sechs Blättern ein. Es geht daher hieraus augenscheinlich hervor, dasz das warme Bad ihre Empfindlichkeit bei einer Reizung mit Fleisch erhöht hatte.

# Beobachtungen zur Einbiegung

Ich beobachtete nun zunächst den Grad der Einbiegung, welche Blätter innerhalb bestimmter Zeiten erlitten, während sie immer noch in warmes Wasser eingetaucht blieben, welches so nahe als möglich auf derselben Temperatur gehalten wurde; ich will aber hier wie in andern Fällen nur einige wenige der von mir angestellten Versuche anführen. Ein Blatt wurde 10 Minuten lang in Wasser von 37,7°C. (100° F.) gelassen, es trat aber keine Einbiegung ein. Bei einem zweiten, in derselben Weise behandelten Blatte wurden indessen einige wenige seiner äuszeren Tentakeln in 6 Minuten sehr unbedeutend eingebogen, und in 10 Minuten trat bei mehreren eine unregelmäszige aber nicht starke Einbiegung ein.

# Weitere Experimente mit unterschiedlichen Temperaturen

Ein drittes in Wasser von 40,5°—41,1°C. (105°—106° F.) gehaltenes Blatt wurde in 6 Minuten sehr mäszig eingebogen. Ein weiteres in Wasser von 43,3°C. (110° F.) gelassenes Blatt war in 4 Minuten etwas, und in Zeit von 6 zu 7 Minuten beträchtlich eingebogen. Drei Blätter wurden in Wasser gelegt, welches ziemlich schnell erhitzt wurde; zu der Zeit nun, wo die Temperatur auf 46,1° bis 46,6°C. (115°—116° F.) gestiegen war, waren alle drei eingebogen.

# Reaktion auf Temperaturveränderungen

Ich entfernte dann die Lampe und in wenig Minuten war jeder einzelne Tentakel dicht eingebogen. Das Protoplasma innerhalb der Zellen war nicht getödtet, denn es war in deutlicher Bewegung zu sehen; auch breiteten sich die Blätter wieder aus, nachdem sie 20 Stunden lang in kaltem Wasser gelassen worden waren. Ein anderes Blatt wurde in Wasser von 37,7°C. (100° F.) getaucht, welches auf 48,8°C. (120° F.) erhitzt wurde; sämmtliche Tentakeln, mit Ausnahme der äussersten randständigen, wurden bald dicht eingebogen.

# Langzeitbeobachtungen und chemische Reaktionen

Das Blatt wurde nun in kaltes Wasser gelegt und in 7 Stunden 30 Minuten war es zum Theil und in 10 Stunden vollständig wieder ausgebreitet. Am folgenden Morgen wurde es in eine schwache Lösung von kohlensaurem Ammoniak gethan, worauf die Drüsen schnell schwarz wurden mit stark ausgesprochener Aggregation in den Tentakeln, wodurch gezeigt wurde, dasz das Protoplasma lebendig war und die Drüsen ihr Absorptionsvermögen nicht verloren hatten.

# Intensive Reaktionen bei hohen Temperaturen

Ein anderes Blatt wurde in Wasser von 43,3°C. (110° F.) gethan, welches auf 48,8°C. (120° F.) erhitzt wurde; alle Tentakeln, mit Ausnahme eines einzigen, wurden schnell und dicht eingebogen. Dies Blatt wurde nun in einige wenige Tropfen einer starken Lösung von kohlensaurem Ammoniak (ein Theil auf 109 Theile Wasser) gethan; in 10 Minuten wurden sämmtliche Drüsen intensiv schwarz und in 2 Stunden war das Protoplasma in den Stielzellen ordentlich zusammengeballt.

# Schlussfolgerungen aus den Experimenten

Ein anderes Blatt wurde plötzlich in Wasser von 48,8°C. (120° F.) getaucht und wie gewöhnlich umhergeschwenkt; in einer Zeit von 2 bis 3 Minuten waren die Tentakeln eingebogen, aber nur so weit, dasz sie zur Blattscheibe im rechten Winkel standen. Das Blatt wurde nun in dieselbe Lösung gebracht (d. h. ein Theil kohlensaures Ammoniak auf 109 Theile Wasser oder 4 Gran auf 1 Unze, was ich künftig immer als starke Lösung bezeichnen will), und als ich nach Verlauf von 1 Stunde wieder nach ihm sah, waren die Drüsen geschwärzt und das Zusammenballen war scharf ausgesprochen.

# Letzte Beobachtungen und Temperaturgrenzen

Nach Verlauf von noch weiteren 4 Stunden waren die Tentakeln viel bedeu-
tender eingebogen. Es verdient Beachtung, dasz eine Lösung, welche so stark ist wie diese, in gewöhnlichen Fällen niemals Einbiegung verur-
sacht. Endlich wurde ein Blatt plötzlich in Wasser von 51,6°C. (125°F.) gethan und darin gelassen, bis das Wasser abgekühlt war; die Tentakeln wurden dadurch hellroth und wurden bald eingebogen. Der Inhalt der Zellen unterlag in einem gewissen Grade einem Zusammenballen, welches im Verlauf von 3 Stunden noch zunahm; aber die Massen von Protoplasma wurden nicht sphärisch, wie es beinahe immer vorkommt, wenn Blätter in eine Lösung von kohlensaurem Ammoniak getaucht werden. Wir ersehen aus diesen Fällen, dasz eine Temperatur von 48,8°# Temperatur und Protoplasma-Bewegung

zu 51,6°C. (120°—125° F.) die Tentakeln zu schneller Bewegung anreizt, aber die Blätter nicht tödtet, wie sich entweder durch ihr später wieder eintretendes Ausbreiten oder durch die Zusammenballung des Protoplasma zeigt. Wir werden nun sehen, dasz eine Temperatur von 54,4°C. (130° F.) zu hoch ist, um eine sofortige Einbiegung zu verursachen, aber doch die Blätter nicht tödtet.

## Versuch 1

Ein Blatt wurde in Wasser von 54,4°C. (130° F.) getaucht und wie in sämmtlichen Fällen einige Minuten lang umhergeschwenkt; es fand sich aber keine Spur einer Einbiegung; dann wurde es in kaltes Wasser gebracht, und nach Verlauf von 15 Minuten war an einer kleinen Masse von Protoplasma in einer der Zellen eines Tentakels eine sehr langsame Bewegung deutlich zu sehen. Sachs gibt an (Lehrbuch der Botanik, 4. Aufl., 1874, p. 700), dasz die Bewegungen des Protoplasma in den Haaren einer Cucurbita aufgehört hätten, nachdem sie eine Minute lang in Wasser einer Temperatur von 47° bis 48°C. (117° bis 119° F.) ausgesetzt worden wären. Nach wenig Stunden wurden sämmtliche Tentakeln und die Blattränder eingebogen.

## Versuch 2

Ein anderes Blatt wurde in Wasser von 54,4° zu 55° C. (130°—131° F.) gethan; und, wie vorher, es trat keine Einbiegung ein. Nachdem es 1 Stunde lang in kaltem Wasser gelassen worden war, wurde es in die starke Lösung von Ammoniak gethan, und in Zeit von 55 Minuten waren die Tentakeln beträchtlich eingebogen. Die Drüsen, welche vorher heller roth gefärbt worden waren, waren nun schwarz geworden. Das Protoplasma in den Zellen der Tentakeln war deutlich zusammengeballt; aber die Kugeln waren viel kleiner als die gewöhnlich in nicht erhitzten Blättern unter Einflusz des kohlensauren Ammoniaks erzeugten. Nach Verlauf von weiteren 2 Stunden waren sämmtliche Tentakeln, mit Ausnahme von sechs oder sieben, dicht eingebogen.

## Versuch 3

Ein ähnliches Experiment wie das letzte, mit genau denselben Resultaten.

## Versuch 4

Ein schönes Blatt wurde in Wasser von 37,7°C. (100° F.) gebracht, welches dann auf 62,7°C. (154° F.) erwärmt wurde. Bald nach dem Eintauchen trat, wie sich hätte erwarten lassen, eine starke Einbiegung ein. Das Blatt wurde nun entfernt und in kaltes Wasser gelegt; da es aber einer so hohen Temperatur ausgesetzt worden war, breitete es sich niemals wieder aus.

## Versuch 5

Ein Blatt wurde in Wasser von 54,4°C. (130° F.) gelegt und dies auf 62,7°C. (145° F.) erwärmt; es trat keine sofortige Einbiegung ein. Das Blatt wurde dann in kaltes Wasser gebracht, und nach 1 Stunde 20 Minuten waren einige Tentakeln auf der einen Seite eingebogen. Dies Blatt wurde nun in die starke Lösung gethan, und in 40 Minuten waren alle dem Rande nahe stehenden Tentakeln ordentlich eingebogen und die Drüsen geschwärzt. Nach Verlauf von weiteren 2 Stunden 45 Minuten waren alle Tentakeln, mit Ausnahme von acht oder zehn, dicht eingebogen, während ihre Zellen in einem geringen Grade ein Zusammenballen des Protoplasma darboten; die Protoplasma-Kugeln waren aber sehr klein und die Zellen der äuszern Tentakeln enthielten etwas pulpöse oder zersetzte bräunliche Substanz.

## Versuch 6 und 7

Zwei Blätter wurden in Wasser von 57,2°C. (135° F.) gelegt, welches auf 62,7°C. (145° F.) erhitzt wurde; keines wurde eingebogen. Eins derselben zeigte indessen, nachdem es 31 Minuten in kaltem Wasser liegen gelassen worden war, eine geringe Einbiegung, welche nach Verlauf von weiteren 1 Stunde 45 Minuten zunahm, bis alle Tentakeln, ausgenommen sechzehn oder siebzehn, mehr oder weniger eingebogen waren; das Blatt war aber so bedeutend verletzt, dasz es sich nicht wieder ausbreitete. Das andere Blatt wurde, nachdem es eine halbe Stunde in kaltem Wasser gelassen worden war, in die starke Lösung gebracht; es folgte aber keine Einbiegung. Die Drüsen wurden indessen geschwärzt und in einigen Zellen trat ein geringes Zusammenballen ein, doch waren die Protoplasma-Kugeln äusserst klein. In anderen Zellen, besonders an den äuszeren Tentakeln, fand sich viel grünlich-braune pulpöse Substanz.

## Versuch 8

Ein Blatt wurde in Wasser von 60°C. (140° F.)# Kapitel 4: Versuche über die Wirkung der Wärme

## Einleitung der Versuche

## Versuch 9

## Versuch 10

## Versuch 11

## Schlussbemerkungen# Temperaturwirkungen auf Pflanzen

Die Blätter werden bei einer Temperatur von 54,4° C. (130° F.) nur für eine Zeit lang paralysiert, da sie später, mögen sie nun einfach in Wasser oder in eine Lösung von kohlensaurem Ammoniak gethan werden, eingebogen werden, und auch ihr Protoplasma einem Zusammenballen unterliegt. Diese große Verschiedenheit in den Wirkungen einer höheren und niedrigeren Temperatur dürfte mit der beim Eintauchen in starke und schwache Lösungen von Ammoniaksalzen zu vergleichen sein; denn die ersteren regen keine Bewegung an, während die letztern energisch wirken. Ein vorübergehendes Aufheben des Bewegungsvermögens als Folge der Hitze wird von Sachs in seinem Lehrbuch der Botanik, 4. Aufl., 1874, p. 857, als Wärmestarre bezeichnet.

# Auswirkungen extremer Temperaturen

Es verdient Beachtung, dass die Blätter der Drosera nach einem Eintauchen in Wasser von 54,4°C. (130° F.) durch eine Lösung von kohlensaurem Ammoniak, welche so stark ist, dass sie gewöhnliche Blätter lähmen und keine Einbiegung verursachen würde, zur Bewegung gereizt werden. Werden die Blätter wenige Minuten lang selbst einer Temperatur von 62,7° C. (145° F.) ausgesetzt, so werden sie nicht immer getötet; denn wenn sie nachher in kaltes Wasser oder in eine starke Lösung von kohlensaurem Ammoniak gelegt werden, so werden sie meistens, wenn schon nicht immer, eingebogen.

# Veränderungen im Protoplasma

Das Protoplasma innerhalb ihrer Zellen erleidet eine Zusammenballung, wenn auch die hierbei gebildeten Kügelchen äußerst klein sind und viele der Zellen zum Teil mit bräunlicher schmutziger Masse gefüllt werden. In zwei Fällen wurden die Blätter, wenn sie in Wasser von einer niedrigeren Temperatur als 54,4°C. (130° F.) eingelegt wurden, welches Wasser dann auf 62,7°C. (145° F.) weiter erwärmt wurde, während der ersten Zeit ihrer Eintauchung eingebogen, waren aber später, als sie in kaltem Wasser liegen gelassen wurden, unfähig, sich wieder auszubreiten.

# Empfindlichkeit der Drüsen

Werden die Blätter wenige Minuten einer Temperatur von 62,7°C. (145° F.) ausgesetzt, so verursacht dies zuweilen an einigen der empfindlicheren Drüsen ein Geflecktwerden mit dem porzellanartigen Aussehen; und bei einer Gelegenheit kam dies bei einer Temperatur von 60° C. (140° F.) vor. Bei einer anderen Gelegenheit wurde, als ein Blatt in Wasser von dieser Temperatur von nur 60°C. (140° F.) gelegt und darin liegen gelassen wurde, bis das Wasser abgekühlt war, jede einzelne Drüse wie Porzellan.

# Hohe Temperaturen und ihre Effekte

Werden Blätter wenige Minuten lang einer Temperatur von 65,5°C. (150°F.) ausgesetzt, so tritt meist diese Wirkung ein, doch behalten viele Drüsen eine rosa Färbung und viele bieten ein geflecktes Aussehen dar. Diese hohe Temperatur verursacht niemals echte Einbiegung; im Gegenteil werden die Tentakeln gewöhnlich zurückgebogen, wenn schon in einem geringeren Grade, als wenn sie in kochendes Wasser getaucht werden; und dies ist augenscheinlich Folge ihrer passiven Elasticität.

# Anomalien bei extremen Temperaturen

Waren die Blätter einer Temperatur von 65,5°C. (150°F.) ausgesetzt, so wird das Protoplasma, wenn es nachher der Einwirkung des kohlensauren Ammoniaks ausgesetzt wird, in zersetzte oder breiige entfärbte Masse verwandelt. Kurz, die Blätter werden meistens durch diesen Wärmegrad getötet; aber in Folge von Verschiedenheiten in Alter oder Konstitution variieren sie etwas in dieser Beziehung. In einem anomalen Falle entgingen vier unter den vielen Drüsen eines Blattes, welches in, auf 68,8° C. (156° F.) erhitztes Wasser eingetaucht worden war, der Verwandlung in porzellanartige Masse.

# Einfluss von Säuren auf die Gerinnung

Da die Undurchsichtigkeit und das porzellanartige Aussehen der Drüsen wahrscheinlich eine Folge der Gerinnung des Eiweißes ist, so will ich noch nach der Autorität der Dr. Burdon Sanderson hinzufügen, dass Eiweiß ungefähr bei 68,3°C. (155° F.) koaguliert, dass aber bei Anwesenheit von Säuren der Grad des Eintritts der Gerinnung niedriger liegt. Die Blätter der Drosera enthalten eine Säure und vielleicht dürfte eine Verschiedenheit in der Menge derselben die unbedeutenden Verschiedenheiten in den oben mitgeteilten Resultaten erklären.# Einleitung
unter diesen Drüsen zeigte einen unbedeutenden und auch unvollkom-
menen Grad von Zusammenballung.

# Drosera rotundifolia
Endlich ist es eine merkwürdige Thatsache, dasz die Blätter von
Drosera rotundifolia, welche auf kalten Hochlandmooren durch ganz
Grosz-Britanien gedeiht und (nach Hooker) innerhalb des Polarkreises
existirt, im Stande sind, selbst für eine kurze Zeit einem Eintauchen
in Wasser zu widerstehen, welches auf 62,7°C. (145° F.) erhöht wor-
den war.

# Temperaturempfindlichkeit
Allem Anscheine nach sind kaltblütige Thiere, wie schon hätte erwartet
werden können, für eine Erhöhung der Temperatur viel empfindlicher, als es
Drosera ist. So höre ich von Dr. Burdon Sanderson, dasz ein Frosch schon in Wasser
von einer Temperatur von nur 29,4° C. (85° F.) beunruhigt zu werden anfängt.
Bei 35° C. (95° F.) werden die Muskeln rigid und das Thier stirbt in steifem
Zustande.

# Eintauchen in kaltes Wasser
Es ist wohl noch der Bemerkung werth, dasz Eintauchen in kaltes
Wasser keine irgendwelche Einbiegung verursacht; ich brachte plötz-
lich vier Blätter, die ich Pflanzen entnommen hatte, welche schon
mehrere Tage hindurch in einer hohen Temperatur, meistens ungefähr
bei 23,8° C. (75° F.) gehalten worden waren, in Wasser von 7,2° C.
(45° F.); sie wurden aber kaum irgendwie afficirt, und zwar nicht so
viel wie einige andere Blätter von den nämlichen Pflanzen, welche zu
derselben Zeit in Wasser von 23,8° C. (75° F.) eingetaucht wurden;
diese wurden nämlich in einem geringen Grade eingebogen.

# Fünftes Kapitel
Die Wirkungen nicht-stickstoffhaltiger und stickstoffhaltiger
organischer Flüssigkeiten auf die Blätter.

# Nicht-stickstoffhaltige Flüssigkeiten
Nicht-stickstoffhaltige Flüssigkeiten. — Lösungen von arabischem Gummi. —
Zucker. — Stärke. — Verdünnter Alkohol. — Oliven-Öl. — Aufgusz und Abkochung
von Thee.

# Stickstoffhaltige Flüssigkeiten
Stickstoffhaltige Flüssigkeiten. — Milch. — Harn. — Flüssiges
Eiweisz. — Aufgusz von rohem Fleisch. — Unreiner Schleim. — Speichel. —
Lösung von Hausenblase. — Verschiedenheit in der Wirkung dieser beiden
Gruppen von Flüssigkeiten. — Abkochung von grünen Erbsen. — Abkochung
und Aufgusz von grünem Kohl. — Abkochung von Grasblättern.

# Vorläufige Versuche
Als ich im Jahre 1860 zuerst Drosera beobachtete und zu der
Ansicht geführt wurde, dasz die Blätter nährbare Substanz aus den
Insecten absorbirten, welche sie fiengen, schien es mir zweckmäszig zu
sein, mit ein paar gewöhnlichen Flüssigkeiten, welche stickstoffhaltige
Substanz enthielten und nicht enthielten, einige vorläufige Versuche
zu machen; die Resultate sind der Mittheilung werth.

# Versuchsanordnung
In allen den folgenden Fällen wurde ein Tropfen von demselben
spitzen Instrumente auf die Mitte des Blattes fallen gelassen; durch
wiederholte Versuche wurde ermittelt, dasz einer dieser Tropfen sehr
nahebei ein halbes Minim oder \frac {1}{960} einer flüssigen Unze oder 0,0295
Mgr. betrug. Doch beanspruchen diese Messungen offenbar durchaus keine
strenge Genauigkeit; überdies waren die Tropfen der klebrigen Flüssig-
keiten deutlich gröszer als die Wassertropfen. Nur ein Blatt wurde
an einer und derselben Pflanze zum Versuch benutzt, und die Pflanzen
wurden an zwei verschiedenen Localitäten gesammelt. Die Versuche
wurden während der Monate August und September angestellt. Bei
Beurtheilung der Wirkungen ist eine Vorsicht nothwendig: wird ein
Tropfen irgend einer klebenden Flüssigkeit auf ein altes oder schwaches
Blatt gelegt, dessen Drüsen aufgehört haben, reichlich abzusondern,
so trocknet der Tropfen zuweilen ein, besonders wenn die Pflanze in
einem Zimmer gehalten wird; dabei werden einige der centralen und
nahe nach dem Rande hin stehenden Tentakeln zusammengezogen, was
ihnen das trügerische Ansehen gibt, als wären sie eingebogen worden.
Dies kommt zuweilen mit Wasser vor, da es durch Vermischung mit
der klebrigen Flüssigkeit klebend geworden ist. Daher ist das einzige# Einleitung
sichere Kennzeichen —, und allein auf dies habe ich mich verlassen, —

# Bewegung der Tentakeln
das Einwärtsbiegen der äuszern Tentakeln, welche von der Flüssigkeit nicht berührt worden sind, oder höchstens allein an ihrer Basis. In diesem Falle ist die Bewegung allein eine Folge davon, dasz die cen- tralen Drüsen von der Flüssigkeit gereizt worden sind und einen moto- rischen Einflusz den äuszeren Tentakeln übermittelt haben. Die Blatt- scheibe krümmt sich gleichfalls häufig nach innen, in derselben Weise als wenn ein Insect oder ein Stückchen Fleisch auf die Scheibe gelegt wird. Diese letztere Bewegung wird, so viel ich gesehen habe, niemals durch das blosze Eintrocknen einer adhäsiven Flüssigkeit und die da- von abhängige Zusammenziehung der Tentakeln verursacht.

# Nicht-Stickstoffhaltige Flüssigkeiten
Zuerst will ich die nicht-stickstoffhaltigen Flüssigkeiten anführen. Als vorläufiger Versuch wurden Tropfen destillirten Wassers auf zwi- schen dreiszig und vierzig Blätter gebracht; und es trat keine irgend- welche Wirkung ein; trotzdem wurden aber in einigen anderen und seltenen Fällen einige wenige Tentakeln für kurze Zeit eingebogen; dies konnte aber auch dadurch verursacht worden sein, dasz die Drüsen zufällig berührt wurden, als die Blätter in eine passende Stellung ge- bracht wurden. Dasz Wasser keine Wirkung hervorbringen würde, hätte vorausgesehen werden können, da im andern Falle die Blätter von jedem Regenschauer zu Bewegung gereizt worden wären.

# Gummi
Gummi. — Es wurden Lösungen von vier verschiedenen Stärke- graden gemacht: eine von sechs Gran auf die Unze Wasser (ein Theil auf 73), eine zweite etwas stärker, doch immer noch sehr dünn, eine dritte mäszig dick und eine vierte so dick, dasz sie gerade nur noch von einem spitzigen Instrument abtropfen konnte. Diese wurden auf vierzehn Blättern versucht, wobei die Tropfen von 24 bis zu 44 Stunden auf den Blattscheiben gelassen wurden, meistens ungefähr 30 Stunden. Einbie- gung wurde hierdurch niemals verursacht. Es ist nothwendig, reines arabisches Gummi zum Versuch zu nehmen, denn einer meiner Freunde kaufte eine fertig bereitete Lösung und diese verursachte eine Biegung der Tentakeln; es wurde indessen später ermittelt, dasz dieselbe viel thie- rische Substanz, wahrscheinlich Leim, enthielt.

# Zucker
Zucker. — Tropfen von Lösungen weiszen Zuckers in drei verschie- denen Stärkegraden (deren schwächste einen Theil Zucker auf 73 Theile Wasser enthielt) wurden auf vierzehn Blättern von 32 bis 48 Stunden gelassen; es wurde aber keine Wirkung hervorgebracht.

# Stärke
Stärke. — Eine Mischung, ungefähr so dick wie Sahne, wurde auf sechs Blätter getropft und 20 Stunden auf denselben gelassen, ohne dasz eine Wirkung hervorgebracht worden wäre. Diese Thatsache überrascht mich, da ich glaube, dasz die Stärke im gewöhnlichen Handel meistens eine Spur von Leim enthält, und diese stickstoffhaltige Substanz Einbie- gung verursacht, wie wir im nächsten Capitel sehen werden.

# Verdünnter Alkohol
Verdünnter Alkohol. — Ein Theil Alkohol wurde auf sieben Theile Wasser zugesetzt und Tropfen hiervon wie gewöhnlich auf die Scheibe von drei Blättern gebracht. Im Laufe von 48 Stunden erfolgte keine Einbiegung. Um mich zu vergewissern, ob diese Blätter in keiner Weise beschädigt worden seien, wurden Stückchen Fleisch auf sie gelegt, und nach 24 Stunden waren dieselben dicht umfaszt. Ich brachte auch Tropfen von Sherry-Wein auf die andern Blätter; sie verursachten keine Einbiegung, doch schienen zwei Blätter etwas beschädigt zu sein. Wir werden später noch sehen, dasz abgeschnittene Blätter, wenn sie in ver- dünnten Alkohol von der angegebenen Stärke gelegt werden, nicht ein- gebogen werden.

# Oliven-Öl
Oliven-Öl. — Es wurden Tropfen hiervon auf elf Blätter ge- bracht, und in einer Zeit von 24 bis 48 Stunden wurde keine Wirkung hervorgebracht. Vier dieser Blätter wurden dann mit auf ihre Schei- ben gebrachten Fleischstückchen probirt; drei derselben fand ich nach 24 Stunden mit ihren sämmtlichen Tentakeln und Rändern dicht eingebo- gen, während am vierten nur einige wenige Tentakeln eingebogen waren. In einem spätern Capitel wird indessen gezeigt werden, dasz abgeschnittene Blätter beim Eintauchen in Oliven-Öl stark afficirt werden.

# Aufguss und Abkochung von Tee
Aufgusz und Abkochung von Thee. — Tropfen eines starken# Experimente mit verschiedenen Flüssigkeiten

## Thee und seine Wirkung
Aufgusses und einer starken Abkochung wurden ebenso wie Tropfen einer ziemlich schwachen Abkochung von Thee auf zehn Blätter gebracht; keines derselben wurde eingebogen. Ich prüfte später drei dieser Blätter dadurch, dasz ich Fleischstückchen zu den Tropfen hinzuthat, die noch immer auf den Blattscheiben liegen blieben; und als ich sie nach 24 Stunden untersuchte, waren sie dicht eingebogen. Der chemische Grundstoff des Thee’s, das Thein, wurde später gleichfalls versucht und brachte keine Wirkung hervor. Die eiweiszartige Substanz, welche die Theeblätter ursprünglich besessen haben müssen, war ohne Zweifel dadurch unlöslich gemacht worden, dasz die Blätter vollkommen getrocknet worden waren. Wir sehen hieraus, dasz mit Ausschlusz der Experimente mit Wasser ein und sechzig Blätter mit Tropfen der obengenannten nicht stickstoffhaltigen Flüssigkeiten versucht wurden; die Tentakeln wurden nicht in einem einzigen Falle eingebogen.

## Stickstoffhaltige Flüssigkeiten
Was die stickstoffhaltigen Flüssigkeiten betrifft, so wurden die ersten, welche mir in die Hand kamen, versucht. Die Experimente wurden in derselben Zeit und in genau derselben Art und Weise angestellt wie die vorhergehenden. Da es sich sofort offenbar herausstellte, dasz diese Flüssigkeiten eine bedeutende Wirkung hervorbrachten, so vernachlässigte ich es in den meisten Fällen zu notiren, wie bald die Tentakeln eingebo- gen wurden. Es trat dies aber immer in weniger als 24 Stunden ein, während die Tropfen nicht-stickstoffhaltiger Flüssigkeiten, welche keine Wirkung hervorbrachten, in allen Fällen während einer beträchtlich längeren Zeit beobachtet wurden.

## Milch
Milch. — Es wurden Tropfen auf sechzehn Blätter gebracht, und die Tentakeln von sämmtlichen, ebensowohl wie die Blattränder bei mehreren wurden bald bedeutend eingebogen. Die Zeitverhältnisse wurden nur in drei Fällen notirt, nämlich bei Blättern, auf welche ungewöhnlich kleine Tropfen gebracht worden waren. Ihre Tentakeln wurden in 45 Minuten ein wenig eingebogen, und nach Verlauf von 7 Stunden 45 Minuten waren die Blattränder von zweien so stark nach innen gekrümmt, dasz sie kleine, die Tropfen umfassende Schälchen bildeten. Diese Blätter breiteten sich am dritten Tage wieder aus. Bei einer andern Gelegenheit war die Scheibe eines Blattes in 5 Stunden, nachdem ein Tropfen Milch auf dieselbe gebracht worden war, bedeutend eingebogen.

## Menschlicher Harn
Menschlicher Harn. — Tropfen hiervon wurden auf zwölf Blätter gebracht, und die Tentakeln von allen, mit einer einzigen Ausnahme, wurden bedeutend eingebogen. Wie ich vermuthe in Folge von Verschiedenheiten in der chemischen Beschaffenheit des Harns bei verschiedenen Gelegenheiten schwankte die zum Hervorrufen der Bewegungen der Tentakeln erforderliche Zeit bedeutend; sie wurden aber immer in weniger als 24 Stunden bewirkt. Bei zwei Fällen habe ich notirt, dasz die sämmtlichen äuszeren Tentakeln in 17 Stunden vollständig eingebogen waren, nicht aber die Scheibe des Blattes. In einem andern Falle wurden die Ränder eines Blattes nach 25 Stunden 30 Minuten so stark eingebogen, dasz dasselbe in eine kleine Schale verwandelt worden war. Die Kraft des Harns liegt nicht im Harnstoff, welcher, wie wir später noch sehen werden, unwirksam ist.

## Eiweisz
Eiweisz (frisch aus einem Hühner-Ei). — Es wurde auf sieben Blätter gebracht und verursachte bei sechs eine ordentliche Einbiegung der Tentakeln. In einem Falle wurde der Blattrand selbst nach Verlauf von 24 Stunden bedeutend eingerollt. Das eine Blatt, welches nicht affi- cirt wurde, blieb 26 Stunden lang so; dann wurde es mit einem Tropfen Milch geprüft und dieser verursachte innerhalb 12 Stunden eine Einbie- gung der Tentakeln.

## Kalter filtrirtor Aufgusz von rohem Fleisch
Kalter filtrirtor Aufgusz von rohem Fleisch. — Dies wurde nur bei einem einzigen Blatte versucht, bei welchem die meisten äuszern Tentakeln und die Scheibe in 19 Stunden eingebogen wurden. Während der folgenden Jahre benutzte ich wiederholt diesen Aufgusz, um Blätter zu prüfen, an welchen mit andern Substanzen Experimente angestellt wor- den waren; es stellte sich heraus, dasz derselbe äuszerst energisch wirkte; da aber keine genaue Schilderung dieser Versuche aufgesetzt wurde, werden sie hier nicht mit angeführt.# Schleim und seine Eigenschaften

Schleim. — Dicker und dünner Schleim aus den Bronchialröhren, auf drei Blätter gebracht, verursachten Einbiegung. Ein Blatt mit dünnem Schleim hatte seine randständigen Tentakeln und die Scheibe in 5 Cap. 5. Stickstoffhaltige Substanzen. Stunden 30 Minuten ein wenig, und in 20 Stunden bedeutend einwärts gebogen. Die Wirksamkeit dieser Flüssigkeit ist ohne Zweifel eine Folge davon, dasz sich Speichel oder irgend eine eiweiszartige Substanz Schleim aus den Luftwegen soll nach Marshall, Outlines of Physiology, Vol. II, 1867, p. 364, etwas Eiweisz enthalten. ihr zugemischt hat, und nicht dem Mucin oder dem chemischen Grundstoff des Schleimes zuzuschreiben, wie wir in folgendem Capitel sehen werden.

# Speichel und seine Wirkung

Speichel. — Menschlicher Speichel hinterläszt, wenn er verdunstet wird, von 1,14 zu 1,19 Procent RückstandMüller, Handbuch der Physiologie, 1844. Bd. 1., p. 422.; dieser ergibt 0,25 Procent Asche, so dasz das Verhältnis stickstoffhaltiger Substanz, welche der Speichel enthält, sehr gering sein musz. Nichtsdestoweniger wirkten Spei- cheltropfen, welche auf die Scheibe von acht Blättern gethan wurden, auf sämmtliche. In einem Falle wurden die sämmtlichen äuszern Tentakeln, mit Ausnahme von neun, in 19 Stunden 30 Minuten eingebogen; in einem andern Falle wurden einige wenige in 2 Stunden und nach Verlauf von 7 Stunden 30 Minuten alle diejenigen, welche der Mitte nahe standen, wo der Tropfen lag, ebenso wie die Blattscheibe beeinfluszt. Seitdem ich diese Versuche gemacht habe, habe ich hundertmal Drüsen mit dem mit Speichel angefeuchteten Griff meines Scalpels eben berührt, um zu ermit- teln, ob ein Blatt sich im activen Zustande befände: dies zeigte sich nämlich im Verlaufe weniger Minuten durch das Einwärtsbiegen der Tentakeln.

# Hausenblase und ihre Effekte

Hausenblase. — Tropfen einer Lösung, welche ungefähr so dick wie Milch war, und einer noch dickeren Lösung wurden auf acht Blätter gebracht; die Tentakeln aller wurden eingebogen. In einem Falle wur- den die äuszern Tentakeln nach Verlauf von 6 Stunden 30 Minuten or- dentlich einwärts gekrümmt und die Blattscheibe nach 24 Stunden in theilweiser Ausdehnung. Da der Speichel so kräftig wirkt und doch ein so geringes Verhältnis an stickstoffhaltiger Substanz enthält, so versuchte ich, eine wie kleine Quantität von Hausenblase wirken würde. Ein Theil wurde in 218 Theilen destillirten Wassers aufgelöst und Tropfen hiervon auf vier Blätter gebracht. Nach 5 Stunden waren zwei derselben be- trächtlich und zwei mäszig eingebogen; nach 22 Stunden waren die er- sternen bedeutend und die letzteren noch viel mehr eingebogen. Im Ver- lauf von 48 Stunden von der Zeit an, wo die Tropfen auf die Blätter gebracht worden waren, hatten sich alle vier beinahe wieder ausgebreitet. Es wurden ihnen dann kleine Stücken Fleisch gegeben, und diese wirkten kräftiger als jene Lösung. Dann wurde weiter ein Theil Hausenblase in 437 Theilen Wasser aufgelöst; die in dieser Weise bereitete Flüssigkeit war so dünn, dasz sie nicht von reinem Wasser unterschieden werden konnte. Tropfen von der gewöhnlichen Grösze wurden dann auf sieben Drosera rotundifolia. Cap. 5 Blätter gethan, von denen ein jedes damit \frac {1}{960} Gran (oder 0,0295 Milligr.) erhielt. Drei derselben wurden 41 Stunden lang beobachtet, wurden aber in keiner Weise afficirt; bei dem vierten und fünften wurden zwei oder drei der äuszeren Tentakeln nach 18 Stunden eingebogen; beim sechsten waren es einige wenige mehr; und beim siebenten war auszerdem der Rand des Blattes eben bemerkbar nach innen gekrümmt. Die Tentakeln der vier letzten Blätter fiengen nach einem weiteren Verlauf von nur acht Stunden sich wieder auszustrecken an. Es ist hiernach \frac {1}{960} Gran Hau- senblase hinreichend, um die empfindlicheren oder activeren Blätter sehr unbedeutend zu afficiren.# Experimentelle Ergebnisse

Lösung nicht eingewirkt hatte, und auf ein anderes, bei welchem nur zwei seiner Tentakeln eingebogen waren, wurden Tropfen der Lösung, die so dick wie Milch war, gethan; und am nächsten Morgen, nach Verlauf von 16 Stunden, fand sich, dasz ihre sämmtlichen Tentakeln stark eingebogen waren. Alles zusammengenommen experimentirte ich mit den oben genannten stickstoffhaltigen Flüssigkeiten an vier und sechzig Blättern, wobei ich die fünf Blätter, welche ich mit der äuszerst schwachen Auflösung von Hausenblase probirte, nicht mitzähle, ebensowenig wie die zahlreichen später angestellten Versuche, von denen ich keine genauen Berichte bewahrt habe. Von diesen vier und sechzig Blättern waren bei drei und sechzig die Tentakeln und häufig auch die Blattscheiben ordentlich eingebogen. Das eine, welches keine Wirkung erkennen liesz, war wahrscheinlich zu alt und torpid. Um aber ein so grosses Verhältnis erfolgreicher Fälle zu erlangen, musz man Sorgfalt anwenden, junge und lebenskräftige Blätter auszuwählen. Blätter in einem solchen Zustande wurden mit gleicher Sorgfalt für die ein und sechzig Versuche mit nicht-stickstoffhaltigen Flüssigkeiten (ohne Einschlusz des Wassers) ausgewählt; und wir haben gesehen, dasz kein einziges derselben auch nur im geringsten Grade afficirt wurde. Wir dürfen daher ruhig schlieszen, dasz in den vier und sechzig Experimenten mit stickstoffhaltigen Flüssigkeiten die Einbiegung der äusseren Tentakeln eine Folge der Absorption stickstoffhaltiger Substanz durch die Drüsen der Tentakeln auf der Scheibe war.

# Weitere Versuche

Einige von den Blättern, welche von den nicht-stickstoffhaltigen Flüssigkeiten nicht afficirt wurden, wurden, wie oben angegeben worden ist, unmittelbar danach mit Stückchen Fleisch probirt und dadurch als im activen Zustande befindlich nachgewiesen. Auszer diesen Versuchen aber wurden noch drei und zwanzig von den Blättern, auf deren Scheiben noch immer Tropfen von Gummi, Syrup oder Stärke lagen, welche aber im Verlaufe von zwischen 24 und 48 Stunden keine Wirkung hervorgebracht hatten, mit Tropfen Milch, Harn oder Eiweisz geprüft. Von den in dieser Weise behandelten drei und zwanzig Blättern hatten siebzehn die Tentakeln und in einigen Fällen auch die Scheiben ordentlich eingebogen; aber ihre Lebenskräfte waren in etwas beeinträchtigt, denn die Schnelligkeit der Bewegung war entschieden langsamer, als wenn frische Blätter mit diesen selben stickstoffhaltigen Flüssigkeiten behandelt wurden. Diese Beeinträchtigung dürfte ebenso wie die Unempfindlichkeit von sechs jener Blätter einer Beschädigung durch Exosmose zuzuschreiben sein, welche durch die Dichte der auf ihre Scheiben gebrachten Flüssigkeiten verursacht wurde.

# Abkochungen und deren Wirkung

Die Resultate einiger weniger anderer Experimente mit stickstoffhaltigen Flüssigkeiten werden zweckmäszig hier noch mitgetheilt werden. Abkochungen einiger Gemüsearten, von denen bekannt ist, dasz sie reich an Stickstoff sind, wurden gemacht; dieselben wirkten wie thierische Flüssigkeiten. So wurden einige wenige grüne Erbsen eine Zeit lang in destillirtem Wasser gekocht; dann liesz man die mäszig dicke, in dieser Weise bereitete Abkochung sich setzen. Tropfen der darüber stehenden Flüssigkeit wurden auf vier Blätter gebracht; und als diese nach 16 Stunden wieder nachgesehen wurden, fand sich, dasz die Tentakeln und Scheiben von allen stark eingebogen waren. Aus einer Bemerkung Gerhardt’s schliesze ich, dasz in den Erbsen sich Legumin findet „in Kombination mit einem Alkali, eine nicht gerinnbare Lösung bildend“ und diese wird sich mit kochendem Wasser vermischen. In Bezug auf die oben verzeichneten und die folgenden Experimente will ich noch erwähnen, dasz nach der Angabe von Schiff gewisse Formen von Eiweisz existiren, welche durch kochendes Wasser nicht coagulirt, sondern in lösliche Peptone verwandelt werden.

# Weitere Experimente mit Kohlblättern

Bei drei Gelegenheiten wurden klein geschnittene Kohlblätter.# Pflanzen und ihre Eigenschaften

Pflanzen, ehe sich das Herz bildet, so wie sie von mir benutzt wurden, enthalten 2,1 Procent albuminöser Substanz, die äuszeren Blätter reifer Pflanzen 1,6 Procent. Watt’s Diction. of Chemistry, Vol. I. p. 653. in destillirtem Wasser eine Stunde oder fünf viertel Stunden lang gekocht; durch Abgieszen der Abkochung, nachdem man dieselbe sich hatte setzen lassen, wurde eine blasse schmutzig grüne Flüssigkeit erhalten. Tropfen von der gewöhnlichen Grösse wurden auf dreizehn Blätter gebracht. Ihre Tentakeln und Scheiben wurden nach 4 Stunden in einem völlig auszerordentlichen Grade eingebogen. Am nächsten Tage fand sich, dasz das Protoplasma innerhalb der Zellen der Tentakeln in der auf das Schärfste ausgesprochenen Art und Weise zusammengeballt war. Ich berührte auch das klebrige Secret rund um die Drüsen mehrerer Tentakeln mit minutiös Drosera rotundifolia. Cap. 5.

# Wirkung von Abkochungen

kleinen Tröpfchen der Abkochung am Kopfe einer kleinen Stecknadel, und in wenig Minuten waren die Tentakeln eingebogen. Da sich die Flüssig-keit als so kräftig herausstellte, wurde ein Theil mit drei Theilen Wasser verdünnt, und hiervon Tropfen auf die Scheiben von fünf Blättern gebracht; die Wirkung auf dieselben war am nächsten Morgen so stark, dasz ihre Scheiben vollständig übereinander gefaltet waren. Wir sehen hieraus, dasz eine Abkochung von Kohlblättern nahezu oder völlig so wirksam ist, wie ein Aufgusz von rohem Fleisch.

# Vergleich von Aufgüssen

Ungefähr die gleiche Quantität klein geschnittener Kohlblätter und destillirten Wassers wie im letzt erwähnten Experiment wurden 20 Stunden lang in einem sehr warmen Raum gehalten, aber nicht bis nahe an den Siedepunkt erhitzt. Tropfen dieses Aufgusses wurden auf vier Blätter gebracht. Eines derselben war nach 23 Stunden stark eingebogen, ein zweites unbedeutend; bei einem dritten waren nur die dem Rande näher stehenden Tentakeln eingebogen, und das vierte war durchaus gar nicht afficirt. Die Kraft dieses Aufgusses ist daher sehr viel geringer als die der Abkochung, und es ist ganz klar, dasz das Eintauchen der Kohlblätter für eine Stunde in Wasser auf der Temperatur des Siedepunkts viel wirk-samer ist, die Substanz, welche Drosera reizt, auszuziehen, als eine viele Stunden lang dauernde Eintauchung in warmes Wasser. Vielleicht wird der Zelleninhalt (wie Schiff in Bezug auf das Legumin bemerkt) dadurch geschützt, dasz die Wände aus Cellulose bestehn und dasz, bis diese durch kochendes Wasser zum Bersten gebracht sind, nur wenig von der einge-schlossenen eiweiszartigen Substanz aufgelöst wird. Aus dem starken Geruch gekochter Kohlblätter erkennen wir, dasz kochendes Wasser eine chemische Veränderung in ihnen hervorbringt und dasz sie dadurch bei weitem verdaulicher und nahrhafter für den Menschen gemacht werden. Es ist daher eine interessante Thatsache, dasz Wasser auf dieser Tem-peratur eine Substanz aus ihnen auszieht, welche Drosera in einem auszer-ordentlichen Grade reizt.

# Stickstoffhaltige Substanzen in Gräsern

Gräser enthalten bei weitem weniger stickstoffhaltige Substanz als Erbsen oder Kohlsorten. Die Blätter und Stengel dreier gemeiner Arten wurden klein geschnitten und eine Zeit lang in destillirtem Wasser ge-kocht. Nachdem diese Abkochung 24 Stunden stehen gelassen worden war, wurden Tropfen davon auf sechs Blätter gebracht; sie wirkten in einer ziemlich eigenthümlichen Art und Weise, von welcher im siebenten Capitol bei Besprechung der Ammoniaksalze noch weitere Beispiele angeführt werden. Nach 2 Stunden und 30 Minuten waren bei vier von den sechs Blättern die Scheiben bedeutend eingebogen, aber nicht die äuszeren Tentakeln; nach 24 Stunden war dasselbe bei allen sechs Blättern der Fall. Zwei Tage später waren die Blattscheiben ebenso wie die wenigen dem Rande näher stehenden Tentakeln, welche eingebogen worden waren, sämmtlich wieder ausgebreitet; auch war um diese Zeit ein groszer Theil der Flüssigkeit auf ihren Scheiben absorbirt. Augenscheinlich reizt daher die Abkochung die Drüsen auf der Scheibe stark und verursacht eine schnelle und bedeutende Einbiegung der Scheibe; aber verschieden von dem, was gewöhnlich eintritt, verbreitet sich der Reiz gar nicht oder nur in einem schwachen Grade auf die äuszeren Tentakeln.

# Zusatz zu Belladonna-Extract

Ich will hier noch hinzufügen, dasz ein Theil Belladonna-Extract Cap. 5. Stickstoffhaltige Substanzen.# Einleitung

gelöst und Tropfen hiervon auf sechs Blätter gebracht wurden. Am nächsten Tage waren sie alle sechs etwas eingebogen und nach Verlauf von 48 Stunden vollständig wieder ausgebreitet. Es war nicht das in dem Extract enthaltene Atropin, was diese Wirkung hervorbrachte, denn später ermittelte ich, dasz dies völlig wirkungslos ist. Ich verschaffte mir auch Bilsenkraut-Extract (Hyosciamus) aus drei Läden und machte Aufgüsse in derselben Stärke wie vorher. Von diesen drei Aufgüssen wirkte nur einer auf einige der Blätter, an welchen die Versuche gemacht wurden. Obgleich die Apotheker glauben, dasz alles Eiweisz bei der Dar-stellung dieser Drogen niedergeschlagen wird, so kann ich doch nicht daran zweifeln, dasz etwas Eiweisz gelegentlich darin erhalten wird; und eine Spur schon würde genügen, die empfindlicheren Blätter der Drosera zu reizen.

# Sechstes Kapitel

Die Verdauungskraft des Secrets der Drosera. Die Absonderung wird durch directe oder indirecte Reizung der Drüsen sauer. — Natur der Säure. — Verdauliche Substanzen. — Eiweisz, seine Verdauung durch Alkalien unterbrochen, durch Zusatz einer Säure wiederbegonnen. — Fleisch. — Fibrin. — Syntonin. — Zellgewebe. — Knorpel. — Faserknorpel. — Knochen. — Schmelz und Zahnbein. — Phosphorsaurer Kalk. — Fibröse Grundlage des Knochens. — Gallerte. — Chondrin. — Milch, Casein und Käse. — Leim. — Legumin. — Pollen. — Globulin. — Haematin. — Unverdauliche Substanzen. — Epidermoide Bildungen. — Fibroelastisches Gewebe. — Mucin. — Pepsin. — Harnstoff. — Chitin. — Cellulose. — Schieszbaumwolle. — Chlorophyll. — Fett und Oel. — Stärke. — Wirkung des Secrets auf lebende Samen. — Zusammenfassung und Schluszbemerkungen.

# Verdauungskraft des Drosera-Secrets

Da wir gesehen haben, dasz stickstoffhaltige Flüssigkeiten sehr verschieden von nicht-stickstoffhaltigen auf die Blätter von Drosera wirken, und da die Blätter über verschiedenen organischen Körpern viel länger zusammengeschlagen bleiben als über unorganischen Körpern, wie z. B. Stückchen Glas, Kohle, Holz u. s. w., so wird die Untersuchung interessant, ob sie nur Substanz absorbiren können, welche schon aufgelöst ist, oder ob sie dieselbe auflöslich machen, — mit anderen Worten, ob sie das Vermögen zu verdauen besitzen. Wir werden sofort sehen, dasz sie ganz gewisz diese Kraft besitzen und dasz sie auf albuminöse Verbindungen in genau derselben Art und Weise einwirken, wie es der Magensaft der Säugethiere thut; die verdaute Substanz wird auch nachher absorbirt. Diese Thatsache, welche ganz klar bewiesen werden wird, ist eine ganz wunderbare in der Physiologie der Pflanzen. Ich musz hier anführen, dasz ich bei allen meinen späteren Experimenten durch viele und werthvolle Winke und Hülfe unterstützt worden bin, die mir Dr. Burdon Sanderson mit der gröszten Freundlichkeit gewährte.

# Verdauung von eiweißhaltigen Körpern

Es wird ganz gut sein, wenn ich zu Gunsten irgend eines Lesers, welcher über die Verdauung zusammengesetzter eiweiszhaltiger Körper durch Thiere nichts weisz, noch vorausschicke, dasz dies mittelst eines Ferments, Pepsin, in Verbindung mit schwacher Salzsäure bewirkt wird, wenngleich beinahe jede andere Säure wirken wird. Doch hat weder das Pepsin noch eine Säure für sich allein irgend eine derartige Kraft. Der Angabe Schiff’s zufolge und im Gegensatz zur Meinung einiger Physiologen löst indessen augenscheinlich schwache Salzsäure, wenn schon langsam, eine sehr geringe Quantität geronnenen Eiweiszes auf. Schiff, Physiol. de la Digestion, Tom. II, 1867, p. 25. Wir haben gesehen, dasz wenn die Drüsen der Blattscheibe durch die Berührung irgend eines Gegenstandes, besonders eines, welcher stickstoffhaltige Substanz enthält, gereizt werden, die äuszern Tentakeln und häufig auch die Blattscheibe eingebogen werden; das Blatt wird hierdurch zeitweise in eine Schale oder einen Magen verwandelt. In derselben Zeit sondern die Drüsen der Scheibe reichlicher ab und die Absonderung wird sauer, Ueberdies übersenden sie einen gewissen Einflusz den Drüsen der äuszern Tentakeln, wodurch sie dieselben veranlassen, eine reichlichere Absonderung zu ergieszen, welche.# Säure und Absonderung

auch sauer oder noch saurer wird, als sie vorher war.
Da dies Resultat ein bedeutungsvolles ist, so will ich das Beweis- material geben. Das Secret vieler Drüsen auf dreiszig Blättern, welche in keiner Weise gereizt worden waren, wurde mit Lackmus-Papier geprüft; die Absonderung von zweiundzwanzig dieser Blätter afficirte nicht im geringsten die Farbe, während die von acht Blättern eine auszerordentlich schwache und zuweilen etwas zweifelhafte rothe Fär- bung verursachte. Indessen wirkten zwei andere alte Blätter, welche allem Anscheine nach mehrere Male eingebogen gewesen waren, viel entschiedener auf das Papier. Stückchen reinen Glases wurden dann auf fünf Blätter, Würfelchen von Eiweisz auf sechs, und Stückchen rohen Fleisches auf drei gelegt, bei deren keinem zu dieser Zeit die Absonderung sauer war. Nach einem Verlauf von 24 Stunden, wo beinahe alle die Tentakeln an diesen vierzehn Blättern mehr oder weniger eingebogen worden waren, prüfte ich nochmals das Secret, wobei ich Drüsen auswählte, welche noch nicht den Mittelpunkt er- reicht oder irgend einen Gegenstand berührt hatten; und nun war es deutlich sauer. Der Grad der sauren Beschaffenheit des Secretes variirte in etwas bei den Drüsen eines und desselben Blattes. Bei einigen Drosera rotundifolia.

# Reaktion auf Reize

Cap. 6.
Blättern wurden aus irgend welchen unbekannten Ursachen einige wenige Tentakeln nicht eingebogen, wie es häufig sich ereignet; und in fünf Fällen ergab es sich, dasz ihre Absonderung nicht im mindesten sauer war, während das Secret der daneben stehenden und eingebognen Ten- takeln auf demselben Blatte entschieden sauer war. Bei Blättern, welche dadurch gereizt worden waren, dasz Stückchen Glas auf die centralen Drüsen gelegt waren, war das Secret, welches sich unter diesen auf der Scheibe ansammelte, viel stärker sauer, als das von den äuszern Tentakeln ergoszne, welche bis dahin nur mäszig einge-bogen waren. Wenn Stückchen Eiweisz (und dies ist natürlich alka- lisch) oder Stückchen Fleisch auf die Scheibe gelegt wurden, so war die sich unter ihnen ansammelnde Absonderung gleichfalls stark sauer. Da rohes Fleisch, wenn es mit Wasser befeuchtet wird, leicht sauer ist, so verglich ich seine Wirkung auf Lackmus-Papier, ehe es auf die Blätter gelegt wurde, mit der späteren, wenn es von der Absonderung umspült war; es konnte dabei nicht der leiseste Zweifel sein, dasz die letztere sehr viel saurer war. Ich habe in der That hunderte von Malen den Zustand der Absonderung auf den Scheiben der Blätter, welche über verschiedene Gegenstände eingebogen waren, geprüft und habe sie niemals anders als sauer gefunden.

# Antiseptische Eigenschaften

Wir können daher schlieszen, dasz das Secret von nicht gereizten Blättern, obschon es in äuszerstem Grade klebrig ist, nicht sauer oder nur unbedeutend sauer ist, dasz es aber sauer wird oder viel stärker sauer, nachdem die Tentakeln begonnen haben, sich über irgend einen unorganischen oder organischen Körper zu biegen; es wird ferner noch stärker sauer, nachdem die Tentakeln einige Zeit lang über irgend einen Gegenstand dicht zusammengeschlagen geblieben sind.
Ich will hier den Leser daran erinnern, dasz die Absonderung bis zu einem gewissen Grade augenscheinlich antiseptisch ist, da sie das Auftreten von Moder und Infusorien aufhält und dadurch eine Zeit lang die Entfärbung und den Zerfall solcher Substanzen, wie das Weisze vom Ei, Käse u. s. w. verhindert. Sie wirkt daher wie der Magen- saft der höheren Thiere, von welchem bekannt ist, dasz er die Fäulnis durch Zerstörung der Microzymen aufhält.

# Untersuchung der Säure

Da ich begierig war zu erfahren, was für eine Säure das Secret enthielt, so wurden 445 Blätter in destillirtem Wasser gewaschen, wel- ches mir Prof. Frankland gegeben hatte; die Absonderung ist aber so klebrig, dasz es kaum möglich ist, das Ganze abzukratzen oder abzuwaschen.
Cap. 6. Natur der Säure im Secrete.
Auch die andern Bedingungen waren ungünstig, da es schon spät im Jahre war und die Blätter klein waren. Prof. Frankland übernahm es mit groszer Freundlichkeit, die in dieser Weise gesammelte Flüssigkeit zu prüfen. Die Blätter wurden durch reine Glasstückchen gereizt, welche 24 Stunden vorher auf sie gelegt wurden. Ohne Zweifel würde viel mehr# Chemische Analyse und Experimente

Säure abgesondert worden sein, wenn die Blätter durch thierische Substanz gereizt worden wären; dies würde aber die Analyse schwieriger gemacht haben. Prof. Frankland theilt mir mit, dasz die Flüssigkeit keine Spur von Salzsäure, Schwefelsäure, Weinsteinsäure, Oxalsäure und Ameisensäure enthalte. Nachdem dies ermittelt worden war, wurde die übrige Flüssigkeit bis nahe zur Trockenheit abgedampft und mit Schwefelsäure sauer gemacht; es entwickelte sich dabei ein flüchtiger saurer Dampf, welcher verdichtet und mit kohlensaurem Silber digerirt wurde. „Das Gewicht des dabei erzeugten Silbersalzes betrug nur 0,37 Gr., eine „viel zu kleine Quantität, um das Atomgewicht der Säure genau bestimmen „zu können. Die erhaltene Zahl entsprach indessen nahezu der der Propionsäure; und ich glaube, dasz diese oder eine Mischung von Essig- und Buttersäure in der Flüssigkeit vorhanden war. Die Säure gehört ohne Zweifel zur Reihe der Essig- oder Fettsäuren.«

# Beobachtungen und Ergebnisse

Prof. Frankland sowohl, als auch sein Assistent, beobachteten (und dies ist eine wichtige Thatsache), dasz die Flüssigkeit, »wenn sie mit „Schwefelsäure angesäuert wurde, einen starken Geruch, ähnlich dem von „Pepsin, entwickelte.« Auch die Blätter, von welchen die Absonderung abgewaschen worden war, wurden Prof. Frankland geschickt; sie wurden einige Stunden lang macerirt, dann mit Schwefelsäure angesäuert und destillirt; es gieng aber keine Säure über. Es musz daher die Säure, welche frische Blätter enthalten, wie sich durch die Färbung des Lackmus-Papiers beim Zerquetschen derselben zeigt, von einer verschiedenen Beschaffenheit sein von der, welche in dem Secret vorhanden ist. Auch entwickelten die Blätter keinen Geruch von Pepsin.

# Verdauungsexperimente

Obgleich es seit langer Zeit bekannt ist, dasz Pepsin mit Essigsäure die Fähigkeit hat, eiweiszhaltige Zusammensetzungen zu verdauen, so er- schien es doch rathsam, zu ermitteln, ob die Essigsäure ohne Verlust der verdauenden Kraft durch die verwandten Säuren ersetzt werden könne, von denen angenommen wurde, dasz sie in der Absonderung der Drosera vorkommen, nämlich Propionsäure, Buttersäure oder Valeriansäure. Dr. Burdon Sanderson war so freundlich, mir zu Gefallen die folgenden Versuche zu machen, deren Resultate ganz abgesehen von der vorliegenden Untersuchung werthvoll sind. Prof. Frankland verschaffte uns die Säure.

# Versuchsaufbau und Methodik

»1. Der Zweck der folgenden Experimente war, die verdauende Thä- tigkeit von Pepsin enthaltenden Flüssigkeiten zu bestimmen, wenn sie „mit gewissen flüchtigen, zu der Essig-Reihe gehörenden Säuren angesäuert „wurden, im Vergleich mit Flüssigkeiten mit Salzsäure in einem Verhältnis angesäuert, welches dem im Magensafte vorhandenen ähnlich ist.«

»2. Es ist empirisch festgestellt worden, dasz bei künstlicher Ver- „dauung die besten Resultate erhalten werden, wenn eine Flüssigkeit an- „gewendet wird, welche dem Gewichte nach zwei pro mille von salz- „saurem Gas enthält. Dies entspricht ungefähr 6,25 Cubikcentimeter per „Liter gewöhnlicher starker Salzsäure. Die Quantitäten von Propionsäure, Drosera rotundifolia. Cap. 6. „Butter- und Valeriansäure respective, welche erforderlich sind, um so „viel Basis zu neutralisiren als 6,25 Cubikcentimeter HCl, sind, in Grammen ausgedrückt, 4,04 Propionsäure, 4,82 Buttersäure und 5,68 Valerian- „säure. Es wurde daher für zweckmäszig gehalten, beim Vergleich der „verdauenden Kraft dieser Säuren mit der der Salzsäure, dieselben in die- sen Proportionen anzuwenden.«

# Durchführung der Experimente

»3. Fünfhundert Cubikcentimeter einer Flüssigkeit, welche ungefähr „8 Cubikcentimeter eines Glycerinauszugs der Magenschleimhaut eines „während der Verdauung getödteten Hundes enthielt, wurden hergestellt; „davon wurden 10 Cubikcentimeter eingedampft und bei 110° getrocknet. „Diese Quantität ergab 0,0031 Rückstand.«

»4. Von dieser Flüssigkeit wurden vier Mengen genommen, welche „einzeln in den oben angegebenen Proportionen mit Salzsäure, mit Pro- „pionsäure, mit Butter- und mit Valeriansäure angesäuert wurden. Jede „Flüssigkeitsmenge wurde dann in eine Röhre gethan, welche man in „einem Wasserbade schwimmen liesz, das ein, eine Temperatur von 38° „bis 40°C. anzeigendes Thermometer enthielt. In eine jede wurde eine „Quantität nicht gekochten Fibrins eingebracht und das Ganze 4 Stunden „lang stehen gelassen, wobei die Temperatur während der ganzen Zeit# Verdauungsexperimente

„innegehalten und Sorge dafür getragen wurde, dasz eine jede einen
„Überschusz von Fibrin enthielt. Nach Verlauf dieser Zeit wurde jede
„Flüssigkeit filtrirt. Von dem Filtrat, welches natürlich so viel Fibrin
„enthielt, als während der 4 Stunden verdaut worden war, wurden 10
„Cubikcentimeter abgemessen, eingedampft und wie vorher bei einer Tem-
„peratur von 110° getrocknet. Die Rückstände betrugen beziehentlich:
»in der Salzsäure enthaltenden Flüssigkeit 0,4079
„ „ Propionsäure „ „ 0,0601
„ „ Buttersäure „ „ 0,1468
„ „ Valeriansäure „ „ 0,1254.
»Zieht man daher von jeder dieser Zahlen den oben erwähnten Rück-
„stand ab, welcher zurückbleibt, wenn die verdauende Flüssigkeit selbst
„eingedampft wird. nämlich 0,0031, so erhalten wir
»für Propionsäure 0,0570
„ Buttersäure 0,1437
„ Valeriansäure 0,1223,
»zu 0,4048 für Salzsäure; diese verschiedenen Zahlen drücken die Gewichts-
„mengen von Fibrin aus, welche in Gegenwart äquivalenter Menge der
„verschiedenen Säuren unter identischen Bedingungen verdaut worden sind.
»Die Resultate des Versuchs können in folgender Weise angegeben
„werden: — Wenn 100 die verdauende Kraft einer Flüssigkeit bezeichnet,
„welche Pepsin mit der gewöhnlichen Proportion von Salzsäure enthält,
„so bezeichnen 14,0, 35,4 und 30,2 beziehentlich die verdauende Kraft
„der drei hier untersuchten Säuren.

## Zweites Experiment

»5. In einem zweiten Experiment, bei welchem der Procesz in jeder
„Beziehung derselbe war, ausgenommen dasz die sämmtlichen Röhren in
„ein und dasselbe Wasserbad getaucht und die Rückstände bei 115°C ge-
„trocknet wurden, waren die Resultate die folgenden: —
Cap. 6. Verdauung.
»Fibrinmenge, in 4 Stunden von 10 Cubikcentimeter Flüssigkeit auf-
„gelöst —
»mit Propionsäure 0,0563
» » Buttersäure 0,0835
» » Valeriansäure 0,0615.
»Die von einer ähnlichen Flüssigkeit, welche Salzsäure enthielt, ver-
„daute Menge betrug 0,3376. Nimmt man daher dies als 100, so stellen
„die folgenden Zahlen die relativen von den anderen Säuren verdauten
„Mengen dar: —
»Propionsäure 16,5
»Buttersäure 24,7
»Valeriansäure 16,1

## Drittes Experiment

»6. Ein drittes Experiment derselben Art ergab:
»Fibrinmenge, in 4 Stunden von 10 Cubikcentimeter Flüssigkeit verdaut:
»mit Salzsäure 0,2915
» » Propionsäure 0,1490
» » Buttersäure 0,1044
» » Valeriansäure 0,0520.
»Vergleicht man, wie vorhin, die drei letzten Zahlen mit der ersten
„und setzt diese gleich 100, so wird die verdauende Kraft der Propion-
„säure durch 16,8, die der Buttersäure durch 35,8, und die der Valerian-
„säure durch 17,8 ausgedrückt.
»Das Mittel aus diesen drei Beobachtungsreihen (Salzsäure als 100
„genommen) ergibt für
»Propionsäure 15,8
»Buttersäure 32,0
»Valeriansäure 21,4

## Weiteres Experiment

»7. Ein weiteres Experiment wurde noch angestellt, um zu ermitteln,
„ob die verdauende Wirksamkeit der Buttersäure (welche gewählt wurde,
„weil sie augenscheinlich die wirksamste war) bei gewöhnlicher Temperatur
„relativ bedeutender sei, als bei der Temperatur des Körpers. Es stellte
„sich heraus, dasz während 10 Cubikcentimeter einer, Salzsäure in der
„gewöhnlichen Proportion enthaltenden Flüssigkeit 0,1311 Gramm ver-
„daute, eine ähnliche mit Buttersäure hergestellte Flüssigkeit 0,0455
„Gramm Fibrin verdaute.# Verdauungskraft der Salzsäure

»Nimmt man daher die mit Salzsäure bei der Temperatur des Körpers verdauten Mengen zu 100 an, so erhalten wir für die verdauende Kraft der Salzsäure bei einer Temperatur von 16° bis 18° die Zahl 44,9, während die Zahl für die Buttersäure bei derselben Temperatur 15,6 ist.« Wir sehen hier, dasz bei der niedrigeren von diesen beiden Temperaturen Salzsäure mit Pepsin innerhalb der nämlichen Zeit etwas weniger als die Hälfte der Fibrinmenge verdaut im Vergleich zu der, welche sie bei der höheren Temperatur verdaut; und die verdauende Kraft der Buttersäure wird unter ähnlichen Bedingungen und Temperaturen in demselben Verhältnis reducirt. Wir haben auch gesehen, dasz Buttersäure, welche viel wirksamer ist als Propion- oder Valeriansäure, mit Pepsin bei der höheren Temperatur weniger als ein Drittel der Fibrinmenge verdaut, welche bei derselben Temperatur von Salzsäure verdaut wird.

# Experimente mit Drosera

Darwin, Insectenfressende Pflanzen. (VIII.) 6 Drosera rotundifolia. Cap. 6. Ich will nun im Detail meine Experimente über die verdauende Kraft des Secrets der Drosera mittheilen und da die bei den Versuchen verwendeten Substanzen in zwei Reihen theilen, nämlich in diejenigen, welche mehr oder weniger vollständig verdaut werden, und solche, welche nicht verdaut werden. Wir werden sofort sehen, dasz der Magensaft der höheren Thiere auf diese sämmtlichen Substanzen in derselben Weise einwirkt. Ich erlaube mir noch, die Aufmerksamkeit auf die Versuche unter der Rubrik Eiweisz zu lenken, welche zeigen, dasz das Secret seine Kraft verliert, wenn es durch Zusatz eines Alkali neutralisirt wird, und dieselbe wieder erlangt, wenn eine Säure zugesetzt wird.

# Verdauung von Eiweisz

Substanzen, welche von dem Secret der Drosera vollständig oder theilweise verdaut werden. Eiweisz. — Nachdem ich verschiedene Substanzen probiert hatte, schlug mir Dr. Burdon Sanderson vor, Würfelchen von geronnenem Eiweisz oder hart gekochtem Ei zu benutzen. Ich will vorausschicken, dasz des Vergleichs wegen fünf Würfel von derselben Grösse wie die in den folgenden Experimenten angewendeten zu der nämlichen Zeit auf feuchtes Moos dicht bei den Drosera-Pflanzen gelegt wurden. Das Wetter war warm und nach vier Tagen waren einige von den Würfeln misfarbig und moderig, ihre Kanten auch etwas abgerundet; sie waren aber nicht von einer Zone durchsichtiger Flüssigkeit umgeben wie diejenigen, welche der Verdauung unterlagen. Andere Würfel behielten ihre scharfen Kanten und ihre weisze Farbe. Nach acht Tagen waren sie sämmtlich an Grösse etwas reduciert, entfärbt und ihre Kanten waren bedeutend abgerundet. Nichtsdestoweniger war an vier unter den fünf Exemplaren der centrale Theil noch immer weisz und undurchsichtig. Der Zustand, in dem sie sich befanden, war daher, wie wir sehen werden, weit von dem der Würfel verschieden, welche der Einwirkung des Secrets der Blätter ausgesetzt worden waren.

# Versuch 1

1. Versuch. — Zuerst wurden ziemlich grosze Würfel von Eiweisz versucht; die Tentakeln waren in 24 Stunden ordentlich eingebogen; nach weiterem Verlauf eines Tages waren die Kanten der Würfel aufgelöst und abgerundet. In allen meinen zahlreichen Versuchen über die Verdauung von Eiweisz-würfeln wurden ausnahmslos zuerst die Winkel und Kanten abgerundet. Nun gibt Schiff an (Leçons phys. de la Digestion. Vol. II, 1867, p. 149), dasz dies für die Verdauung des Eiweiszes durch den Magensaft von Thieren characteristisch ist.; die Würfel waren aber zu gross, so dasz die Blätter verletzt waren; nach sieben Tages starb eines ab, und die andern waren im Absterben. Eiweisz, welches vier oder fünf Tage lang aufbewahrt wurde und welches, wie wohl angenommen werden konnte, ange-
fangen hatte, sich in geringeren Grade zu zersetzen, schien schneller zu wirken als frisch gekochte Eier. Da meistentheils die letztern gebraucht wurden, so feuchtete ich sie mit etwas Speichel an, um die Tentakeln schneller zum Einbiegen zu veranlassen.

# Versuch 2

2. Versuch. — Ein Würfel von \frac {1}{10} Zoll (d. h. bei welchem jede# Experimente zur Eiweißverdauung

## Versuch 1
Seite \frac {1}{10} Zoll oder 2,54 Mm. lang war) wurde auf ein Blatt gelegt, und nach 50 Stunden war er in eine Kugel von ungefähr \frac {3}{40} Zoll Durchmesser verwandelt (1,905 Mm.) und von vollständig durchsichtiger Flüssigkeit umgeben. Nach zehn Tagen war das Blatt wieder ausgebreitet; es blieb aber ein äusserst kleines Stückchen, nun vollkommen durchscheinend gewordenen Eiweiszes auf der Scheibe. Es hatte dies Blatt mehr Eiweisz erhalten, als aufgelöst oder verdaut werden konnte.

## Versuch 2
Zwei Eiweiszwürfel von \frac {1}{20} Zoll (1,27 Mm.) wurden auf zwei Blätter gelegt. Nach 46 Stunden war jedes Atom derselben aufgelöst und das Meiste der verflüssigten Masse war absorbirt; die zurückbleibende Flüssigkeit war in diesem wie in allen übrigen Fällen sehr sauer und klebrig. Die Wirkung auf die andern Würfel war etwas langsamer.

## Versuch 3
Zwei Eiweiszwürfel von derselben Grösze wie die letzten wurden auf zwei Blätter gelegt und waren in 50 Stunden in zwei grosse Tropfen durchscheinender Flüssigkeit verwandelt; als sie aber unter den eingebognen Tentakeln hervorgenommen und bei reflectirtem Lichte unter dem Mikroskop betrachtet wurden, konnten in dem einen feine Streifen undurchsichtiger Substanz, in dem andern Spuren ähnlicher Streifen beobachtet werden. Die Tropfen wurden auf die Blätter zurückgebracht, welche sich nach 10 Tagen wieder ausbreiteten, und nun war nichts übrig als sehr wenig durchsichtiger saurer Flüssigkeit.

## Versuch 4
Dieser Versuch wurde unbedeutend abgeändert, so dass das Eiweisz der Einwirkung des Secrets schneller ausgesetzt wurde. Zwei Würfel, jeder von ungefähr \frac {1}{40} Zoll (0,635 Mm.), wurden auf dasselbe Blatt gelegt, und zwei ähnliche Würfel auf ein anderes. Diese wurden nach 21 Stunden 30 Minuten untersucht und alle waren, wie sich ergab, abgerundet. Nach 46 Stunden waren die zwei Würfel auf dem einen Blatte vollständig verflüssigt, die gebildete Flüssigkeit war vollkommen durchsichtig; auf dem andern Blatte waren in der Mitte der Flüssigkeit noch einige undurchsichtige weisse Streifen zu sehen. Nach 72 Stunden verschwanden diese Streifen; es war aber noch ein wenig klebrige Flüssigkeit auf der Scheibe zurückgeblieben, während dieselbe auf dem ersten Blatte beinahe gänzlich absorbirt war. Beide Blätter fingen nun an, sich wieder auszubreiten.

## Versuch 5
Der beste und beinahe einzige Beweis für die Gegenwart irgend eines dem Pepsin analogen Fermentes in der Absonderung schien der Andererseits bemerkt er: „les dissolutions, en chimie, en lieu sur toute la surface des corps en contact avec l’agent dissolvant.‟

## Versuch 6
zu sein, dasz man die Säure des Secrets mit einem Alkali neutralisirte und beobachtete, ob der Procesz der Verdauung aufhörte, und dasz man dann ein wenig Säure zusetzte und beobachtete, ob der Procesz wieder begönne. Dies wurde, und zwar, wie wir sehen werden, mit Erfolg, gethan; es war aber nothwendig, zuerst zwei Controlversuche anzustellen: nämlich, ob der Zusatz äusserst kleiner Tropfen Wasser von derselben Grösze wie der der Alkalilösungen den Procesz der Verdauung aufhalten würden, und zweitens, ob äusserst kleine Tropfen schwacher Salzsäure, von derselben Stärke und Grösze wie die benutzten, die Blätter verletzen würden. Es wurden demzufolge die beiden folgenden Versuche angestellt:

## Versuch 7
Kleine Eiweiszwürfel wurden auf drei Blätter gelegt und äusserst kleine Tropfen destillirten Wassers auf einem Stecknadelknopf zwei- oder dreimal täglich hinzugefügt. Diese hielten nicht im mindesten den Procesz auf; denn nach 48 Stunden waren die Würfel auf allen drei Blättern vollständig aufgelöst. Am dritten Tage fiengen die Blätter an, sich wieder auszubreiten, und am vierten Tage war die ganze Flüssigkeit absorbirt.

## Versuch 8
Kleine Eiweiszwürfel wurden auf zwei Blätter gelegt und äusserst kleine Tropfen von Salzsäure, von der Stärke eines Theiles auf 437 Theile Wasser, wurden zwei- oder dreimal hinzugefügt. Dies hielt den Procesz der Verdauung nicht im mindesten auf, schien ihn im# Experimente mit Eiweiß

## Versuch 8
Würfel von Eiweisz (von \frac {1}{10} Zoll oder 2,54 Mm.) wurden auf fünf Blätter gelegt und sehr kleine Tropfen einer Auflösung von einem Theil kohlensauren Natrons in 437 Theilen Wasser dreien derselben in Zwischenräumen zugefügt, während die beiden andern Tropfen einer Auflösung kohlensauren Kalis von derselben Stärke erhielten. Die Tropfen wurden mit dem Kopfe einer ziemlich groszen Stecknadel übertragen, und ich ermittelte, dasz jeder ungefähr gleich \frac {1}{10} Minim, (0,0059 Cub. Cent.) war, so dasz ein jeder nur \frac {1}{4800} Gran (0,0135 Milligr.) des Alkali enthielt. Dies war nicht genügend, denn nach 46 Stunden waren alle fünf Würfel aufgelöst.

## Versuch 9
Der letzterwähnte Versuch wurde an vier Blättern wiederholt, doch mit dem Unterschiede, dasz Tropfen derselben Auflösung von kohlensaurem Natron im Ganzen häufiger zugefügt wurden, und zwar so oft als das Secret sauer wurde, so dasz es viel wirksamer neutralisirt wurde. Jetzt nun waren nach 24 Stunden die Kanten von dreien der Würfel nicht im mindesten abgerundet, die des vierten waren es nur in einem sehr unbedeutendem Grade. Tropfen äusserst schwacher Salzsäure (nämlich ein Theil auf 827 Theile Wasser) wurden nun zugesetzt, gerade hinreichend, um das noch immer vorhandene Alkali zu neutralisiren; sofort begann der Verdauungsprocesz wieder, so dasz nach 23 Stunden 30 Minuten drei der Würfel vollständig aufgelöst waren, während der vierte in eine äuszerst kleine, von durchscheinender Flüssigkeit umgebene Kugel verwandelt war; und diese Kugel verschwand am folgenden Tage.

## Versuch 10
Zunächst wurden nun stärkere Lösungen von kohlensaurem Natron und Kali angewandt, nämlich ein Theil auf 109 Theile Wasser; da Tropfen von derselben Grösze gegeben wurden, enthielt ein jeder \frac {1}{1200} Grau (0,0539 Milligr.) des betreffenden Salzes. Zwei Eiweisz-würfel (jeder ungefähr \frac {1}{40} Zoll oder 0,635 Mm.) wurden auf ein und dasselbe Blatt gethan und zwei auf ein anderes. Jedes Blatt erhielt, so bald die Absonderung unbedeutend sauer wurde (und dies trat viermal schon innerhalb 24 Stunden ein), Tropfen entweder von der Natron- oder Kali-Lösung, wodurch die Säure wirksam neutralisirt wurde. Der Versuch gelang nun vollkommen; denn nach 22 Stunden waren die Kanten der Würfel so scharf, wie sie zuerst waren; und aus dem 5. Versuch haben wir gesehen, dasz so kleine Würfel in dieser Zeit von dem Secret in seiner natürlichen Beschaffenheit vollständig abgerundet worden sein würden. Nun wurde etwas von der Flüssigkeit mittelst Löschpapier von den Blatt-scheibe entfernt und minutiöse Tropfen von Salzsäure in der Stärke von einem Theile auf 200 Theile Wasser zugefügt. Es wurde Säure von dieser beträchtlicheren Stärke angewandt, da auch die alkalischen Lösungen stärker waren. Der Procesz der Verdauung begann nun auf’s Neue, so dasz innerhalb 48 Stunden von der Zeit, wo die Säure zugefügt wurde, die vier Würfel nicht nur vollständig aufgelöst, sondern auch ein grosser Theil des flüssig gewordenen Eiweiszes aufgesaugt war.

## Versuch 11
Zwei Eiweiszwürfel (jeder \frac {1}{40} Zoll oder 0,635 Mm. Seitenlänge) wurden auf zwei Blätter gebracht und wie im vorhergehenden Versuche mit Alkalien behandelt und auch mit demselben Resultat; denn nach 22 Stunden waren die Kanten derselben noch vollkommen scharf, was bewies, dasz der Verdauungsprocesz vollständig aufgehalten worden war. Ich wünschte nun zu ermitteln, was wohl die Wirkung einer Anwendung stärkerer Salzsäure sein würde; ich fügte demgemäsz minutiöse Tropfen von einer einprocentigen Verdünnung hinzu. Dies erwies sich als etwas zu stark; denn 48 Stunden nach der Zeit,# Einleitung zur Verdauung von Drosera rotundifolia

wo die Säure zugefügt wurde, war der eine Würfel noch immer beinahe
vollkommen, und der andere nur sehr unbedeutend abgerundet; und beide
waren leicht rosa gefärbt. Diese letztere Thatsache zeigt, dasz die Blätter
verletzt warenSachs bemerkt (Lehrbuch der Botanik, 4. Aufl., 1874, p. 701), dasz
Zellen,
welche durch Erfrieren, durch zu grosze Hitze oder durch chemische Agentien ge-
tödtet worden sind, alle ihre gefärbten Inhaltstheile in das umgebende Wasser
austreten lassen., denn während des normalen Verlaufes des Verdauungs-
processes wird das Eiweisz nicht in dieser Weise gefärbt, und wir können
hieraus verstehen, warum die Würfel nicht aufgelöst wurden.

# Ergebnisse der Experimente

Aus diesen Versuchen geht deutlich hervor, dasz die abgesonderte
Flüssigkeit das Vermögen hat, Eiweisz aufzulösen, und wir sehen
ferner, dasz, wenn ein Alkali zugesetzt wird, der Verdauungsprocesz
zum Stillstand gebracht wird, dasz er aber sofort wieder beginnt, so-
bald das Alkali durch schwache Salzsäure neutralisirt wird. Selbst
wenn ich keine anderen Versuche als diese angestellt hätte, würden
sie beinahe schon hingereicht haben, nachzuweisen, dasz die Drüsen
der Drosera irgend ein dem Pepsin analoges Ferment absondern, wel-
ches bei Anwesenheit einer Säure dem Secrete sein Vermögen, eiweisz-
artige Verbindungen aufzulösen, verleiht.

# Versuche mit Glas und Glycerin

Splitter von reinem Glase wurden auf eine grosze Zahl von Blät-
tern ausgestreut, und diese wurden mäszig eingebogen. Sie wurden
dann abgeschnitten und in drei Gruppen getheilt; davon wurden
zwei eine Zeit lang in ein wenig destillirtem Wasser gelegt und
dies dann durchgeseiht, wobei etwas misfarbige, klebrige, unbedeu-
tend saure Flüssigkeit erhalten wurde. Das dritte Häufchen wurde
ordentlich in wenig Tropfen von Glycerin eingeweicht, welches be-
kanntlich Pepsin auflöst. Eiweisswürfel (von \frac {1}{20} Zoll) wurden nun
auf Uhrgläsern in diese drei Flüssigkeiten gethan, von denen einige
mehrere Tage lang auf einer Temperatur von ungefähr 32,2° C. (90° F.),
andere in der Temperatur meines Zimmers gelassen wurden; keiner
der Würfel wurde indesz aufgelöst, es blieben die Kanten so scharf
wie je. Diese Thatsache weist wahrscheinlich darauf hin, dasz das
Ferment nicht eher abgesondert wird, als bis die Drüsen durch die
Absorption einer äuszerst geringen Quantität bereits auflöslicher thieri-
scher Substanz gereizt werden, — eine Folgerung, welche durch das,
was wir später in Bezug auf Dionaea sehen werden, unterstützt wird.

# Beobachtungen von Dr. Hooker

Dr. Hooker fand gleichfalls, dasz die Flüssigkeit in den Schläuchen der
Nepenthes, obschon sie das Vermögen der Verdauung in auszerordent-
lichem Grade besitzt, dennoch, wenn sie aus den Schläuchen entfernt,
ehe dieselben gereizt wurden, und in ein Gefäsz gethan wird, kein
derartiges Vermögen hat, trotzdem sie bereits sauer ist. Wir können
diese Thatsache nur durch die Annahme erklären, dasz das eigentliche
Ferment nicht eher abgesondert wird, als bis etwas reizende Substanz
aufgesaugt ist.

# Weitere Versuche mit Eiweiß

Bei drei andern Gelegenheiten wurden acht Blätter stark durch
Eiweisz, was mit Speichel befeuchtet war, gereizt; sie wurden dann
abgeschnitten und mehrere Stunden oder einen ganzen Tag lang
in einigen wenigen Tropfen Glycerin liegen gelassen. Etwas von diesem
Auszug wurde dann einem kleinen Theil Salzsäure von verschiedenen
Stärkegraden (meist ein Theil auf 400 Theile Wasser) zugesetzt; und
in diese Mischung wurden sehr kleine Würfel von Eiweisz gelegt. Als Controlversuch
wurden Stückchen Eiweisz in Glycerin mit Salzsäure von
derselben Stärke gebracht; nach zwei Tagen war, wie sich hätte erwarten lassen,
das Eiweisz nicht im Allermindesten afficirt.

# Ergebnisse der Kontrollversuche

In zweien von diesen Versuchen trat nicht die geringste Wirkung auf
das Eiweisz ein; im dritten aber war der Versuch erfolgreich. Denn
in einem, zwei Würfel enthaltenden Gefäsz waren beide in 3 Stunden
an Grösze reducirt; und nach 24 Stunden waren nur noch blosze
Streifen ungelösten Eiweiszes übrig. In einem zweiten Gefäsz, welches
zwei äuszerst kleine zerfetzte Stückchen Eiweisz enthielt, waren beide
gleichfalls in 3 Stunden an ihrer Grösze reducirt und nach 24 Stunden.# Verdauung und Pepsin

vollständig verschwunden. Ich fügte dann ein wenig schwacher Salzsäure beiden Gefässen zu und legte frische Eiweiszwürfel in dieselben; die Flüssigkeit wirkte aber nicht auf diese. Diese letztere Thatsache wird nach der hohen Autorität von SchiffLeçons phys. de la Digestion, 1867. Tom. II. p. 114—126. insofern verständlich, als er, wie er meint, nachgewiesen hat, und zwar im Gegensatz zu der von einigen Physiologen vertretenen Ansicht, dasz eine bestimmte geringe Menge von Pepsin während des Actes der Verdauung zerstört wird. Enthielt daher, wie es doch wahrscheinlich ist, meine Lösung eine äuszerst kleine Menge dieses Ferments, so wird dies durch die Auflösung der zuerst in die Lösung gethanenen Eiweiszwürfel aufgebraucht worden und keines mehr übrig geblieben sein, als die Salzsäure zugesetzt wurde. Die Zerstörung des Ferments während des Processes der Verdauung oder seine Absorption nach der Verwandlung des Eiweiszes in Peptone dürfte es auch erklären, dasz unter den drei letzten Versuchsreihen nur die eine erfolgreich war.

# Verdauung gerösteten Fleisches

Verdauung gerösteten Fleisches. — Würfel mässig gerösteten Fleisches von ungefähr \frac {1}{20} Zoll (1,27 Mm.) wurden auf fünf Blätter gelegt, welche in 12 Stunden dicht eingebogen waren. Nach 48 Stunden öffnete ich ein Blatt sanft; das Fleisch bestand jetzt nur noch aus einer äuszerst kleinen in der Mitte gelegenen Kugel, welche theilweise verdaut und von einer dicken Hülle durchscheinender klebriger Flüssigkeit umgeben war. Das Ganze wurde, ohne es sehr zu stören, entfernt und unter das Mikroskop gebracht. Im centralen Drosera rotundifolia. Cap. 6. Theile waren die Querstreifen der Muskelfasern völlig deutlich, und es war interessant zu beobachten, wie allmählich sie verschwanden, wenn man eine und dieselbe Faser in die umgebende Flüssigkeit verfolgte. Sie verschwanden in der Weise, dasz die Streifen durch quere aus äuszerst minutiösen dunklen Punkten bestehende Linien ersetzt wurden, welche nach auszen hin nur bei einer sehr starken Vergrösse- rung gesehen werden konnten; endlich verloren sich diese Punkte. Als ich diese Beobachtungen machte, hatte ich Schiff’s SchilderungLeçons phys. de la Digestion. Tom. II, p. 145. der Verdauung des Fleisches durch den Magensaft noch nicht gelesen und sah die Bedeutung der dunklen Punkte nicht ein. Dies wird aber in der folgenden Angabe erklärt; auch sehen wir ferner, wie auszer- ordentlich ähnlich der Procesz der Verdauung durch den Magensaft dem durch das Secret der Drosera ist.

# Zerstörung der Muskelfasern

»On a dit que le suc gastrique faisait perdre à la fibre musculaire „ses stries transversales. Ainsi énoncée, cette proposition pourrait donner „lieu à une équivoque, car se qui se perd, se n’est que l’aspect extérieur „de la striature et non les éléments anatomiques qui la composent. On „sait que les stries qui donnent un aspect si caractéristique à la fibre „musculaire, sont le résultat de la juxtaposition und des parallélisme des „corpuscules élémentaires, placés, à distances égales, dans l’interieur des „fibrilles contiguës. Or, dès que le tissu connectif qui relie entre elles „les fibrilles élémentaires vient à se gonfler et à se dissoudre, und que „les fibrilles elles-mêmes se dissocient, ce parallélisme est détruit und avec „lui l’aspect, le phénomène optique des stries. Si, après la désagrégation „des fibres, on examine au microscope les fibrilles élémentaires, on distingue „encore très-nettement à leur intérieur les corpuscules, und on continue „à les voir, de plus en plus pâles, jusqu’au moment où les fibrilles elles- mêmes se liquéfient und disparaissent dans le suc gastrique. Ce qui con- „stitue la striature, à proprement parler, n’est donc pas détruit, avant „la liquéfaction de la fibre charnue elle-même.«

# Beobachtungen zur Verdauung

In der die zentrale Kugel unverdauten Fleisches umgebenden klebrigen Flüssigkeit fanden sich Fettkügelchen und kleine Stückchen elastischen Fasergewebes; keines von beiden war im geringsten verdaut. Auch waren wenige freie Parallelogramme einer gelblichen, in hohem Grade durchscheinenden Substanz vorhanden. Schiff erwähnt, wo er von der Verdauung des Fleisches durch den Magensaft spricht, der- artige Parallelogramme und sagt: — »Le gonflement par lequel commence la digestion de la viande, ré-# Verdauung

## Fibrin und seine Eigenschaften

## Experimente mit Fibrin

### Erster Versuch

### Zweiter Versuch

### Dritter Versuch# Versuch und Beobachtungen

## Fibrin und seine Wirkung
Ähnliche Stückchen Fibrin wurden auf die Scheiben zweier Blätter gethan; da die Drüsen nach 2 Stunden ziemlich trocken zu sein schienen, wurden sie reichlich mit Speichel befeuchtet; dies bewirkte bald eine starke Einbiegung sowohl der Tentakeln als auch der Blattscheiben mit reichlicher Absonderung der Drüsen. In 18 Stunden war das Fibrin vollständig verflüssigt, aber unverdaute Atome schwammen noch in der Flüssigkeit; diese verschwanden indessen in weniger als zwei weiteren Tagen. Nach diesen Experimenten ist es klar, dasz die Absonderung reines Fibrin vollständig auflöst. Die Schnelligkeit der Auflösung ist im Ganzen gering; dies hängt aber nur davon ab, dasz diese Substanz die Blätter nicht genügend erregt, so dasz nur die unmittelbar benachbarten Tentakeln eingebogen werden und die Menge des Secrets eine geringe bleibt.

## Syntonin
Diese aus Muskeln ausgezogene Substanz hatte mir Dr. Moore freundlichst präparirt. Sehr verschieden vom Fibrin wirkt sie schnell und energisch ein. Kleine, auf die Scheiben von drei Blättern gebrachte Portionen bewirkten innerhalb 8 Stunden eine starke Einbiegung ihrer Tentakeln und Scheiben; es wurden aber keine weiteren Beobachtungen angestellt. Es ist wahrscheinlich eine Folge der Anwesenheit dieser Substanz, dasz rohes Fleisch ein zu mächtiger Reiz ist, welcher die Blätter häufig beschädigt oder selbst tödtet.

## Zellgewebe
Kleine Portionen dieses Gewebes von einem Schafe wurden auf die Scheiben dreier Blätter gelegt; diese wurden in 24 Stunden mäßig eingebogen, fingen aber nach 48 Stunden an, sich wieder auszubreiten und waren in 72 Stunden vollständig ausgebreitet, immer von der Zeit an gerechnet, wo die Stückchen zuerst aufgelegt worden waren. Diese Substanz reizt daher, wie das Fibrin, die Blätter nur für kurze Zeit. Der auf den Blättern nach deren völliger Wiederausbreitung zurückgelassene Rückstand wurde unter starker Vergrößerung untersucht und stellte sich als bedeutend verändert heraus; aber in Folge der Anwesenheit einer Menge von elastischem Gewebe, welches niemals der Einwirkung unterliegt, konnte man kaum sagen, dasz er sich in einem verflüssigten Zustande befunden habe.

## Elastisches Gewebe
Etwas, von elastischem Gewebe freies Zellgewebe verschaffte ich mir nun aus der Eingeweidehöhle einer Kröte und brachte Stücke von mäßiger Größe, ebenso wie sehr kleine Stückchen auf fünf Blätter. Nach 24 Stunden waren zwei dieser Stückchen vollständig verflüssigt; zwei andere waren durchscheinend geworden, aber nicht ganz verflüssigt, während das fünfte nur wenig afficirt war. Mehrere Drüsen auf den drei letzten Blättern wurden nun mit etwas Speichel angefeuchtet, was bald eine bedeutende Einbiegung und Absonderung bewirkte, mit dem Resultate, dasz im Verlaufe von weiteren 12 Stunden nur ein Blatt ein Überbleibsel von unverdautem Gewebe noch darbot. Auf den Scheiben der vier andern Blätter (deren einem ein ziemlich großes Stück gegeben worden war) war nichts zurückgelassen, ausgenommen etwas durchscheinende klebrige Flüssigkeit. Ich will noch hinzufügen, dasz etwas von diesem Gewebe Punkte von schwarzem Pigment enthielt, und diese waren durchaus gar nicht afficirt. Zur Kontrolle wurden in einem andern Versuche kleine Partien dieses Gewebes in Wasser und auf feuchtem Moose eine gleich lange Zeit hindurch gelassen; sie blieben aber weiß und undurchsichtig. Aus diesen Thatsachen geht deutlich hervor, dasz Zellgewebe von dem Secrete leicht und schnell verdaut wird, dasz es aber die Blätter nur unbedeutend reizt.

## Knorpel
Drei Würfel (von \frac {1}{20} Zoll oder 1,27 Mm. Seitenlänge) weißen, durchscheinenden, äußerst zähen Knorpels wurden vom Ende eines leicht gerösteten Schenkelbeins eines Schafes abgeschnitten. Dieselben wurden auf drei Blätter gelegt, welche ärmliche kleine Pflanzen in meinem Gewächshause im Laufe des November trugen; es schien mir im höchsten Grade unwahrscheinlich, dasz eine so harte# Verdauung unter ungünstigen Umständen

Substanz unter so ungünstigen Umständen verdaut werden würde. Nichtsdestoweniger waren nach 48 Stunden die Würfel bedeutend gelöst und in äusserst kleine Kugeln verwandelt, die von durchsichtiger, sehr saurer Flüssigkeit umgeben waren. Zwei dieser Kugeln waren bis zu ihrem Mittelpunkte vollständig aufgeweicht, während die dritte noch einen sehr kleinen, unregelmäszig geformten Kern von solidem Knorpel enthielt. Ihre Oberfläche erschien unter dem Mikroskope merkwürdig von vorspringenden Leisten gezeichnet, was dafür sprach, dasz der Knorpel von dem Secrete ungleichmäszig corrodirt war. Ich brauche kaum zu sagen, dasz Würfel desselben Knorpels, eine gleich lange Zeit in Wasser gelassen, nicht im Geringsten afficirt wurden.

# Experimente mit Katzenohren

Während einer günstigeren Jahreszeit wurden mäszig grosze Stückchen des abgehäuteten Ohres einer Katze, welches Knorpel, Bindegewebe und elastisches Gewebe enthält, auf drei Blätter gelegt. Einige der Drüsen wurden mit Speichel berührt, was eine sofortige Einbiegung veranlaszt. Zwei von den Blättern fiengen sich nach drei Tagen wieder auszubreiten an und das dritte am fünften Tage. Es wurde nun der flüssige Rückstand, der auf den Blattscheiben übrig gelassen war, untersucht; in einem Falle bestand derselbe aus vollkommen durchsichtiger klebriger Substanz; in den andern zwei Fällen enthielt er etwas elastisches Gewebe und allem Anscheine nach Überrreste halbverdauten Zellgewebes.

# Faserknorpel und künstlicher Magensaft

Faserknorpel (aus den Zwischenwirbelbändern vom Schwanze eines Schafes). — Mäszig grosze und kleine Stückchen (die letzteren ungefähr \frac {1}{20} Zoll grosz) wurden auf neun Blätter gebracht. Einige derselben wurden ordentlich, manche wiederum sehr wenig eingebogen. Im letztern Falle wurden dann die Stückchen über die Scheiben hin gezogen, so dasz sie gehörig mit dem Secrete bestrichen und dabei auch viele Drüsen gereizt wurden. Alle diese Blätter breiteten sich nach nur zwei Tagen wieder aus, so dasz sie von dieser Substanz nur unbedeutend gereizt worden waren. Die Stückchen waren nicht verflüssigt, waren aber sicher in einem veränderten Zustande, waren geschwollen, viel durchscheinender, und so zart, dasz sie sich leicht zer- setzten. Mein Sohn Francis stellte etwas künstlichen Magensaft dar, welcher sich dadurch als wirksam erwies, dasz er Fibrin schnell auf- löste, und suspendirte Portionen von Faserknorpel darin. Diese schwol- len an und wurden hyalin, genau so wie die, welche der Einwirkung des Secrets der Drosera ausgesetzt waren, sie wurden aber nicht auf- gelöst. Dieses Resultat überraschte mich sehr, da zwei Physiologen der Meinung waren, dasz Faserknorpel leicht vom Magensaft verdaut werden würde. Ich bat daher Dr. Klein, die Stückchen zu unter- suchen; er theilt mir mit, dasz die beiden, welche der Einwirkung des künstlichen Magensaftes ausgesetzt gewesen waren, „sich in dem „Zustande der Verdauung befanden, auf welchem wir Bindegewebe „finden, wenn es mit einer Säure behandelt wird, d. h. geschwollen, „mehr oder weniger hyalin, wobei die Fibrillenbündel homogen gewor- den sind und ihren fibrillären Bau verloren haben.„In den Stück- chen, welche auf den Blättern der Drosera gelassen worden waren, bis sich diese wieder ausgebreitet hatten, „waren einzelne Stellen, „wenn auch nur unbedeutend, in derselben Art und Weise umgewandelt, „wie die dem Magensafte ausgesetzten, da auch sie durchscheinender, „beinahe hyalin und die Fibrillation der Bündel undeutlich geworden „war.‟ Auf den Faserknorpel wirkt daher der Magensaft in nahezu derselben Art und Weise ein wie das Secret der Drosera.

# Knochenuntersuchungen

Knochen. — Kleine, glatte Stückchen des getrockneten Zungen- beins eines Huhns wurden mit Speichel befeuchtet auf zwei Blätter gebracht und ein ähnlich befeuchteter Splitter eines auszerordentlich harten, angerösteten Knochens aus einem Hammelcotelette auf ein drittes Blatt. Diese Blätter wurden bald stark eingebogen und blieben eine ungewöhnlich lange Zeit hindurch so: nämlich, das eine Blatt zehn und die andern beiden neun Tage lang. Die Knochenstückchen waren während dieser ganzen Zeit von saurem Secrete umgeben. Als sie unter schwacher Vergrösserung untersucht wurden, zeigten sie sich# Untersuchung der Knochenstruktur

völlig erweicht, so dasz sie leicht mit einer stumpfen Nadel durch-
stochen, in Fasern zerrissen, oder zusammengedrückt werden konnten.
Dr. Klein war so gut, von beiden Knochen Durchschnitte zu machen
und dieselben zu untersuchen. Er theilt mir mit, dasz beide die nor-
male Erscheinung von entkalktem Knochen darboten, gelegentlich hier
und da noch mit Überresten der erdigen Salze. Die Knochenkörper-
chen mit ihren Fortsätzen waren an den meisten Stellen sehr deut-
lich; aber an einigen Stellen, besonders in der Nähe der Peripherie
des Zungenbeins, waren keine zu sehen. Andere Partien erschienen
ferner ganz amorph; es war nicht einmal die Längsstreifung des Kno-
chens mehr zu erkennen. Diese amorphe Structur kann, wie Dr. Klein
meint, entweder das Resultat der beginnenden Verdauung der fasrigen
Grundlage oder der Entfernung sämmtlicher erdiger Substanz sein, wo-
durch die Knochenkörperchen unsichtbar geworden waren. Eine harte,
brüchige gelbliche Substanz nahm die Stelle des Knochenmarks in den
Bruchstücken des Zungenbeins ein.

# Reaktion der faserigen Grundsubstanz

Da die Kanten und kleinen Vorsprünge der fasrigen Grundsub-
stanz nicht im mindestens abgerundet oder corrodirt waren, so wurden
zwei dieser Stückchen auf frische Blätter gelegt. Dieselben waren
am nächsten Morgen dicht eingebogen und blieben es, das eine sechs,
das andere sieben Tage lang, daher keine so lange Zeit hindurch als
bei der ersten Gelegenheit, aber doch viel länger, als jemals bei Blät-
tern vorkommt, welche über unorganische oder selbst viele organische
Körper eingebogen wurden. Das Secret färbte die ganze Zeit hindurch
Lackmus-Papier hellroth; dies kann aher eine Folge der Anwesenheit
von saurem Kalksuperphosphat gewesen sein. Als sich die Blätter
wieder ausbreiteten, waren die Kanten und Vorsprünge der faserigen
Grundlage so scharf wie je. Ich folgerte daher hieraus (wie wir gleich
sehen werden irrthümlicherweise), dasz das Secret die faserige Grund-
substanz des Knochens nicht angreifen könne. Die wahrscheinlichere
Erklärung ist die, dasz die ganze Säure bei der Zersetzung des noch
übrig gelassenen phosphorsauren Kalkes aufgebraucht worden war, so
daz keine mehr im freien Zustande übrig war, um in Verbindung mit
dem Ferment auf die faserige Grundsubstanz einzuwirken.

# Einfluss auf Schmelz und Zahnbein

Schmelz und Zahnbein. — Da das Secret gewöhnlichen Kno-
chen seines Kalkes beraubte, entschlosz ich mich zu versuchen, ob sie
auch auf Schmelz und Zahnbein einwirken würde, erwartete aber nicht,
daz es bei einer so harten Substanz wie dem Zahnschmelz Erfolg
haben würde. Dr. Klein gab mir einige dünne Querschnitte des Eck-
zahns eines Hundes; hiervon wurden kleine eckige Bruchstücke auf
vier Blätter gebracht; und diese wurden an jedem folgenden Tage
um dieselbe Stunde untersucht. Ich glaube, die Resultate verdienen
im Detail mitgetheilt zu werden.

## Versuch 1

1. Mai; ein Bruchstück auf ein Blatt gebracht; am 3. waren die
Tentakeln nur wenig eingebogen, es wurde daher etwas Speichel
zugesetzt; am 6.: da die Tentakeln nicht stark eingebogen waren,
wurde das Fragment auf ein anderes Blatt gebracht, welches zuerst nur
langsam reagierte, aber am 9. das Bruchstück dicht umschlosz. Am 11.
fieng dies zweite Blatt an, sich wieder auszubreiten; das Bruchstück
war offenbar erweicht, und Dr. Klein berichtet: »ein groszer Theil des
„Schmelzes und der gröszere Theil des Zahnbeins des Kalkes beraubt.«

## Versuch 2

1. Mai; ein Bruchstück auf ein Blatt gelegt; am 2. waren die
Tentakeln ziemlich ordentlich eingebogen, bei reichlicher Ab-
sonderung auf der Scheibe, und blieben bis zum 7. eingebogen, wo
sich das Blatt wieder ausbreitete. Das Fragment wurde nun auf ein
frisches Blatt gebracht, welches am nächsten Tage (am 8.) in der
stärksten Weise eingebogen war und bis zum 11. so blieb, wo es sich
wieder ausbreitete. Dr. Klein berichtet: »ein groszer Theil des
Schmelzes und der gröszere Theil des Zahnbeins des Kalkes beraubt.«

## Versuch 3

1. Mai; ein Bruchstück mit Speichel befeuchtet und auf ein Blatt
gebracht, welches bis zum 5. gut eingebogen blieb und sich dann
wieder ausbreitete. Der Schmelz war durchaus nicht und# Experimente mit Zahnbein und Schmelz

Das Zahnbein nur unbedeutend erweicht. Das Bruchstück wurde nun auf ein frisches Blatt gebracht, welches am nächsten Morgen (6.) stark eingebogen war und bis zum 11. so blieb. Der Schmelz und das Zahnbein waren jetzt beide etwas erweicht, und Dr. Klein berichtet: »weniger „als die Hälfte des Schmelzes, aber der gröszere Theil des Zahnbeins „des Kalkes beraubt.«

## Versuch 4

1. Mai; ein äuszerst kleines und dünnes Stückchen Zahnbein wurde, mit Speichel befeuchtet, auf ein Blatt gebracht, welches bald eingebogen wurde und sich am 5. wieder ausbreitete. Das Zahnbein war so biegsam geworden wie dünnes Papier. Es wurde dann auf ein frisches Blatt gebracht, welches am nächsten Morgen (am 6.) stark eingebogen war und sich am 10. wieder öffnete. Das seiner Kalksalze beraubte Zahnbein war nun so zart, dasz es durch die blosze Kraft der sich ausbreitenden Tentakeln in Stückchen zerrissen wurde.

## Ergebnisse der Versuche

Aus diesen Versuchen geht hervor, dasz die Schmelzsubstanz von dem Secrete mit mehr Schwierigkeit angegriffen wird, als das Zahnbein, wie sich nach ihrer auszerordentlichen Härte hätte erwarten lassen; beide werden ferner schwieriger angegriffen als Knochen. Nach dem Procesz der Auflösung einmal begonnen hat, wird er mit gröszerer Leichtigkeit weiter geführt; dies kann man daraus schlieszen, dasz die Blätter, auf welche die Bruchstücke übertragen wurden, in allen vier Fällen im Laufe eines einzigen Tages stark eingebogen wur- den, während die erste Reihe Blätter viel weniger schnell und energisch reagierten. Die Kanten und Vorsprünge der faserigen Grundsubstanz des Schmelzes und Zahnbeins (vielleicht mit Ausnahme des 4. Falles, welcher nicht ordentlich beobachtet werden konnte) waren nicht im mindesten abgerundet; auch bemerkt Dr. Klein, dasz ihre mikrosko- pische Structur nicht verändert gewesen sei. Dies hätte man aber auch nicht erwarten können, da die Entkalkung in den drei Exemplaren welche sorgfältig untersucht wurden, nicht vollständig war.

## Faserige Grundsubstanz des Knochens

Ich war, wie ich bereits angeführt habe, zuerst zu dem Schlusse gelangt, dasz das Secret diese Substanz nicht verdauen könne. Ich bat daher Dr. Bur- don Sanderson, die Verdauung von Knochen, Schmelz und Zahnbein in künstlichem Magensaft zu versuchen, und er fand, dasz sie nach einer beträchtlichen Zeit vollständig aufgelöst wurden. Dr. Klein untersuchte einige der kleinen Lamellen, in welche sich ein Stück eines Katzenschädels nach einem ungefähr einwöchentlichen Liegen in jener Flüssigkeit spaltete, und fand, dasz nach den Rändern zu „die Grundsubstanz rarificirt war, so dasz das Aussehen entstand, als „wenn die Canälchen der Knochenkörperchen gröszer geworden wären. „Übrigens waren die Körperchen und ihre Canälchen sehr deutlich.‟

## Schlussfolgerungen

Es geht daher bei Knochen, welche der Einwirkung künstlichen Magen- saftes ausgesetzt werden, die vollständige Entkalkung der Auflösung der faserigen Grundsubstanz voraus. Dr. Burdon Sanderson sprach die Vermuthung gegen mich aus, dasz das scheinbare Unvermögen der Drosera, die faserige Grundsubstanz des Knochens, Schmelzes und Zahnbeins zu verdauen, vielleicht eine Folge davon sei, dasz die Säure bei der Zersetzung der erdigen Salze aufgebraucht werde, so dasz keine übrig bleibe für die Arbeit der Verdauung. Dementsprechend ent- kalkte mein Sohn den Knochen eines Schafes gänzlich mittelst schwa- cher Salzsäure; sieben äuszerst kleine Fragmente der faserigen Grund- substanz wurden auf ebenso viele Blätter gebracht, wobei vier dieser Bruchstücke zuerst mit Speichel befeuchtet wurden, um die sofortige Einbiegung zu unterstützen. Sämmtliche sieben Blätter wurden ein- gebogen, aber nur sehr mäszig, und zwar im Verlaufe eines Tages. Sie fiengen schnell an, sich wieder auszubreiten, fünf von ihnen schon am zweiten und die andern beiden am dritten Tag. Auf allen sieben Blättern war das fasrige Gewebe in vollkommen durchscheinende, klebrige, mehr oder weniger verflüssigte kleine Massen verwandelt. In der Mitte einer derselben sah indessen mein Sohn bei starker Ver- gröszerung einige wenige Körperchen mit Spuren einer Faserung in der umgebenden durchscheinenden Substanz. Nach diesen Thatsachen# Verdauung und Drüsen

ist es klar, dasz die Blätter von der fasrigen Grundsubstanz des Kno-
chens sehr wenig gereizt werden, dasz aber das Secret dieselbe leicht
und schnell verflüssigt, wenn sie vollständig entkalkt ist. Die Drüsen,
Cap. 6. Verdauung.
welche zwei oder drei Tage lang mit den klebrigen Massen in Be-
rührung geblieben waren, waren nicht entfärbt und hatten dem An-
scheine nach wenig von dem verflüssigten Gewebe absorbirt, oder
waren nur wenig von ihm afficirt worden.

# Phosphorsaurer Kalk

Phosphorsaurer Kalk. — Da, wie wir gesehen haben, die
Tentakeln der ersten Reihe Blätter neun oder zehn Tage lang über
minutiösen Knochenfragmenten eingeschlagen geblieben waren, die Ten-
takeln der Blätter der zweiten Reihe über denselben Fragmenten
sechs oder sieben Tage lang, so wurde ich auf die Vermuthung ge-
führt, dasz es der phosphorsaure Kalk und nicht irgend welche ein-
geschlossene thierische Substanz sei, welcher eine so lange andauernde
Einbiegung bewirke. Nach dem, was soeben erst gezeigt worden ist,
ist es wenigstens sicher, dasz letztere nicht in Folge der Anwesen-
heit der fasrigen Grundsubstanz eintrat. Bei Schmelz und Zahnbein
(ersterer enthält nur 4 Procent organischer Substanz) blieben die
Tentakeln zweier nach einander versuchter Reihen von Blättern im
Ganzen elf Tage lang eingebogen. Um meine Meinung über die
Wirksamkeit des phosphorsauren Kalks zu prüfen, verschaffte ich mir
durch Professor Frankland etwas von thierischer Substanz und von
irgend einer Säure absolut freies Phosphat. Eine kleine mit Wasser
angefeuchtete Quantität wurde auf die Scheiben von zwei Blättern
gebracht. Eines derselben wurde nur unbedeutend afficirt; das andere
blieb zehn Tage lang dicht eingebogen, worauf dann einige wenige
Tentakeln sich wieder auszustrecken begannen, während die übrigen
bedeutend beschädigt oder getödtet waren. Ich wiederholte das Ex-
periment, befeuchtete aber das Phosphat mit Speichel, um einer sofor-
tigen Einbiegung mich zu versichern. Ein Blatt blieb sechs Tage
lang eingebogen (die geringe Menge des angewandten Speichels würde
auch nicht annähernd so lange gewirkt haben) und starb dann ab;
das andere Blatt versuchte am sechsten Tage sich wieder auszubrei-
ten, es gelang ihm aber nach neun Tagen nicht, dann starb es
gleichfalls. Obgleich die diesen vier Blättern gegebene Quantität von
Phosphat äuszerst klein war, blieb doch in allen Fällen viel ungelöst
zurück. Eine gröszere mit Wasser befeuchtete Quantität wurde nun
zunächst auf die Scheiben von drei Blättern gebracht; diese wurden
im Laufe von 24 Stunden äuszerst stark eingebogen. Sie breiteten
sich niemals wieder aus; am vierten Tage sahen sie kränklich aus
und am sechsten waren sie beinahe todt. Grosze Tropfen nicht sehr
klebriger Flüssigkeit hiengen während der sechs Tage von ihren
Rändern herab. Diese Flüssigkeit wurde jeden Tag mit Lackmus-
Papier probirt, färbte es aber niemals; dies ist ein Umstand, den ich
nicht verstehen kann, da das Kalksuperphosphat ja sauer ist. Ich
vermuthe nämlich, dasz sich etwas Superphosphat durch Einwirkung
der Säure des Secrets auf das Phosphat gebildet haben musz, dasz es
aber gänzlich absorbirt worden ist und die Blätter verletzt hat; die
groszen von den Blatträndern herabhängenden Tropfen wären dann
eine abnorme und hydropische Absonderung. Unter allen Umständen
ist offenbar der phosphorsaure Kalk ein äuszerst wirksames Reizmittel.
Selbst kleine Dosen sind mehr oder weniger giftig, wahrscheinlich in
Folge desselben Princips, wornach rohes Fleisch und andere im Über-
schusz gegebene nährbare Substanzen die Blätter tödten. Es ist da-
her die Schluszfolgerung ohne Zweifel correct, dasz die lange an-
dauernde Einbiegung der Tentakeln über Bruchstücken von Knochen,
Schmelz und Zahnbein durch die Gegenwart von phosphorsaurem Kalk,
nicht durch die irgend welcher eingeschlossener thierischer Substanz
bewirkt wird.

# Gelatine

Gelatine. — Ich benutzte reine Gelatine in dünnen Blättern,
welche mir Prof. Hoffmann gegeben hatte. Zur Vergleichung wurden# Gelatine und ihre Wirkung auf Drosera

Quadrate von derselben Grösze wie die auf die Blätter gelegten dicht daneben auf feuchtem Moose liegen gelassen. Diese schwollen bald an, behielten aber ihre Kanten drei Tage lang; nach fünf Tagen bildeten sie abgerundete, erweichte Massen; aber selbst am achten Tage noch konnte eine Spur von Gelatine nachgewiesen werden. Andere Quadrate wurden in Wasser eingetaucht, und obgleich diese bedeutend aufschwollen, behielten sie doch ihre Kanten sechs Tage lang. Quadrate von \frac {1}{10} Zoll (2,54 Mm.) Seitenlänge wurden, eben mit Wasser befeuchtet, auf zwei Blätter gelegt, und nach zwei oder drei Tagen war nichts mehr auf ihnen übrig als etwas saure klebrige Flüssigkeit, welche in diesem Falle eben so wenig wie in andern irgend- welche Neigung zeigte, sich wieder in Gallerte zu verwandeln; es musz daher das Secret auf die Gelatine anders einwirken als Wasser und allem Anscheine nach in derselben Art und Weise, wie es der Magensaft thut.

# Vergleich der Wirkungen

Vier Quadrate von derselben Grösse wie vorhin wurden dann drei Tage lang in Wasser eingeweicht und dann auf grosze Blätter gebracht; die Gelatine war in zwei Tagen verflüssigt und sauer geworden, rief aber keine starke Einbiegung hervor. Die Blätter fiengen nach vier oder fünf Tagen an, sich wieder auszubreiten, wobei viel klebrige Flüssigkeit auf ihren Scheiben liegen blieb, als wenn nur wenig absorbirt worden wäre. Eines dieser Blätter fieng, sobald es sich wieder ausgebreitet hatte, eine kleine Fliege und war nach 24 Stunden dicht eingebogen; woraus hervorgeht, um wie viel wirksamer die von einem Insect aufgesaugte thierische Substanz ist als Gelatine. Einige gröszere, fünf Tage lang in Wasser eingeweichte Stücke Gelatine wurden dann auf drei Blätter gebracht, diese wurden aber nicht eher als am dritten Tage bedeutend eingebogen; auch war die Gelatine nicht vor dem vierten Tage vollständig verflüssigt. An diesem Tage fieng das eine Blatt an, sich wieder auszubreiten, das zweite am fünften, das dritte am sechsten Tage. Diese verschiedenen Thatsachen beweisen, dasz die Gelatine durchaus nicht energisch auf die Drosera einwirkt.

# Hausenblase und ihre Wirkung

Im letzten Capitel wurde gezeigt, dasz eine Lösung von Hausenblase, wie sie im Handel vorkommt, so dick wie Milch oder Rahm eine starke Einbiegung veranlaszt. Ich wünschte daher ihre Einwirkung mit der der reinen Gelatine zu vergleichen. Lösungen von einem Theile beider Substanzen in 218 Theilen Wasser wurden gemacht, und halbe Minim-Tropfen (0,0296 Cub. Cent.) auf die Scheiben von acht Blättern gethan, so dasz ein jedes \frac {1}{480} Gran (0,135 Milligr.) erhielt. Die vier Blätter mit der Hausenblase wurden viel stärker eingebogen als die andern vier. Ich schliesze daher hieraus, dasz die Hausenblase etwas, wennschon vielleicht sehr wenig, lösliche albuminöse Substanz enthält. Sobald diese acht Blätter sich wieder ausgebreitet hatten, wurden ihnen Stückchen gerösteten Fleisches gegeben, und alle wurden in einigen Stunden bedeutend eingebogen; was wiederum zeigt, wie viel mehr Fleisch die Drosera reizt, als es Gelatine oder Hausenblase thut. Dies ist eine interessante That- sache, da es wohl bekannt ist, dasz Gelatine für sich allein nur wenig im Stande ist, Thiere zu ernähren.

# Chondrin und seine Eigenschaften

Chondrin. — Dies schickte mir Dr. Moore im gallertigen Zustand. Etwas davon wurde langsam getrocknet und ein kleines Schnittchen davon auf ein Blatt, ein viel gröszeres Schnittchen auf ein zweites Blatt gelegt. Das erste war in einem Tage verflüssigt; das gröszere Stück war bedeutend geschwollen und erweicht, war aber nicht vor dem dritten Tage vollständig flüssig geworden. Es wurde nun die nicht getrocknete Gallerte versucht, und als Controleversuch wurden kleine Würfel vier Tage lang in Wasser liegen gelassen, wo...# Experimentelle Beobachtungen

sie ihre Kanten behielten. Würfel derselben Grösze wurden auf zwei Blätter, und gröszere Würfel auf zwei andere Blätter gelegt. Die Tentakeln und Blattscheiben der letzteren waren nach 22 Stunden dicht eingebogen, diejenigen der beiden Blätter mit den kleineren Würfelchen aber nur in einem mäszigen Grade. Die Gallerte war in dieser Zeit auf allen vier Blättern verflüssigt und sehr sauer gewor- den. Die Drüsen waren in Folge der Zusammenballung ihres proto- plasmatischen Inhalts geschwärzt. In 46 Stunden von der Zeit an, wo die Gallerte aufgelegt worden war, hatten sich die Blätter beinahe wieder ausgebreitet, und waren vollständig ausgebreitet nach 70 Stunden, jetzt war nur ein wenig in geringem Grade klebrige Flüssigkeit nicht aufgesaugt auf den Blattscheiben übrig geblieben. Ein Theil der Chondrin-Gallerte wurde in 218 Theilen kochenden Wassers aufgelöst und halbe Minim-Tropfen auf vier Blätter gebracht; ein jedes derselben erhielt also \frac {1}{480} Gran (0,135 Milligr.) von der Gallerte, und natürlich viel weniger trockenes Chondrin. Dies wirkte äuszerst kräftig, denn nach nur 3 Stunden 80 Minuten waren alle vier Blätter stark eingebogen. Drei derselben fiengen nach 24 Stun- den an, sich wieder auszubreiten und waren in 48 Stunden vollstän- dig geöffnet; das vierte aber hatte sich nur zum Theil wieder aus- gebreitet. Alles flüssig gewordene Chondrin war in dieser Zeit ab- sorbirt. Es scheint daher eine Lösung von Chondrin bei weitem schneller und energischer einzuwirken als reine Gelatine oder Hausen- blase; gute Gewährsmänner haben mir aber versichert, dasz es äuszerst schwierig, wenn nicht unmöglich ist zu erkennen, ob Chondrin rein ist, und wenn dasselbe irgend welche albuminöse Verbindung enthielt, würde diese die oben geschilderten Wirkungen hervorgebracht haben. Nichtsdestoweniger habe ich diese Thatsachen der Mittheilung werth gehalten, da über den Ernährungswerth der Gelatine noch so viel Zweifel besteht; auch kennt Dr. Lauder Brunton keine Versuche an Thieren über den relativen Werth der Gelatine und des Chondrins.

# Milch und ihre Wirkung

Milch. — Wir haben im letzten Capitel gesehen, dasz Milch äuszerst kräftig auf die Blätter wirkt; ob dies aber in Folge des in ihr enthaltenen Casëins oder Albumins geschieht, weisz ich nicht. Ziemlich grosze Tropfen Milch regen eine so starke Absonderung an (die sehr sauer ist), dasz sie zuweilen von den Blättern abtröpfelt; dies ist gleichfalls für chemisch präparirtes Casëin characteristisch. Sehr kleine Tropfen Milch auf Blätter gebracht, waren in ungefähr zehn Minuten geronnen. Schiff läugnetLeçons etc. Tom. II. p. 151., dasz die Gerinnung der Milch durch den Magensaft ausschlieszlich Folge der vorhandenen Säure sei, sondern schreibt sie theilweise dem Pepsin zu; es scheint auch zweifelhaft zu sein, ob bei Drosera die Coagulation gänzlich eine Folge der Säure ist, da das Secret gewöhnlich Lackmus-Papier nicht eher färbt, als bis die Tentakeln ordentlich eingebogen worden sind, während doch, wie wir gesehen haben, die Coagulation in un- gefärh zehn Minuten beginnt. Sehr kleine Tropfen abgerahmter Milch wurden auf die Scheiben von fünf Blättern gebracht; ein groszer Theil der geronnenen Substanz oder des Quarks war in 6 Stunden und noch vollständiger in 8 Stunden aufgelöst. Diese Blätter breiteten sich nach zwei Tagen wieder aus, und nun wurde die auf ihren Scheiben zurückgelassene klebrige Flüssigkeit sorgfältig abgekratzt und untersucht. Auf den ersten Blick schien es, als ob nicht alles Casëin aufgelöst worden sei, denn es blieb ein wenig Substanz zurück, welche bei auffallendem Lichte weisz erschien. Wenn aber diese Sub- stanz unter starker Vergröszerung untersucht und mit einem minu- tiösen Tropfen abgerahmter, durch Essigsäure zur Gerinnung gebrachter Milch verglichen wurde, so sah man, dasz sie ausschlieszlich aus mehr oder weniger aggregirten Fettkügelchen ohne eine Spur von Casëin be- stand. Da ich mit der mikroskopischen Erscheinung der Milch nicht vertraut war, bat ich Dr. Lauder Brunton die Präparate zu unter- suchen; er prüfte die Kügelchen mit Äther und fand, dasz sie sich darin lösten. Wir dürfen daher schlieszen, dasz das Secret das Casëin# Chemisch präparirtes Casëin

Chemisch präparirtes Casëin. — Diese Substanz, welche in Wasser unlöslich ist, wird von vielen Chemikern für von dem Casëin der frischen Milch verschieden gehalten. Ich verschaffte etwas davon, aus harten Kügelchen bestehend, von den Herren Hopkins und Williams und stellte viele Versuche damit an. Kleine Stückchen und Drosera rotundifolia.

# Versuche mit Casëin

das Pulver, beides sowohl im trockenen Zustande als mit Wasser angefeuchtet, veranlassten die Blätter, auf welche sie gelegt wurden, sich sehr langsam einzubiegen, meist nicht vor Ablauf zweier Tage. Andre, mit schwacher Salzsäure (ein Theil auf 437 Theile Wasser) befeuchtet, wirkten in einem einzigen Tage, wie es auch etwas von Dr. Moore frisch für mich präparirtes Casëin that. Die Tentakeln blieben gewöhnlich sieben bis neun Tage lang eingebogen, und während dieser ganzen Zeit war das Secret stark sauer. Selbst am elften Tage war etwas auf der Scheibe eines vollständig wieder ausgebreiteten Blattes zurückgebliebenes Secret noch stark sauer.

# Wirkung von Casëin auf Drosera

Die Säure scheint schnell abgesondert zu werden, denn in einem Falle färbte das Secret von den scheibenständigen Drüsen, auf welche ein wenig gepulvertes Casëin gestreut worden war, Lackmus-Papier, ehe noch einer der äuszeren Tentakeln eingebogen worden war. Kleine Würfel mit Wasser angefeuchteten harten Casëins wurden auf zwei Blätter gebracht; nach drei Tagen waren die Kanten des einen Würfels ein wenig abgerundet, und nach sieben Tagen bestanden beide aus runden erweichten Massen, mitten in vieler klebriger und saurer Absonderungsflüssigkeit.

# Beobachtungen zur Auflösung von Casëin

Man darf aber aus dieser That-sache nicht folgern, dasz die Kanten aufgelöst worden wären, denn Würfel, welche in Wasser gelegt waren, zeigten eine ähnliche Einwirkung. Nach neun Tagen begannen diese Blätter sich wieder auszubreiten; das Casëin schien aber in diesem Falle wie in anderen Fällen, so weit sich mit bloszem Auge beurtheilen liesz, an Umfang nicht bedeutend, wenn überhaupt nur, reducirt worden zu sein.

# Chemische Eigenschaften von Casëin

Nach der Angabe Hoppe-Seyler’s und Lubavin’sDr. Lauder Brunton, Handbook for Physiol. Labor. p. 529. besteht das Casëin aus einer eiweiszartigen Substanz in Verbindung mit einer nicht eiweiszartigen: und die Absorption einer sehr geringen Quantität der ersteren wird die Blätter reizen und doch das Casëin in keinem bemerkbaren Grade vermindern. Schiff behauptetLeçons etc. Tom. II. p. 153. — und dies ist eine bedeutungsvolle Thatsache für uns, — dasz „la caséine purifiée des chimi-stes est un corps presque complètement inattaquable par le suc gastrique.‟

# Verdauung von Käse

Ein paar Versuche wurden mit Käse gemacht; Würfel von \frac {1}{20} Zoll (1,27 Mm.) wurden auf vier Blätter gelegt, worauf dieselben nach einem oder zwei Tagen ordentlich eingebogen wurden, während ihre Drüsen viel saures Secret ergoszen. Nach fünf Tagen fiengen sie an, sich wieder auszubreiten, aber das eine starb ab, und einige von den Drüsen auf den andern Blättern waren verletzt.

# Beobachtungen zur Käseverdauung

Nach bloszem Augenscheine zu urtheilen waren die auf den Blattscheiben zurückgelassenen erweichten und niedergesunkenen Massen von Käse sehr wenig oder überhaupt gar nicht der Grösse nach reducirt. Wir dürfen indesz wohl nach der Zeit, während welcher die Tentakeln eingebogen blieben, nach der veränderten Farbe einiger Drüsen, ebenso wie nach der Schädigung andrer schlieszen, dasz Substanz aus dem Käse absorbirt worden war.

# Legumin

Legumin. — Ich erhielt diese Substanz nicht im getrennten Zustande; man kann aber kaum daran zweifeln, dasz sie leicht verdaut werden wird, wenn man nach der kräftigen Wirkung urtheilt, welche, wie im letzten Capitel beschrieben wurde, durch Tropfen einer Abkochung grüner Erbsen hervorgebracht wird. Dünne Schnittchen# Verdauung von Erbsen und Pollen

einer getrockneten Erbse wurden, nachdem sie in Wasser eingeweicht worden waren, auf zwei Blätter gethan; diese wurden im Laufe einer einzigen Stunde einigermaszen, und in 21 Stunden äuszerst stark eingebogen. Sie breiteten sich nach drei oder vier Tagen wieder aus. Die Schnittchen waren nicht verflüssigt, denn die aus Cellulose bestehenden Zellwände werden von dem Secrete nicht im geringsten angegriffen.

## Pollenuntersuchung

Pollen. — Ein wenig frischer Pollen von der gemeinen Erbse wurde auf die Scheiben von fünf Blättern gelegt, welche bald dicht eingebogen wurden und es für zwei oder drei Tage blieben. Die Körner wurden dann entfernt und unter dem Mikroskope untersucht; es fand sich, dasz sie entfärbt und die Ölkügelchen merkwürdig zusammengeballt waren. Bei vielen war der Inhalt bedeutend zusammengeschrumpft und einige waren beinahe leer. Nur in einigen wenigen Fällen waren die Pollenschläuche vorgetreten. Es konnte daran kein Zweifel sein, dasz das Secret die äuszeren Hüllen der Körner durchdrungen und den Inhalt theilweise verdaut hatte. Dasselbe musz bei dem Magensaft der Insecten der Fall sein, welche von Pollen sich ernähren, ohne ihn zu zerkauenA. W. Bennett fand die unverdauten Hüllen der Körner im Darmeanal. Drosera wird Drosera rotundifolia.

## Nutzen der Pollenverdauung

Cap. 6. natürlich im Naturzustande in einer gewissen Ausdehnung aus diesem Vermögen, Pollen zu verdauen, Nutzen ziehen, da zahllose Körner aus den Ried- und andern Gräsern, den Sauerampfern, Fichtenbäumen und andern vom Winde befruchteten Pflanzen, welche gewöhnlich in derselben Örtlichkeit wachsen, unvermeidlich von der die vielen Drüsen umgebenden klebrigen Absonderung werden gefangen werden.

## Eigenschaften des Leims

Leim. — Diese Substanz ist aus zwei eiweiszartigen Körpern, einem in Alkohol löslichen und einem darin unlöslichen, zusammengesetztWatt’s Diction. of Chemistry, Vol. II. 1872, p. 873.. Es wurde etwas Leim einfach durch Auswaschen von Weizenmehl in Wasser dargestellt. Zunächst wurde ein provisorischer Versuch mit verhältnismäszig groszen Stücken, die auf zwei Blätter gelegt wurden, angestellt; die Blätter waren nach 21 Stunden dicht eingebogen und blieben es vier Tage lang, als eines abstarb, während die Drüsen des andern äuszerst intensiv geschwärzt waren; doch wurde es nicht weiter beobachtet.

## Versuche mit Leim

Es wurden nun kleinere Stückchen auf zwei Blätter gelegt; diese wurden in zwei Tagen nur unbedeutend eingebogen, wurden es aber später viel stärker. Ihre Absonderung war nicht so stark sauer wie die der durch Casëin gereizten Blätter. Nachdem die Stückchen Leim drei Tage auf den Blättern gelegen hatten, waren sie viel durchsichtiger als andere, ebenso lange Zeit in Wasser liegen gelassene Stückchen. Nach sieben Tagen breiteten sich beide Blätter wieder aus, der Leim schien aber kaum irgendwie an Grösse reducirt zu sein. Die Drüsen, welche mit ihm in Berührung gewesen waren, waren äuszerst schwarz.

## Weitere Experimente mit Leim

Es wurden nun noch kleinere Stückchen halb faulen Leims auf zwei Blättern versucht; diese waren in 24 Stunden ordentlich eingebogen, und gänzlich so in vier Tagen, die Drüsen in Berührung mit der Substanz stark geschwärzt. Nach fünf Tagen fieng ein Blatt an sich wieder auszubreiten und nach acht Tagen waren beide vollständig ausgebreitet, wobei noch etwas Leim auf ihren Scheiben zurückgeblieben war. Weiter wurden vier kleine Schnittchen getrockneten Leimes, die eben nur in Wasser getaucht waren, versucht, und diese wirkten etwas verschieden von frischem Leim. Das eine Blatt war in drei Tagen beinahe vollständig wieder ausgebreitet, und die andern drei Blätter in vier Tagen. Die Schnittchen waren bedeutend aufgeweicht, beinahe verflüssigt, aber nicht nahezu gänzlich aufgelöst. Die Drüsen, welche mit ihnen in Berührung gewesen waren, waren, anstatt bedeutend geschwärzt zu sein, von einer sehr blassen Färbung und viele von ihnen waren.# Einleitung
offenbar getödtet.

# Verdauung von Leim
In nicht einem einzigen unter diesen zehn Fällen war der ganze Leim aufgelöst, selbst wenn nur sehr kleine Stückchen gegeben wor- den waren. Ich bat in Folge dessen Dr. Burdon Sanderson, Leim in künstlicher Verdauungsflüssigkeit von Pepsin mit Salzsäure zu ver- suchen; dies löste das Ganze auf. Der Leim wurde indessen bedeu- tend langsamer angegriffen als Fibrin; das Verhältnis der in 4 Stun- den aufgelösten Menge betrug 40,8 Leim auf 100 Fibrin. Auch in zwei andern verdauenden Flüssigkeiten, bei denen die Salzsäure durch Propionsäure und durch Buttersäure ersetzt war, wurde der Leim versucht und von dieser Flüssigkeit bei der gewöhnlichen Zimmer- temperatur vollständig aufgelöst. Hier haben wir denn endlich einen Fall vor uns, in welchem allem Anscheine nach ein wesentlicher Unterschied in dem Verdauungsvermögen des Secrets der Drosera und des Magensaftes besteht; der Unterschied würde auf das Ferment beschränkt sein, denn, wie wir so eben gesehen haben, wirkt Pepsin in Verbindung mit Säuren der Essigreihe vollkommen auf den Leim ein. Ich glaube, die Erklärung liegt einfach in der Thatsache, dasz Leim ein zu kräftiges Reizmittel ist (wie rohes Fleisch, oder phos- phorsaurer Kalk, oder selbst ein zu groszes Stück Eiweisz) und dasz er die Drüsen verletzt oder tödtet, ehe sie Zeit gehabt haben, eine genügende Menge der passenden Absonderung zu ergieszen. Dasz etwas Substanz aus dem Leim absorbirt wird, dafür gibt die Länge der Zeit einen deutlichen Beleg, während welcher die Tentakeln ein- gebogen bleiben, ebenso die bedeutend veränderte Färbung der Drüsen.

# Behandlung mit schwacher Salzsäure
Auf den Rath des Dr. Sanderson wurde etwas Leim 15 Stunden lang in schwacher Salzsäure (0,02 Procent) gelassen, um die Stärke daraus zu entfernen. Er wurde farblos, durchsichtiger und aufge- schwollen. Kleine Partien wurden gewaschen und auf fünf Blätter gebracht, welche bald dicht eingebogen wurden, sich aber zu meiner Überraschung in 48 Stunden vollständig wieder ausbreiteten. Auf zwei der Blätter war nur eine Spur von Leim zurückgeblieben, und nicht eine Spur auf den andern dreien. Die klebrige und saure Ab- sonderung, welche auf den Scheiben der letzten drei Blätter geblieben war, wurde abgeschabt und von meinem Sohne mit einer starken Drosera rotundifolia. Cap. 6. Vergröszerung untersucht; es liesz sich indessen nichts erkennen als ein wenig Schmutz und eine ziemlich bedeutende Anzahl von Stärk- mehlkörnern, welche von der Salzsäure nicht aufgelöst worden waren. Einige der Drüsen waren ziemlich blasz. Wir erkennen hieraus, dasz mit schwacher Salzsäure behandelter Leim kein so kräftiger und kein so anhaltender Reiz ist wie frischer Leim, auch die Drüsen nicht be- deutend verletzt; und wir erkennen ferner, dasz er von dem Secrete schnell und vollständig verdaut werden kann.

# Globulin oder Crystallin
Globulin oder Crystallin. — Dr. Moore war so gut, mir diese Substanz aus der Linse des Auges darzustellen; sie bestand ans harten, farblosen, durchscheinenden Bruchstücken. Es wird angegebenWatts, Diction. of Chemistry. Vol. II, p. 874., Globulin soll »in Wasser aufschwellen und sich lösen, für den gröszten Theil eine „gummiartige Flüssigkeit bildend«; dies trat aber mit den erwähnten Bruchstücken nicht ein, trotzdem sie vier Tage lang in Wasser liegen gelassen wurden. Verschiedene Stückchen, einige mit Wasser, andere mit schwacher Salzsäure befeuchtet, noch andere einen oder zwei Tage lang in Wasser gelassen, wurden auf neunzehn Blätter gelegt. Die meisten dieser Blätter, besonders diejenigen mit den in Wasser gelegenen Stück- chen wurden in wenig Stunden stark eingebogen. Die gröszere Zahl breitete sich nach drei oder vier Tagen wieder aus; aber drei Blätter blieben noch einen, zwei oder drei weitere Tage lang eingebogen. Es musz demnach etwas reizende Substanz absorbirt worden sein; die Frag- mente aber, obschon sie vielleicht in einem bedeutenderen Grade erweicht waren als die eine gleich lange Zeit in Wasser gelassenen, behielten alle ihre Winkel so scharf wie je. Da das Globulin eine albuminöse Substanz ist, so war ich über das Resultat erstaunt; da meine Absicht die war, die Wirkungsweise des Drosera-Secrets mit der des Magensaftes.# Vergleich von Globulin und Fibrin

zu vergleichen, so bat ich Dr. Burdon Sanderson, mit dem von mir benutzten Globulin Versuche zu machen. Er theilt mir mit, dasz es »der „Wirkung einer Flüssigkeit ausgesetzt wurde, welche 0,2 Procent Salzsäure und ungefähr 1 Procent Glycerinextract eines Hundemagens enthielt. Es wurde dann ermittelt, dasz diese Flüssigkeit im Stande war, 1,31 ihres Gewichts ungekochten Fibrins in 1 Stunde zu verdauen, während im Verlauf dieser Stunde nur 0,141 des obigen Globulin gelöst wurde. In beiden Fällen wurde ein Überschusz der verdaut werden sollenden Substanz der Flüssigkeit zugesetzt. Ich will noch hinzufügen, dasz Dr. Sanderson noch etwas frisches Globulin nach der Schmidt’schen Methode darstellte; hiervon wurde in derselben Zeit, nämlich in einer Stunde 0,865 aufgelöst; es war daher bei weitem löslicher als das, was ich gebraucht hatte, obschon immerhin weniger löslich als Fibrin, von dem, wie wir gesehen haben, 1,31 aufgelöst wurde. Ich wünschte, ich hätte auf diese Weise dargestelltes Globulin bei der Drosera versucht..« Wir sehen hieraus, dasz innerhalb einer und derselben Zeit dem Gewicht nach weniger als ein Neuntel der aufgelösten Fibrinmenge vom Globulin aufgelöst wurde;

# Verdauung

und erinnert man sich der Thatsache, dasz Pepsin mit Säuren der Essigreihe nur ungefähr ein Drittel von dem Verdauungsvermögen des Pepsins mit Salzsäure hat, so ist es nicht überraschend, dasz die Globulinbruchstücke von dem Secrete der Drosera nicht corrodirt oder abgerundet wurden, obschon sicherlich etwas lösliche Substanz aus ihnen ausgezogen und von den Drüsen absorbirt war.

# Haematin

— Es wurden mir einige dunkelrothe, aus Ochsenblute dargestellte Körnchen gegeben; Dr. Sanderson fand, dasz dieselben in Wasser, Säuren und Alcohol unlöslich waren, so dasz sie wahrscheinlich Haematin enthielten in Verbindung mit andern aus dem Blute stammenden Körpern. Stückchen mit kleinen Tropfen Wasser wurden auf vier Blätter gebracht, von denen drei ziemlich dicht in zwei Tagen eingebogen waren; das dritte war es nur mäßig. Am dritten Tage waren die Drüsen in Berührung mit dem Haematin geschwärzt und einige Tentakeln schienen verletzt zu sein. Nach fünf Tagen starben zwei Blätter ab, und das dritte war am Sterben; das vierte fieng an, sich wieder auszubreiten, aber viele von seinen Drüsen waren geschwärzt und verletzt. Es ist daher klar, dasz Substanz absorbirt worden war, welche entweder factisch giftig oder von einer zu stark reizenden Beschaffenheit war. Die Stückchen waren viel mehr erweicht als die ebenso lange Zeit im Wasser gelassenen, waren aber, dem Augenscheine nach zu urtheilen, an Grösze sehr wenig reducirt. Dr. Sanderson prüfte diese Substanz mit künstlicher Verdauungsflüssigkeit, in der beim Globulin beschriebenen Art und Weise, und fand, dasz, während vom Fibrin in einer Stunde 1,31 gelöst wurden, vom Haematin sich nur 0,456 in einer Stunde lösten; aber die durch das Secret bewirkte Auflösung eines selbst noch kleineren Betrags würde seine Einwirkung auf Drosera erklären. Der von der künstlichen Verdauungsflüssigkeit zuerst übrig gelassene Rückstand gab während mehrerer folgender Tage nichts mehr an dieselbe ab.

# Substanzen, welche von dem Secrete nicht verdaut werden

Alle die bis jetzt erwähnten Substanzen bewirken lange anhaltende Einbiegung der Tentakeln und werden entweder vollständig oder mindestens theilweise von der Absonderung aufgelöst. Es gibt aber viele andere Substanzen, einige auch stickstoffhaltig, auf welche das Secret nicht im Mindesten einwirkt, und welche Einbiegung für keine längere Zeit herbeiführen als es unorganische und unlösliche Gegenstände thun. Solche nicht erregende und unverdauliche Substanzen sind, so weit ich es beobachtet habe, Epidermis-Bildungen (wie Stückchen menschlichen Nagels, Haarkügelchen, Federkiele), elastisches Fasergewebe, Mucin, Pepsin, Harnstoff, Chitin, Chlorophyll, Cellulose, Schieszbaumwolle, Fett, Öl und Stärke.

Diesen kann noch hinzugefügt werden: aufgelöster Zucker und Gummi, verdünnter Alcohol und vegetabilische, kein Eiweisz enthal-tende Aufgüsse, denn keiner dieser Körper erregt, wie im letzten Cap.# Einleitung

pitel gezeigt wurde, Einbiegung. Es ist nun eine merkwürdige That-
sache, welche noch weitere und wichtige Belege dafür abgibt, dasz
das Ferment der Drosera dem Pepsin sehr ähnlich oder mit ihm
identisch ist, dasz keine einzige dieser nämlichen Substanzen, so weit
es bekannt ist, vom Magensaft der Thiere verdaut wird, obschon die
andern Absonderungen des Darmcanals auf einige von ihnen einwirken.
Über die oben aufgezählten Substanzen braucht nichts weiter gesagt
zu werden, ausgenommen, dasz sie wiederholt auf den Blättern der
Drosera versucht worden sind, aber nicht im geringsten von dem
Secrete angegriffen wurden. Über die andern wird es räthlich sein,
meine Versuche anzuführen.

# Elastisches Fasergewebe

Elastisches Fasergewebe. — Wir haben bereits gesehen, dasz,
wenn kleine Würfel von Fleisch u. s. w. auf Blätter gelegt wurden, die
Muskeln, das Zellgewebe und der Knorpel vollständig aufgelöst wurden,
dasz aber das elastische Fasergewebe, selbst die allerzartesten Fäserchen
ohne die mindesten Zeichen einer Einwirkung auf dieselben zurückblieben.
Es ist auch wohl bekannt, dasz dies Gewebe vom Magensaft der Thiere
nicht verdaut werden kanns. z. B. Schiff, Leçons phys. de la Digestion, 1867,
Tom. II, p. 38..

# Mucin

Mucin. — Da diese Substanz ungefähr 7 Procent Stickstoff ent-
hält, erwartete ich, dasz sie die Blätter bedeutend erregen und dasz sie
vom Secret verdaut werden würde; darin irrte ich mich aber. Nach dem,
was in chemischen Werken angegeben wird, scheint es äusserst zweifel-
haft zu sein, ob Mucin als reine Grundsubstanz dargestellt werden kann.
Das, was ich anwandte (von Dr. Moore dargestellt) war trocken und hart.
Mit Wasser angefeuchtete Stückchen wurden auf vier Blätter gebracht;
nach zwei Tagen aber war nur eine Spur von Einbiegung an den un-
mittelbar benachbarten Tentakeln zu bemerken. Diese Blätter wurden
dann mit Stückchen Fleisch probirt und alle vier wurden stark einge-
bogen. Etwas von dem trocknen Mucin wurde dann zwei Tage lang in
Wasser eingeweicht, und kleine Würfel der gehörigen Grösse wurden auf
drei Blätter gebracht. Nach vier Tagen waren die Tentakeln rund um
die Scheibenränder ein wenig eingebogen; auch war die sich auf der
Scheibe angesammelte Absonderung sauer, aber die äuszern Tentakeln
waren nicht afficirt. Ein Blatt fieng am vierten Tage an, sich wieder
auszubreiten, und alle waren am sechsten vollständig ausgebreitet. Die
Drüsen, welche in Berührung mit dem Mucin gestanden hatten, waren ein
wenig gedunkelt. Wir können daher schlieszen, dasz eine geringe Menge
irgend einer Verunreinigung von mäszig reizender Beschaffenheit absorbirt
worden war. Dasz das von mir angewandte Mucin etwas lösliche Sub-
stanz enthielt, wies Dr. Sanderson nach, welcher fand, dasz etwas davon
aufgelöst worden war, nachdem er es eine Stunde lang der Einwirkung
künstlichen Magensaftes ausgesetzt hatte, aber nur in dem Verhältnis von
Cap. 6. Verdauung.
23 zu 100, letztere Zahl für die in gleicher Zeit aufgelöste Menge Fibrin
genommen. Obgleich die Würfel im Ganzen vielleicht etwas weicher
waren als die, eine gleich lange Zeit in Wasser liegen gelassenen, be-
hielten sie doch alle Kanten so scharf wie jemals. Wir können daher
schlieszen, dasz das Mucin selbst nicht aufgelöst oder verdaut wurde.
Auch wird es vom Magensaft lebender Thiere nicht verdaut, und nach
Schiff Leçons phys. de la Digestion, Tom. II, 1867, p. 304. ist es eine Schicht
dieser Substanz, welche die Häute des Ma-
gens gegen Corrosion während der Verdauung schützt.

# Pepsin

Pepsin. — Meine Experimente verdienen kaum mitgetheilt zu wer-
den, da es kaum möglich ist, von Albuminoiden freies Pepsin darzustellen;
ich war aber begierig zu ermitteln, so weit dies eben möglich war, ob
das Ferment in dem Secret der Drosera auf das Ferment im Magensafte
von Thieren wirken werde. Ich benutzte anfänglich das zu medicinischen
Zwecken verkäufliche Pepsin, später andres, was viel reiner war, und was
Dr. Moore mir dargestellt hatte. Fünf Blätter, denen eine beträchtliche
Quantität von dem ersteren gegeben war, blieben fünf Tage lang einge-
bogen; vier von ihnen starben dann ab, allem Anscheine nach in Folge
des zu starken Reizes. Ich versuchte dann Dr. Moore’s Pepsin, machte
mit Wasser einen Teig daraus und legte dann so kleine Stückchen davon# Einleitung in die Experimente

auf die Scheibe von fünf Blättern, dasz alles sehr schnell aufgelöst wor-
den sein würde, wenn es Fleisch oder Eiweisz gewesen wäre. Die Blätter
wurden bald eingebogen; nach nur 20 Stunden fiengen zwei von ihnen
an, sich wieder auszubreiten und die andern drei waren nach 44 Stunden
vollständig wieder ausgebreitet. Einige von den Drüsen, welche mit den
Pepsinstückchen oder mit dem sauren, dieselben umgebenden Secrete in
Berührung gewesen waren, waren eigenthümlich blasz, während andere
eigenthümlich dunkel gefärbt waren. Etwas von dem Secrete wurde ab-
gekratzt und unter starker Vergröszerung untersucht; es fanden sich Massen
von Körnchen darin, welche von denjenigen des, eine gleich lange Zeit
in Wasser gelassenen Pepsin nicht zu unterscheiden waren. Wir dürfen
daher (wenn wir uns erinnern, welche kleine Quantitäten gegeben
worden waren) als in hohem Grade wahrscheinlich annehmen, dasz das
Ferment der Drosera auf Pepsin nicht wirkt und dasselbe nicht verdaut,
sondern daraus nur eine albuminöse Verunreinigung absorbirt, welche
Einbiegung veranlaszt und in gröszeren Mengen in hohem Grade schädlich ist.
Dr. Lauder Brunton gab sich auf meine Bitte Mühe, zu ermitteln, ob
Pepsin mit Salzsäure Pepsin verdaut; so weit er es beurtheilen konnte, hat
es diese Kraft nicht. Der Magensaft stimmt daher allem Anscheine nach
in dieser Beziehung mit dem Secret der Drosera überein.

# Untersuchung des Harnstoffs

Harnstoff. — Es schien mir interessant zu sein, zu untersuchen,
ob dieser Auswurfsstoff des lebenden Körpers, welcher viel Stickstoff ent-
hält, von den Drüsen der Drosera, wie so viele andere Flüssigkeiten und
Substanzen, absorbirt werden und Einbiegung bewirken würde. Halbe
Minim-Tropfen einer Lösung von einem Theile auf 437 Theile Wasser
wurden auf die Scheiben von vier Blättern gebracht, wobei jeder Tropfen
die gewöhnlich von mir angewendete Menge enthielt, nämlich \frac {1}{960} Gran
oder 0,0674 Milligr.; die Blätter wurden aber kaum irgendwie afficirt.
Drosera rotundifolia. Cap. 6.
Sie wurden dann mit Stückchen Fleisch probirt und waren bald dicht
eingebogen. Ich wiederholte denselben Versuch mit etwas, von Dr. Moore
frisch präparirten Harnstoff an vier Blättern; nach zwei Tagen war keine
Einbiegung vorhanden; ich gab ihnen dann eine andere Dose, aber noch
immer erfolgte keine Einbiegung. Diese Blätter wurden später mit gleich
groszen Tropfen eines Aufgusses von rohem Fleisch probirt, und in 6 Stun-
den war beträchtliche Einbiegung eingetreten, welche in 24 Stunden ex-
cessiv wurde. Der Harnstoff war aber dem Anscheine nach nicht völlig
rein; denn als vier Blätter in 2 Drachmen (7,1 Cub. Cent.) der Lösung
eingetaucht wurden, so dasz sämmtliche Drüsen, anstatt blosz die auf
der Scheibe, in den Stand gesetzt wurden, irgendwelche kleine Menge
eines verunreinigenden Zusatzes in der Lösung zu absorbiren, trat in
24 Stunden beträchtliche Einbiegung ein, sicherlich mehr, als einer ähn-
lichen Eintauchung in reines Wasser gefolgt wäre. Dasz der Harnstoff,
welcher nicht vollkommen weisz war, eine Quantität von albuminoider
Substanz oder von irgend einem Ammoniaksalz enthalten haben solle,
hinreichend grosz, um die eben geschilderte Wirkung hervorzubringen, ist
durchaus nicht überraschend; denn, wie wir im nächsten Capitel sehen
werden, sind erstaunlich kleine Dosen von Ammoniak in hohem Grade
wirksam. Wir können daher schlieszen, dasz der Harnstoff selbst für die
Drosera nicht reizend oder nahrhaft sei; auch wird er vom Secrete nicht
modificirt, so dasz er nahrhaft gemacht würde; denn, wäre dies der Fall
gewesen, so würden zuverlässig sämmtliche Blätter, auf deren Scheiben
Tropfen lagen, ordentlich eingebogen worden sein. Dr. Lauder Brunton
theilt mir mit, dasz nach Versuchen, die er auf meine Bitte in St. Bar-
tholomew’s Hospital angestellt hat, allem Anscheine nach künstlicher
Magensaft, d. h. Pepsin mit Salzsäure, auf den Harnstoff nicht wirkt.

# Analyse der Chitinhüllen

Chitin. — Die Chitinhüllen der auf natürlichem Wege von den
Blättern gefangenen Insecten scheinen nicht im mindesten corrodirt zu
werden. Kleine viereckige Stückchen des zarten Flügels und der Flügel-
decke eines Staphylinus wurden auf einige Blätter gelegt, und nachdem
diese sich wieder ausgebreitet hatten, wurden die Stücke sorgfältig unter-
sucht. Ihre Kanten waren so scharf wie je und sie waren auch im An-
sehen von dem andern Flügel und der andern Flügeldecke desselben In-
sects, welches in Wasser liegen gelassen worden war, nicht verschieden.# Einleitung zur Verdauung

Die Flügeldecke hatte indesz offenbar etwas nährbare Substanz abgegeben, denn das Blatt blieb vier Tage lang über ihm geschlossen, während die Blätter mit Stückchen echten Flügels sich am zweiten Tage wieder ausbreiteten. Ein Jeder, der nur die Exeremente insectenfressender Thiere untersuchen will, wird sehen, wie machtlos ihr Magensaft in Bezug auf das Chitin ist.

# Cellulose

Ich erhielt diese Substanz nicht in getrenntem Zustand, sondern machte die Versuche mit eckigen Stückchen trocknen Holzes, mit Kork, Sphagnum-Moos, leinenen und baumwollenen Fäden. Keiner dieser Körper wurde von dem Secrete im Mindesten angegriffen und sie bewirkten nur jenen mäßigen Grad der Einbiegung, welcher allen unorganischen Gegenständen eigen ist. Schieszbaumwolle, welche aus Cellulose besteht, bei welcher der Wasserstoff durch Stickstoff vertreten ist, wurde mit dem nämlichen Erfolge probiert.

# Versuche mit Kohlblättern

Wir haben gesehen, dasz eine Abkochung von Kohlblättern eine äußerst kräftige Einbiegung bewirkt. Ich brachte daher zwei kleine viereckige Stückchen der Scheibe eines Kohlblattes und vier kleine aus der mittleren Blattrippe ausgeschnittene Würfelchen auf sechs Blätter von Drosera. Dieselben wurden in 12 Stunden ordentlich eingebogen und blieben so zwischen zwei und vier Tage lang, wobei die Stückchen Kohl die ganze Zeit von dem sauren Secrete umspült wurden. Dies beweist, dasz etwas reizende Substanz, auf welche ich sofort zurückkommen werde, absorbiert worden ist; aber die Kanten der viereckigen Stückchen und Würfel blieben so scharf wie je, damit beweisend, dasz das Cellulosen-Gerüst nicht angegriffen worden war.

# Chlorophyll

Ich probirte diese Substanz, da sie Stickstoff enthält. Dr. Moore schickte mir etwas in Alcohol aufbewahrtes; es wurde getrocknet, zerflosz aber bald. Stückchen wurden auf vier Blätter gelegt; nach 3 Stunden war das Secret sauer; nach 8 Stunden war ein netter Ansatz zur Einbiegung da, welche in 24 Stunden ziemlich gut ausgeprägt war. Nach vier Tagen fingen zwei Blätter sich wieder zu öffnen an und die andern beiden waren zu dieser Zeit beinahe vollständig wieder ausgebreitet.

# Schlussfolgerungen zu Chlorophyll

Es ist daher klar, dasz dieses Chlorophyll Substanz enthielt, welche die Blätter in einem mäßigen Grade reizte; aber nach dem Augenschein zu urtheilen, war nur wenig oder gar nichts aufgelöst; im reinen Zustande würde es daher wahrscheinlich vom Secrete nicht angegriffen worden sein. Dr. Sanderson stellte mit dem Chlorophyll, welches ich angewendet hatte, ebenso mit etwas frisch präparirtem Versuche in künstlicher Verdauungsflüssigkeit an und fand, dasz es nicht verdaut wurde.

# Weitere Experimente

Es wurde auch mit Glycerinextract des Pancreas probirt, aber gleichfalls mit negativem Erfolg. Chlorophyll scheint auch von den Darmabsonderungen verschiedener Thiere nicht angegriffen zu werden, wenn man nach der Farbe ihrer Excremente urtheilt. Es darf nach diesen Thatsachen nicht etwa angenommen werden, dasz die Chlorophyll-Körner, wie sie in lebenden Pflanzen existiren, von dem Secrete gar nicht angegriffen werden können; denn diese Körner bestehen aus Protoplasma, welches nur mit Chlorophyll gefärbt ist.

# Experimentelle Beobachtungen

Mein Sohn Francis legte ein dünnes Schnittchen eines Spinatblattes, welches mit Speichel angefeuchtet war, auf ein Blatt der Drosera, andere Schnittchen auf feuchte Watte und setzte sie sämmtlich der nämlichen Temperatur aus. Nach 19 Stunden war das Schnittchen auf dem Drosera-Blatte in reichliches, von den einzelnen Tentakeln ausgehendes Secret eingetaucht; es wurde nun unter dem Mikroskope untersucht. Es waren keine voll-# Drosera rotundifolia

## Chlorophyll-Körner und ihre Wirkung

## Fett und Öl

## Stärkmehl

## Wirkung des Secrets auf lebende Samen

## Rettichsamen und ihre Reaktion

## Kressensamen und ihre Beobachtungen# Einleitung zur Untersuchung der Samen und deren Wirkung auf Pflanzen

# Ergebnisse der Experimente mit verschiedenen Samen

# Einfluss der Samen auf die Blätter und deren Reaktion

# Zusammenfassung und Schluszbemerkungen über das Verdauungsvermögen der Drosera# Verdauung und Peptogene

nur dann ab, wenn sie gewisse lösliche Pflanzen, welche er als Peptogene bezeichnet, aufgesaugt haben. Es besteht daher ein merk- würdiger Parallelismus zwischen den Drüsen der Drosera und denen des Magens in Bezug auf die Absonderung ihrer eigenthümlichen Säure und ihres Ferments.

# Wirkung des Sekrets

Das Secret löst, wie wir gesehen haben, Eiweisz, Muskel, Fibrin, Zellgewebe, Knorpel, die fasrige Grundsubstanz des Knochens, Gelatine, Chondrin, Casëin in dem Zustande, in dem es in der Milch existirt, und Leim, welcher der Einwirkung schwacher Salzsäure aus- gesetzt worden war, vollständig auf. Syntonin und Legumin reizen die Blätter so mächtig, dasz darüber kaum ein Zweifel bestehen kann, dasz beide vom Secrete aufgelöst werden dürften.

# Einfluss von frischem Leim und Fleisch

Das Secret war nicht im Stande, frischen Leim aufzulösen, allem Anscheine nach, weil er die Drüsen verletzte, obschon etwas absorbirt wurde. Rohes Fleisch, wenn es nicht in sehr kleinen Stückchen gegeben wurde, und grosze Stücke von Eiweisz u. s. w. verletzen die Blätter gleichfalls, welche, wie Thiere, an Überladung zu leiden scheinen.

# Nährstoffaufnahme

Ich weisz nicht, ob die Analogie eine wirkliche ist; es ist aber der Bemerkung werth, dasz eine Abkochung von Kohlblättern bei weitem erregender und wahrscheinlich nährender für die Drosera ist als ein mit lauem Wasser gemachter Aufgusz; ebenso sind gekochte Kohlarten, wenig- stens für den Menschen, bei weitem nahrhafter als die ungekochten Blätter.

# Verdauung von Knorpel

Der auffallendste von allen Fällen, wenn schon in Wirklich- keit nicht merkwürdiger als viele andere, ist die Verdauung einer so harten und zähen Substanz wie Knorpel. Die Auflösung von reinem phosphorsaurem Kalk, von Knochen, Zahnbein und besonders von Schmelz scheint wunderbar zu sein; sie hängt aber lediglich von der lange anhaltenden Absonderung einer Säure ab; und dieselbe wird unter diesen Umständen eine längere Zeit hindurch abgesondert, als unter irgend welchen andern.

# Beobachtungen zur Verdauung

Es war interessant zu beobachten, dasz, so lange die Säure zur Auflösung des phosphorsauren Kalkes verbraucht wurde, keine echte Verdauung eintrat; dasz aber, sobald der Knochen vollständig entkalkt war, die fasrige Grundsubstanz des Knochens angegriffen und mit der gröszten Leichtigkeit verflüssigt wurde.

# Vergleich mit Magensaft

Die zwölf oben angeführten Substanzen, welche von dem Secrete vollständig aufgelöst werden, werden gleichfalls von dem Magensaft höherer Thiere aufgelöst, die Einwirkung auf dieselben geschieht in beiden Fällen auf dieselbe Weise, wie es sich in dem Abrunden der Kanten der Eisweiszstückchen und in einer noch besonderern Weise in der Art zeigt, wie die Querstreifen der Muskelfasern verschwinden.

# Chemische Reaktionen

Das Secret der Drosera und der Magensaft waren beide im Stande, irgend einen Stoff oder eine Verunreinigung aus dem von mir ange- wandten Globulin und Haematin aufzulösen. Auch löste das Secret etwas aus chemisch präparirtem Casëin auf, was, wie angegeben wird, aus zwei Substanzen besteht; und obschon Schiff behauptet, dasz Casëin in diesem Zustande vom Magensaft nicht angegriffen wird, so kann er doch leicht eine minutiöse Menge irgend einer eiweiszartigen Substanz übersehen haben, welche Drosera entdecken und absorbiren wird.

# Faserknorpel und Verdauung

Obschon ferner Faserknorpel nicht eigentlich aufgelöst wird, so wirken doch beide Flüssigkeiten, das Secret der Drosera und der Magensaft in gleicher Weise auf ihn ein. Doch hätte diese Substanz ebenso wie das von mir benutzte sogenannte Haematin vielleicht unter die unverdaulichen Substanzen classificirt werden sollen.

# Rolle des Pepsins

Dasz der Magensaft mittelst seines Ferments, des Pepsins, nur in Gegenwart einer Säure wirkt, ist ganz sicher ermittelt; und wir haben ausgezeichnete Belege, dasz in dem Secrete der Drosera ein Ferment vorhanden ist, welches gleichfalls nur in Gegenwart einer Säure wirkt; denn wir haben gesehen, dasz, wenn das Secret durch äusserst kleine Tropfen einer Alkalilösung neutralisirt wird, die Verdauung von Eiweisz vollständig zum Stillstand gebracht wird und dasz sie beim Zusatz einer äusserst geringen Dose Salzsäure sofort wieder.# Einleitung

Auf die neun folgenden Substanzen, oder Classen von Substanzen wirkt das Secret der Drosera nicht ein, nämlich auf Epidermoidal-gebilde, elastisches Fasergewebe, Mucin, Pepsin, Harnstoff, Chitin, Cellulose, Schieszbaumwolle, Chlorophyll, Stärkmehl, Fette und Öle; ebenso wirkt auch, so viel man weisz, der Magensaft von Thieren nicht auf sie ein. Aber sowohl durch das Drosera-Secret als durch künstlichen Magensaft wurde etwas lösliche Substanz aus dem von mir benutzten Mucin, Pepsin und Chlorophyll ausgezogen.

# Wirkung der Substanzen

Die verschiedenen Substanzen, welche von dem Secrete vollständig aufgelöst und hernach von den Drüsen absorbirt werden, afficiren die Blätter ziemlich verschieden. Sie führen Einbiegung mit sehr verschiedener Geschwindigkeit und in sehr verschiedenen Graden herbei; auch bleiben die Tentakeln sehr verschieden lange Zeiträume hindurch eingebogen. Schnelle Einbiegung hängt zum Theil von der Menge der verabreichten Substanz ab, so dasz viele Drüsen gleichzeitig afficirt werden, zum Theil von der Leichtigkeit, mit welcher dieselbe vom Secrete durchdrungen und verflüssigt wird, zum Theil von ihrer Beschaffenheit, hauptsächlich aber von der Gegenwart einer bereits in Lösung befindlichen reizenden Substanz. So wirkt Speichel oder eine schwache Lösung rohen Fleisches viel schneller ein, als selbst eine starke Lösung von Gelatine.

# Einfluss der Textur

Ferner werden Blätter, welche sich nach vorgängiger Absorption von Tropfen einer Lösung von reiner Gelatine oder Hausenblase (die letztere ist die wirksamere von beiden) wieder ausgebreitet haben, wenn ihnen Stückchen Fleisch gegeben werden, viel energischer und schneller sich einbiegen, als sie es vorher thaten, trotzdem dasz meistens etwas Ruhe zwischen zwei Einbiegungs-acten nothwendig ist. Wir sehen wahrscheinlich den Einflusz einer Texturänderung, wenn wir beobachten, dasz Gelatin und Globulin, welche durch Liegenlassen im Wasser erweicht sind, schneller wirken, als wenn sie blosz angefeuchtet werden. Es dürfte zum Theil Folge veränderter Textur und zum Theil Folge einer Änderung der chemischen Beschaffenheit sein, dasz Eiweisz, welches eine Zeit lang aufge-hoben worden ist, und Leim, welcher der Einwirkung schwacher Salzsäure ausgesetzt gewesen ist, schneller wirken als diese Substanzen im frischen Zustande.

# Dauer der Einbiegung

Die Länge der Zeit, während welcher die Tentakeln eingebogen bleiben, hängt zum groszen Theile von der Quantität der den Blättern gegebenen Substanz ab, zum Theil von der Leichtigkeit, mit welcher sie von dem Secrete durchdrungen und angegriffen wird und zum Theil von ihrer eigenthümlichen Beschaffenheit. Die Tentakeln bleiben immer viel länger über groszen Stückchen oder groszen Tropfen als über kleinen Stückchen oder Tropfen eingebogen. Wahrscheinlich spielt die Textur ihre Rolle bei Bestimmung der auszerordentlichen Länge Zeit, während welcher die Tentakeln über den harten Körnern chemisch präparirten Casëins eingebogen bleiben.

# Einfluss der Insekten

Die Tentakeln bleiben aber eine gleich lange Zeit über fein gepulvertem, präcipitirtem phosphorsauren Kalk eingebogen; in diesem letztern Falle bietet offenbar der Phosphor den Anziehungspunkt dar, und in dem Fall mit dem Casëin thierische Substanz. Die Blätter bleiben über Insecten lange eingebogen; es ist aber zweifelhaft, in wie weit dies eine Folge des den Insecten durch ihre chitinhaltigen Integumente gewährten Schutzes ist; denn thierische Substanz wird bald aus Insecten ausgezogen (wahrscheinlich durch Exosmose aus ihren Körpern in das dichte umgebende Secret), wie es sich in der sofortigen Einbiegung der Blätter zeigt.

# Unterschiedliche Substanzen

Wir sehen den Einflusz der Natur verschiedener Substanzen bei Stückchen Fleisch, Eiweisz und frischem Leim, deren Einwirkung sehr verschieden ist von der gleich groszer Stückchen Gelatine, Zellgewebe und fasriger Grundsubstanz des Knochens. Die erste-ren verursachen nicht blosz eine bei weitem schnellere und energischere, sondern auch länger anhaltende Einbiegung als die letzteren. Wir sind daher, wie ich glaube, berechtigt anzunehmen, dasz Gelatine, Drosera rotundifolia.# Zellgewebe und Nahrhaftigkeit

Zellgewebe, und die Fasersubstanz des Knochens für die Drosera viel weniger nahrhaft sein werden, als solche Substanzen wie Insecten, Fleisch, Eiweisz u. s. w. Dies ist eine interessante Schluszfolgerung, da es bekannt ist, dasz Gelatine den Thieren nur geringe Nahrung darbietet; dasselbe wird wahrscheinlich auch mit Zellgewebe und der Fasersubstanz des Knochens der Fall sein. Das Chondrin, welches ich benutzte, wirkte kräftiger ein als Gelatine; ich weisz aber nicht, ob es rein war. Es ist eine noch merkwürdigere Thatsache, dasz Fibrin, welches zu der groszen Classe der Protein-Verbindungen s. die von Dr. Michael Foster angenommene Classification in Watt’s Diction. of Chemistry, Supplement, 1872, p. 969. gehört, deren eine Untergruppe auch das Eiweisz enthält, die Tentakeln in keinem höheren Grade reizt oder dieselben für eine längere Zeit eingebogen hält, als es Gelatine oder Zellgewebe oder die fasrige Grundsubstanz des Knochens thun. Es ist nicht bekannt, wie lange ein Thier leben bleiben würde, wenn es allein mit Fibrin gefüttert würde; Dr. Sanderson zweifelt aber nicht daran, dasz es länger leben würde als wenn es mit Gelatine gefüttert würde; auch würde es kaum vor-schnell sein, vorherzusagen, dasz, nach den Wirkungen auf Drosera zu urtheilen, Eiweisz sich als viel nahrhafter herausstellen wird, als Fibrin. Globulin gehört gleichfalls zu den Protëin-Verbindungen, es bildet darin eine andere Unter-Gruppe; und obschon diese Substanz irgend einen Körper enthält, welcher die Drosera ziemlich stark reizte, wurde sie doch kaum von dem Secrete und sehr wenig oder sehr langsam vom Magensafte angegriffen. In wie weit Globulin für Thiere nahrhaft sein dürfte, ist nicht bekannt. Wir sehen hiernach, wie verschieden die oben einzeln aufgeführten verschiedenen verdau-lichen Substanzen auf Drosera einwirken; wir können als in hohem Grade wahrscheinlich folgern, dasz sie in gleicher Weise sowohl für Drosera als für Thiere in sehr verschiedenen Graden nahrhaft sein werden.

# Absorption von Substanzen

Die Drüsen der Drosera absorbiren Substanz aus lebenden Samen, welche von dem Secrete verletzt oder getödtet werden. Sie absorbiren gleichfalls Substanz aus Pollen und aus frischen Blättern; und dies ist mit dem Magen der pflanzenfressenden Thieren notorisch der Fall. Drosera ist eigentlich eine insectenfressende Pflanze; da es aber gar nicht anders sein kann, als dasz Pollen häufig auf die Drüsen geweht wird, wie es auch gelegentlich mit Samen und Blättern benachbarter Pflanzen der Fall sein wird, so ist Drosera auch in gewissem Masze ein Pflanzenfresser.

# Verdauungsvermögen und Physiologie

Endlich zeigen uns die in diesem Capitel verzeichneten Experi-mente, dasz eine merkwürdige Übereinstimmung besteht zwischen dem Verdauungsvermögen des Magensaftes von Thieren mit seinem Pepsin und seiner Salzsäure und dem des Secrets der Drosera mit seinem Ferment und seiner zur Essigreihe gehörenden Säure. Wir können daher kaum daran zweifeln, dasz das Secret in beiden Fällen sehr ähnlich ist, wenn es nicht identisch dasselbe ist. Dasz eine Pflanze und ein Thier dasselbe oder nahezu dasselbe zusammengesetzte Secret ergieszen, welches einem und dem nämlichen Zwecke der Verdauung angepast ist, ist eine neue und wunderbare Thatsache in der Physiologie. Ich werde aber auf diesen Gegenstand im fünfzehnten Capitel, in meinen Schluszbemerkungen über die Droseraceae zurückzu-kommen haben.

# Die Wirkungen von Ammoniaksalzen

Siebentes Capitel.
Die Wirkungen von Ammoniaksalzen.
Art, die Versuche auszuführen. — Wirkung destillirten Wassers im Vergleich mit den Lösungen. — Kohlensaures Ammoniak, von den Wurzeln absorbirt. — Der Dampf von den Drüsen absorbirt. — Tropfen auf den Blattscheiben. — Minutiöse Tröpfchen auf einzelne Drüsen gebracht. — Blätter in schwache Lösungen eingetaucht. — Auszerordentliche Kleinheit der Dosen, welche Aggregation des Protoplasma herbeiführen. — Salpetersaures Ammoniak, analoge Versuche damit. — Phosphorsaures Ammoniak, analoge Versuche. —# Ammoniaksalze und ihre Wirkung

## Zusammenfassung und Schluszbemerkungen

Die hauptsächliche Aufgabe dieses Capitels ist, zu zeigen, wie mächtig die Ammoniaksalze auf die Blätter der Drosera einwirken, und besonders noch nachzuweisen, was für eine auszerordentlich kleine Menge hinreicht, Einbiegung zu erregen. Ich werde daher genöthigt sein, in ausführliche Einzelnheiten einzugehen. Stets wurde doppelt destillirtes Wasser benutzt; und für die feineren Versuche gab mir Professor Frankland Wasser, was mit der äussersten nur möglichen Sorgfalt dargestellt war. Die graduirten Masze wurden geprüft und für so genau befunden, als derartige Masze es nur sein können. Die Salze wurden sorgfältig gewogen und zwar bei allen feineren Experimenten nach Borda’s doppelter Methode. Äuszerste Genauigkeit würde aber überflüssig gewesen sein, da die Blätter je nach Alter, Zustand und Constitution bedeutend in Bezug auf die Irritabilität von einander verschieden sind. Selbst die Tentakeln an einem und demselben Blatte weichen betreffs der Irritabilität in einem ausgesprochenen Grade von einander ab. Meine Versuche wurden auf die folgenden verschiedenen Weisen angestellt.

## Erste Versuchsreihe

Erstens. — Tropfen, von denen durch wiederholte Versuche ermittelt wurde, dasz sie im Mittel ungefähr ein halbes Minim, oder \frac {1}{960} einer flüssigen Unze (0,0296 Cub. Cent.) betrugen, wurden mit einem und demselben spitzen Instrumente auf die Scheiben der Blätter gebracht und dann die Einbiegung der äuszeren Tentakelreihen in aufeinanderfolgenden Zeitabschnitten beobachtet. Es wurde zunächst, nach zwischen dreiszig und vierzig Versuchen, ermittelt, dasz in dieser Weise aufgetropftes destillirtes Wasser keine Wirkung hervorbringt, ausgenommen dasz zuweilen, obschon selten, zwei oder drei Tentakeln eingebogen werden. In der That führen alle die vielen Versuche mit Lösungen, welche so schwach waren, dasz sie keine Wirkung hervorbrachten, zu demselben Resultat, dasz Wasser wirkungslos ist.

## Zweite Versuchsreihe

Zweitens. — Der Kopf einer kleinen, in einen Stiel befestigten Stecknadel wurde in die dem Experimente unterliegende Lösung eingetaucht. Der kleine Tropfen, welcher ihm anhieng und welcher viel zu klein war, um abzufallen, wurde mit Hülfe einer Lupe sorgfältig in Berührung gebracht mit dem die Drüsen eines, zweier, drei oder vier der äuszeren Tentakeln eines und desselben Blattes umgebenden Secrete. Grosze Sorgfalt wurde angewendet, dasz die Drüsen selbst nicht berührt wurden. Ich hatte vermuthet, dasz die Tropfen von nahezu derselben Grösze wären; nach einem Versuch stellte sich dies als ein groszer Irrthum heraus. Ich masz zunächst etwas Wasser und entfernte 300 Tropfen, wobei ich jedesmal den Stecknadelkopf auf Löschpapier auflegte; als ich dann das Wasser wieder masz, ergab sich, dasz ein Tropfen im Mittel ungefähr gleich \frac {1}{60} Minim war. Etwas Wasser in einem kleinen Gefäsz wurde gewogen (und dies ist eine genauere Methode) und dann wie vorher 300 Tropfen entfernt; als ich dann das Wasser wieder wog, stellte sich heraus, dasz ein Tropfen im Mittel ungefähr nur gleich \frac {1}{80} Minim war. Ich wiederholte die Operation, versuchte aber diesmal dadurch, dasz ich den Stecknadelknopf schräg und ziemlich geschwind aus dem Wasser nahm, so grosze Tropfen als möglich zu entfernen; das Resultat zeigte, dasz mir dies gelungen war; denn jeder Tropfen war im Mittel gleich \frac {1}{19′4} Minim. Ich wiederholte die Operation in genau derselben Weise, und jetzt waren die Tropfen im Mittel gleich \frac {1} {23′5} Minim. Erinnert man sich, dasz bei diesen zwei letzten Gelegenheiten besondere Mühe angewendet wurde, so grosze Tropfen als möglich zu entfernen, so können wir ruhig schlieszen, dasz die in meinen Experimenten angewandten Tropfen mindestens gleich \frac {1}{20} Minim oder 0,0029 Cub. Cent. waren. Einer dieser Tropfen konnte auf drei oder selbst vier Drüsen verwendet werden, und wenn die Tentakeln eingebogen wurden, so musz etwas von der Lösung von allen absorbirt worden sein; denn Tropfen reinen Wassers in derselben Weise applicirt, bringen niemals irgend eine Wirkung hervor. Ich war nur im Stande, den Tropfen zehn oder fünfzehn Secunden lang in# Stetige Berührung mit dem Secrete

Es wurde festgestellt, dass die Diffusion des Salzes in Lösung nicht lange genug war, um alle Tentakeln zu beeinflussen.

## Vergleich der Blätter

Blätter wurden in eine abgemessene Quantität der Versuchsflüssigkeit eingetaucht und die Ergebnisse wurden mit denen in destilliertem Wasser verglichen.

## Absorption von Substanzen

Die Absorption von Substanzen durch die Drüsen und Papillen wurde untersucht, wobei festgestellt wurde, dass die Bewegung der Tentakeln von der Reizung der Drüsen abhängt.

## Schlussfolgerungen zur Absorption

Die Ergebnisse führten zu interessanten Schlussfolgerungen über die Menge des absorbierten Salzes und die Empfindlichkeit der Drüsen.

# Wirkung destillierten Wassers

Die Wirkungsweise von destilliertem Wasser beim Verursachen von Einbiegung wurde analysiert, wobei Unterschiede im Verhalten der Blätter in Wasser und verschiedenen Lösungen festgestellt wurden.# Übersicht über die Wirkungen des Wassers

## Experimente und Beobachtungen

## Zustand der Blätter nach dem Eintauchen

## Empfindlichkeit der Pflanzen

## Unterschiede zwischen Wasser und Ammoniaklösungen# Blättern in schwachen Lösungen

Blättern in den schwachen Lösungen wird häufig die Platte oder Scheibe eingebogen: und dies ist ein an Blättern in Wasser so selten eintretender Umstand, dasz ich nur zwei Fälle davon gesehen habe, und in beiden war die Einbiegung sehr schwach. Ferner schreitet bei Blättern in den schwachen Lösungen die Einbiegung der Tentakeln und der Blattscheibe oft stetig fort, wenn auch langsam, und viele Stunden lang immer zu; dies ist wiederum bei Blättern in Wasser ein so seltener Umstand, dasz ich nur drei Fälle von irgend einer derartigen Zunahme nach den ersten 8 bis 12 Stunden gesehen habe; und in diesen drei Fällen waren die zwei äuszeren Reihen von Tentakeln durchaus gar nicht afficirt. Es besteht daher zuweilen ein viel bedeutenderer Unterschied zwischen den Blättern in Wasser und den in den schwachen Lösungen nach Verlauf von 8 bis 24 Stunden, als in den ersten drei Stunden vorhanden war; doch ist es der allgemeinen Regel nach am besten, sich auf die in der kürzeren Zeit beobachteten Verschiedenheit zu verlassen.

## Zeitpunkt der Wiederausstreckung

Was den Zeitpunkt der Wiederausstreckung der Blätter betrifft, sowohl wenn sie in Wasser als wenn sie in den schwachen Lösungen eingetaucht gelassen wurden, so konnte es kaum etwas variableres geben. In beiden Fällen beginnen die äuszeren Tentakeln sich wieder auszustrecken nach Verlauf von nur 6 bis 8 Stunden; das ist ungefähr gerade die Zeit, wenn die kurzen Tentakeln rings um die Scheibenränder eingebogen werden. Auf der andern Seite bleiben die Tentakeln zuweilen einen ganzen Tag lang oder selbst zwei Tage lang eingebogen; der allgemeinen Regel nach bleiben sie aber in sehr schwachen Lösungen länger eingebogen als in Wasser. In Lösungen, welche nicht gerade äuszerst schwach sind, breiten sie sich niemals innerhalb einer auch nur annähernd so kurzen Zeit wie 6 oder 8 Stunden wieder aus. Nach diesen Angaben könnte man meinen, es sei schwierig, zwischen den Wirkungen des Wassers und der schwächerer Lösungen zu unterscheiden; in Wahrheit besteht aber so lange nicht die geringste Schwierigkeit, bis excessiv schwache Lösungen versucht werden; dann ist die Unterscheidung, wie sich hätte erwarten lassen, sehr zweifelhaft und verschwindet zuletzt ganz. Da aber in allen Fällen, ausgenommen die einfachsten, der Zustand der gleichzeitig für eine gleiche Zeitdauer in Wasser und in die Lösungen eingetauchten Blätter beschrieben werden wird, so kann sich der Leser sein Urtheil selbst bilden.

# Kohlensaures Ammoniak

Wenn dieses Salz von den Wurzeln absorbirt wird, verursacht es keine Einbiegung der Tentakeln. Eine Pflanze wurde so in eine Lösung von einem Theile des kohlensauren Salzes in 146 Theilen Wasser gestellt, dasz die jungen unverletzten Wurzeln beobachtet werden konnten. Die terminalen Zellen, welche von einer rosa Färbung waren, wurden augenblicklich farblos und ihr klarer Inhalt wolkig wie ein Mezzotinto-Stich, so dasz ein gewisser Grad von Zusammenballung beinahe augenblicklich verursacht wurde; es erfolgte aber keine weitere Veränderung und die absorbirenden Härchen wurden nicht sichtbar afficirt. Die Tentakeln krümmten sich nicht. Zwei andere Pflanzen wurden, ihre Wurzeln von feuchtem Moos umgeben, in eine halbe Unze (14,198 Cub. Cent.) einer Lösung von einem Theile des kohlensauren Salzes auf 218 Theile Wasser gestellt und# Beobachtungen und Experimente

24 Stunden lang beobachtet; es wurde aber nicht ein einziger Tentakel eingebogen. Um diese Wirkung hervorzubringen, musz das kohlensaure Salz von den Drüsen absorbirt werden. Der Dampf bringt eine mächtige Wirkung auf die Drüsen hervor und verursacht Einbiegung. Drei Pflanzen, deren Wurzeln in Flaschen waren, so dasz die umgebende Luft nicht sehr feucht werden konnte, wurden zusammen mit 4 Gran kohlensauren Ammoniaks in einem Uhrglas unter eine Glasglocke (von 122 flüssigen Unzen Inhalt) gestellt. Nach Verlauf von 6 Stunden 15 Minnten schienen die Blätter nicht afficirt zu sein; aber am nächsten Morgen, nach 20 Stunden, sonderten die geschwärzten Drüsen reichlich ab und die meisten Tentakeln waren stark eingebogen. Diese Pflanzen starben bald ab. Zwei andere Pflanzen wurden zusammen mit einem halben Gran des kohlensauren Salzes unter dieselbe Glasglocke gebracht und die Luft so feucht als möglich gemacht; in 2 Stunden waren die meisten Blätter afficirt, viele der Drüsen waren geschwärzt und die Tentakeln eingebogen. Es ist aber eine merkwürdige Thatsache, dasz einige der dicht neben einander stehenden Tentakeln an einem und demselben Blatte, sowohl auf der Scheibe als auch rings um den Rand herum bedeutend und einige allem Anscheine nach nicht im Mindesten afficirt waren. Die Pflanzen wurden 24 Stunden unter der Glasglocke gehalten, es folgte aber keine weitere Veränderung. Ein gesundes Blatt war kaum irgendwie afficirt, obgleich andere Blätter an der nämlichen Pflanze bedeutend afficirt waren. Bei einigen Blättern waren alle Tentakeln auf einer Seite eingebogen, aber nicht die auf der entgegengesetzten Seite. Ich bezweifle es, ob diese äuszerst ungleiche Wirkung durch die Vermuthung erklärt werden kann, dasz die thätigeren Drüsen allen Dampf so geschwind absorbiren, wie er erzeugt wird, so dasz dann keiner für die übrigen Drüsen zurückbleibt; wir werden nämlich analogen Fällen begegnen, wo die Luft mit Dämpfen von Chloroform und Äther völlig durchdrungen war.

# Wirkung des kohlensauren Salzes

Äuszerst kleine Stückchen des kohlensauren Salzes wurden dem mehrere Drüsen umgebenden Secrete hinzugefügt. Diese wurden augenblicklich schwarz und sonderten reichlich ab; aber ausgenommen in zwei Fällen, wo äuszerst minutiöse Stückchen gegeben wurden, fand keine Einbiegung statt. Dies Resultat ist dem analog, welches dem Eintauchen von Blättern in eine starke Auflösung von einem Theil des kohlensauren Salzes in 109, oder 146, oder selbst in 218 Theilen Wasser folgt; denn die Blätter werden dann gelähmt und es erfolgt keine Einbiegung, obschon die Drüsen geschwärzt werden und das Protoplasma in den Zellen der Tentakeln starker Zusammenballung unterliegt.

# Lösungen des kohlensauren Salzes

Wir wollen uns nun zu den Wirkungen der Lösungen des kohlensauren Salzes wenden. Halbe Minims einer Lösung von einem Theil in 437 Theilen Wasser wurden auf die Scheiben von zwölf Blättern gebracht; so dasz ein jedes \frac {1}{960} Gran oder 0,0675 Milligr. erhielt. Bei zehn von diesen wurden die äuszeren Tentakeln gut eingebogen; auch die Blattscheiben einiger wurden stark einwärts gekrümmt. In zwei Fällen waren mehrere von den äuszeren Tentakeln in 35 Minuten eingebogen; die Bewegung war aber im Allgemeinen langsamer. Diese zehn Blätter breiteten sich nach einer verschiedenen Zeitdauer wieder aus, welche zwischen 21 und 45 Stunden schwankte; in einem Falle erfolgte die Wiederausbreitung nicht vor Verlauf von 67 Stunden, so dasz sie sich viel schneller wieder ausbreiteten als Blätter, welche Insecten gefangen hatten.

# Weitere Experimente

Gleich grosse Tropfen einer Lösung von einem Theil in 875 Theilen Wasser wurden auf die Scheiben von elf Blättern gebracht; sechs blieben völlig unafficirt, während bei fünf von drei bis sechs oder acht ihrer äuszeren Tentakeln eingebogen wurden; doch kann dieser Grad von Bewegung kaum für zuverläszig angesehen werden. Jedes dieser Blätter erhielt \frac {1}{1920} Gran (0,0337 Milligr.) über die Drüsen der Scheibe.# Experimentelle Ergebnisse

dies war aber eine zu kleine Menge, um irgend eine entschiedene Wir-
kung auf die äuszeren Tentakeln hervorzubringen, deren Drüsen selbst
nichts von dem Salze erhalten hatten.
Äuszerst kleine Tropfen, am Kopfe einer kleinen Stecknadel, einer
Lösung von einem Theil des kohlensauren Salzes in 218 Theilen Wasser
wurden nun zunächst in der oben beschriebenen Art und Weise versucht.
Ein Tropfen dieser Art gleicht im Mittel \frac {1}{20} Minim und enthält daher
\frac {1}{4800} Gran (0,0135 Milligr.) des kohlensauren Salzes. Ich berührte das
klebrige Secret rings um drei Drüsen damit, so dasz jede Drüse nur \frac {1}
{14400}
Gran (0,00445 Milligr.) erhielt. Nichtsdestoweniger wurden in zwei Versuchen
alle Drüsen deutlich geschwärzt; in einem Falle waren alle drei Ten-
takeln nach Verlauf von 2 Stunden 40 Minuten gut eingebogen, und in
einem andern Falle waren zwei von den drei Tentakeln eingebogen. Ich
versuchte dann Tropfen einer schwächeren Lösung von einem Theile auf
292 Wasser an vier und zwanzig Drüsen, immer das klebrige Secret
rings um drei Drüsen mit denselben kleinen Tropfen berührend. Jede
Drüse erhielt hiernach nur \frac {1}{19200} Gran (0,00337 Milligr.), und doch
wurden einige von ihnen etwas dunkel; in keinem einzigen Falle aber
wurde irgend einer der Tentakeln eingebogen, obschon sie 12 Stunden
lang beobachtet wurden. Als eine noch schwächere Lösung (nämlich ein
Theil auf 437 Theile Wasser) an sechs Drüsen versucht wurde, war durch-
aus gar keine Wirkung wahrnehmbar. Wir lernen hieraus, dasz \frac {1}{14400}
Gran (0,00445 Milligr.) kohlensauren Ammoniaks, wenn es von einer Drüse
absorbirt wird, hinreicht, in dem basalen Theile des nämlichen Tentakels
Einbiegung zu veranlassen; wie aber bereits erwähnt, war ich nur wenige
Secunden lang im Stande, mit stetiger Hand die äuszerst kleinen Tropfen
mit dem Secrete in Berührung zu halten; wäre zur Diffusion und Ab-
sorption mehr Zeit gelassen worden, so würde sicherlich eine viel schwä-
chere Lösung gewirkt haben.

# Versuche mit Blättern

Einige Versuche wurden so gemacht, dasz abgeschnittene Blätter in
Lösungen verschiedener Stärkegrade eingetaucht wurden. So wurden vier
Blätter, jedes ungefähr 3 Stunden lang, in einer Drachme (3,549 Cub. Cent.)
einer Lösung von einem Theile des kohlensauren Salzes auf 5250 Theile
Wasser gelassen; bei zweien derselben war beinahe jeder Tentakel ein-
gebogen, beim dritten war ungefähr die Hälfte und beim vierten unge-
fähr ein Drittel der Tentakeln eingebogen; sämmtliche Drüsen waren ge-
schwärzt. Ein anderes Blatt wurde in eine gleich grosze Menge einer
Lösung von einem Theile in 7000 Theilen Wasser gelegt, und in 1 Stunde
16 Minuten war jeder einzelne Tentakel ordentlich eingebogen und sämmt-
liche Drüsen geschwärzt. Sechs Blätter wurden ein jedes in dreiszig
Minims (1,774 Cub. Cent.) einer Lösung von einem Theile in 4375 Theilen
Wasser eingetaucht, und in 31 Minuten waren die Drüsen sämmtlich ge-
schwärzt. Alle sechs Blätter boten etwas unbedeutende Einbiegung dar,
und eines war stark eingebogen. Vier Blätter wurden dann in dreiszig
Minims einer Lösung von einem Theil in 8750 Theilen Wasser einge-
taucht, so dasz jedes Blatt \frac {1}{320} Gran (0,2025 Milligr.) erhielt. Nur
eins
wurde stark eingebogen; aber sämmtliche Drüsen auf allen Blättern waren
nach 1 Stunde von einem so dunklen Roth, dasz es beinahe verdiente
schwarz genannt zu werden, während dies bei den zu derselben Zeit in
Wasser eingetauchten Blättern nicht eintrat; auch brachte überhaupt
Wasser diese Wirkung bei keiner andern Gelegenheit in auch nur nahezu
so kurzer Zeit wie einer Stunde hervor. Diese Fälle von gleichzeitigem
Dunkel- oder Schwarzwerden der Drüsen in Folge der Wirkung schwacher
Lösungen sind wichtig, da sie zeigen, dasz sämmtliche Drüsen das kohlen-
saure Salz innerhalb der nämlichen Zeit aufsaugten, welche Thatsache zu
bezweifeln allerdings nicht der geringste Grund vorhanden war. Sobald
ferner sämmtliche Tentakeln innerhalb derselben Zeit eingebogen werden,
haben wir, wie vorhin schon bemerkt, einen Beweis von gleichzeitiger
Absorption. Ich habe die Anzahl der Drüsen auf diesen vier Blättern
nicht gezählt; da es aber schöne Blätter waren, und da wir wissen, dasz# Drüsen und ihre Absorption

Die mittlere Anzahl von Drüsen auf ein und zwanzig Blättern betrug, so können wir getrost annehmen, dasz ein jedes im Mittel mindestens 170 trug; war dies der Fall, so konnte jede geschwärzte Drüse nur \frac {1}{54400} Gran (0,00119 Milligr.) des kohlensauren Salzes aufgesaugt haben.

# Versuche mit Lösungen

Eine grosze Anzahl von Versuchen war vorläufig mit Lösungen von einem Theil salpetersauren und phosphorsauren Ammoniaks auf 43750 Theile Wasser (d. h. ein Gran auf 100 Unzen) angestellt worden, wobei sich diese Lösungen als in hohem Grade wirksam herausstellten. Es wurden daher vierzehn Blätter ein jedes in dreiszig Minims einer Lösung von einem Theile des kohlensauren Salzes in der angegebenen Menge Wassers gelegt, so dasz jedes Blatt \frac {1}{1600} Gran (0,0405 Milligr.) erhielt.

# Affektion der Blätter

Die Drüsen wurden nicht bedeutend dunkler. Zehn von den Blättern wurden nicht afficirt oder nur sehr unbedeutend. Vier indessen wurden stark afficirt: das erste hatte in 47 Minuten sämmtliche Tentakeln, ausgenommen vierzig, eingebogen; in 6 Stunden 30 Minuten waren alle eingebogen mit Ausnahme von zwölf, und nach 4 Stunden war es die Blatt-scheibe selbst.

# Wirkung des kohlensauren Ammoniaks

Es kann daher daran kein Zweifel sein, dasz, wenn ein in hohem Grade empfindliches Blatt in eine Lösung eingetaucht wird, so dasz alle Drüsen in den Stand gesetzt werden, zu absorbiren, \frac {1}{1600} Gran des kohlensauren Salzes auf dasselbe einwirkt. Nimmt man an, dasz das Blatt, welches ein groszes war und dessen sämmtliche Tentakeln mit Ausnahme von acht eingebogen wurden, 170 Drüsen trug, so konnte jede Drüse nur \frac {1}{268800} Gran (0,00024 Milligr.) absorbirt haben; und doch war dies hinreichend, auf einen jeden der 162 Tentakeln, welche eingebogen wurden, einzuwirken.

# Zusammenballung des Protoplasma

Zusammenballung des Protoplasma in Folge der Einwirkung des kohlensauren Ammoniaks. — Ich habe im dritten Capitel ausführlich die merkwürdigen Wirkungen mäszig starker Dosen dieses Salzes beschrieben, wie sie sich in der Verursachung einer Zusammenballung des Protoplasma innerhalb der Zellen der Drüsen und Tentakeln äuszern; meine Absicht ist, hier lediglich zu zeigen, welche kleine Dosen schon genügen.

# Versuche mit verschiedenen Lösungen

Es wurde dann eine Lösung von einem Theil in 5250 Theilen Wasser gemacht, womit ich an vierzehn Blättern Versuche aufstellte; doch will ich nur einige wenige Fälle anführen. Acht junge Blätter wurden ausgewählt und mit Sorgfalt untersucht; sie zeigten keine Spur von# Zusammenballung und Experimente

Zusammenballung. Vier von diesen wurden in eine Drachme (3,549 Cub. Cent.) destillirten Wassers gelegt; vier in ein ähnliches Gefäsz mit einer Drachme der Lösung. Nach einiger Zeit wurden die Blätter unter einer starken Vergröszerung untersucht, wobei immer abwechselnd eines aus der Lösung und aus dem Wasser genommen wurde. Das erste Blatt wurde aus der Lösung genommen nach einem Eintauchen von 2 Stunden 40 Minuten, und das letzte Blatt wurde aus dem Wasser genommen nach 3 Stunden 50 Minuten; die Untersuchung währte 1 Stunde 40 Minuten. In den vier aus dem Wasser genommenen Blättern war keine Spur von Zusammenballung mit Ausnahme eines Exemplars vorhanden, in welchem sehr wenige äuszerst minutiöse Kügelchen von Protoplasma unterhalb einiger der runden Drüsen zu bemerken waren. Sämmtliche Drüsen waren durchscheinend und roth. Die vier Blätter, welche in die Lösung einge- taucht gewesen waren, boten auszerdem, dasz sie eingebogen waren, ein weit davon verschiedenes Ansehen dar; denn der Inhalt der Zellen jeden einzelnen Tentakels an allen vier Blättern war augenfällig zusammen-geballt; die Kugeln und länglichen Massen von Protoplasma erstreckten sich in vielen Fällen die halbe Länge der Tentakeln hinab. Sämmtliche Drüsen, sowohl die der centralen als auch die der äuszeren Tentakeln waren opak und geschwärzt; und dies zeigt, dasz sie alle etwas von dem kohlensauren Salze absorbirt hatten. Diese vier Blätter waren von nahezu der nämlichen Grösse; auf einem wurden die Drüsen gezählt; es waren 167 vorhanden. Wenn unter solchen Umständen die vier Blätter in eine Drachme der Lösung eingetaucht wurden, so konnte jede Drüse im Mittel nur \frac {1}{64128} Gran (0,001009 Milligr.) von dem Salze erhalten haben; und diese Quantität war hinreichend, innerhalb einer kurzen Zeit augenfällige Zusammenballung in den Zellen unterhalb aller der Drüsen herbeizuführen.

# Beobachtungen und Ergebnisse

Ein kräftiges, aber eher etwas kleines rothes Blatt wurde in sechs Minims der nämlichen Lösung (nämlich ein Theil auf 5250 Theile Wasser) gethan, so dasz es \frac {1}{960} Gran (0,0675 Milligr.) erhielt. In 40 Minuten erschienen die Drüsen eher dunkler; und in 1 Stunde hatten sich von vier bis sechs Protoplasma-Kugeln in den Zellen unterhalb der Drüsen sämmtlicher Tentakeln gebildet. Ich habe die Tentakeln nicht gezählt; wir können aber getrost annehmen, dasz mindestens 140 vorhanden waren; war dies der Fall, so konnte jede Drüse nur \frac {1}{134400} Gran oder 0,00048 Milligr. erhalten haben. Es wurde dann eine schwächere Lösung von einem Theile in 7000 Theilen Wasser gemacht, und vier Blätter wurden in dieselbe getaucht; ich will aber nur einen einzigen Fall anführen. Ein Blatt wurde in zehn Minims dieser Lösung gelegt; nach 1 Stunde 37 Minuten wurden die Drüsen etwas dunkler, und die Zellen unter ihnen allen enthielten nun viele Kugeln zusammengeballten Protoplasmas. Dies Blatt erhielt \frac {1}{768} Gran und trug 166 Drüsen. Jede Drüse konnte daher nur \frac {1}{127488} Gran (0,000507 Milligr.) des kohlensauren Salzes erhalten haben.

# Weitere Experimente

Zwei andere Experimente sind noch der Mittheilung werth. Ein Blatt wurde 4 Stunden 15 Minuten lang in destillirtes Wasser einge- taucht, es trat aber keine Zusammenballung ein: dann wurde es 1 Stunde 15 Minuten lang in ein wenig Lösung von einem Theile auf 5250 Theile Wasser gelegt; und dies erregte wohl ausgesprochene Zusammenballung und Einbiegung. Bei einem andern Blatte waren, nachdem es 21 Stunden 15 Minuten in destilliertem Wasser gelegen hatte, die Drüsen geschwärzt; es fand sich aber keine Zusammenballung in den Zellen unter ihnen; dann wurde es in sechs Minims der nämlichen Lösung gelassen, und in 1 Stunde fand sich bedeutende Zusammenballung in vielen der Tentakeln; in 2 Stunden waren sämmtliche Tentakeln (146 an Zahl) afficirt, wobei die Zusammenballung eine Strecke weit hinabreichte, welche der halben oder der ganzen Länge der Drüsen gleich kam. Es ist äuszerst unwahr- scheinlich, dasz diese beiden Blätter einer Zusammenballung unterlegen wären, wenn sie ein wenig länger im Wasser liegen gelassen worden wären, nämlich 1 Stunde und 1 Stunde 15 Minuten, während welcher Zeit sie in die Lösung eingetaucht waren; denn der Procesz der Zusammen- ballung scheint ausnahmslos langsam und sehr allmählich im Wasser ein-# Zusammenfassung der Resultate mit kohlensaurem Ammoniak

Die Wurzeln absorbiren die Lösung, wie sich aus ihrer veränderten Färbung und aus der Zusammenballung des Inhalts ihrer Zellen ergibt. Der Dampf wird von den Drüsen absorbirt; dieselben werden geschwärzt und die Tentakeln eingebogen. Wenn die Drüsen der Scheibe durch einen halben Minim-Tropfen (0,0296 Cub. Cent.) gereizt werden, der \frac {1}{960} Gran (0,0675 Milligr.) enthält, so übermitteln sie den äuszeren Tentakeln einen motorischen Impuls, welcher dieselben einwärts zu biegen veranlaszt. Ein minutiöser, \frac {1}{14400} Gran (0,00445 Milligr.) enthaltender Tropfen verursacht, wenn er wenige Secunden lang mit einer Drüse in Berührung gehalten wird, dasz sich der dieselbe tragende Tentakel bald einbiegt. Wenn ein Blatt wenige Stunden lang in einer Lösung eingetaucht gelassen wird, und eine Drüse absorbirt \frac {1}{134400} Gran (0,00048 Milligr.), so wird ihre Färbung dunkler, wennschon nicht factisch schwarz; auch wird der Inhalt der Zellen unterhalb der Drüse deutlich zusammengeballt. Endlich genügt unter denselben Umständen die Aufsaugung von \frac {1}{268800} Gran (0,00024 Milligr.) durch eine Drüse, um den diese Drüse tragenden Tentakel zur Bewegung zu reizen.

# Salpetersaures Ammoniak

Bei diesem Salze achtete ich nur auf die Einbiegung der Blätter; denn es ist in Bezug auf Verursachung von Zusammenballung bei weitem weniger wirksam als das kohlensaure Salz, obschon es beträchtlich wirkungsvoller in Bezug auf Verursachung von Einbiegung ist. Ich experimentirte mit halben Minims (0,0296 Cub. Cent,) auf den Scheiben von zwei und fünfzig Blättern, will aber nur einige wenige Fälle anführen. Eine Lösung von einem Theile in 109 Theilen Wasser war zu stark; sie verursachte wenig Einbiegung und tödtete nach 24 Stunden, (oder tödtete beinahe), vier von den sechs Blättern, welche in dieser Weise probirt wurden; jedes derselbe erhielt \frac {1}{240} Gran (oder 0,27 Milligr.). Eine Lösung von einem Theil in 218 Theilen Wasser wirkte äuszerst energisch; sie verursachte nicht allein die starke Einbiegung aller der Tentakeln, sondern auch der Blattscheiben einiger. Vierzehn Blätter wurden mit Tropfen einer Lösung von einem Theil auf 875 Theile Wasser versucht, so dasz die Scheibe eines jeden \frac {1}{1920} Gran (0,0337 Milligr.) erhielt. Von diesen Blättern wirkte die Lösung auf sieben sehr stark ein, indem allgemein auch die Ränder eingebogen wurden; die Einwirkung auf zwei war mäszig, und fünf wurden durchaus gar nicht beeinfluszt. Ich versuchte später drei von diesen letztgenannten fünf Blättern mit Harnstoff, Speichel und Schleim, sie wurden aber nur unbedeutend afficirt; und dies beweist, dasz sie sich in keinem lebenskräftigen Zustande befanden. Ich erwähne diese Thatsache, um zu zeigen, wie nothwendig es ist, an verschiedenen Blättern zu experimentiren. Zwei der Blätter, welche ordentlich eingebogen waren, breiteten sich nach 51 Stunden wieder aus.

# Drosera rotundifolia

In dem folgenden Experimente traf es sich, dasz ich sehr empfindliche Blätter gewählt hatte. Halbe Minims einer Lösung von einem Theil auf 1094 Wasser (d. h. 1 Gran auf 2½ Unzen) wurden auf die Scheiben von neun Blättern gebracht, so dasz jedes \frac {1}{2400} Gran (0,027 Milligr.) erhielt. Bei drei von ihnen waren die Tentakeln stark eingebogen und ihre Scheiben einwärts gerollt; fünf waren unbedeutend und etwas zweifelhaft afficirt, indem von drei bis acht ihrer äuszern Tentakeln eingebogen waren; ein Blatt war durchaus gar nicht afficirt, doch wirkte später Speichel auf dasselbe ein. In sechs von diesen Fällen war eine Spur von Wirkung in 7 Stunden bemerkbar, aber die volle Wirkung wurde nicht vor Ablauf von 24 bis 30 Stunden hervorgerufen. Zwei von den Blättern, welche nur unbedeutend eingebogen waren, breiteten sich nach Verlauf von wei...# Experimentelle Ergebnisse

Halbe Minims einer etwas schwächeren Lösung, nämlich von einem Theil in 1312 Theilen Wasser (1 Gran auf 3 Unzen) wurden auf vierzehn Blättern versucht, so dasz jedes \frac {1}{2880} Gran (0,0225 Milligr.) erhielt. Die Scheibe eines derselben wurde deutlich eingebogen, wie es auch sechs der äuszeren Tentakeln wurden; die Scheibe eines zweiten wurde unbedeutend, zwei der äuszeren Tentakeln gut eingebogen, während alle die andern Tentakeln in rechten Winkeln zur Blattscheibe eingerollt wurden; bei drei andern Blättern waren von fünf bis acht Tentakeln eingebogen, bei fünf andern nur zwei oder drei, und gelegentlich, obschon sehr selten, verursachen Tropfen reinen Wassers so viel Wirkung; die vier übrig bleibenden Blätter waren in keiner Weise afficirt, doch wurden drei von ihnen, als sie später mit Harn probirt wurden, bedeutend eingebogen. In den meisten dieser Fälle war eine unbedeutende Wirkung innerhalb 6 bis 7 Stunden bemerkbar, doch wurde die volle Wirkung nicht vor Ablauf von 24 bis 30 Stunden hervorgebracht. Offenbar haben wir hier sehr nahe den Minimalbetrag erreicht, welcher, zwischen die Drüsen der Scheibe vertheilt, auf die äuszeren Tentakeln wirkt; diese selbst hatten nichts von der Lösung erhalten.

# Wirkung der Lösungen

An nächster Stelle wurde die klebrige Absonderung rings um drei der äuszeren Drüsen mit einem und demselben kleinen Tropfen (\frac {1}{20} Minim) einer Lösung von einem Theile in 437 Theilen Wasser berührt; und nach Verlauf von 2 Stunden 50 Minuten waren alle drei Tentakeln gut eingebogen. Jede dieser Drüsen konnte nur \frac {1}{28800} Gran oder 0,00225 Milligr. erhalten haben. Ein kleiner Tropfen von der nämlichen Grösze und Stärke wurde auch auf vier andere Drüsen verwandt, und in einer Stunde waren zwei eingebogen, während die andern beiden sich niemals bewegten. Wir sehen hier wie in dem Falle, wo die halben Minims auf die Scheibe gebracht wurden, dasz das salpetersaure Ammoniak wirksamer ist, Einbiegung zu verursachen, als das kohlensaure; denn äuszerst kleine Tropfen des letztern Salzes von dieser Stärke brachten keine Wirkung hervor. Ich versuchte sehr kleine Tropfen einer noch schwächeren Lösung des salpetersauren Salzes, nämlich ein Theil auf 875 Theile Wasser, bei ein und zwanzig Drüsen; es wurde aber durchaus gar keine Wirkung hervorgebracht vielleicht mit Ausnahme eines Falles.

# Versuche mit verschiedenen Lösungen

Drei und sechzig Blätter wurden in Lösungen verschiedener Stärkegrade eingetaucht; während andere Blätter zu derselben Zeit in dasselbe reine Wasser gelegt wurden, was zur Anfertigung der Lösungen benutzt wurde. Die Resultate sind so merkwürdig, obschon weniger merkwürdig als die mit phosphorsaurem Ammoniak erhaltenen, dasz ich die Versuche im Einzelnen beschreiben musz; doch will ich nur einige wenige anführen. Wenn ich von den aufeinanderfolgenden Perioden spreche, in denen Einbiegung eintrat, so rechne ich immer von der Zeit der ersten Eintauchung an.

# Beobachtungen nach Eintauchung

Nachdem ich einige vorläufige Experimente zur Orientirung ange-
stellt hatte, wurden fünf Blätter in einem und demselben kleinen Gefäsz in dreiszig Minims einer Lösung von einem Theile des salpetersauren Salzes in 7875 Theilen Wasser (1 Gran auf 18 Unzen) gelegt; diese Menge Flüssigkeit war gerade hinreichend sie zu bedecken. Nach 2 Stunden 10 Minuten waren drei der Blätter beträchtlich eingebogen und die andern beiden mäszig. Die Drüsen aller waren so dunkel roth geworden, dasz sie beinahe verdienten, schwarz genannt zu werden. Nach 8 Stunden waren bei vier von den Blättern alle Tentakeln mehr oder weniger eingebogen, während am fünften, welches, wie ich jetzt bemerkte, ein altes Blatt war, nur dreiszig Tentakeln eingebogen waren. Am nächsten Morgen, nach 23 Stunden 40 Minuten, fanden sich sämmtliche Blätter in demselben Zustande, ausgenommen, dasz bei dem alten Blatte einige wenige Tentakeln mehr eingebogen waren.# Experimentelle Beobachtungen

nämlichen Zeit in Wasser gelegt worden waren, wurden in denselben Zeit-
zwischenräumen beobachtet; nach 2 Stunden 10 Minuten waren bei zwei
von ihnen vier, bei einem sieben, bei einem zehn der langköpfigen, rand-
ständigen Tentakeln und beim fünften vier rundköpfige Tentakeln einge-
bogen. Nach 8 Stunden war keine Veränderung an diesen Blättern sicht-
bar, und nach 24 Stunden waren alle randständigen Teutakeln wieder
ausgebreitet, bei einem Blatte aber war ein Dutzend und bei einem zwei-
ten Blatte ein halbes Dutzend submarginaler Tentakeln eingebogen. Da
die Drüsen der fünf Blätter in der Lösung gleichzeitig dunkel geworden
waren, so hatten sie alle ohne Zweifel eine nahezu gleiche Menge von
dem Salze aufgesaugt; und da allen fünf Blättern zusammen \frac {1}{288} Gran
gegeben worden war, so erhielt ein jedes \frac {1}{1440} Gran (0,045 Milligr.).

# Tentakeln und ihre Reaktion

Ich
habe die Tentakeln an diesen Blättern nicht gezählt, welche mäszig schöne
waren; da aber die mittlere Zahl bei ein und dreiszig Blättern 192 war,
so dürfte es sicher sein anzunehmen, dasz jedes im Mittel mindestens 160
trug. War dies der Fall, so konnte jede der dunkel gewordenen Drüsen
nur \frac {1}{230400} Gran des salpetersauren Salzes erhalten haben; und dies
verursachte die Einbiegung einer groszen Anzahl von Tentakeln.
Diese Methode, mehrere Blätter in ein und dasselbe Gefäsz zu bringen,
ist keine gute, da man dabei unmöglich sicher sein kann, ob nicht die
kräftigeren Blätter den schwächeren ihren Antheil am Salze rauben.

# Fehlerquellen und weitere Experimente

Überdies müssen die Drüsen häufig einander oder die Gefäszwände berüh-
ren, und dadurch kann Bewegung angeregt werden; aber die entsprechen-
den Blätter in Wasser, welche wenig eingebogen wurden, obschon eher
mehr als gewöhnlich vorkömmt, waren denselben Fehlerquellen in einem
beinahe gleichen Grade ausgesetzt. Ich will daher nur noch ein weiteres,
nach dieser Methode angestelltes Experiment anführen, obschon viele an-
Drosera rotundifolia. Cap. 7.
gestellt wurden, und alle die vorstehend erwähnten und die folgenden
Resultate bestätigten. Vier Blätter wurden in vierzig Minims einer Lösung
von einem Theile in 10500 Theilen Wasser gelegt; und angenommen sie
absorbirten gleichmäszig, so erhielt jedes Blatt \frac {1}{1152} Gran (0,0562
Milligr.).

# Zeitliche Entwicklung der Tentakeln

Nach 1 Stunde 20 Minuten waren viele der Tentakeln an allen vier
Blättern etwas eingebogen. Nach 5 Stunden 30 Minuten waren bei zwei
Blättern alle Tentakeln eingebogen, bei einem dritten Blatt sämmtliche,
ausgenommen die äussersten randständigen, welche alt und torpid zu sein
schienen, und bei den vierten eine grosze Zahl. Nach 21 Stunden war
jeder einzelne Tentakel an allen vier Blättern dicht eingebogen. Bei den
vier zu der nämlichen Zeit in Wasser gelegten Blättern waren nach 5
Stunden 45 Minuten an einem fünf randständige Tentakeln eingebogen,
bei einem zweiten zehn, bei einem dritten neun marginale und submar-
ginale, und beim vierten zwölf, hauptsächlich submarginale. Nach 21
Stunden breiteten sich alle diese randständigen Tentakeln wieder aus,
einige wenige der submarginalen an zweien von den Blättern blieben in-
dessen unbedeutend einwärts gekrümmt.

# Vergleich der Ergebnisse

Der Contrast zwischen diesen
vier Blättern in Wasser und denen in der Lösung war wunderbar grosz;
bei den letzteren war jeder einzelne ihrer Tentakeln dicht eingebogen.
Macht man die mäszige Annahme, dasz jedes dieser Blätter 160 Tentakeln
trug, so kann jede Drüse nur \frac {1}{184320} Gran (0,000351 Milligr.)
absorbirt
haben. Dieses Experiment wurde an drei Blättern mit derselben relativen
Menge der Lösung wiederholt; und nach 6 Stunden 15 Minuten waren
sämmtliche Tentakeln, mit Ausnahme von neun von allen drei Blättern
zusammengenommen, dicht eingebogen. In diesem Falle wurden die Ten-
takeln an jedem Blatte gezählt und ergaben ein Mittel von 162 pro Blatt.

# Sommerexperimente 1873

Die folgenden Versuche wurden während des Sommers 1873 ange-
stellt, und zwar so, dasz die Blätter jedes in ein besonderes Uhrglas ge-
legt und dreiszig Minims (1,775 Cub. Cent.) der Lösung darüber gegossen
wurden; andere Blätter wurden in ganz genau derselben Manier mit dem
doppelt destillirten Wasser behandelt, welches beim Anfertigen der Lösun-
gen benutzt wurde. Die oben mitgetheilten Versuche waren mehrere Jahre
vorher angestellt worden, und als ich meine Notizen durchsah, konnte# Einleitung
ich nicht an die Resultate glauben; ich entschlosz mich daher, nochmals mit mäszig starken Lösungen anzufangen.

# Experimentelle Methode
Zuerst wurden sechs Blätter, und zwar ein jedes in dreiszig Minims einer Lösung von einem Theil des salpetersauren Salzes in 8750 Theilen Wasser (1 Gran auf 20 Unzen) gethan, so dasz jedes \frac {1}{320} Gran (0,2025 Milligr.) erhielt.

# Beobachtungen nach 30 Minuten
Vor Verlauf von 30 Minuten waren vier dieser Blätter ungeheuer und zwei von ihnen mäszig eingebogen. Die Drüsen waren dunkelroth geworden.

# Langzeitbeobachtungen
Die vier entsprechenden Blätter in Wasser wurden vor Ablauf von 6 Stunden durchaus gar nicht afficirt, und dann nur die kurzen Tentakeln an den Rändern der Scheibe; ihre Einbiegung ist, wie früher erklärt wurde, niemals von irgendwelcher Bedeutung.

# Weitere Versuche mit unterschiedlichen Lösungen
Vier Blätter wurden ein jedes in dreiszig Minims einer Lösung von einem Theile auf 17500 Theile Wasser (1 Gran auf 40 Unzen) einge-taucht, so dasz jedes \frac {1}{640} Gran (0,101 Milligr.) erhielt; in weniger als 45 Minuten waren bei dreien von ihnen sämmtliche Tentakeln, mit Aus-nahme von vier bis zehn, eingebogen; die Scheibe eines Blattes war nach Cap. 7. Salpetersaures Ammoniak.

# Ergebnisse nach 6 Stunden
6 Stunden und die Scheibe eines zweiten nach 21 Stunden eingebogen. Das vierte Blatt war durchaus gar nicht afficirt. Die Drüsen waren an keinem dunkel geworden.

# Wasserbeobachtungen
Was die entsprechenden Blätter in Wasser be-trifft, so waren nur bei einem ein paar seiner äuszern Tentakeln, näm-lich fünf, eingebogen; die kurzen Tentakeln an den Rändern der Scheibe bildeten in der gewöhnlichen Art und Weise in einem Falle nach 6 Stun-den und in zwei Fällen nach 21 Stunden einen Ring.

# Weitere Versuche mit verdünnten Lösungen
Vier Blätter wurde jedes in dreiszig Minims einer Lösung von einem Theil auf 43750 Theile Wasser (1 Gran auf 100 Unzen) eingetaucht, so dasz jedes Blatt \frac {1}{1600} Gran (0,0405 Milligr.) erhielt.

# Schnelle Reaktionen
Von diesen war eines in 8 Minuten bedeutend eingebogen und nach 2 Stunden 7 Minuten waren alle seine Tentakeln, mit Ausnahme von dreizehn gleichfalls ein-gebogen.

# Langsame Reaktionen
Beim zweiten Blatt waren nach 10 Minuten sämmtliche Tentakeln mit Ausnahme dreier eingebogen. Das dritte und vierte waren kaum überhaupt afficirt, kaum mehr als die entsprechenden Blätter in Wasser.

# Absorptionsergebnisse
An dem Blatt, an welchem sämmtliche Tentakeln mit Ausnahme von dreien in 10 Minu-ten eingebogen waren, konnte jede Drüse (angenommen, dasz das Blatt 160 Tentakeln trug) nur \frac {1}{251200} Gran oder 0,000258 Milligr. absorbirt haben.

# Letzte Versuche
Vier Blätter wurden wie früher einzeln in eine Lösung von einem Theil auf 131250 Theile Wasser (1 Gran auf 300 Unzen gethan, so dasz ein jedes \frac {1}{4800} Gran oder 0,0135 Milligr. erhielt.

# Zusammenfassung der Ergebnisse
Nach 50 Minuten waren an einem Blatte alle Tentakeln mit Ausnahme von sechzehn und nach 8 Stunden 20 Minuten sämmtliche bis auf vierzehn eingebogen.

# Weitere Beobachtungen
Beim zweiten Blatt waren nach 40 Minuten alle Tentakeln bis auf zwanzig eingebogen, und nach 8 Stunden 10 Minuten fieng es an, sich wieder auszubreiten.

# Reaktionen über Zeit
Beim dritten war in 3 Stunden ungefähr die Hälfte der Tentakeln eingebogen, welche sich nach 8 Stunden 15 Minuten wieder auszustrecken begannen.

# Schlussfolgerungen
Es ist offenbar, dasz zufällig sehr empfindliche Blätter ausgelesen worden waren. Überdies war der Tag heisz.# Einleitung
sauren Salzes zu sein, welche hinreicht, die Einbiegung eines einzelnen Tentakels zu veranlassen.

# Negative Resultate
Da negative Resultate von Bedeutung sind zur Bestätigung der vorstehenden positiven, will ich anführen, dasz von acht Blättern wie früher jedes in dreiszig Minims einer Lösung von einem Theile auf 175000 Theile Drosera rotundifolia. Cap. 7.

# Zusammenfassung der Resultate mit salpetersaurem Ammoniak
Zusammenfassung der Resultate mit salpetersaurem Ammoniak. — Wenn die Drüsen der Scheibe durch einen halben Minim-Tropfen (0,296 Cub. Cent.), welcher \frac {1}{2400} Gran des salpetersauren Salzes (0,027 Milligr.) enthält, gereizt werden, so übermitteln sie einen motorischen Impuls den äuszern Tentakeln, welcher dieselben sich einwärts zu biegen veranlaszt.

# Phosphorsaures Ammoniak
Phosphorsaures Ammoniak. Dieses Salz ist kraftvoller als das salpetersaure Ammoniak und selbst in einem noch gröszeren Verhältnisse als das salpetersaure Salz schon kräftiger als das kohlensaure ist.

# Experimentelle Methodik
Im Jahre 1872 experimentirte ich Cap. 7. Phosphorsaures Ammoniak an zwölf eingetauchten Blättern, wobei ich jedem nur zehn Minims einer Lösung gab; dies war aber eine schlechte Methode, denn eine so kleine Quantität bedeckte sie kaum.

# Reflexion über die Experimente
Als ich im Jahre 1873 meine Notizen durchlas, glaubte ich sie durchaus nicht und beschlosz eine andere Reihe von Versuchen mit scrupulöser Sorgfalt nach derselben Methode anzustellen, wie ich die mit dem salpetersauren Salz ausgeführt hatte.# Experimente mit phosphorsauren Salzen

derum, dasz irgend ein Irrthum untergelaufen sein müsse, und es
wurden nochmals fünfunddreiszig frische Versuche mit den schwäch-
sten Lösungen angestellt; die Resultate waren aber ebenso deutlich
ausgesprochen wie vorher. Alles zusammengenommen, wurden an 106
sorgfältig ausgewählten Blättern Versuche gemacht und zwar sowohl
in Wasser als auch in Lösungen des phosphorsauren Salzes. Ich kann
daher nach der peinlichsten Betrachtung keinen Zweifel an der sub-
stantiellen Genauigkeit meiner Resultate hegen.

# Vorbereitungen und Materialien

Ehe ich meine Experimente mittheile, dürfte es gut sein, vorauszu-
schicken, dasz krystallisirtes phosphorsaures Ammoniak, solches, wie ich
benutzte, 35,33 Procent Krystallisationswasser enthält, so dasz in allen
folgenden Versuchen die wirksamen Elemente nur 64,67 Procent des an-
gewandten Salzes bildeten.

# Durchführung der Experimente

Äuszerst minutiöse Stückchen des trocknen phosphorsauren Salzes
wurden mittelst einer Nadelspitze auf das mehrere Drüsen umgebende
Secret gelegt. Diese ergoszen viel Absonderung, wurden geschwärzt und
starben schlieszlich ab, aber die Tentakeln bewegten sich nur unbedeu-
tend. So klein auch die Dose war, so war sie doch offenbar zu grosz,
und das Resultat war dasselbe wie mit Stückchen kohlensauren Ammoniaks.

# Ergebnisse der Versuche

Halbe Minims einer Lösung von einem Theile auf 437 Theile Wasser
wurden auf die Scheiben von drei Blättern gebracht und wirkten äuszerst
energisch; sie verursachten, dasz die Tentakeln des einen in 15 Minuten
eingebogen wurden und dasz sich die Scheiben aller drei in 2 Stunden
15 Minuten bedeutend einwärts krümmten. Ähnliche Tropfen einer Lösung
von einem Theile auf 1312 Theile Wasser (1 Gran auf 3 Unzen) wurden
dann auf die Scheiben von fünf Blättern gelegt, so dasz ein jedes \frac {1}
{2880}
Gran (0,0225 Milligr.) erhielt. Nach 8 Stunden waren die Tentakeln von
vieren beträchtlich eingebogen und nach 24 Stunden die Scheiben von
dreien. Nach 48 Stunden waren alle fünf beinahe wieder ausgebreitet.

# Beobachtungen und Schlussfolgerungen

In Bezug auf eines dieser Blätter will ich erwähnen, dasz während der
vorhergehenden 24 Stunden ein Tropfen Wasser auf seiner Scheibe ge-
lassen worden war, aber keine Wirkung hervorbrachte, und dasz es kaum
trocken war, als die Lösung hinzugebracht wurde. Ähnliche Tropfen einer Lösung
von einem Theil auf 1750 Theile Wasser (1 Gran auf 4 Unzen) wurden dann auf die Scheiben von sechs
Blättern gebracht, so dasz jedes \frac {1}{3840} Gran (0,0169 Milligr.) erhielt; nach 8 Stunden waren bei drei derselben viele Tentakeln und auch die
Scheiben eingebogen; bei zwei andern waren nur einige wenige Tentakeln
unbedeutend eingebogen, und das sechste war durchaus gar nicht afficirt.

# Wirkung der Konzentration

Nach 24 Stunden waren bei den meisten Blättern einige wenige Tentakeln
mehr eingebogen, eines hatte aber angefangen, sich wieder auszubreiten.
Wir sehen hieraus, dasz bei den empfindlicheren Blättern \frac {1}{3840} Gran,
von
den centralen Drüsen absorbirt, hinreicht, viele der äuszern Tentakeln
und die Scheiben zum Biegen zu veranlassen, während \frac {1}{1920} Gran des
kohlensauren Salzes in ähnlicher Weise gegeben, keine Wirkung hervor-
rief; und \frac {1}{2880} Gran des salpetersauren Salzes war nur gerade
hinreichend,
eine ordentlich ausgesprochene Wirkung hervorzubringen.

# Minimaldosen und deren Effekte

Ein äuszerst kleiner Tropfen (ungefähr gleich \frac {1}{20} Minim) einer Lö-
sung von einem Theile des Phosphats auf 875 Theile Wasser wurde der
Absonderung an drei Drüsen zugefügt, von denen hienach eine jede nur
\frac {1}{57600} Gran (0,00112 Milligr.) erhielt; und alle drei Tentakeln wurden
eingebogen. Ähnliche Tropfen einer Lösung von einem Theile in 1312
Theilen Wasser (1 Gran auf 3 Unzen) wurden nun an drei Blättern pro-
birt, wobei ein Tropfen auf vier Drüsen eines und desselben Blattes ver-
theilt wurde. Am ersten Blatte wurden drei der Tentakeln in 6 Minuten
unbedeutend eingebogen und breiteten sich nach 8 Stunden 45 Minuten
wieder aus. Am zweiten wurden zwei Tentakeln in 12 Minuten halb
eingebogen, und am dritten waren in 12 Minuten alle vier Tentakeln
entschieden eingebogen; sie blieben 8 Stunden 30 Minuten lang so, waren
aber am nächsten Morgen wieder vollständig ausgebreitet. In diesem# Experimentelle Ergebnisse

letzteren Falle konnte jede Drüse nur \frac {1}{115200} Gran (oder 0,000563 Milligr.) erhalten haben. Endlich wurden ähnliche Tropfen einer Lösung von einem Theile auf 1750 Theile Wasser (1 Gran auf 4 Unzen) an fünf Blättern versucht, wobei ein Tropfen auf vier Drüsen eines und desselben Blattes verwandt wurde. Die Tentakeln an dreien dieser Blätter wurden nicht im mindesten afficirt; am vierten Blatt wurden zwei eingebogen, während am fünften, welches zufällig ein sehr empfindliches war, alle vier Tentakeln in 6 Stunden 15 Minuten deutlich eingebogen waren, aber nur einer blieb nach 24 Stunden noch eingebogen. Ich musz indessen bemerken, dasz in diesem Falle ein ungewöhnlich groszer Tropfen am Stecknadelknopf hieng. Jede dieser Drüsen konnte sehr wenig mehr als \frac {1}{153600} Gran (oder 0,000423 Milligr.) erhalten haben; aber diese kleine Quantität reichte hin, Einbiegung zu verursachen. Wir müssen im Auge behalten, dasz diese Tropfen nur 10 bis 15 Secunden lang an das klebrige Secret gehalten wurden, und haben zur Annahme gute Gründe, dasz alles phosphorsaures Salz in der Lösung in dieser Zeit nicht diffundirt und absor-birt sein wird. Wir haben unter denselben Umständen gesehen, dasz die Absorption von \frac {1}{19200} Gran des kohlensauren und von \frac {1}{57600} Gran des salpetersauren Salzes durch eine Drüse den die in Frage stehende Drüse tragenden Tentakel nicht zur Einbiegung veranlaszte; es ist mithin hier wiederum das phosphorsaure wirkungsvoller als die andern beide Salze.

# Versuche mit eingetauchten Blättern

Wir wollen uns nun zu den 106 Versuchen mit eingetauchten Blättern wenden. Nachdem ich durch wiederholte Versuche ermittelt hatte, dasz mäszig starke Lösungen in hohem Grade wirksam seien, begann ich mit sechzehn Blättern, von denen ein jedes in dreiszig Minims einer Lösung von einem Theile auf 43750 Wasser (1 Gran auf 100 Unzen) gelegt wurde, so dasz jedes \frac {1}{1600} Gran oder 0,04058 Milligr. erhielt. Von diesen Blättern waren bei elf nahezu alle oder eine grosze Anzahl ihrer Tentakeln in 1 Stunde und beim zwölften Blatt in 3 Stunden eingebogen. Zwei Blätter von den sechzehn waren nur mäszig afficirt, aber doch mehr als irgend eines der gleichzeitig in Wasser eingetauchten, und die übrigen zwei, welches blasze Blätter waren, wurden fast gar nicht afficirt. Von den sechzehn entsprechenden Blättern in Wasser waren bei einem neun Tentakeln, bei einem andern sechs und bei zwei andern zwei Tentakeln im Laufe von 5 Stunden eingebogen. Es war daher der Contrast im Ansehen zwischen den beiden Gruppen äuszerst grosz.

# Weitere Experimente

Achtzehn Blätter wurden jedes in dreiszig Minims einer Lösung von einem Theile in 87500 Theilen Wasser (1 Gran auf 200 Unzen) einge-taucht, so dasz jedes \frac {1}{3200} Gran (0,0202 Milligr.) erhielt. Vierzehn derselben waren innerhalb 2 Stunden stark eingebogen und einige von ihnen in 15 Minuten; drei unter den achtzehn waren nur unbedeutend afficirt, da nur einundzwanzig, neunzehn und zwölf Tentakeln eingebogen waren; und auf eines wirkte die Lösung durchaus gar nicht. Durch einen Zu-fall wurden nur fünfzehn, anstatt achtzehn Blätter zu derselben Zeit in Wasser eingetaucht; diese wurden 24 Stunden lang beobachtet; bei einem waren sechs, bei einem andern vier, bei einem dritten zwei ihrer äusze-ren Tentakeln eingebogen; die übrigen blieben völlig unafficirt.

# Optimale Bedingungen für Experimente

Das nächste Experiment wurde unter sehr günstigen Umständen an-stellt, denn der Tag (8. Juli) war sehr warm, und ich hatte zufällig ungewöhnlich schöne Blätter. Fünf wurden wie vorher in eine Lösung von einem Theil auf 131250 Theile Wasser (1 Gran auf 300 Unzen) eingetaucht, so dasz jedes \frac {1}{4800} Gran oder 0,0135 Milligr. erhielt. Nach einem Eintauchen von 25 Minuten waren alle fünf Blätter bedeutend ein-biegen. Nach 1 Stunde 25 Minuten waren bei einem Blatte alle Tentakeln bis auf acht eingebogen; beim zweiten alle bis auf drei; beim dritten alle bis auf fünf, beim vierten alle bis auf dreiundzwanzig; andererseits waren beim fünften niemals mehr als vierundzwanzig einge-# Experimentelle Beobachtungen

Bogen. Von den entsprechenden fünf Blättern in Wasser waren bei einem sieben, beim zweiten zwei, beim dritten zehn, beim vierten einer und beim fünften kein einziger Tentakel eingebogen. Man beachte wohl, welchen Contrast diese letztern Blätter gegen diejenigen in der Lösung darbieten. Ich zählte die Drüsen am zweiten Blatt in der Lösung, die Zahl betrug 217; angenommen, dasz die drei Tentakeln, welche nicht eingebogen wurden, nichts absorbirten, finden wir, dasz jede der übrig bleibenden 214 Drüsen nur \frac {1}{1027200} Gran oder 0,0000631 Milligr. absorbirt haben konnte. Das dritte Blatt trug 236 Drüsen, und zieht man die fünf ab, deren Tentakeln nicht eingebogen wurden, so konnte jede der übrig bleibenden 231 Drüsen nur \frac {1}{1108800} Gran oder 0,0000584 Milligr. absor- birt haben, und diese Menge genügte die Biegung der Tentakeln zu verursachen.

# Versuchsreihe und Ergebnisse

Zwölf Blätter wurden wie vorher in einer Lösung von einem Theile auf 175000 Theils Wasser (1 Gran auf 400 Unzen) versucht, so dasz jedes Blatt \frac {1}{6400} Gran oder 0,0101 Milligr. erhielt. Meine Pflanzen fanden sich zu dieser Zelt in keinem guten Zustande, und viele Blätter waren jung und blasz. Nichtsdestoweniger waren bei zweien von ihnen sämmtliche Tentakeln, ausgenommen drei oder vier, in weniger als 1 Stunde dicht eingebogen. Sieben waren beträchtlich afficirt, einige innerhalb 1 Stunde und andere nicht eher bis 3 Stunden, 4 Stunden 30 Minuten und 8 Stunden verlaufen waren; diese langsame Wirkung kann man dem Umstande zuschreiben, dasz die Blätter jung und blasz waren. Von diesen neun Blättern waren bei vieren die Scheiben wohl eingebogen, bei einem fünften in einem unbedeutenden Grade. Die drei übrigen Blätter wurden nicht afficirt. In Bezug auf die zwölf entsprechenden Blätter in Wasser ist zu erwähnen, dasz nicht bei einem die Scheibe eingebogen war; nach Verlauf von 1 bis 2 Stunden waren bei einem dreizehn der äuszeren Tentakeln eingebogen, bei einem zweiten sechs, und bei vier andern entweder einer oder zwei. Nach 8 Stunden wurden die äuszern Tentakeln nicht weiter eingebogen, während dies bei den Blättern in der Lösung eintrat. Ich bemerke in meinen Niederschriften, dasz es nach 8 Stunden unmög- lich war, die beiden Gruppen zu vergleichen und auch nur für einen Augenblick an der Wirkung der Lösung zu zweifeln.

# Weitere Versuche und Beobachtungen

Bei zwei der obigen Blätter in der Lösung waren sämmtliche Tentakeln, ausgenommen drei oder vier, innerhalb einer Stunde eingebogen. Ich zählte ihre Drüsen, und nach dem früher angewandten Grundsatze konnte jede einzelne Drüse an dem einen Blatte nur \frac {1}{1164800} Gran und an dem andern Blatte nur \frac {1}{1472000} Gran des phosphorsauren Salzes erhalten haben. Zwanzig Blätter wurden in der gewöhnlichen Weise jedes in dreiszig Minims einer Lösung von einem Theile in 218750 Theilen Wasser (1 Gran auf 500 Unzen) eingetaucht. Es wurden so viele Blätter zu Versuchen genommen, weil ich damals mich unter dem irrigen Eindrucke befand, dasz es unglaublich sei, dasz eine irgend noch schwächere Lösung eine Wir- kung hervorbringen könne. Jedes Blatt erhielt \frac {1}{8000} Gran oder 0,0081 Milligr. Die ersten acht Blätter, welche ich versuchte, und zwar in der Lösung und in Wasser, waren entweder jung und blasz oder zu alt; auch war das Wetter nicht warm. Sie wurden kaum überhaupt afficirt; nichts destoweniger wäre es unbillig, sie auszuschlieszen. Ich wartete dann, bis ich acht Paare schöner Blätter erhielt und das Wetter günstig war; die Temperatur des Zimmers, wo die Blätter eingetaucht wurden, schwankte von 23,8° bis 27,2° C. (75° bis 81° F.) Bei einem andern Versuche mit vier Paaren (die in den oben genannten zwanzig Paaren eingeschlossen sind) war die Temperatur in meinem Zimmer ziemlich niedrig, ungefähr 15,5° C. (60° F.); die Pflanzen waren aber mehrere Tage lang in einem sehr warmen Gewächshause gehalten worden und waren dadurch äuszerst empfindlich geworden. Es wurden für diese Reihe von Experimenten spezielle Vorsichtsmaszregeln getroffen; ein Chemiker wog mir auf einer ausgezeichneten Wage einen Gran ab; und frisches, mir von Professor Frank- land gegebenes Wasser wurde sorgfältig abgemessen. Die Blätter wurden# Einleitung

von einer groszen Anzahl von Pflanzen in der folgenden Weise ausge-
wählt: die vier schönsten wurden in Wasser eingetaucht und die vier
nächst schönsten in die Lösung, und sofort bis die zwanzig Paare voll-
zählig waren. Die Exemplare im Wasser wurden dabei ein wenig be-
günstigt, sie erlitten aber nicht mehr Einbiegung als in den früheren
Fällen im Vergleich mit den Blättern in der Lösung.

# Ergebnisse der Experimente

Von den zwanzig Blättern in der Lösung wurden elf innerhalb
40 Minuten eingebogen, acht von ihnen deutlich und drei etwas zweifel-
haft; doch waren an den letztern mindestens zwanzig ihrer äuszern Ten-
takeln eingebogen. In Folge der Schwäche der Lösung trat die Einbie-
gung, mit Ausnahme von Nr. 1, viel langsamer ein als in den voraus-
gehenden Versuchen. Den Zustand der elf Blätter, welche beträchtlich
eingebogen waren, will ich nun für bestimmte Zeitintervalle mittheilen,
immer von der Zeit des Eintauchens an rechnend: —

## Blatt 1

Nach nur 8 Minuten war eine grosze Anzahl von Tentakeln ein-
gebogen und nach 17 Minuten sämmtliche bis auf fünfzehn; nach 2 Stun-
den waren alle bis auf acht eingebogen oder deutlich halb eingebogen.
Nach 4 Stunden fiengen die Tentakeln an, sich wieder auszustrecken, und
eine so schnelle Wiederausstreckung ist ungewöhnlich; nach 7 Stunden
30 Minuten waren sie beinahe völlig wieder ausgebreitet.

## Blatt 2

Nach 39 Minuten war eine grosze Zahl Tentakeln eingebogen,
nach 2 Stunden 18 Minuten alle bis auf fünfundzwanzig; nach 4 Stunden
17 Minuten waren alle bis auf sechzehn eingebogen. Das Blatt blieb
viele Stunden lang in diesem Zustande.

## Blatt 3

Nach 12 Minuten fand sich ein beträchtlicher Grad von Ein-
biegung; nach 4 Stunden waren alle Tentakeln eingebogen mit Aus-
nahme derer der zwei äuszeren Reihen, und in diesem Zustande blieb
das Blatt einige Zeit lang; nach 23 Stunden fieng es an, sich wieder
auszubreiten.

## Blatt 4

Nach 40 Minuten war bedeutende Einbiegung vorhanden; nach
4 Stunden 13 Minuten war reichlich die Hälfte der Tentakeln einge-
bogen; nach 23 Stunden war es noch immer unbedeutend eingebogen.

## Blatt 5

Nach 40 Minuten war bedeutende Einbieguung vorhanden; nach
4 Stunden 22 Minuten war reichlich die Hälfte der Tentakeln einge-
bogen; nach 23 Stunden war es noch immer unbedeutend eingebogen.

## Blatt 6

Nach 40 Minuten trat etwas Einbiegung ein; nach 2 Stunden
18 Minuten waren ungefähr achtundzwanzig äuszere Tentakeln einge-
bogen; nach 5 Stunden 20 Minuten war ungefähr ein Drittel der Ten-
takeln eingebogen; nach 8 Stunden war die Wiederausstreckung bedeutend
vorgeschritten.

## Blatt 7

Nach 20 Minuten trat etwas Einbiegung ein; nach 2 Stunden
wurde eine beträchtliche Anzahl von Tentakeln eingebogen; nach 7 Stun-
den 45 Minuten fiengen sie an, sich wieder auszustrecken.

## Blatt 8

Nach 38 Minuten waren achtundzwanzig Tentakeln eingebogen,
nach 3 Stunden 45 Minuten waren dreiunddreiszig eingebogen, dabei
waren die meisten der submarginalen Tentakeln halb eingebogen; dies
dauerte zwei Tage lang so fort und dann streckten sie sich theilweise
wieder aus.

## Blatt 9

Nach 38 Minuten waren zweiundvierzig Tentakeln eingebogen;
nach 3 Stunden 12 Minuten sechsundsechzig eingebogen oder halb ein-
gebogen, nach 6 Stunden 40 Minuten alle bis auf vierundzwanzig einge-
bogen oder halb eingebogen; nach 9 Stunden 40 Minuten alle bis auf
siebenzehn eingebogen, nach 24 Stunden alle bis auf vier eingebogen oder
halb eingebogen, nur einige wenige waren dicht eingebogen; nach 27 Stun-
den bog sich die Blattscheibe ein. Das Blatt blieb zwei Tage lang in
diesem Zustande und fieng dann an, sich wieder auszubreiten.

## Blatt 10

Nach 38 Minuten waren einundzwanzig Tentakeln eingebogen;
nach 3 Stunden 12 Minuten sechsundvierzig Tentakeln eingebogen oder
halb eingebogen; nach 6 Stunden 40 Minuten waren alle bis auf sieben-
zehn eingebogen, obschon keiner dicht; nach 24 Stunden war jeder Ten-
takel leicht nach innen gekrümmt; nach 27 Stunden 40 Minuten war
die Blattscheibe stark eingebogen und blieb es zwei Tage lang; dann brei-
teten sich die Tentakeln und die Scheibe sehr langsam wieder aus.# Beobachtungen an Blättern

11. Dieses schöne dunkel rothe und eher alte Blatt trug, obschon es nicht sehr grosz war, eine auszerordentlich grosze Zahl von Tentakeln (nämlich 252) und benahm sich auch in einer anomalen Art und Weise. Nach 6 Stunden 40 Minuten waren nur die kurzen Tentakeln rund um den äuszeren Theil der Scheibe eingebogen und bildeten einen Ring, wie es innerhalb 8 bis 24 Stunden sowohl bei Blättern in Wasser als bei solchen in den schwächeren Lösungen so häufig vorkommt. Nach 9 Stunden 40 Minuten aber waren sämmtliche äuszeren Tentakeln, mit Ausnahme von fünfundzwanzig eingebogen, wie es auch in einer stark ausgesproche- nen Art und Weise die Blattscheibe war. Nach 24 Stunden war ein jeder Tentakel, mit Ausnahme eines, dicht eingebogen und die Scheibe war vollständig übereinander gefaltet. So blieb das Blatt zwei Tage lang, wo es dann sich wieder auszubreiten anfieng. Ich will noch hinzu- fügen, dasz die drei letzten Blätter (Nr. 9, 10 und 11) nach drei Tagen noch immer etwas eingebogen waren. Die Tentakeln wurden nur bei wenigen unter diesen elf Blättern innerhalb einer so kurzen Zeit dicht eingebogen, wie es in den vorausgehenden Versuchen mit stärkeren Lö- sungen der Fall war.

# Vergleich der Blätter in Wasser und Lösung

Wir wollen uns nun zu den zwanzig entsprechenden Blättern in Wasser wenden. Bei neun derselben war keiner der äuszeren Tentakeln eingebogen, bei neun anderen waren einer bis drei eingebogen und diese streckten sich nach 8 Stunden wieder aus. Die noch übrigen zwei Blätter wurden mäszig afficirt; bei einem waren in 34 Minuten sechs Tentakeln eingebogen, bei den andern waren dreiundzwanzig in 2 Stunden 12 Mi- nuten eingebogen; beide blieben 24 Stunden lang so. Bei keinem dieser Blätter war die Blattscheibe eingebogen. Es war daher der Contrast zwischen den zwanzig Blättern in Wasser und den zwanzig in der Lösung sehr grosz, sowohl innerhalb der ersten Stunde als auch nach Verlauf von 8 bis 12 Stunden.

# Drüsen und Tentakeln

Von den Blättern in der Lösung wurden die Drüsen am Blatt Nr. 1, bei welchem in 2 Stunden alle Tentakeln mit Ausnahme von acht ein- gebogen waren, gezählt; es ergab sich, dasz es 202 waren. Zieht man die acht davon ab, so kann jede Drüse nur \frac {1}{1552000} Gran (oder 0,0000411 Milligr.) des Phosphats erhalten haben. Das Blatt Nr. 9 hatte 213 Ten- takeln, von denen alle mit Ausnahme von vier nach 24 Stunden einge- bogen waren, wenn auch keiner dicht; auch die Blattscheibe war einge- bogen; jede Drüse kann nur \frac {1}{1672000} Gran oder 0,0000387 Milligr. erhalten haben. Endlich das Blatt Nr. 11, bei welchem nach 24 Stunden sämmtliche Tentakeln mit Ausnahme eines ebenso wie die Blattscheibe dicht eingebogen waren, trug die ungewöhnlich grosze Zahl von 252 Ten- takeln; nach demselben Grundsatz wie früher berechnet, kann eine jede Drüse nur \frac {1}{2008000} Gran oder 0,0000322 Milligr. absorbirt haben.

# Empfindlichkeit der Blätter

Was die folgenden Versuche betrifft, so musz ich vorausschicken, dasz die Blätter, sowohl die, welche in Wasser, als auch die, welche in die Lösungen gelegt wurden, Pflanzen entnommen wurden, welche wäh- rend des Winters in einem sehr warmem Gewächshause gehalten worden waren. Sie waren dadurch äuszerst empfindlich geworden, wie sich daraus zeigt, dasz Wasser sie viel mehr erregte, als es in den vorausgehenden Versuchen der Fall war. Ehe ich meine Beobachtungen mittheile, dürfte es gut sein, den Leser daran zu erinnern, dasz, nach einunddreiszig schönen Blättern zu urtheilen, die mittlere Anzahl der Tentakeln 192 beträgt und dasz die äuszeren oder dem Rande nahen, deren Bewegungen allein von Bedeutung sind, zu den kürzeren auf der Scheibe ungefähr in dem Ver- hältnis von sechzehn zu neun stehen.

# Versuche mit Lösungen

Vier Blätter wurden wie früher ein jedes in dreiszig Minims einer Lösung von einem Theil auf 328125 Theile Wasser (1 Gran auf 750 Unzen) getaucht. Jedes Blatt erhielt danach \frac {1}{12000} Gran (0,0054 Milligr.) von dem Salze; und alle vier wurden bedeutend eingebogen. 1. Nach 1 Stunde waren alle äuszeren Tentakeln bis auf einen ein- gebogen und die Blattscheibe bedeutend; nach 7 Stunden begann das Blatt, sich wieder auszubreiten.# Tentakeln und ihre Einbiegung

## Einbiegung nach Zeitintervallen
2. Nach 1 Stunde waren alle äuszeren Tentakeln bis auf acht ein-
gebogen; nach 12 Stunden streckten sich alle wieder aus.

## Fortschritt der Einbiegung
3. Nach 1 Stunde war die Einbiegung bedeutend; nach 2 Stunden
30 Minuten waren alle Tentakeln bis auf sechsunddreiszig eingebogen;
nach 6 Stunden waren alle bis auf zweiundzwanzig eingebogen; nach
12 Stunden breiteten sie sich zum Theil wieder aus.

## Weitere Beobachtungen
4. Nach 1 Stunde waren alle Tentakeln bis auf zweiunddreiszig ein-
gebogen, nach 2 Stunden 30 Minuten alle bis auf einundzwanzig; nach
6 Stunden waren sie beinahe wieder ausgebreitet.

## Drosera rotundifolia
Von den vier entsprechenden Blättern in Wasser waren bei dem
Drosera rotundifolia. Cap. 7.

## Wirkung der Lösung
1. nach 1 Stunde fünfundvierzig Tentakeln eingebogen; aber nach
7 Stunden hatten sich so viele wieder ausgestreckt, dasz nur zehn stark
eingebogen blieben.

## Tentakeln und ihre Reaktion
2. Nach 1 Stunde waren sieben Tentakeln eingebogen; diese waren
in 6 Stunden beinahe wieder ausgestreckt.

## Unbeeinflusste Tentakeln
3. und 4. waren nicht afficirt, ausgenommen, dasz, wie gewöhnlich,
nach 11 Stunden die Tentakeln an den Rändern der Scheibe einen Ring
bildeten.

## Absorption von Phosphat
Es kann daher über die Wirksamkeit der obigen Lösung kein Zweifel
bestehen; und, wie früher berechnet, folgt aus den Zahlen, dasz jede Drüse
von Nr. 1 nur \frac {1}{2412000} Gran (0,0000268 Milligr.) und jede Drüse von
Nr. 2 nur \frac {1}{2460000} Gran (0,0000263 Milligr.) vom Phosphate absorbirt
haben kann.

## Eintauchen der Blätter
Sieben Blätter wurden jedes in dreiszig Minims einer Lösung von
einem Theile auf 437500 Theile Wasser (1 Gran auf 1000 Unzen) ein-
getaucht. Jedes Blatt erhielt hiernach \frac {1}{16000} Gran (0,00405 Milligr.).

## Günstige Bedingungen
Der Tag war warm und die Blätter waren sehr schön, so dasz alle Um-
stände günstig waren.

## Tentakeln nach 30 Minuten
1. Nach 30 Minuten waren alle äuszeren Tentakeln, ausgenommen
fünf, eingebogen, die meisten von ihnen dicht; nach 1 Stunde war die
Blattscheibe unbedeutend eingebogen; nach 9 Stunden 30 Minuten fiengen
sie an, sich wieder auszubreiten.

## Tentakeln nach 33 Minuten
2. Nach 33 Minuten waren alle äuszeren Tentakeln bis auf fünf-
undzwanzig eingebogen, die Blattscheibe unbedeutend; nach 1 Stunde
30 Minuten war die Scheibe stark eingebogen und blieb 24 Stunden
lang so; aber einige von den Tentakeln hatten sich da schon wieder
ausgestreckt.

## Tentakeln nach 1 Stunde
3. Nach 1 Stunde waren sämmtliche Tentakeln bis auf zwölf ein-
gebogen; nach 2 Stunden 30 Minuten waren alle bis auf neun einge-
bogen, und zwar von den eingebognen Tentakeln alle mit Ausnahme von
vieren dicht, während die Blattscheibe nur unbedeutend eingebogen war.
Nach 8 Stunden war die Scheibe vollständig zusammengefaltet und nun
waren auch alle Tentakeln, mit Ausnahme von acht, dicht eingebogen.
Das Blatt blieb zwei Tage lang in diesem Zustande.

## Tentakeln nach 2 Stunden 20 Minuten
4. Nach 2 Stunden 20 Minuten waren nur neunundfünfzig Tentakeln
eingebogen; nach 5 Stunden waren aber alle Tentakeln dicht eingebogen,
ausgenommen zwei, welche nicht afficirt waren, und elf, welche nur halb
eingebogen waren; nach 7 Stunden war die Blattscheibe beträchtlich
eingebogen; nach 12 Stunden war die Wiederausbreitung bedeutend im
Gange.

## Tentakeln nach 4 Stunden
5. Nach 4 Stunden waren alle Tentakeln bis auf vierzehn einge-
bogen; nach 9 Stunden 30 Minuten Beginn der Wiederausbreitung.

## Tentakeln nach 1 Stunde
6. Nach 1 Stunde waren sechsunddreiszig Tentakeln eingebogen;
nach 5 Stunden waren alle bis auf vierundfünfzig eingebogen; nach
12 Stunden war die Wiederausbreitung beträchtlich.

## Tentakeln nach 4 Stunden 30 Minuten
7. Nach 4 Stunden 30 Minuten waren nur fünfunddreiszig Tentakeln
eingebogen oder halb eingebogen, und dieser geringe Grad von Einbiegung
nahm niemals zu.

## Phosphorsaures Ammoniak
Cap. 7. Phosphorsaures Ammoniak.

## Tentakeln in Wasser
Was nun die sieben entsprechenden Blätter in Wasser betrifft, so
waren bei
1. nach 4 Stunden achtunddreiszig Tentakeln eingebogen; aber nach
7 Stunden breiteten sich dieselben, mit Ausnahme von sechs, wieder aus.# Tentakelbeobachtungen

2. Nach 4 Stunden 20 Minuten waren zwanzig Tentakeln einge- bogen; diese breiteten sich nach 9 Stunden zum Theil wieder aus.
3. Nach 4 Stunden waren fünf Tentakeln eingebogen, welche nach 7 Stunden sich wieder auszustrecken anfiengen.
4. Nach 24 Stunden war ein Tentakel eingebogen.
5., 6. und 7. Waren durchaus gar nicht afficirt, obschon sie 24 Stun- den lang beobachtet wurden, mit Ausnahme der kurzen Tentakeln an den Rändern der Scheibe, welche wie gewöhnlich einen Ring bildeten.

# Wirkung der Lösung

Eine Vergleichung der Blätter in der Lösung, besonders der ersten fünf oder selbst sechs der Liste, mit denen im Wasser nach Verlauf von 1 oder von 4 Stunden und in einem noch schärfer ausgesprochenen Grade nach Verlauf von 7 oder 8 Stunden konnte nicht den geringsten Zweifel beste- hen lassen, dasz die Lösung eine grosze Wirkung hervorgebracht hatte. Dies zeigte sich nicht allein in der ungeheuer viel gröszeren Zahl eingebogner Tentakeln, sondern auch in dem Grade oder der Dichte ihrer Einbiegung ebenso wie in der Einbiegung der Blattscheiben. Und doch kann eine jede Drüse an dem Blatt Nr. 1 (welches 255 Drüsen trug, von denen alle, mit Ausnahme von fünf, in 30 Minuten eingebogen waren) nicht mehr als ein Viermilliontel Gran (0,0000162 Milligr.) des Salzes erhalten haben. Ferner konnte jede Drüse an Blatt Nr. 3 (welches 233 Drüsen trug, von denen alle, ausgenommen neun, in 2 Stunden 30 Minuten ein- gebogen waren) höchstens nur \frac {1}{3584000} Gran oder 0,0000181 Milligr. erhalten haben.

# Vergleich der Blätter

Vier Blätter wurden wie früher in eine Lösung von einem Theile auf 656250 Theile Wasser (1 Gran auf 1500 Unzen) eingetaucht; bei dieser Gelegenheit traf es sich aber zufällig, dasz ich sehr wenig empfind- liche Blätter wählte, wie ich bei andern Gelegenheiten zufällig ungewöhn- lich empfindliche Blätter ausgelesen hatte. Die Blätter waren nach 12 Stunden nicht mehr afficirt als die vier entsprechenden im Wasser; nach 24 Stunden waren sie aber unbedeutend eingebogen. Derartige Be-weise sind indessen durchaus nicht zuverlässig.

# Zustand der Blätter

Zwölf Blätter wurden jedes in dreiszig Minims einer Lösung von einem Theile auf 1,312,500 Theile Wasser (1 Gran auf 3000 Unzen) eingetaucht, so dasz jedes Blatt \frac {1}{48000} Gran (0,00135 Milligr.) erhielt. Die Blätter waren in keinem sehr guten Zustande; vier von ihnen waren zu alt und von einer dunkelrothen Färbung; vier waren zu blasz, doch reagirte eines dieser letztern ganz gut; die vier andern schienen, so viel sich nach dem bloszen Augenschein sagen liesz, in ausgezeichnetem Zu- stande sich zu befinden. Das Resultat war das folgende.

# Ergebnisse der Beobachtungen

1. Dies war ein blasses Blatt; nach 40 Minuten waren ungefähr achtunddreiszig Tentakeln eingebogen; nach 3 Stunden 30 Minuten waren die Scheibe und viele der äuszeren Tentakeln eingebogen; nach 10 Stun- den 15 Minuten waren sämmtliche Tentakeln bis auf siebenzehn einge- bogen und die Blattscheibe ganz zusammengefaltet; nach 24 Stunden waren alle Tentakeln bis auf zehn mehr oder weniger eingebogen. Die meisten derselben waren dicht eingebogen, aber fünfundzwanzig nur halb.
2. Nach 1 Stunde 40 Minuten waren fünfundzwanzig Tentakeln ein- gebogen; nach 6 Stunden alle bis auf einundzwanzig; nach 10 Stunden waren alle bis auf sechzehn mehr oder weniger eingebogen; nach 24 Stun- den waren sie wieder ausgebreitet.
3. Nach 1 Stunde 40 Minuten waren fünfunddreiszig eingebogen; nach 6 Stunden war »eine grosze Anzahl« (um die Worte meines eigenen Notizbuches zu citiren) eingebogen, aus Mangel an Zeit wurden sie aber nicht gezählt; nach 24 Stunden breiteten sie sich wieder aus.
4. Nach 1 Stunde 40 Minuten waren ungefähr dreiszig eingebogen; nach 6 Stunden war »eine grosze Anzahl ganz rings um das Blatt herum« eingebogen, sie wurden aber nicht gezählt; nach 10 Minuten fiengen sie an, sich wieder auszustrecken.
5. bis 12. Diese wurden nicht mehr eingebogen, als es häufig Blätter in Wasser werden, indem bei ihnen beziehentlich 16, 8, 10, 8, 4, 9, 14 und 0 Tentakeln eingebogen wurden. Zwei dieser Blätter waren# Experimentelle Beobachtungen

indessen dadurch merkwürdig, dasz ihre Blattscheiben nach 6 Stunden unbedeutend eingebogen waren. Was die zwölf entsprechenden Blätter in Wasser betrifft, so hatte Nr. 1 nach 1 Stunde 35 Minuten fünfzig Tentakeln eingebogen, nach 11 Stunden blieben aber nur zweiundzwanzig so und diese bildeten eine Gruppe, indem an diesem Punkte die Blattscheibe unbedeutend eingebogen war. Es schien fast so, als wäre das Blatt auf irgend eine Art und Weise zufällig gereizt worden, z. B. durch ein Stückchen thierischer Substanz etwa, welches in Wasser aufgelöst gewesen wäre. 2. Nach 1 Stunde 45 Minuten waren zweiunddreiszig Tentakeln eingebogen, aber nach 5 Stunden 30 Minuten waren nur fünfundzwanzig eingebogen, und diese streckten sich sämmtlich nach 10 Stunden wieder aus; 3. nach 1 Stunde waren fünfundzwanzig Tentakeln eingebogen, welche nach 10 Stunden 20 Minuten sämmtlich wieder ausgestreckt waren; bei 4. und 5. waren nach 1 Stunde 35 Minuten sechs und sieben Tentakeln eingebogen, welche sich nach 11 Stunden wieder ausstreckten; bei 6., 7. und 8. waren von einem bis drei Tentakeln eingebogen, welche sich bald wieder ausstreckten; bei 9., 10., 11. und 12. wurde nichts eingebogen, trotzdem sie vierundzwanzig Stunden lang beobachtet wurden.

# Vergleich der Blätter in Wasser und Lösung

Vergleicht man den Zustand der zwölf Blätter in Wasser mit dem der Blätter in Lösung, so kann darüber kein Zweifel bestehen, dasz bei den letzteren eine gröszere Anzahl von Tentakeln eingebogen waren und zwar auch in einem bedeutenderen Grade; die Beweiskraft dieser Versuche war aber durchaus nicht so klar, wie in den früheren Experimenten mit stärkeren Lösungen. Es verdient Beachtung, dasz die Einbiegung bei vier von den Blättern in der Lösung während der ersten 6 Stunden zuzunehmen fortfuhr, bei einigen von ihnen sogar eine noch längere Zeit, während im Wasser die Einbiegung bei den drei Blättern, welche am stärksten afficirt waren, ebenso wie bei allen übrigen, während der nämlichen Zeitdauer wieder abzunehmen begann. Es ist auch bemerkenswerth, dasz die Blattscheiben von dreien der Blätter in der Lösung unbedeutend eingebogen waren; und dies ist ein äuszerst seltenes Ereignis bei Blättern in Wasser, obschon es in einem unbedeutenden Grade bei einem (Nr. 1) vorkam, welches in irgend einer Art und Weise zufällig gereizt worden zu sein schien. Alles dies zeigt, dasz die Lösung eine Wirkung hervorbrachte, wennschon geringer und viel langsamer als in den vorausgehenden Fällen. Die geringe Wirkung dürfte indessen zum groszen Theil dadurch erklärt werden, dasz die Blätter sich in einem dürftigen Zustande befanden.

# Absorption und Wirkung der Lösung

Von den Blättern in der Lösung trug Nr. 1 200 Drüsen und erhielt \frac {1}{48000} Gran von dem Salze. Zieht man die siebenzehn Tentakeln ab, welche nicht eingebogen wurden, so konnte jede Drüse nur \frac {1}{8784000} Gran oder 0,00000738 Milligr. absorbirt haben. Diese Menge verursachte eine bedeutende Einbiegung des eine jede Drüse tragenden Tentakels. Endlich wurden acht Blätter und zwar jedes in dreiszig Minims einer Lösung von einem Theile des phosphorsauren Salzes auf 21,875,002 Theile Wasser (1 Gran auf 5000 Unzen) eingetaucht. Jedes Blatt erhielt danach \frac {1}{80000} Gran oder 0,00081 Milligr. von dem Salze. Ich gab mir besondere Mühe, die schönsten Blätter aus dem Gewächshause zum Einlegen sowohl in die Lösung als auch in Wasser auszuwählen, und beinahe alle erwiesen sich als äuszerst empfindlich. Ich fange, wie früher, mit denen in der Lösung an:

# Beobachtungen nach Zeitintervallen

1. Nach 2 Stunden 30 Minuten waren alle Tentakeln bis auf zweiundzwanzig eingebogen, einige indessen nur halb eingebogen; die Scheibe war stark eingebogen; nach 6 Stunden 30 Minuten waren alle Tentakeln bis auf dreizehn, die Scheibe ganz ungemein eingebogen; das Blatt blieb so 48 Stunden lang.
2. In den ersten 12 Stunden trat keine Veränderung ein; aber nach 24 Stunden waren sämmtliche Tentakeln eingebogen, ausgenommen diejenigen der alleräuszersten Reihe, von denen nur elf eingebogen waren. Die Einbiegung fuhr fort zuzunehmen und nach 48 Stunden waren alle Tentakeln, ausgenommen drei, eingebogen, und zwar die meisten von ihnen dicht, während vier oder fünf nur halb eingebogen waren.# Beobachtungen der Tentakeln

3. In den ersten 12 Stunden trat keine Veränderung ein; aber nach 24 Stunden waren alle Tentakeln, mit Ausnahme der der alleräuszersten Reihe, halb eingebogen, die Blattscheibe dagegen eingebogen. Nach 36 Stunden war die Scheibe stark eingebogen und sämmtliche Tentakeln, ausgenommen drei, eingebogen oder halb eingebogen. Nach 48 Stunden fand sich das Blatt noch in demselben Zustande.

# Reaktion der Blätter in Wasser

4. bis 8. Bei diesen Blättern waren nach 2 Stunden 30 Minuten beziehentlich 32, 17, 7, 4 und 0 Tentakeln eingebogen, von denen sich die meisten nach wenig Stunden wieder ausstreckten, mit Ausnahme von Nr. 4, welches seine zweiunddreiszig Tentakeln 48 Stunden lang eingebogen behielt. Nun zu den acht entsprechenden Blättern in Wasser: 1. Nach 2 Stunden 40 Minuten waren an diesem Blatte zwanzig der äuszeren Tentakeln eingebogen, von denen fünf sich nach 6 Stunden 30 Minuten wieder ausstreckten. Nach 10 Stunden 15 Minuten trat ein äuszerst ungewöhnlicher Umstand ein, die ganze Blattscheibe nämlich wurde unbedeutend nach dem Stengel zu gebogen und blieb so 48 Stunden lang. Die äuszeren Tentakeln, mit Ausnahme derjenigen von drei oder vier der äuszersten Reihen, waren jetzt gleichfalls in einem ungewöhnlichen Grade eingebogen.

# Vergleich der Gruppen

2. bis 8. Bei diesen Blättern waren nach 2 Stunden 40 Minuten beziehentlich 42, 12, 9, 8, 2, 1 und 0 Tentakeln eingebogen, welche sich sämmtlich innerhalb 24 Stunden wieder ausstreckten, die meisten derselben innerhalb einer viel kürzeren Zeit. Wurden die beiden Gruppen von je acht Blättern in der Losung und in Wasser nach Verlauf von 24 Stunden mit einander verglichen, so wichen sie zweifellos im äuszeren Ansehen bedeutend von einander ab. Die wenigen Tentakeln, welche an den Blättern in Wasser eingebogen waren, hatten sich nach Verlauf dieser Zeit wieder ausgestreckt, mit Ausnahme eines Blattes; und dies bot den sehr ungewöhnlichen Fall dar, dasz die Scheibe etwas eingebogen war, obschon dies in einem Grade eintrat, welcher sich kaum dem näherte, welcher bei den beiden Blättern in der Lösung erreicht wurde. Von diesen letztern Blättern waren bei Nr. 1 beinahe alle ihre Tentakeln zusammen mit der Blattscheibe nach einem Eintauchen von 2 Stunden 30 Minuten eingebogen. Die Blätter Nr. 2 und 3 wurden in einem viel langsameren Verhältnis afficirt; aber nach Verlauf von 24 bis 48 Stunden waren beinahe alle ihre Tentakeln dicht eingebogen und die Scheibe des einen völlig zusammengefaltet.

# Absorption von Phosphat

Wir müssen daher, so unglaublich die Thatsache auf den ersten Blick erscheinen mag, zugeben, dasz diese äuszerst schwache Lösung auf die empfindlicheren Blätter einwirkte; jedes derselben erhielt nur \frac {1}{80000} Gran (0,00081 Milligr.) von dem Phosphate. Nun trug das Blatt Nr. 3 178 Tentakeln; ziehen wir die drei ab, welche nicht eingebogen waren, so kann jede Drüse nur \frac {1}{14000000} Gran oder 0,00000463 Milligr. absorbirt haben. Das Blatt Nr. 1, auf welches die Einwirkung in 2 Stunden 30 Minuten schon stark war und dessen sämmtliche äuszere Tentakeln mit Ausnahme von drei- zehen innerhalb 6 Stunden 30 Minuten eingebogen waren, trug 260 Tentakeln; nach demselben Princip, wie vorher berechnet, konnte jede Drüse nur \frac {1}{19760000} Gran oder 0,00000328 Milligr. absorbirt haben; und diese excessiv minutiöse Menge reicht hin, eine bedeutende Einbiegung aller der, diese Drüsen tragenden Tentakeln zu verursachen. Auch die Blatt- scheibe war eingebogen.

# Zusammenfassung der Resultate

Zusammenfassung der Resultate mit phosphorsau- rem Ammoniak. — Wenn die Drüsen der Blattscheibe durch einen halben Minim-Tropfen (0,0296 Cub. Cent.), welcher \frac {1}{3846} Gran (0,0169 Milligr.) dieses Salzes enthält, gereizt werden, übermitteln sie den äuszeren Tentakeln einen motorischen Impuls, welcher dieselben zum Biegen nach innen veranlaszt. Ein äuszerst kleiner Tropfen, welcher \frac {1}{153600} Gran (0,000432 Milligr.) enthält, verursacht, wenn er wenige Secunden lang mit einer Drüse in Berührung gehalten wird, dasz der diese Drüse tragende Tentakel eingebogen wird. Wenn ein Blatt# Kapitel 7: Andere Ammoniaksalze

## Einleitung
wenige Stunden lang zuweilen sogar eine kürzere Zeit in eine so schwache Lösung eingetaucht wird, dasz jede Drüse nur \frac {1}{19760000} Gran (0,00000328 Milligr.) absorbiren kann, so ist dies doch genug, den Tentakel zur Bewegung anzuregen, so dasz er dicht eingebogen wird, wie es auch zuweilen die Scheibe wird. In der allgemeinen Zusammenfassung dieses Capitels sollen noch einige wenige Bemerkungen hinzugefügt werden, welche zeigen, dasz die Wirksamkeit solcher äuszerst minutiöser Dosen nicht so unglaublich ist, als es auf den ersten Blick erscheinen musz.

## Schwefelsaures Ammoniak
Die wenigen Versuche mit diesem und den folgenden fünf Ammoniaksalzen wurden einfach in der Absicht unternommen, zu ermitteln, ob sie Einbiegung veranlassten. Halbe Minims einer Lösung von einem Theile schwefelsauren Ammoniaks auf 437 Theile Wasser wurden auf die Scheiben von sieben Blättern gelegt, so dasz jedes \frac {1}{960} Gran oder 0,0675 Milligr. erhielt. Nach 1 Stunde waren bei fünf von ihnen die Tentakeln, ebenso wie die Blattscheibe eines, stark eingebogen. Die Blätter wurden später nicht weiter beobachtet.

## Citronensaures Ammoniak
Halbe Minims einer Lösung von einem Theile auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gelegt. In 1 Stunde waren die kurzen äuszeren Tentakeln um die Scheibe herum ein wenig eingebogen, während die Drüsen auf den Scheiben geschwärzt waren. Nach 3 Stunden 25 Minuten war bei einem Blatte die Scheibe eingebogen, aber bei keinem die äuszeren Tentakeln. Alle sechs Blätter blieben während des Tages in nahezu demselben Zustand, indessen wurden die submarginalen Tentakeln etwas mehr eingebogen. Nach 23 Stunden waren bei dreien der Blätter die Scheiben etwas eingebogen, und die submarginalen Tentakeln von allen beträchtlich eingebogen, aber bei keinem waren die zwei, drei oder vier äuszeren Reihen afficirt. Ich habe selten diesem ähnliche Fälle gesehen, ausge- nommen in Folge der Wirkung einer Abkochung von Gras. Die Drüsen auf den Scheiben der obigen Blätter waren, anstatt wie nach der ersten Stunde beinahe schwarz zu sein, nun nach 23 Stunden sehr blasz. Ich versuchte zunächst an vier Blättern halbe Minims einer schwächeren Lösung von einem Theile auf 1312 Theile Wasser (1 Gran auf 3 Unzen), so dasz ein jedes \frac {1}{2880} Gran oder 0,0225 Milligr. erhielt. Nach 2 Stunden 18 Minuten waren die Drüsen auf der Scheibe sehr dunkel gefärbt; nach 24 Stunden waren zwei der Blätter in leichtem Grade afficirt, die andern beiden durchaus gar nicht.

## Essigsaures Ammoniak
Halbe Minims einer Lösung von ungefähr einem Theile auf 109 Theile Wasser wurden auf die Scheiben zweier Blätter gebracht, auf welche in 5 Stunden 30 Minuten eine Einwirkung erfolgte; nach 23 Stunden war jeder einzelne Tentakel dicht eingebogen.

## Oxalsaures Ammoniak
Halbe Minims einer Lösung von einem Theile auf 218 Theile Wasser wurden auf zwei Blätter gebracht, Drosera rotundifolia. welche nach 7 Stunden mäszig, und nach 23 Stunden stark eingebogen wurden. Zwei andere Blätter wurden mit einer schwächeren Lösung von einem Theile auf 437 Theile Wasser versucht. Das eine war in 7 Stunden stark eingebogen, das andere nicht eher bis 30 Stunden verlaufen waren.

## Weinsteinsaures Ammoniak
Halbe Minims einer Lösung von einem Theile in 437 Theilen Wasser wurden auf die Scheiben von fünf Blättern gebracht. In 31 Minuten war bei einigen der Blätter an den äuszeren Tentakeln eine Spur von Einbiegung vorhanden, und dieselbe wurde nach 1 Stunde bei allen Blättern entschiedener; die Tentakeln wurden aber niemals dicht eingebogen. Nach 8 Stunden 30 Minuten fiengen sie an, sich wieder auszustrecken. Am nächsten Morgen, nach 23 Stunden waren sie alle vollständig wieder ausgebreitet, mit Ausnahme eines, welches noch immer leicht eingebogen war. Die Kürze der Einbiegungsdauer ist in diesem und in dem folgenden Falle merkwürdig.

## Ammoniumchlorid
Halbe Minims einer Lösung von einem Theile auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern# Einleitung

gelegt. Ein entschieden ausgesprochener Grad von Einbiegung in den äuszeren und submarginalen Tentakeln war in 25 Minuten wahrnehmbar; und dies nahm während der nächsten drei oder vier Stunden zu, wurde aber nie scharf markirt. Nach nur 8 Stunden 30 Minuten fiengen die Tentakeln an, sich wieder auszustrecken, und am nächsten Morgen, nach 24 Stunden, waren sie an vier von den Blättern vollständig wieder ausgestreckt, aber bei zweien noch unbedeutend eingebogen.

# Allgemeine Zusammenfassung und Schlussbemerkungen über die Ammoniaksalze

Allgemeine Zusammenfassung und Schluszbemer- kungen über die Ammoniaksalze. — Wir haben nun gesehen, dasz die neun Ammoniaksalze, welche versucht wurden, sämmtlich die Einbiegung der Tentakeln und häufig auch der Scheibe des Blattes verursachen. So weit nach den oberflächlichen Versuchen mit den letzterwähnten sechs Salzen ermittelt werden kann, ist das citronensauren Salz das schwächste und das phosphorsaure sicher bei weitem das wirksamste. Das weinsteinsaure Salz und das Chlorid sind merk- würdig wegen der kurzen Dauer ihrer Wirkung. Die relative Wirk- samkeit des kohlensauren, salpetersauren und phosphorsauren Salzes ist in der folgenden Tabelle durch die geringste Menge ausgedrückt, welche genügt, die Einbiegung der Tentakeln zu verursachen.

# Zusammenfassung über Ammoniaksalze

Cap. 7. Zusammenfassung über Ammoniaksalze. Aus den auf diese drei verschiedene Weisen angestellten Versuchen sehen wir, dasz das kohlensaure Salz, welches 23,7 Procent Stickstoff enthält, weniger wirksam ist, als das salpetersaure, welches 35 Procent enthält. Das phosphorsaure Salz enthält weniger Stick- stoff als beide andern Salze, nämlich nur 21,2 Procent, und doch ist es bei weitem wirksamer; seine Kraft hängt ohne Zweifel ganz ebenso sehr vom Phosphor als vom Stickstoff ab, welchen es enthält. Dasz dies der Fall ist, können wir aus der energischen Art und Weise schlieszen, in welcher Stückchen von Knochen oder von phosphorsaurem Kalke die Blätter afficiren. Die durch die andern Ammoniak- salze angeregte Einbiegung ist wahrscheinlich allein Folge ihres Stickstoffgehalts, — nach demselben Principe, wie stickstoffhaltige organische Flüssigkeiten kräftig einwirken, während nicht stickstoffhaltige organische Flüssigkeiten wirkungslos sind. Da solche äuszerst kleine Dosen der Ammoniaksalze die Blätter beeinflussen, so können wir wohl beinahe sicher sein, dasz Drosera die wenn auch geringe Menge, welche im Regenwasser vorhanden ist, absorbirt und aus ihr Nutzen zieht, in derselben Weise, wie andere Pflanzen diese selben Salze mit ihren Wurzeln absorbiren.

# Die Kleinheit der Dosen

Die Kleinheit der Dosen des salpetersauren und ganz besonders des phosphorsauren Ammoniaks. welche eine Einbiegung der Tentakeln an den eingetauchten Blättern verursacht, ist vielleicht die merk- würdigste in diesem Bande mitgetheilte Thatsache. Wenn wir sehn, dasz viel weniger als der millionte Theil Es ist kaum möglich, sich vorzustellen, was eine Million bedeutet. Die beste Illustration, die mir vorgekommen ist, ist die, welche W. Croll gibt; er sagt: — „Man nehme einen schmalen Streifen Papier 83 Fusz 4 Zoll lang und strecke ihn an der Wand eines groszen Saales aus; dann bezeichne man an einem Ende ein Zehntel Zoll. Dieses Zehntel wird ein Hundert und der ganze Streifen eine Million repräsentiren. eines Gran des Phosphats, von der Drüse eines der äuszeren Tentakeln absorbirt, diesen zu bie- gen veranlaszt, so könnte man meinen, dasz die Wirkungen der Lösung auf die Drüsen der Blattscheibe übersehen worden seien, nämlich die Übermittelung eines motorischen Impulses von ihnen aus an die äuszeren Tentakeln. Ohne Zweifel werden die Bewegungen der letz- teren hierdurch unterstützt; aber die in dieser Weise geleistete Hülfe musz unbedeutend sein; denn wir wissen, dasz ein Tropfen, welcher so viel wie \frac {1}{3840} Gran enthält, wenn er auf die Scheibe gebracht wird, nur gerade eben im Stande ist, die äuszern Tentakeln eines in hohem Grade empfindlichen Blattes zum Biegen zu veranlassen. Es ist sicherlich eine äuszerst überraschende Thatsache, dasz \frac {1}{19760000} eines Grans, oder in runder Zahl ein zwanzigmillionter Theil eines Grans (0,0000033 Milligr.) des phosphorsauren Salzes irgend eine# Einleitung
Pflanze oder selbst irgend ein Thier afficiren sollte; und da dies Salz 35,33 Procent Krystallisationswasser enthält, so werden die wirksamen Elemente auf \frac {1}{30555126} Gran oder in runder Zahl auf ein dreiszig-milliontel Gran (0,00000216 Milligr.) reducirt.

# Verdünnung und Wirkung
Überdies war die Lösung in diesen Versuchen im Verhältnis von einem Theile des Salzes auf 2,187,500 Theile Wasser oder 1 Gran auf 5000 Unzen verdünnt. Der Leser wird sich vielleicht diesen Grad von Verdünnung am besten vergegenwärtigen, wenn er sich erinnert, dasz 5000 Unzen mehr als ein 31 Gallonenfasz füllen würden, und dasz zu dieser groszen Masse Wasser ein Gran des Salzes hinzugethan wird; über ein Blatt wird dann nur eine halbe Drachme oder dreiszig Minims der Lösung gegossen.

# Unglaubliche Ergebnisse
Und doch reichte diese Menge hin, die Einbiegung beinahe jeden Tentakels und häufig auch der Blattscheibe zu verursachen. Ich bin mir wohl bewuszt, dasz diese Angabe auf den ersten Blick beinahe Jedermann unglaublich erscheinen wird.

# Vergleich mit chemischen Methoden
Drosera ist weit davon entfernt, mit dem Unterscheidungsvermögen des Spectroskops rivalisiren zu können; doch kann sie, wie es sich in den Bewegungen ihrer Blätter zeigt, eine sehr viel kleinere Quantität des phosphorsauren Ammoniaks entdecken, als der geschickteste Chemiker es von irgend einer Substanz kann.

# Historische Beobachtungen
Als meine ersten Beobachtungen über das salpetersaure Ammoniak vor vierzehn Jahren angestellt wurden, waren die Leistungen des Spectroskops noch nicht entdeckt, und mich interessirten die damals völlig beispiellosen Leistungen der Drosera um so mehr.

# Aktuelle wissenschaftliche Erkenntnisse
Jetzt hat nun das Spectroskop die Drosera vollständig geschlagen; denn nach Bunsen und Kirchhoff kann wahrscheinlich weniger als \frac {1}{200000000} Gran Natron auf diese Weise entdeckt werden.

# Chemische Prüfungen
In Bezug auf gewöhnliche chemische Prüfungen entnehme ich dem Werke Dr. Alfred Taylor’s über Gifte, dasz ungefähr \frac {1}{4000} Gran Arsenik, \frac {1}{4400} Gran Blausäure, \frac {1}{1400} Gran Jod und \frac {1}{2000} Gran Brechweinstein entdeckt werden kann; aber die Fähigkeit des Nachweises hängt sehr davon ab, dasz die beim Versuche verwandten Lösungen nicht äuszerst schwach sind.

# Zweifel und Wiederholungen
Meine Resultate waren eine lange Zeit mir selbst unglaublich und suchte ich ängstlich nach jeder Fehlerquelle. Das Salz wurde in einigen Fällen von einem Chemiker auf einer ausgezeichneten Wage für mich abgewogen, und frisches Wasser wurde viele Male mit Sorgfalt abgemessen.

# Vergleichende Experimente
Die Beobachtungen wurden während mehrerer Jahre wiederholt. Zwei meiner Söhne, welche so ungläubig wie ich selbst waren, verglichen mehrere Gruppen von Blättern, welche gleichzeitig in die schwächeren Lösungen und in Wasser eingetaucht wurden, mit einander und erklärten, es könne über die Verschiedenheit ihrer äuszeren Erscheinung gar kein Zweifel bestehen.

# Aufforderung zur Wiederholung
Ich hoffe, dasz irgend Jemand sich später veranlasst finden möge, meine Versuche zu wiederholen; in diesem Falle sollte er junge und kräftige Blätter auswählen, deren Drüsen von reichlichem Secrete umgeben sind.

# Experimentelle Bedingungen
Die Blätter müssen sorgfältig abgeschnitten und sanft in Uhrgläser gelegt werden, und eine abge-messene Quantität von der Lösung und von Wasser über jedes derselben gegossen werden.

# Reinheit des Wassers
Das benutzte Wasser musz so absolut rein sein, wie es nur gemacht werden kann.

# Wetterbedingungen
Es ist noch besonders zu beachten, dasz die Versuche mit den schwächeren Lösungen nach mehreren Tagen sehr warmen Wetters angestellt werden sollten.

# Pflanzenbedingungen
Diejenigen mit den schwächsten Lösungen sollten mit Pflanzen ange-stellt werden, welche eine beträchtliche Zeit lang in einem warmen Kalthause oder in einem kühlen Treibhause gehalten worden sind; doch ist dies für Versuche mit mäszig starken Lösungen durchaus nicht nothwendig.

# Empfindlichkeit der Drosera
Ich bitte den Leser, zu beachten, dasz die Empfindlichkeit oder Reizbarkeit der Tentakeln auf dreierlei verschiedene Methoden ermittelt wurde: — indirect durch Tropfen, welche auf die Scheibe gebracht wurden, direct durch Tropfen, welche an die Drüsen der äuszeren.# Chemische Experimente und Ergebnisse

Tentakeln applicirt wurden, und durch Eintauchen der ganzen Blätter; durch diese drei Methoden wurde gefunden, dasz das salpetersaure Salz wirksamer war, als das kohlensaure, und das phosphorsaure viel wirksamer als das salpetersaure; dies Resultat wird verständlich durch die Verschiedenheit in der Menge von Stickstoff, welche die beiden ersten Salze enthalten, und durch die Gegenwart von Phosphor im dritten. Es wird vielleicht den Glauben des Lesers unterstützen, wenn er sich zu den Versuchen mit einer Lösung von einem Theile des phosphorsauren Salzes auf 1000 Unzen Wasser wendet; er wird hier entscheidende Beweise finden, dasz ein Viermilliontel Gran hinreichend ist, die Einbiegung eines einzelnen Tentakels zu verursachen. Es liegt daher darin nichts sehr Unwahrscheinliches, dasz ein Fünftel dieses Gewichtes oder ein Zwanzigmilliontel Gran auf den Tentakel eines in hohem Grade empfindlichen Blattes wirken kann. Ferner wurden zwei von den Blättern in der Lösung von einem Gran in 3000 Unzen und drei von den Blättern in der Lösung von einem Gran in 5000 Unzen afficirt, und zwar nicht nur viel bedeutender als die zu gleicher Zeit in Wasser versuchten Blätter, sondern auch unvergleichlich mehr als überhaupt irgend welche fünf Blätter, welche aus den 173 von mir in verschiedenen Zeiten in Wasser beobachteten ausgelesen werden könnten.

# Absorption von Salzen durch Pflanzen

In der bloszen Thatsache, dasz der einzwanzigmillionte Theil eines Gran des phosphorsauren Salzes, in mehr als zwei Millionen mal seines Gewichtes in Wasser aufgelöst, von einer Drüse absorbirt wird, liegt nichts Merkwürdiges. Alle Physiologen geben zu, dasz die Wurzeln der Pflanzen die ihnen durch das Regenwasser gebrachten Ammoniaksalze absorbiren; und vierzehn Gallonen Regenwasser enthalten einen Gran Ammoniak, daher nur ein wenig mehr als zweimal so viel als die schwächste von mir angewandte Lösung. Die Thatsache, welche wahrhaft wunderbar erscheint, ist, dasz der einzwanzigmillionte Theil eines Grans des phosphorsauren Ammoniaks (welcher weniger als den eindreiszigmilliontel Gran wirksamer Substanz enthält), wenn er von einer Drüse absorbirt wird, in dieser eine gewisse Veränderung hervorruft, welche dahin führt, dasz ein motorischer Impuls die ganze Länge des Tentakels hinab geleitet wird und den basalen Theil zu biegen verursacht, häufig durch einen Winkel von über 180 Grad.

# Unglaubliche Ergebnisse und deren Erklärungen

So staunenswerth dies Resultat ist, so ist doch kein vernünftiger Grund vorhanden, weshalb wir dasselbe als unglaublich verwerfen sollten. Professor Donders in Utrecht theilt mir mit, dasz er nach Versuchen, welche er früher mit Dr. De Ruyter angestellt habe, zu dem Schlusse gelangt sei, dasz weniger als der einmillionte Theil eines Grans schwefelsauren Atropins in einem äuszerst verdünnten Zustande direct auf die Iris eines Hundes gebracht, die Muskeln dieses Organs paralysirt. Wir haben aber in der That jedesmal, wenn wir einen Geruch wahrnehmen, Beweise, dasz unendlich kleinere Teilchen auf unsre Nerven wirken. Wenn ein Hund eine Viertelmeile unter dem Winde von einem Hirsche oder einem andern Thiere steht und er nimmt dessen Gegenwart wahr, so bewirken die riechbaren Teilchen irgend eine Veränderung in seinen Geruchsnerven; und doch müssen diese Teilchen unendlich kleiner sein.

# Mikroskopische Größen und deren Bedeutung

Mein Sohn, George Darwin, hat mir den Durchmesser einer Kugel von phosphorsaurenem Ammoniak (specifisches Gewicht 1,678), welche den einzwanzigmilliontel Theil eines Grans wiegt, berechnet und findet ihn \frac {1}{1044} Zoll grosz. Nun theilt mir Dr. Klein mit, dasz die kleinsten Mikrokokken, welche unter einer Vergröszerung von 800 malen deutlich unterscheidbar sind, zu 0,0002 bis 0,0005 Millimeter geschätzt werden, d. h. von \frac {1}{50800} zu \frac {1}{127000} Zoll Durchmesser. Es kann daher ein Gegenstand von zwischen \frac {1}{31} und \frac {1}{77} der Grösse einer Kugel von phosphorsaurenem Ammoniak von dem oben erwähnten Gewicht unter einer# Einleitung
starken Vergröszerung gesehen werden; und Niemand vermuthet, dasz riechbare Theilchen, solche, wie sie in dem obigen Beispiel vom Hirsche abgegeben werden, unter irgend welcher Vergröszerung eines Mikroskops gesehen werden könnten. als die von phosphorsaurem Ammoniak sein, welche den einzwanzigmilliontel Theil eines Grans wiegen. Diese Nerven übermitteln dann einen gewissen Einflusz dem Gehirne des Hundes, welches zu Thätigkeit seinerseits führt. Bei Drosera liegt die wirklich wunderbare Thatsache darin, dasz eine Pflanze ohne irgend ein specialisirtes Nervensystem durch solche äuszerst kleine Theilchen afficirt werden kann; wir haben aber keine Gründe zur Annahme, dasz nicht auch andre Gewebe so exquisit empfänglich für Eindrücke von auszen her gemacht werden könnten, wenn dies für den Organismus wohlthätig wäre, wie es das Nerven-system der höheren Thiere ist.

# Achtes Kapitel
Die Wirkungen verschiedener Salze und Säuren auf die Blätter.

# Zusammenfassung der Salze
Natron-, Kali- und andere alkalische, erdige und metallische Salze. — Zusammenfassung über die Wirkung dieser Salze. — Verschiedene Säuren. — Zusammenfassung über ihre Wirkungen.

# Untersuchung der Salze
Nachdem ich gefunden hatte, dasz die Ammoniaksalze so wirk-sam wären, wurde ich darauf geführt, die Wirkung einiger andern Salze zu untersuchen. Es wird zweckmäszig sein, zuerst eine Liste der versuchten Substanzen (welche neun und vierzig Salze und zwei Metallsäuren umfaszt) mitzutheilen, und zwar in zwei Columnen ge-theilt, von denen die eine die Körper enthält, welche Einbiegung verursachen, die andere die, welche dies nicht oder nur zweifelhaft thun. Meine Versuche wurden so angestellt, dasz halbe Minim-Tropfen auf die Scheiben von Blättern gelegt, oder, noch gewöhn-licher, dasz die Blätter in die Lösungen eingetaucht wurden, zuweilen auch nach beiden Methoden. Dann soll eine Zusammenfassung der Resultate mit einigen Schluszbemerkungen gegeben werden. Die Wirkung verschiedener Säuren werden nachher beschrieben werden.

# Salze und ihre Wirkungen
Salze, welche Einbiegung verursachen.
Salze, welche keine Einbiegung verursachen.
(Nach der chemischen Classification in Watt’s Dictionary of Chemistry in Gruppen angeordnet.)
Kohlensaures Natron, rapide Ein-biegung.
Salpetersaures Natron, rapide Ein-biegung.
Schwefelsaures Natron, mäszig schnelle Einbiegung.
Phosphorsaures Natron, sehr rapide Einbiegung.
Kohlensaures Kali: langsam giftig.
Salpetersaures Kali: etwas giftig.
Schwefelsaures Kali.
Phosphorsaures Kali.

# Weitere Salze
Cap. 8. Wirkung verschiedener Salze.
Salze, welche Einbiegung verursachen.
Salze, welche keine Einbiegung verursachen.
(Nach der chemischen Classification in Watt’s Dictionary of Chemistry in Gruppen angeordnet.)
Citronensaures Natron, rapide Ein-biegung.
Oxalsaures Natron, rapide Einbie-gung.
Chlornatrium, mäszig rapide Ein-biegung.
Jodnatrium, eher langsame Einbie-# Chemische Substanzen und ihre Eigenschaften

## Einbiegung von Salzen

Bromnatrium, mäszig schnelle Einbiegung.
Oxalsaures Kali, langsame und zweifelhafte Einbiegung.
Salpetersaures Lithion, mäszig rapide Einbiegung.
Caesiumchlorid, eher langsame Einbiegung.
Salpetersaures Silber, rapide Einbiegung; schnelles Gift.
Cadmiumchlorid, langsame Einbiegung.
Quecksilberhyperchlorid, rapide Einbiegung; schnelles Gift.
Aluminiumchlorid, langsame und zweifelhafte Einbiegung.
Goldchlorid, rapide Einbiegung: schnelles Gift.
Zinnchlorid, langsame Einbiegung: giftig.
Weinsteinsaures Antimon, langsame Einbiegung; wahrscheinlich giftig.
Arsenige Säure, schnelle Einbiegung: giftig.

## Weitere chemische Verbindungen

Citronensaures Kali.
Chlorkalium.
Jodkalium, ein unbedeutender und zweifelhafter Grad von Einbiegung.
Bromkalium.
Essigsaures Lithion.
Rubidiumchlorid.
Essigsaurer Kalk.
Salpetersaurer Kalk.
Essigsaure Magnesia.
Salpetersaure Magnesia.
Magnesiumchlorid.
Schwefelsaure Magnesia.
Essigsaurer Baryt.
Salpetersaurer Baryt.
Essigsaurer Strontian.
Salpetersaurer Strontian.
Zinkchlorid.
Salpetersaurer Alaun, eine Spur von Einbiegung.
Schwefelsaurer Alaun und schwefelsaures Kali.
Bleichlorid.
Drosera rotundifolia. Cap. 8.

## Klassifikation der Salze

Salze, welche Einbiegung verursachen.
Salze, welche keine Einbiegung verursachen.
(Nach der chemischen Classification in Watt’s Dictionary of Chemistry in Gruppen angeordnet.)

## Giftige Substanzen

Eisenchlorid, langsame Einbiegung: wahrscheinlich giftig.
Chromsäure, schnelle Einbiegung: in hohem Grade giftig.
Kupferchlorid, eher langsame Einbiegung: giftig.
Nickelchlorid, rapide Einbiegung: wahrscheinlich giftig.# Platinchlorid und seine Wirkung

Platinchlorid, rapide Einbiegung: giftig. Manganchlorid. Kobaltchlorid. Kohlensaures Natron (rein, mir von Prof. Hoffmann gegeben). — Halbe Minims (0,0296 Cub. Cent.) einer Lösung eines Theils auf 218 Theile Wasser (2 Gran auf 1 Unze) wurden auf die Scheiben von 12 Blättern gelegt. Sieben derselben wurden gehörig eingebogen. Drei hatten nur zwei oder drei ihrer äuszern Tentakeln eingebogen, und die übrigen zwei waren gar nicht afficirt. Aber die Dosis, obgleich nur \frac {1}{480} Gran (0,135 Milligr.) war augenscheinlich zu stark; denn drei der sieben gut eingebogenen Blätter waren getödtet. Auf der andern Seite breitete sich eins der sieben, welches nur einige Tentakeln eingebogen hatte, nach 48 Stunden wieder aus und schien ganz gesund. Unter Anwenden einer schwächeren Lösung (nämlich ein Theil auf 437 Theile Wasser oder 1 Gran auf 1 Unze) wurden Dosen von \frac {1}{960} Gran (0,0675 Milligr.) sechs Blättern gegeben. Auf einige derselben hatten dieselben in 37 Minuten eingewirkt, und in 8 Stunden waren die äuszeren Tentakeln aller, ebenso wie die Scheiben von zweien beträchtlich eingebogen. Nach 23 Stunden 15 Minuten hatten sich die Tentakeln beinahe wieder ausgestreckt, aber die Scheiben der zwei waren noch gerade wahrnehmbar nach innen gebogen. Nach 48 Stunden waren alle sechs Blätter völlig wieder ausgebreitet, und erschienen vollkommen gesund.

# Salpetersaures Natron

Drei Blätter wurden eingetaucht, jedes in dreiszig Minims einer Lösung von einem Theil auf 875 Theile Wasser (1 Gran auf 2 Unzen), so dasz jedes \frac {1}{32} Gran (2,02 Milligr.) erhielt; nach 40 Minuten waren die drei bedeutend afficirt und nach 6 Stunden 45 Minuten die Tentakeln aller und die Scheibe des einen dicht eingebogen. Salpetersaures Natron (rein). — Halbe Minims einer Lösung von einem Theil auf 437 Theile Wasser, \frac {1}{960} Gran (0,0675 Milligr.) enthaltend, wurden auf die Scheiben von fünf Blättern gelegt. Nach 1 Stunde 25 Minuten waren die Tentakeln beinahe aller und die Scheibe eines etwas eingebogen. Die Einbiegung fuhr fort zuzunehmen und in 21 Stunden 15 Minuten war die Einwirkung auf die Tentakeln und die Scheiben von vier derselben bedeutend, während die Wirkung auf die Scheibe des fünften nur in einem unbedeutenden Grad eingetreten war. Nach weiteren 24 Stunden blieben die vier Blätter noch dicht eingebogen, während das fünfte anfieng, sich wieder auszubreiten. Vier Tage nachdem die Lösung angewendet worden war, hatten sich zwei der Blätter ganz, und eins theilweise wieder ausgebreitet; während die übrigen zwei dicht eingebogen blieben und verletzt schienen.

# Schwefelsaures Natron

Drei Blätter wurden eingetaucht, jedes in dreiszig Minims einer Lösung eines Theils auf 875 Theile Wasser; in 1 Stunde war bedeutende Einbiegung vorhanden, und nach 8 Stunden 15 Minuten waren alle Tentakeln und die Scheiben aller drei sehr stark eingebogen. Schwefelsaures Natron. — Halbe Minims einer Lösung von einem Theil auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gelegt. Nach 5 Stunden 30 Minuten waren die Tentakeln von drei derselben (mit der Scheibe des einen) bedeutend, und die der andern drei leicht eingebogen. Nach 21 Stunden hatte die Einbiegung etwas abgenommen und in 45 Stunden waren die Blätter vollständig wieder ausgebreitet, und erschienen ganz gesund. Drei Blätter wurden eingetaucht, jedes in dreiszig Minims einer Lösung von einem Theil des schwefelsauren Salzes auf 875 Theile Wasser; nach 1 Stunde 30 Minuten war etwas Einbiegung da, welche so zunahm, dasz in 8 Stunden 10 Minuten alle Tentakeln und die Scheiben aller drei Blätter dicht eingebogen waren.

# Phosphorsaures Natron

Phosphorsaures Natron. — Halbe Minims einer Lösung von einem Theil auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gebracht, Die Lösung wirkte mit auszerordentlicher Schnelligkeit, denn in 8 Minuten waren die äuszeren Tentakeln mehrerer Blätter.# Einleitung

# Experimente mit verschiedenen Lösungen

## Citronensaures Natron

## Oxalsaures Natron

## Chlornatrium (Küchensalz)

## Jodnatrium# Experimentelle Ergebnisse

## Einflüsse von Bromnatrium

## Wirkung von Kohlensauren Kali

## Effekte von Salpetersauren Kali

## Ergebnisse mit Schwefelsauren Kali# Darwin, Insectenfressende Pflanzen

## Kapitel 8: Wasser und seine Wirkung

Wasser, brachte keine augenscheinliche Wirkung hervor. Sie wurden dann mit derselben Lösung von kohlensaurem Ammoniak behandelt, mit demselben Resultat wie in dem Fall mit dem salpetersauren Kali.

## Phosphorsaures Kali

Phosphorsaures Kali. — Halbe Minims einer Lösung von einem Teil auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gebracht, welche während dreier Tage beobachtet wurden; es wurde aber keine Wirkung hervorgebracht. Das theilweise Auftrocknen der Flüssigkeit auf der Scheibe zog die Tentakeln auf ihr leicht zusammen, wie es oft bei Experimenten dieser Art vorkommt. Die Blätter erschienen am dritten Tage ganz gesund.

## Citronensaures Kali

Citronensaures Kali. — Halbe Minims einer Lösung von einem Teil auf 437 Theile Wasser drei Tage auf den Scheiben von sechs Blättern gelassen, und das Eintauchen dreier Blätter, 9 Stunden lang, jedes in 30 Minims einer Lösung von einem Teil auf 875 Theile Wasser, brachten nicht die geringste Wirkung hervor.

## Oxalsaures Kali

Oxalsaures Kali. — Halbe Minims wurden bei verschiedenen Gelegenheiten auf die Scheiben von siebzehn Blättern gebracht, und die Resultate verwirrten mich sehr, wie sie es noch thun. Einbiegung trat sehr langsam ein. Nach 24 Stunden waren vier von den siebzehn Blättern gut eingebogen, zusammen mit den Scheiben von zweien; sechs waren leicht afficirt und sieben gar nicht. Drei Blätter aus einer Gruppe wurden fünf Tage lang beobachtet, und alle starben ab; aber in einer anderen Gruppe von sechs sahen alle, eins ausgenommen, noch nach vier Tagen gesund aus. Drei Blätter wurden 9 Stunden lang eingetaucht, jedes in dreiszig Minims einer Lösung von einem Teil auf 875 Theile Wasser, und waren nicht im Geringsten afficirt, aber sie hätten längere Zeit beobachtet werden sollen.

## Chlorkalium

Chlorkalium. — Weder halbe Minims einer Lösung von einem Teil auf 437 Theile Wasser drei Tage lang auf den Scheiben von sechs Blättern gelassen, noch das Eintauchen dreier Blätter für 25 Stunden lang in 30 Minims einer Lösung von einem Teil auf 875 Theile Wasser brachte die geringste Wirkung hervor. Die eingetauchten Blätter wurden dann mit kohlensaurem Ammoniak, wie beim salpetersauren Kali beschrieben wurde, behandelt, und mit demselben Erfolg.

## Jodkali

Jodkali. — Halbe Minims einer Lösung von einem Teil auf 437 Theile Wasser wurden auf die Scheiben von sieben Blättern gebracht. In 30 Minuten hatte ein Blatt seine Scheibe eingebogen; nach einigen Stunden hatten drei Blätter die meisten ihrer halbrandständigen Tentakeln mäßig eingebogen. Die übrigbleibenden drei waren sehr unbedeutend afficirt. Kaum irgend eines dieser Blätter hatte seine äußeren Tentakeln eingebogen. Nach 21 Stunden streckten sich alle wieder aus, ausgenommen zwei, welche noch einige wenige halbrandständige Tentakeln eingebogen hatten. Drei Blätter wurden demnächst 8 Stunden 40 Minuten lang, jedes in 30 Minims einer Lösung von einem Teil auf 875 Theile Wasser eingetaucht, und wurden nicht im Geringsten afficirt. Ich weiß nicht, was ich aus diesen sich widersprechenden Tatsachen folgern soll; aber es ist klar, dass Jodkali gewöhnlich keine besonders ausgesprochene Wirkung hervorbringt.

## Kapitel 8: Wirkungen verschiedener Salze

Bromkali. — Halbe Minims einer Lösung von einem Teil auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gebracht; nach 22 Stunden hatte eins seine Scheibe und viele Tentakeln eingebogen, aber ich vermute, dass ein Insekt sich darauf niedergelassen hatte, und dann wieder entkommen war. Die fünf andern Blätter waren in keiner Weise afficirt. Ich versuchte drei dieser Blätter mit Stückchen Fleisch und nach 24 Stunden wurden sie herrlich eingebogen. Drei Blätter wurden auch 21 Stunden lang in 30 Minims einer Lösung von einem Teil auf 875 Theile Wasser eingetaucht; aber sie wurden gar nicht afficirt, außer dass die Drüsen ziemlich blass aussahen.

## Essigsaures Lithion

Essigsaures Lithion. — Vier Blätter wurden zusammen in ein Gefäß, welches 120 Minims einer Lösung von einem Teil auf 437 Theile Wasser enthielt, eingetaucht, so dass jedes, wenn die Blätter gleich auf-# Experimente mit verschiedenen Lösungen

## Salpetersaures Lithion
Vier Blätter wurden wie in dem letzten Falle in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 1 Stunde 30 Minuten waren alle vier ein wenig und nach 24 Stunden bedeutend eingebogen. Ich verdünnte dann die Lösung mit etwas Wasser, sie blieben aber noch am dritten Tage etwas eingebogen.

## Caesiumchlorid
Vier Blätter wurden wie oben in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht. Nach 1 Stunde 5 Minuten waren die Drüsen dunkel; nach 4 Stunden 20 Minuten war eine Spur von Einbiegung da; nach 6 Stunden 40 Minuten waren zwei Blätter stark, aber nicht dicht, und die andern zwei beträchtlich eingebogen. Nach 22 Stunden war die Einbiegung auszerordentlich stark und zwei hatten ihre Scheiben eingebogen. Ich übertrug dann die Blätter in Wasser, und in 46 Stunden, von ihrem ersten Eintauchen an gerechnet, waren sie beinah wieder ausgebreitet.

## Rubidiumchlorid
Auf vier Blätter, welche wie oben in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser einge-taucht waren, hatte dieselbe in 22 Stunden nicht eingewirkt. Ich fügte dann etwas von der starken Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak hinzu, und in 30 Minuten waren alle ungeheuer eingebogen.

## Salpetersaures Silber
Drei Blätter wurden in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser getaucht, so dasz jedes, wie vorher, \frac {1}{16} Gran erhielt. Nach 5 Minuten war leichte Einbiegung und nach 11 Minuten sehr starke Einbiegung da, wobei die Drüsen auszerordentlich schwarz wurden; nach 46 Minuten waren alle Tentakeln dicht eingebogen. Nach 6 Stunden wurden die Blätter aus der Lösung genommen, gewaschen und in Wasser gelegt; aber am nächsten Morgen waren sie augenscheinlich todt.

## Essigsaurer Kalk
Vier Blätter wurden in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 24 Stunden war keiner der Tentakeln eingebogen, ausgenommen einige wenige da, wo die Scheibe sich an den Stiel ansetzt, und dies mag dadurch ver-ursacht worden sein, dasz das Salz von dem abgeschnittenen Ende des Stieles aufgesaugt wurde. Ich fügte dann etwas von der Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak hinzu, aber dies erregte zu meinem Erstaunen nur leichte Einbiegung, selbst nach 24 Stunden. Es würde daher scheinen, als hätte das essigsaure Salz die Blätter betäubt.

## Salpetersaurer Kalk
Vier Blätter wurden in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht, aber waren in 24 Stunden nicht afficirt. Ich fügte dann etwas von der Lösung von phosphorsaurem Ammoniak (1 Gran auf 20 Unzen) hinzu, aber dies bewirkte nur sehr leichte Einbiegung nach 24 Stunden. Ein frisches Blatt wurde dann in eine gemischte Lösung der oben erwähnten Stärke-graden von salpetersaurem Kalk und phosphorsaurem Ammoniak gebracht, und es wurde in 5 bis 10 Minuten dicht eingebogen. Halbe Minims einer Lösung von einem Theil des phosphorsauren Kalkes auf 218 Theile Wasser wurden auf die Scheiben von drei Blättern getropft, aber brach-ten keine Wirkung hervor.

## Essigsaure, salpetersaure Magnesia und Chlormagnesium
Vier Blätter wurden in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser, von jedem dieser drei Salze eingetaucht; nach 6 Stunden war keine Einbiegung da; aber nach 22 Stunden war eins der Blätter in dem essigsaurem Salze eher etwas mehr eingebogen, als gewöhnlich nach einem Eintauchen in Wasser für diese Länge von.# Experimentelle Ergebnisse

## Phosphorsaure Ammoniak und seine Wirkungen

## Salpetersaure Magnesia

## Essigsaurer Baryt

## Salpetersaurer Baryt

## Essigsaurer Strontian

## Salpetersaurer Strontian

## Cadmiumchlorid

## Quecksilbersuperchlorid

## Zinkchlorid

## Chloraluminium# Kapitel 8: Wirkungen verschiedener Salze

## Lösung von Salzen
Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 7 Stunden 45 Minuten war keine Einbiegung vorhanden; nach 24 Stunden hatte sich ein Blatt ziemlich dicht, das zweite mäßig, das dritte und vierte kaum irgendwie eingebogen. Das Resultat ist zweifelhaft, aber ich denke, eine geringe Fähigkeit, langsame Einbiegung zu verursachen, muss diesem Salz zugeschrieben werden. Diese Blätter wurden dann in die Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak gelegt und nach 7 Stunden 30 Minuten wurden die drei, welche durch das Chlorid nur wenig affiziert waren, ziemlich dicht eingebogen.

## Salpetersaurer Alaun
Salpetersaurer Alaun. — Vier Blätter wurden in 120 Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 7 Stunden 45 Minuten war nur eine Spur von Einbiegung da; nach 24 Stunden war ein Blatt mäßig eingebogen. Das Resultat ist hier wieder zweifelhaft, wie in dem Fall mit dem Chloraluminium. Die Blätter wurden dann in dieselbe Lösung von phosphorsaurem Ammoniak übertragen wie vorher. Dies brachte in 7 Stunden 30 Minuten kaum irgend eine Wirkung hervor; aber nach 25 Stunden war ein Blatt ziemlich dicht eingebogen, die drei andern nur sehr leicht, vielleicht nicht mehr so als durch Wasser.

## Schwefelsaurer Alaun und schwefelsaures Kali
Schwefelsaurer Alaun und schwefelsaures Kali (gewöhnlicher Alaun). — Halbe Minims einer Lösung von der gewöhnlichen Stärke wurden auf die Scheiben von neun Blättern gebracht, aber brachten keine Wirkung hervor.

## Goldchlorid
Goldchlorid. — Sieben Blätter wurden in so viel von einer Lösung von einem Theil auf 437 Theile Wasser getaucht, dass jedes 30 Minims des Chlorids erhielt, welche \frac {1}{16} Gran oder 4,048 Milligr. enthielten. Es war nach 8 Minuten etwas Einbiegung da, welche in 45 Minuten ganz extrem wurde. In 3 Stunden war die umgebende Flüssigkeit purpurn gefärbt und die Drüsen waren geschwärzt. Nach 6 Stunden wurden die Blätter in Wasser übertragen; am nächsten Morgen wurden sie entfärbt und augenscheinlich getötet gefunden. Das Secret zersetzt das Chlorid sehr leicht; die Drüsen selbst werden mit einer äußerst dünnen Schicht von metallischem Gold überzogen und Teile davon schwimmen auf der Oberfläche der umgebenden Flüssigkeit herum.

## Chlorblei
Chlorblei. — Drei Blätter wurden in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht. Nach 23 Stunden war nicht eine Spur von Einbiegung da; die Drüsen waren nicht geschwärzt und die Blätter schienen nicht verletzt zu sein. Sie wurden dann in die Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak übertragen, und nach 24 Stunden waren zwei derselben etwas, das dritte sehr wenig eingebogen; und so blieben sie noch weitere 24 Stunden lang.

## Zinnchlorid
Zinnchlorid. — Vier Blätter wurden in 120 Minims einer Lösung von ungefähr einem Theil (es wurde nicht Alles aufgelöst) auf 437 Theile Wasser eingetaucht. Nach 4 Stunden war keine Wirkung da; nach 6 Stunden 30 Minuten hatten alle vier Blätter ihre halbrandständigen Tentakeln eingebogen; nach 22 Stunden war jeder einzelne Tentakel und die Scheiben dicht eingebogen. Die umgebende Flüssigkeit war nun rosa gefärbt. Die Blätter wurden gewaschen und in Wasser übertragen, aber am nächsten Morgen waren sie augenscheinlich tot. Dieses Chlorid ist ein tödliches Gift, aber wirkt langsam.

## Weinsteinsaures Antimon
Weinsteinsaures Antimon. — Drei Blätter wurden in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht. Nach 8 Stunden 30 Minuten war leichte Einbiegung da; nach 24 Stunden waren zwei der Blätter dicht, und das dritte mäßig eingebogen; die Drüsen nicht sehr geschwärzt. Die Blätter wurden gewaschen und in Wasser gelegt, aber sie blieben 48 weitere Stunden in demselben Zustand. Dieses Salz ist wahrscheinlich giftig, wirkt aber langsam.

## Arsenige Säure
Arsenige Säure. — Eine Lösung von einem Theil auf 437 Theile Wasser; drei Blätter wurden in neunzig Minims getaucht; in 25 Minuten beträchtliche Einbiegung; in 1 Stunde große Einbiegung; die Drüsen# Wirkung von Chemikalien auf Pflanzen

## Eisenchlorid
Drei Blätter wurden in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; in 8 Stunden keine Einbiegung; aber nach 24 Stunden beträchtliche Einbiegung; die Drüsen geschwärzt; die Flüssigkeit gelb gefärbt, mit schwimmenden flockigen Theilchen von Eisenoxyd. Die Blätter wurden dann in Wasser gelegt; nach 48 Stunden hatten sie sich sehr wenig wieder ausgebreitet, sondern waren, glaube ich, getödtet; die Drüsen auszerordentlich schwarz.

## Chromsäure
Ein Theil auf 437 Theile Wasser; drei Blätter wurden in neunzig Minims eingetaucht; in 30 Minuten etwas, in 1 Stunde beträchtliche Einbiegung; nach 2 Stunden alle Tentakeln dicht einge-
bogen, die Drüsen entfärbt. In Wasser gelegt; am nächsten Tag waren die Blätter ganz entfärbt und augenscheinlich getödtet.

## Manganchlorid
Drei Blätter in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 22 Stunden nicht mehr Einbiegung als auch oft in Wasser vorkommt; die Drüsen nicht geschwärzt. Dle Blätter wurden dann in die gewöhnliche Lösung von phosphorsaurem Ammoniak gelegt, aber keine Einbiegung wurde selbst nach 48 Stunden verursacht.

## Kupferchlorid
Drei Blätter in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 2 Stunden etwas Einbiegung; nach 3 Stunden 45 Minuten die Tentakeln dicht ein-
gebogen und die Drüsen geschwärzt. Nach 22 Stunden noch dicht ein-
gebogen und die Blätter schlaff. In reines Wasser gelegt, waren sie am nächsten Tage augenscheinlich todt. Ein rapid wirkendes Gift.

## Nickelchlorid
Drei Blätter in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; in 25 Minuten be-
trächtliche Einbiegung, und in 3 Stunden alle die Tentakeln dicht einge-
bogen; die meisten Drüsen, aber nicht alle, geschwärzt. Die Blätter
wurden dann in Wasser gelegt; nach 24 Stunden blieben sie eingebogen;
waren etwas entfärbt und die Drüsen und die Tentakeln schmutzig roth.
Wahrscheinlich getödtet.

## Kobaltchlorid
Drei Blätter in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; nach 23 Stunden
war nicht eine Spur von Einbiegung da, und die Drüsen waren nicht
mehr geschwärzt als auch oft vorkommt nach einem ebenso langen Ein-
tauchen in Wasser.

## Platinchlorid
Drei Blätter in neunzig Minims einer Lösung von einem Theil auf 437 Theile Wasser eingetaucht; in 6 Minuten etwas
Einbiegung, welche nach 48 Minuten ganz ungeheuer wurde. Nach
3 Stunden waren die Drüsen ziemlich blasz. Nach 24 Stunden alle Ten-
takeln noch dicht eingebogen. Die Drüsen farblos; blieben vier Tage in
demselben Zustande; die Blätter augenscheinlich getödtet.

## Schluszbemerkungen über die Wirkung der vor-
stehend angeführten Salze
Von den einundfünfzig Salzen und metallischen Säuren, welche versucht wurden, verursachten fünf-
undzwanzig eine Einbiegung der Tentakeln, und sechsundzwanzig
hatten keine solche Wirkung; zwei ziemlich zweifelhafte Fälle kamen
in jeder Versuchsreihe vor. In der Tabelle am Anfang dieser Erörte-
rung sind die Salze nach ihrer chemischen Verwandtschaft geordnet;
aber ihre Wirkung auf Drosera scheint nicht dadurch bestimmt zu
werden. Die Natur der Basis ist viel wichtiger, so weit nach diesen
wenigen hier gegebenen Versuchen geurtheilt werden kann, als die
Natur der Säure; und dies ist der Schlusz, zu welchem die Physio-
logen auch in Bezug auf die Thiere gekommen sind. Wir sehen diese
Thatsache dadurch erläutert, dasz alle neun Natronsalze Einbiegung
verursachen und nicht giftig sind, auszer wenn sie in groszen Dosen
gegeben werden; während sieben der correspondirenden Salze von Kali
keine Einbiegung verursachen und einige derselben giftig sind. Zwei
derselben jedoch, nämlich das oxalsaure und Jodkali, verursachten.# Einleitung
langsam einen leichten und ziemlich zweifelhaften Grad von Einbiegung.

# Unterschied zwischen Natronsalzen und Kalisalzen
Dieser Unterschied zwischen den zwei Serien ist interessant, da Dr. Burdon Sanderson mir mittheilt, dasz Natronsalze in groszen Dosen in die Circulation von Säugethieren eingeführt werden können, ohne irgend eine schädliche Wirkung; während kleine Dosen von Kalisalzen den Tod, durch plötzliches Anhalten der Thätigkeit des Herzens, ver- ursachen.

# Wirkung von phosphorsaurem Natron
Ein ausgezeichnetes Beispiel der verschiedenen Wirkung der beiden Reihen wird durch das phosphorsaure Natron dargeboten, welches schnell kräftige Einbiegung verursacht, während phosphor- saures Kali ganz unwirksam ist.

# Einfluss von Phosphor
Die grosze Kraft des ersteren ist wahrscheinlich Folge der Gegenwart von Phosphor, wie in den Fällen des phosphorsauren Kalkes und Ammoniaks. Daher können wir an- nehmen, dasz die Drosera aus dem phosphorsauren Kali keinen Phos- phor erhalten kann.

# Merkwürdige Beobachtungen
Dies ist merkwürdig, da ich von Dr. Burdon Sanderson höre, dasz phosphorsaures Kali sicher in den Körpern von Thieren zersetzt wird. Die meisten Natronsalze wirken sehr schnell, Jodnatrium am langsamsten.

# Wirkung verschiedener Salze
Das oxalsaure, salpetersaure und citronen- saure Salze scheinen eine besondere Neigung zu haben, die Scheibe des Blattes zum Einbiegen zu veranlassen. Die Drüsen der Scheibe übersenden, nachdem sie das citronensaure Salz aufgesaugt haben, kaum irgend einen motorischen Impuls nach den äuszeren Tentakeln;

# Vergleich von Säuren
Cap. 8. Wirkung von Säuren. und in dieser Eigenschaft ähnelt das citronensaure Natron dem citronen- sauren Ammoniak, oder einer Abkochung von Grasblättern; diese drei Flüssigkeiten wirken sämmtlich hauptsächlich auf die Scheibe.

# Regel des überwiegenden Einflusses
Es scheint der Regel von dem überwiegenden Einflusz der Basis zu widersprechen, dasz das salpetersaure Lithion mäszig schnelle Ein- biegung verursacht, während das essigsaure keine verursacht; aber dieses Metall ist nahe verwandt mit dem Natrium und KaliumMiller, Elements of Chemistry, 3. edit., p. 337, 448., welche so verschieden wirken; darum konnten wir erwarten, dasz seine Wirkung die Mitte zwischen beiden halten würde.

# Beobachtungen zu Caesium und Rubidium
Wir sehen auch, dasz Caesium Einbiegung verursacht, und Rubidium nicht; und diese beiden Metalle sind mit Natrium und Kalium verwandt. Die meisten erdigen Salze sind unwirksam.

# Wirkung von Erdalkali-Salzen
Zwei Salze von Kalk, vier von Mag- nesia, zwei von Barium und zwei von Strontium verursachten keine Einbiegung und folgen so der Regel von dem überwiegenden Vermögen der Basis.

# Aluminium-Salze
Von drei Aluminium-Salzen wirkte eines nicht, ein zwei- tes zeigte eine Spur von Wirkung, und das dritte wirkte langsam und zweifelhaft, so dasz ihre Wirkungen beinahe gleich sind.

# Versuch mit Metallsalzen
Von den Salzen und Säuren von gewöhnlichen Metallen wurden siebzehn versucht, und nur vier, die des Zink, Blei, Mangan und Kobalt, verursachten keine Einbiegung. Die Salze von Cadmium, Zinn, Antimon und Eisen wirken langsam; und die drei letzteren scheinen mehr oder wenig giftig zu sein.

# Giftige Salze
Die Salze von Silber, Queck- silber, Gold, Kupfer, Nickel und Platin, Chromsäure und arsenige Säure verursachen mit auszerordentlicher Geschwindigkeit grosze Ein- biegung und sind tödtliche Gifte. Es ist überraschend, wenn man von Thieren aus urtheilt, dasz Blei und Barium nicht giftig sein sollen.

# Beobachtungen zu Drüsen
Die meisten giftigen Salze machen die Drüsen schwarz, aber Platinchlorid machte sie sehr blasz. Ich werde im nächsten Capitel Gelegenheit haben, einige Bemerkungen über die verschiedenen Wir- kungen von phosphorsaurem Ammoniak auf vorher in verschiedene Lösungen getauchte Blätter hinzuzufügen.

# Liste der Säuren
Ich will wie bei den Salzen zuerst eine Liste von den vierund- zwanzig Säuren, welche versucht werden, geben, in zwei Reihen ge- theilt, je nachdem sie Einbiegung verursachen oder nicht verursachen. Nach Beschreibung der Experimente werden einige Schluszbemerkungen hinzugefügt werden.

# Säuren, die Einbiegung verursachen
Drosera rotundifolia. Cap. 8. Säuren, welche, sehr verdünnt, Ein- biegung verursachen. 1. Salpetersäure, starke Einbie-# Säuren und ihre Eigenschaften

## Giftige und nicht giftige Säuren
1. Salzsäure, mäßige und langsame Einbiegung; nicht giftig.
2. Jodwasserstoffsäure, starke Einbiegung; giftig.
3. Jodsäure, starke Einbiegung; giftig.
4. Schwefelsäure, starke Einbiegung; etwas giftig.
5. Phosphorsäure, starke Einbiegung; giftig.
6. Borsäure, mäßige und ziemlich langsame Einbiegung; nicht giftig.
7. Ameisensäure, sehr unbedeutende Einbiegung; nicht giftig.
8. Essigsäure, starke und schnelle Einbiegung; giftig.
9. Propionsäure, starke, aber nicht sehr schnelle Einbiegung; giftig.
10. Ölsäure, schnelle Einbiegung; sehr giftig.
11. Carbolsäure, sehr langsame Einbiegung; giftig.
12. Milchsäure, langsame u. mäßige Einbiegung; giftig.
13. Oxalsäure, mäßig schnelle Einbiegung; sehr giftig.
14. Äpfelsäure, sehr langsame, aber beträchtliche Einbiegung; nicht giftig.
15. Benzoësäure, schnelle Einbiegung; sehr giftig.
16. Bernsteinsäure, mäßig schnelle Einbiegung; mäßig giftig.
17. Hippursäure, ziemlich langsame Einbiegung; giftig.
18. Blausäure, ziemlich rapide Einbiegung; sehr giftig.

## Säuren ohne Einbiegung
Säuren, welche, in demselben Grade verdünnt, keine Einbiegung verursachen.
1. Gallussäure; nicht giftig.
2. Gerbsäure; nicht giftig.
3. Weinsteinsäure; nicht giftig.
4. Citronensäure; nicht giftig.
5. Harnsäure; (?) nicht giftig.

## Wirkung von Säuren
Salpetersäure. — Vier Blätter wurden jedes in dreiszig Minims von einem Gewichtstheil der Säure auf 437 Theile Wasser gethan, so dasz jedes \frac {1}{16} Gran oder 4,048 Milligr. erhielt. Diese Stärke wurde für diesen und die meisten der folgenden Versuche gewählt, da es dieselbe wie die der meisten vorhergehend angewandten salzigen Lösungen ist.

In 2 Stunden 30 Minuten waren einige der Blätter beträchtlich und in 6 Stunden 30 Minuten alle ungeheuer stark eingebogen, wie es auch ihre Scheiben waren. Die umgebende Flüssigkeit war leicht rosa gefärbt, welches allemal beweist, dasz die Blätter verletzt worden sind. Sie wurden dann drei Tage in Wasser gelassen; aber sie blieben eingebogen und waren augenscheinlich getötet. Die meisten Drüsen waren farblos geworden. Zwei Blätter wurden dann jedes in dreiszig Minims von einem Teil auf 1000 Theile Wasser getaucht; in einigen wenigen Stunden war etwas Einbiegung da; und nach 24 Stunden hatten beide Blätter beinahe alle ihre Tentakeln und Scheiben eingebogen; sie wurden drei Tage lang in Wasser gelassen, und eins breitete sich theilweise wieder aus und er-# Einleitung
holte sich. Zwei Blätter wurden zunächst jedes in dreiszig Minims einer Lösung von einem Theil auf 2000 Theile Wasser getaucht; dieses brachte sehr wenig Wirkung hervor, ausgenommen, dasz die meisten Tentakeln dicht an der Spitze des Blattstieles eingebogen wurden, als ob die Säure durch das abgeschnittene Ende aufgesaugt worden wäre.

# Salzsäure
Ein Theil auf 437 Theile Wasser; vier Blätter wurden wie vorher, jedes in dreiszig Minims, eingetaucht. Nach 6 Stunden war nur ein Blatt beträchtlich eingebogen. Nach 8 Stunden 15 Minuten hatte eins seine Tentakeln und Scheibe ordentlich eingebogen; die andern drei waren mäszig eingebogen und die Scheibe von einem nur unbe-
deutend. Die umgebende Flüssigkeit war gar nicht rosa gefärbt. Nach 25 Stunden fiengen drei dieser vier Blätter an, sich wieder auszubreiten, aber ihre Drüsen waren von einer rosa anstatt rothen Färbung; nach weiteren zwei Tagen breiteten sie sich vollständig wieder aus; aber das vierte Blatt blieb eingebogen, und schien sehr verletzt oder getödtet zu sein, seine Drüsen waren ganz weisz. Vier Blätter wurden dann, jedes mit dreiszig Minims von einem Theil auf 875 Theile Wasser ver-
sucht; nach 21 Stunden waren sie mäszig eingebogen; und nachdem sie in Wasser übertragen worden waren, breiteten sie sich in zwei Tagen vollständig wieder aus, und schienen ganz gesund.

# Jodwasserstoffsäure
Ein Theil auf 437 Theile Wasser; drei Blätter wurden wie vorher, jedes in dreiszig Minims getaucht. Nach 45 Minuten waren die Drüsen entfärbt, und die umgebende Flüssigkeit war leicht rosa gefärbt, aber keine Einbiegung war da. Nach 5 Stunden waren alle Tentakeln dicht eingebogen; und eine ungeheure Menge von Schleim war abgesondert, so dasz die Flüssigkeit in langen Fäden ausge-
zogen werden konnte. Die Blätter wurden dann in Wasser gelegt, brei-
teten sich aber nie wieder aus und waren augenscheinlich getödtet. Vier Blätter wurden demnächst in einen Theil auf 875 Theile Wasser einge-
taucht; die Wirkung war nun langsamer, aber nach 22 Stunden waren alle vier Blätter dicht eingebogen, und waren auch in anderen Beziehun-
gen afficirt, wie oben beschrieben. Diese Blätter breiteten sich nicht wieder aus, obgleich sie vier Tage in Wasser gelassen wurden. Diese Säure wirkt viel kraftvoller als Salzsäure, und ist giftig.

# Jodsäure
Ein Theil auf 437 Theile Wasser; drei Blätter wurden, jedes in dreiszig Minims getaucht; nach 3 Stunden starke Ein-
biegung; nach 4 Stunden waren die Drüsen dunkelbraun; nach 8 Stun-
den 30 Minuten dichte Einbiegung und die Blätter waren schlaff gewor-
den; die umgebende Flüssigkeit nicht rosa gefärbt. Diese Blätter wurden dann in Wasser gelegt und waren am nächsten Tage augenscheinlich todt.

# Schwefelsäure
Ein Theil auf 437 Theile Wasser; vier Blätter wurden jedes in dreiszig Minims getaucht; nach 4 Stunden bedeutende Einbiegung; nach 6 Stunden war die umgebende Flüssigkeit gerade leicht rosa gefärbt; sie wurden dann in Wasser gelegt, und nach 46 Stunden waren zwei derselben noch dicht eingebogen, zwei fiengen an, sich wieder auszubreiten; viele der Drüsen waren farblos. Diese Säure ist nicht so giftig wie Salz- oder Jodsäure.

# Phosphorsäure
Ein Theil auf 437 Theile Wasser; drei Blät-
ter wurden zusammen in neunzig Minims getaucht; nach 5 Stunden 32 Mi-
nuten etwas Einbiegung, und einige Drüsen farblos; nach 8 Stunden alle Tentakeln dicht eingebogen, und viele Drüsen farblos; die umgebende Flüssigkeit rosa. In Wasser zwei und einen halben Tag gelassen blieben sie in demselben Zustand und schienen todt zu sein.

# Borsäure
Ein Theil auf 437 Theile Wasser; vier Blätter wur-
den zusammen in 120 Minims getaucht; nach 6 Stunden sehr leichte Einbiegung, nach 8 Stunden 15 Minuten waren zwei beträchtlich, die andern zwei leicht eingebogen. Nach 24 Stunden war ein Blatt ziemlich dicht eingebogen, das zweite weniger dicht, das dritte und vierte mäszig. Die Blätter wurden gewaschen und in Wasser gelegt; nach 24 Stunden waren sie beinah vollständig wieder ausgebreitet, und sahen gesund aus. Diese Säure stimmt mit Salzsäure derselben Stärke, in ihrer Fähigkeit Einbiegung zu verursachen, nahe überein, und ist, wie jene auch, nicht giftig.# Wirkung von Säuren

## Ameisensäure
Vier Blätter wurden zusammen in 120 Minims von einem Theil auf 437 Theile Wasser getaucht; nach 40 Minuten leichte und nach 6 Stunden 30 Minuten sehr mäßige Einbiegung; nach 22 Stunden nur wenig mehr Einbiegung als oft in Wasser vorkommt. Zwei der Blätter wurden dann gewaschen und in eine Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak gelegt; nach 24 Stunden waren sie beträchtlich eingebogen und der Inhalt ihrer Zellen zusammengeballt, welches zeigte, dass das phosphorsaure Salz gewirkt hat, obgleich nicht bis zum vollen und gewöhnlichen Grad.

## Essigsäure
Vier Blätter wurden zusammen in 120 Minims von einem Theil auf 437 Theile Wasser getaucht. In 1 Stunde 20 Minuten waren die Tentakeln aller vier und die Scheiben von zweien stark eingebogen. Nach 8 Stunden waren die Blätter schlaff geworden, aber blieben noch dicht eingebogen, die umgebende Flüssigkeit war rosa geworden. Sie wurden dann gewaschen und in Wasser gelegt; am nächsten Morgen waren sie noch eingebogen und von sehr dunkelrother Färbung, aber ihre Drüsen farblos. Nach einem weiteren Tage waren sie trüb gefärbt und augenscheinlich tot. Diese Säure ist viel wirksamer als Ameisensäure und in hohem Grade giftig. Halbe Minim-Tropfen einer stärkeren Mischung (nämlich ein Theil, nach Maß, auf 320 Theile Wasser) wurden auf die Scheiben von 5 Blättern gelegt; keiner der äußeren Tentakeln, nur die auf den Rändern der Scheibe, welche tatsächlich die Säure aufsaugten, wurden eingebogen. Wahrscheinlich war die Dosis zu stark und lähmte die Blätter, denn Tropfen einer schwächeren Wirkung verursachten bedeutende Einbiegung; demohngeachtet starben die Blätter alle nach zwei Tagen.

## Propionsäure
Drei Blätter wurden in neunzig Minims einer Mischung von einem Theil auf 437 Theile Wasser getaucht; in 1 Stunde 50 Minuten war keine Einbiegung da; aber nach 3 Stunden 40 Minuten war ein Blatt stark eingebogen und die andern zwei leicht. Die Einbiegung fuhr fort, zuzunehmen, so dass in 8 Stunden alle drei Blätter dicht eingebogen waren. Am nächsten Morgen, nach 20 Stunden, waren die meisten Drüsen sehr blass, aber ein paar waren beinahe schwarz. Kein Schleim war abgesondert worden, und die umgebende Flüssigkeit war nur gerade bemerkbar mit einem blassen Rosa gefärbt. Nach 46 Stunden wurden die Blätter leicht schlaff und waren augenscheinlich getötet, was später durch das Liegenlassen derselben in Wasser als richtig bewiesen wurde. Das Protoplasma in den dicht eingebogenen Tentakeln war nicht im Geringsten zusammengeballt, aber nach ihren Basen zu war es zu kleinen bräunlichen Massen auf dem Boden der Zellen angesammelt. Dieses Protoplasma war tot; denn als das Blatt in einer Lösung von kohlensaurem Ammoniak gelassen wurde, trat keine Zusammenballung ein. Propionsäure ist in hohem Grade giftig für die Drosera wie die verwandte Essigsäure, aber verursacht Einbiegung in einem viel langsameren Tempo.

## Ölsäure
Drei Blätter wurden in diese Säure getaucht, etwas Einbiegung wurde beinahe sofort verursacht, welche leicht zunahm, aber dann aufhörte; die Blätter schienen dann getötet zu sein. Am nächsten Morgen waren sie ziemlich zusammengeschrumpft und viele Drüsen waren von den Tentakeln abgefallen. Tropfen dieser Säure wurden auf die Scheiben von vier Blättern gebracht; in 40 Minuten waren alle Tentakeln stark eingebogen, ausgenommen die äußersten randständigen; und viele dieser wurden nach 3 Stunden eingebogen. Ich war dadurch darauf geführt worden, diese Säure zu versuchen, als ich vermutete, dass sie in Olivenöl vorhanden sei, was nicht der Fall zu sein scheint. Die Artikel über Glycerin und Ölsäure in Watt’s Diction. of Chemistry., dessen Wirkung so anomal ist. So verursachen Tropfen dieses Öls, auf die Scheiben gebracht, keine Einbiegung der äußeren Tentakeln; als jedoch kleine Tropfen zu dem, die Drüsen der äußeren Tentakeln umgebenden Sekrete hinzugefügt wurden, wurden dieselben gelegentlich, aber durchaus nicht immer, eingebogen. Zwei Blätter wurden auch in dieses Öl eingetaucht und in ungefähr 12 Stunden war keine Einbiegung da; aber nach 23 Stunden waren bei...# Einbiegung von Blättern in verschiedenen Lösungen

## Lein-Öl

## Carbolsäure

## Milchsäure

## Wirkung von Säuren# Experimentelle Ergebnisse

## Tannin- und Weinsteinsäure

## Äpfelsäure

## Oxalsäure

## Benzoësäure

## Bernsteinsäure

## Harnsäure

## Hippursäure# Flüssigkeit und Drüsenverhalten

Flüssigkeit rosa gefärbt; die Drüsen blasz, aber keine Einbiegung. Nach 6 Stunden etwas Einbiegung; nach 9 Stunden alle vier Blätter stark eingebogen; viel Schleim abgesondert; alle Drüsen sehr blasz. Die Blätter wurden dann zwei Tage lang in Wasser gelassen; sie blieben dicht ein- gebogen, ihre Drüsen farblos; ich bezweifle nicht, dasz sie getödtet waren.

# Cyanwasserstoffsäure (Blausäure)

Cyanwasserstoffsäure (Blausäure). — Vier Blätter wurden, jedes in dreiszig Minims von einem Theil auf 437 Theile Wasser getaucht, in 2 Stunden 45 Minuten waren alle Tentakeln beträchtlich eingebogen, und viele der Drüsen blasz; nach 3 Stunden 45 Minuten alle stark ein- gebogen, und die umgebende Flüssigkeit rosa gefärbt; nach 6 Stunden alle dicht eingebogen. Nach einem 8 Stunden 20 Minuten langem Ein- tauchen wurden die Blätter gewaschen und in Wasser gelegt; am näch- sten Morgen, nach ungefähr 16 Stunden, waren sie noch eingebogen und entfärbt; am folgenden Tage waren sie augenscheinlich todt. Zwei Blätter wurden in eine stärkere Mischung eingetaucht, von einem Theil auf fünfzig Theile Wasser; in 1 Stunde 15 Minuten waren die Drüsen so weisz wie Porzellan, als ob sie in kochendes Wasser getaucht worden wären; sehr wenig Tentakeln waren eingebogen; aber nach 4 Stunden waren beinahe alle eingebogen. Diese Blätter wurden dann in Wasser gelegt, und waren am nächsten Morgen augenscheinlich todt. Halbe Minims-Tropfen derselben Stärke (nämlich ein Theil auf fünfzig Theile Wasser) wurden zunächst auf die Scheiben von fünf Blättern gebracht; nach 21 Stunden waren alle äuszeren Tentakeln eingebogen und die Blätter schienen sehr verletzt. Ich berührte gleichfalls die Absonderung um eine grosze Menge Drüsen mit kleinen Tropfen (ungefähr \frac {1}{20} Minim oder 0,00296 Cub. Cent.) von Scheele’s Mischung (6 Procent). Die Drüsen wurden zuerst hell roth, und nach 3 Stunden 15 Minuten waren ungefähr zwei Drittel der Tentakeln, die diese Drüsen trugen, eingebogen und blieben die beiden folgenden Tage so, wo sie dann todt zu sein schienen.

# Schluszbemerkungen über die Säuren

Cap. 8. Schluszbemerkungen über die Säuren. Schluszbemerkungen über die Wirkung von Säuren. — Es ist augenscheinlich, dasz Säuren eine starke Neigung haben, die Einbiegung der Tentakeln zu verursachen; denn von den vier und zwanzig versuchten Säuren wirkten neunzehn in dieser Weise, ent- weder schnell und energisch, oder langsam und unbedeutend. Diese Thatsache ist merkwürdig, da die Säfte vieler Pflanzen mehr Säure enthalten, nach dem Geschmack zu urtheilen, als die bei meinen Ver- suchen angewendeten Lösungen. Nach den kräftigen Wirkungen so vieler Säuren auf die Drosera werden wir veranlasst anzunehmen, dasz die in den Geweben sowohl dieser Pflanze, als auch anderer, natürlich enthaltenen Säuren eine wichtige Rolle in ihrem Haushalte spielen müssen. Von den fünf Fällen, in welchen die Säuren keine Einbiegung der Tentakeln bewirkten, ist einer zweifelhaft; denn Harn- säure wirkte unbedeutend und verursachte eine reichliche Absonderung von Schleim. Blosz saures Gefühl für den Geschmack ist kein Beweis der Wirkungsfähigkeit einer Säure auf die Drosera, da Citronen- und Weinsteinsäure sehr sauer schmecken und doch keine Einbiegung erregen. Es ist merkwürdig, wie Säuren in ihrer Kraft von einander verschieden sind. So wirkt Salzsäure viel weniger kräftig, als Jod- wasserstoffsäure und viele andere Säuren derselben Stärke, und ist nicht giftig. Dies ist eine interessante Thatsache, da die Salzsäure eine so wichtige Rolle in dem Verdauungsprocesz der Thiere spielt. Ameisensäure bringt sehr leichte Einbiegung hervor und ist nicht giftig; während die ihr verwandte Essigsäure schnell und kräftig wirkt und giftig ist. Äpfelsäure wirkt sehr leicht, während Citronen- und Weinsteinsäure keine Wirkung hervorbringen. Milchsäure ist giftig und ist merkwürdig, weil sie Einbiegung nur nach Verlauf einer beträchtlichen Zeit bewirkt. Nichts überraschte mich mehr, als dasz eine Lösung von Benzoësäure, so schwach, dasz sie für den# Einleitung
Geschmack kaum säuerlich war, mit groszer Schnelligkeit wirkte, und sehr giftig war; denn man hat mir mitgetheilt, dasz sie keine aus- gesprochene Wirkung auf den thierischen Haushalt hervorbringt. Man wird beim Durchsehen der Liste am Anfang dieser Erörterung sehen, dasz die meisten Säuren giftig sind, oft sogar sehr. Es ist bekannt, Darwin, Insectenfressende Pflanzen. (VIII.) 12 Drosera rotundifolia. Cap. 8.

# Säuren und ihre Wirkungen
dasz verdünnte Säuren negative OsmoseMiller’s Elements of Chemistry, Part. I. 1867, p. 87. verursachen, und die giftige Wirkung so vieler Säuren auf Drosera hängt vielleicht mit dieser Kraft zusammen; denn wir haben gesehen, dasz die Flüssigkeiten, in welche sie getaucht wurden, oft rosa, und die Drüsen blasz farbig oder weisz wurden. Viele der giftigen Säuren, wie Jodwasserstoff-, Benzoë-, Hippur- und Carbolsäure (ich versäumte aber, alle Fälle auf- zuzählen) verursachten die Absonderung einer auszerordentlichen Menge von Schleim, so dasz lange Fäden dieser Substanz von den Blättern herabhiengen, als sie aus der Lösung gehoben wurden. Andere Säuren, solche wie Salzsäure und Äpfelsäure, haben keine solche Neigung; in diesen letzten zwei Fällen war die umgebende Flüssigkeit nicht rosa gefärbt, und die Blätter waren nicht vergiftet. Auf der andern Seite verursacht Propionsäure, welche giftig ist, keine starke Abson- derung von Schleim, doch wurde die umgebende Flüssigkeit leicht rosa. Endlich wirkte, wie es mit den salzigen Lösungen der Fall war, nachdem die Blätter in gewisse Säuren getaucht gewesen waren, phosphorsaures Ammoniak bald auf dieselben ein, während sie anderer- seits nach einem Eintauchen in gewisse andere Säuren nicht so afficirt wurden. Ich werde jedoch auf diesen Gegenstand zurückkommen müssen.

# Neuntes Kapitel
Die Wirkungen gewisser alkoloiden Gifte, andrer Substanzen und Dämpfe. Strychninsalze. — Schwefelsaures Chinin unterbricht nicht bald die Bewegung des Protoplasma. — Andere Chininsalze. — Digitalin. — Nicotin. — Atropin. — Veratrin. — Colchicin. — Theïn. — Curare. — Morphium. — Hyoscyamus. — Das Gift der Cobra beschleunigt dem Anscheine nach die Bewegungen des Protoplasma. — Campher, ein kräftiges Reizmittel, seine Dämpfe narcotisch. — Gewisse ätherische Öle erregen Bewegung. — Glycerin. — Wasser und ge- wisse Lösungen verzögern oder verhindern die spätere Wirkung des phosphor- sauren Ammoniaks. — Alkohol unschädlich, sein Dampf narcotisch und giftig. — Chloroform, Schwefel- und Salpeter-Äther, ihre reizenden, giftigen und nar- cotischen Eigenschaften. — Kohlensäure narcotisch, nicht schnell giftig. — Schluszbemerkungen.

# Versuche und Ergebnisse
Wie im letzten Capitel will ich zuerst meine Versuche mittheilen, und dann eine kurze Übersicht der Resultate mit einigen Schlusz- bemerkungen geben. Essigsaures Strychnin. — Halbe Minims einer Lösung von einem Theil auf 437 Theile Wasser wurden auf die Scheiben von sechs Blättern gelegt, so dasz jedes \frac {1}{960} Gran oder 0,0675 Milligr. erhielt. In 8 Stunden 30 Minuten waren die äuszeren Tentakeln auf einigen Blättern eingebogen, aber in einer unregelmäszigen Weise, manchmal nur auf einer Seite des Blattes. Am nächsten Morgen, nach 22 Stunden 30 Minuten, hatte die Einbiegung nicht zugenommen. Die Drüsen auf der mittleren Scheibe waren geschwärzt, und hatten aufgehört abzusondern. Nach 24 Stunden schienen alle mittleren Drüsen todt zu sein, aber die einge- bogenen Tentakeln hatten sich wieder ausgebreitet und erschienen ganz gesund. Es scheint daher die giftige Thätigkeit des Strychnins auf die Drüsen, welche es aufgesaugt haben, beschränkt zu sein; demungeachtet senden diese Drüsen den äuszeren Tentakeln einen motorischen Impuls zu. Kleine Tropfen (ungefähr \frac {1}{20} Minim) derselben Lösung an die Drüsen der äuszeren Tentakeln gehalten, verursachten gelegentlich eine Einbiegung. Das Gift scheint nicht schnell zu wirken, denn nachdem gleiche Tropfen einer eher stärkeren Lösung, von einem Theil auf 292 Theile Wasser, an# Drosera rotundifolia

## Tentakelnbewegung und Drüsenreaktion

## Wirkung von citronensauren Strychnin

## Einfluss von starken Lösungen

## Beobachtungen bei verschiedenen Blättern

## Wirkung von schwefelsauren Chinin# Einleitung

# Experimentelle Beobachtungen

# Protoplasma und Bewegung

# Wirkung von Chinin

# Zusammenballung des Protoplasmas

# Giftigkeit von Chinin

# Essigsaures Chinin# Einleitung

Minims einer Lösung von einem Theil auf 437 Theile Wasser getaucht. Die Lösung wurde mit Lackmus-Papier versucht, und war nicht sauer. Nach nur 10 Minuten waren alle vier Blätter bedeutend, und nach 6 Stunden ungeheuer eingebogen. Sie wurden dann 60 Stunden lang in Wasser gelassen, aber breiteten sich nie wieder aus; die Drüsen waren weisz und die Blätter augenscheinlich todt. Dieses Salz ist viel wirk-samer als das schwefelsaure in Bezug auf das Herbeiführen von Einbie-gung, und wie jenes Salz ist es bedeutend giftig.

# Salpetersaures Chinin

Salpetersaures Chinin. — Vier Blätter wurden jedes in dreiszig Minims einer Lösung von einem Theil auf 437 Theile Wasser getaucht. Nach 6 Stunden war kaum eine Spur von Einbiegung da; nach 22 Stunden waren drei der Blätter mäszig und das vierte leicht eingebogen; so dasz dieses Salz, obgleich ziemlich langsam, gut ausgesprochene Einbie-gung hervorbringt. Nachdem diese Blätter 48 Stunden lang in Wasser gelassen worden waren, breiteten sie sich beinahe vollständig wieder aus, aber die Drüsen waren sehr entfärbt. Es ist daher dies Salz nicht in irgend welchem hohen Grade giftig. Die verschiedene Wirkung der drei vorstehend erwähnten Salze des Chinins ist eigenthümlich.

# Digitalin

Digitalin. — Halbe Minims einer Lösung von einem Theil auf 437 Theile Wasser wurden auf die Scheiben von fünf Blättern gebracht. In 3 Stunden 45 Minuten hatten einige derselben ihre Tentakeln und eins seine Scheibe mäszig eingebogen. Nach 8 Stunden waren drei der-selben gut eingebogen; das vierte hatte nur einige Tentakeln eingebogen, und das fünfte (ein altes Blatt) war durchaus gar nicht afficirt. Sie blieben zwei Tage lang in beinahe demselben Zustand, aber die Drüsen auf ihren Scheiben wurden blasz. Am dritten Tage schienen die Blätter sehr verletzt zu sein. Demungeachtet wurden die äuszeren Tentakeln, als Stückchen Fleisch auf zwei derselben gelegt wurden, eingebogen. Ein minutiöser Tropfen (ungefähr \frac {1}{20} Minim) der Lösung wurde an drei Drüsen gehalten, und nach 6 Stunden waren alle drei Tentakeln eingebogen, aber hatten sich am nächsten Tage beinahe wieder ausgebreitet, so dasz diese sehr kleine Dosis von \frac {1}{28800} Gran (0,00225 Milligr.) auf einen Tentakel einwirkt, aber nicht giftig ist. Es scheint nach diesen verschiedenen Thatsachen, dasz Digitalin Einbiegung verursacht, und die Drüsen, welche eine mäszig grosze Menge aufsaugen, vergiften.

# Nicotin

Nicotin. — Die Absonderung um mehrere Drüsen wurde mit minu-tiosen Tropfen der reinen Flüssigkeit berührt, und die Drüsen wurden augenblicklich geschwärzt; die Tentakeln wurden in wenig Minuten ein-biegen. Zwei Blätter wurden in eine schwache Lösung von 2 Tropfen auf 1 Unze oder 437 Gran Wasser getaucht. Als sie nach 3 Stunden 20 Minuten untersucht wurden, waren nur ein und zwanzig Tentakeln an einem Blatt dicht eingebogen, und sechs unbedeutend am andern; aber alle Drüsen waren geschwärzt oder sehr dunkelfarbig, das Protoplasma in allen Zellen aller Tentakeln bedeutend zusammengeballt und dunkelfarbig. Die Blätter waren nicht ganz getödtet; denn als sie in ein wenig Lösung von kohlensaurem Ammoniak (2 Gran auf 1 Unze) gebracht wurden, wur-den noch einige weitere Tentakeln eingebogen; auf die übrigen aber wirkte während der nächsten 24 Stunden die Lösung nicht ein. Halbe Minims einer stärkeren Lösung (2 Tropfen auf ½ Unze Wasser) wurden auf die Scheiben von sechs Blättern gebracht, und in 30 Minuten wurden alle diese Tentakeln eingebogen; ihre Drüsen hatten wirklich die Lösung berührt, was durch ihre Schwärze bewiesen wurde; aber kaum irgend ein motorischer Impuls wurde nach den äuszeren Tentakeln hin-gesendet. Nach 22 Stunden schienen die meisten Drüsen todt zu sein; aber dies kann nicht der Fall gewesen sein, denn als Stückchen Fleisch auf drei derselben gebracht wurden, wurden einige wenige der äuszern Tentakeln in 24 Stunden eingebogen. Daher hat Nicotin eine grosze Neigung, die Drüsen zu schwärzen und Zusammenballung des Protoplasma hervorzurufen; aber ausgenommen, wenn es rein angewendet wird, hat es nur in sehr mäszigem Grade die Fähigkeit, Einbiegung hervorzurufen, und noch weniger Fähigkeit, einen motorischen Einflusz von den Scheiben-# Einleitung
ständigen Drüsen nach den äuszern Tentakeln zu übermitteln. Es ist mäszig giftig.

# Atropin
Atropin. — Ein Gran wurde zu 437 Theilen Wasser gethan, aber es wurde nicht alles aufgelöst; ein andrer Gran wurde zu 437 Gran einer Mischung von einem Theil Alkohol auf sieben Theile Wasser hinzugefügt; und eine dritte Lösung wurde gemacht durch Hinzufügen eines Theils von valeriansaurem Atropin auf 437 Theile Wasser. Halbe Minims dieser drei Lösungen wurden in jedem einzelnen Falle auf die Scheiben von sechs Blättern gebracht; aber durchaus keine Wirkung wurde hervorgerufen, ausgenommen, dasz die Drüsen auf den Scheiben, welchen das Drosera rotundifolia. Cap. 9. valeriansaure Atropin gegeben war, gering entfärbt wurden. Den sechs Blättern, auf welchen Tropfen der Lösung von Atropin in verdünntem Alkohol 21 Stunden lang gelassen worden waren, wurden Stückchen Fleisch gegeben, und alle wurden in 24 Stunden ziemlich gut eingebogen, so dasz Atropin keine Bewegung erregt, und nicht giftig ist. Ich versuchte auf dieselbe Weise das Alkaloid, welches als Daturin verkauft wird, von dem man aber glaubt, dasz es von Atropin nicht verschieden ist, und es brachte keine Wirkung hervor. Dreien der Blätter, auf welchen Tropfen dieser letzteren Lösung 24 Stunden lang gelassen worden waren, wurden gleichfalls Stückchen Fleisch gegeben, und sie hatten im Lauf von 24 Stunden eine gute Menge ihrer halbrandständigen Tentakeln eingebogen.

# Veratrin, Colchicin, Theïn
Veratrin, Colchicin, Theïn. — Lösungen dieser drei Alkaloide wurden so bereitet, dasz ein Theil zu 437 Theile Wasser gethan wurde. Halbe Minims wurden in jedem einzelnen Fall auf die Scheiben von wenigsten sechs Blättern gebracht, es wurde aber keine Einbiegung verur-sacht, ausgenommen vielleicht ein sehr leichter Grad durch das Theïn. Halbe Minims eines starken Aufgusses von Thee brachten, wie vorher angegeben, keine Wirkung hervor. Ich versuchte auch ähnliche Tropfen eines Aufgusses von einem Theil des von Apothekern verkauften Extracts von Colchicum auf 218 Theile Wasser; die Blätter wurden indesz 48 Stunden lang beobachtet, ohne dasz eine Wirkung hervorgebracht worden wäre. Den sieben Blättern, auf welchen Tropfen des Veratrins 26 Stunden lang gelassen worden waren, wurden Stückchen Fleisch gegeben, und nach 21 Stunden waren sie gut eingebogen. Diese drei Alkaloide sind daher ganz unschädlich.

# Curare
Curare. — Ein Theil dieses berühmten Giftes wurde 218 Theilen Wasser zugesetzt, und drei Blätter in neunzig Minims der filtrirten Lösung getaucht. In 3 Stunden 30 Minuten waren einige der Tentakeln ein wenig eingebogen; wie die Scheibe des einen nach 4 Stunden. Nach 7 Stunden waren die Drüsen wunderbar geschwärzt, was bewies, dasz Substanz irgend welcher Art aufgesaugt worden war. In 9 Stunden hatten zwei der Blätter die meisten ihrer Tentakeln halb eingebogen, aber die Einbiegung nahm im Laufe von 24 Stunden nicht zu. Eins dieser Blätter wurde, nach einem 9 Stunden langen Eintauchen in die Lösung, in Wasser gebracht und hatte sich am nächsten Morgen zum groszen Theile wieder ausgebreitet. Die andern zwei wurden nach einem 24 Stunden langen Eintauchen gleichfalls in Wasser gebracht, und waren in 24 Stunden beträchtlich wieder ausgebreitet, obgleich ihre Drüsen so schwarz wie je waren. Halbe Minims wurden auf die Scheiben von sechs Blättern gebracht, und keine Einbiegung erfolgte; aber nach drei Tagen schienen die Drüsen auf den Scheiben ziemlich trocken zu sein, doch waren sie zu meinem Erstaunen nicht geschwärzt. Bei einer andern Gelegenheit wurden Tropfen auf die Scheiben von sechs Blättern gebracht, und bald war ein beträchtlicher Grad von Einbiegung bewirkt worden; aber da ich die Lösung nicht filtrirt hatte, so können kleine herumschwimmende Theilchen auf die Drüsen gewirkt haben. Nach 24 Stunden wurden Stückchen Fleisch auf die Scheiben von dreien dieser Blätter gebracht, und am nächsten Tage wurden sie stark eingebogen. Da ich zuerst dachte, das Gift könnte in reinem Wasser nicht aufgelöst sein, wurde ein Gran zu 437 Gran einer Mischung von einem Theil Alkohol auf sieben Theile Wasser gesetzt und davon halbe Minims auf die Scheiben von sechs Blättern ge-# Einleitung
bracht. Diese wurden gar nicht afficirt, und als ihnen nach Verlauf eines Tages Stückchen Fleisch gegeben wurden, waren sie in 5 Minuten leicht und in 24 Stunden dicht eingebogen. Es folgt aus diesen verschiedenen Thatsachen, dasz eine Lösung von Curare einen sehr mäszigen Grad von Einbiegung bewirkt, und dies mag vielleicht Folge der Gegenwart einer minutiösen Menge von Eiweisz sein. Es ist sicher nicht giftig. Das Protoplasma in einem der Blätter, welches 24 Stunden lang eingetaucht gewesen und gering eingebogen worden war, hatte einen sehr geringen Grad von Zusammenballung erfahren, nicht mehr als oft nach einem Ein-tauchen von dieser Dauer in Wasser vorkommt.

# Essigsaures Morphium
Essigsaures Morphium. — Ich machte eine grosze Anzahl Versuche mit dieser Substanz, aber mit keinem sicheren Resultat. Eine beträchtliche Anzahl Blätter wurden von 2 bis 6 Stunden lang in eine Lösung von einem Theil auf 218 Theile Wasser getaucht, und wurden nicht eingebogen. Auch waren sie nicht vergiftet, denn als sie gewaschen und in schwache Lösungen von phosphorsaurem und kohlensaurem Ammoniak gelegt wurden, wurden sie bald stark eingebogen, und das Protoplasma in ihren Zellen gut zusammengeballt. Wenn jedoch, während die Blätter in die Morphiumlösung getaucht waren, phosphorsaures Ammoniak hinzu-gesetzt wurde, trat Einbiegung nicht schnell ein. Minutiöse Tropfen der Lösung wurden in der gewöhnlichen Weise an die Absonderung um dreiszig bis vierzig Drüsen gehalten; und als nach einer 6 Minuten langen Pause Stückchen Fleisch, etwas Speichel oder Glastheilchen auf dieselben ge-bracht wurden, war die Bewegung der Tentakeln bedeutend verlangsamt. Aber bei andern Gelegenheiten kam keine solche Verzögerung vor. Ähnlich angewendete Tropfen Wasser haben nie irgend eine verzögernde Wirkung. Minutiöse Tropfen einer Lösung von Zucker von derselben Stärke (ein Theil auf 218 Theile Wasser) verzögerte manchmal die fol-gende Wirkung von Fleisch und Glastheilchen, und manchmal that es dies nicht. Einmal fühlte ich mich überzeugt, dasz Morphium wie ein Narcoticum auf die Drosera wirkte; aber nachdem ich gefunden hatte, in welch’ eigenthümlicher Weise das Eintauchen in gewisse nicht giftige Salze und Säuren die folgende Wirkung von phosphorsaurem Ammoniak verhindert, während andere Lösungen keine solche Wirkung äuszern, er-scheint meine frühere Überzeugung sehr zweifelhaft.

# Hyoscyamus-Extract
Hyoscyamus-Extract. — Mehrere Blätter wurden jedes in dreiszig Minims eines Aufgusses von 3 Gran des von Apothekern ver-kauften Extracts auf 1 Unze Wasser gebracht. Eins derselben war, nach- dem es 5 Stunden 15 Minuten lang eingetaucht gewesen war, nicht ein-biegen, und wurde dann in eine Lösung (1 Gran auf 1 Unze) von kohlensaurem Ammoniak gelegt; nach 2 Stunden 40 Minuten wurde es bedeutend eingebogen gefunden, und die Drüsen sehr geschwärzt. Vier von diesen Blättern wurden, nachdem sie 2 Stunden 14 Minuten lang eingetaucht gewesen, in 120 Minims einer Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak gebracht; sie waren schon durch das Hyoscyamus-Extract unbedeutend eingebogen worden, wahrscheinlich in Drosera rotundifolia. Cap. 9. Folge der Gegenwart von etwas eiweiszartiger Substanz, wie vorher aus-einandergesetzt wurde; aber die Einbiegung nahm augenblicklich zu, und war nach 1 Stunde stark ausgesprochen; so dasz Hyoscyamus nicht wie ein Narcoticum oder ein Gift wirkt.

# Gift aus dem Giftzahn einer lebenden Otter
Gift aus dem Giftzahn einer lebenden Otter. — Minutiöse Tropfen wurden auf die Drüsen von vielen Tentakeln gebracht; diese wurden schnell eingebogen, gerade als ob ihnen Speichel gegeben worden wäre. Am nächsten Morgen, nach 17 Stunden 30 Minuten, fiengen alle an, sich wieder auszubreiten und sie schienen unverletzt zu sein.

# Gift der Cobra
Gift der Cobra (Brillenschlange). — Dr. Fayrer, durch seine Untersuchungen über das Gift dieser tödtlichen Schlange wohl bekannt, war so gütig, mir etwas davon in getrocknetem Zustande zu geben. Es ist eine eiweiszartige Substanz und man glaubt, dasz sie das Ptyalin des Speichels ersetzeDr. Fayrer, The Thanatophidia of India, 1872, p. 150.. Ein kleiner Tropfen (ungefähr \frac {1}{20} Minim) einer Lösung von einem Theil auf 437 Theile Wasser wurde an das Secret um vier Drüsen gehalten, so dasz jede nur ungefähr \frac {1}{38400} Gran (0,0016# Experimentelle Beobachtungen

Die Operation wurde bei vier andern Drüsen wiederholt; und in 15 Minuten wurden mehrere der acht Tentakeln gut eingebogen, und sie alle in 2 Stunden. Am nächsten Morgen, nach 24 Stunden, waren sie noch eingebogen und die Drüsen von sehr blasz rosa Farbe. Nach weiteren 24 Stunden waren sie beinahe wieder ausgebreitet, und am folgenden Tage vollständig; aber die meisten Drüsen blieben beinahe weisz.

# Wirkung der Lösung

Halbe Minims derselben Lösung wurden auf die Scheiben von drei Blättern gebracht, so dasz jedes \frac {1}{960} Gran (0,0675 Milligr.) erhielt; in 4 Stunden 15 Minuten waren die äuszeren Tentakeln sehr eingebogen; und nach 6 Stunden 30 Minuten waren sie an zweien der Blätter dicht eingebogen, ebenso die Scheibe des einen; das dritte Blatt war nur mäßig afficirt. Die Blätter blieben während des nächsten Tages in dem selben Zustande, aber breiteten sich nach 48 Stunden wieder aus.

# Stärkere Lösung und deren Effekte

Drei Blätter wurden nun jedes in dreiszig Minims der Lösung eingetaucht, so dasz jedes \frac {1}{16} Gran oder 4,048 Milligr. erhielt. In 6 Minuten war etwas Einbiegung da, welche stetig zunahm, so dasz nach 2 Stunden 30 Minuten alle drei Blätter dicht eingebogen waren; die Drüsen waren zuerst etwas geschwärzt, und wurden dann blasz; und das Protoplasma in den Zellen der Tentakeln war theilweise zusammengeballt.

# Untersuchung des Protoplasmas

Die kleinen Massen von Protoplasma wurden nach 3 Stunden untersucht, und nach 7 Stunden wieder, und bei keiner andern Gelegenheit habe ich sie so rapide Formveränderungen erleiden sehen. Nach 8 Stunden 30 Minuten waren die Drüsen ganz weisz geworden; sie hatten keine große Menge Schleim abgesondert. Die Blätter wurden nun in Wasser gelegt, und waren nach 40 Stunden wieder ausgebreitet, wodurch bewiesen wurde, dasz sie nicht sehr oder gar nicht verletzt waren.

# Weitere Experimente mit starker Lösung

Zwei Blätter wurden ferner jedes in dreiszig Minims einer viel stärkeren Lösung, von einem Theil auf 109 Theile Wasser, getaucht; so dasz jedes ¼ Gran oder 16,2 Milligr. erhielt. Nach 1 Stunde 45 Minuten waren die halbrandständigen Tentakeln stark eingebogen, und die Drüsen etwas blasz; nach 3 Stunden 30 Minuten hatten beide Blätter alle ihre Tentakeln dicht eingebogen und die Drüsen waren weisz.

# Langzeitbeobachtungen

Nach einem 24 Stunden langen Eintauchen wurden einige der Tentakeln untersucht, und das Protoplasma, noch von schöner purpurner Färbung, wurde in Ketten von kleinen kugligen Massen zusammengeballt gefunden. Diese veränderten ihre Formen mit merkwürdiger Schnelligkeit. Nach einem 48 Stunden langen Eintauchen wurden sie wieder untersucht, und ihre Bewegungen waren so deutlich, dasz sie unter einer schwachen Vergrößerung leicht gesehen werden konnten.

# Rückkehr zur Normalität

Die Blätter wurden nun in Wasser gelegt, und nach 24 Stunden (d. h. 72 Stunden von ihrem ersten Eintauchen an) waren die kleinen Massen Protoplasma, welche von einem schmutzigen Purpur waren, noch in starker Bewegung, ihre Formen verändernd, sich vereinigend und wieder trennend. In 8 Stunden, nachdem sie in Wasser gelegen hatten (d. h. in 56 Stunden nach ihrem Eintauchen in die Lösung), fingen diese zwei Blätter an, sich wieder auszubreiten und waren am nächsten Morgen noch weiter ausgebreitet.

# Fazit der Beobachtungen

Nach Verlauf eines weiteren Tages (d. h. am vierten Tage nach ihrem Eintauchen in die Lösung) waren sie bedeutend aber nicht ganz vollständig wieder ausgebreitet. Die Tentakeln wurden nun untersucht, und die zusammengeballten Massen waren beinahe gänzlich wieder aufgelöst; die Zellen waren mit homogener purpurner Flüssigkeit, mit Ausnahme einer einzigen kugligen Masse hie und da, angefüllt. Wir sehen hieraus, wie vollständig das Protoplasma aller Verletzung durch das Gift entgangen war.# Protoplasma und Giftwirkungen

folglich, dasz das Protoplasma in diesen Zellen gar nicht afficirt worden wäre. Dem entsprechend brachte ich ein anderes Blatt, welches 48 Stunden lang in das Gift, und nachher 24 Stunden lang in Wasser gelegt worden war, in ein wenig Lösung von einem Theil kohlensauren Ammoniak auf 218 Theile Wasser; in 30 Minuten wurde das Protoplasma in den Zellen unter den Drüsen dunkler, und im Lauf von 24 Stunden waren die Tentakeln bis hinunter zu ihren Basen mit dunkelfarbigen kugligen Massen angefüllt. Es hatten daher die Drüsen ihre Fähigkeit zum Aufsaugen nicht verloren, so weit das kohlensaure Ammoniak in Betracht kommt.

# Wirkung des Cobra-Gifts

Nach diesen Thatsachen ist es offenbar, dasz das Gift der Cobra, obgleich Thieren so tödtlich, gar nicht giftig für die Drosera ist. Doch verursacht es starke und rapide Einbiegung der Tentakeln und entfernt bald alle Farbe aus den Drüsen. Es scheint selbst als ein Reizmittel auf das Protoplasma zu wirken, denn nach beträchtlicher Erfahrung im Beobachten der Bewegungen dieser Substanz bei der Drosera habe ich es bei keiner andern Gelegenheit in einem so thätigen Zustande gesehen. Ich war daher sehr gespannt, zu hören, wie dieses Gift auf thierisches Protoplasma wirke; und Dr. Fayrer war so gütig, einige Beobachtungen für mich zu machen, welche er seitdem veröffentlicht hat.

# Experimente mit Froschgewebe

Flimmer-epithelium aus der Mundhöhle eines Frosches wurde in eine Lösung von 0,03 Gramm auf 4,6 Cub. Cent. Wasser gebracht; andere Stücke zur selben Zeit zum Vergleich in reines Wasser. Die Bewegung der Wimpern in der Lösung schien zuerst zugenommen zu haben, nahm aber bald ab und hörte nach 15 bis 20 Minuten ganz auf, während jene im Wasser sich noch kräftig bewegten. Die weiszen Blutkörperchen eines Frosches und die Wimpern zweier Infusionsthiere, eines Paramaecium und eines Volvox, wurden durch das Gift ähnlich afficirt. Dr. Fayrer fand auch, dasz der Muskel eines Frosches seine Reizbarkeit nach einem 20 Minuten langen Eintauchen in die Lösung verlor, und dann einem starken elektrischen Strome nicht mehr antwortete. Auf der andern Seite wurden die Bewegungen der Wimpern auf dem Mantel eines Unio nicht immer zum Stillstand gebracht, selbst als sie eine beträchtliche Zeit in einer sehr starken Lösung gelassen worden waren. Im Ganzen scheint es, dasz das Gift der Cobra viel schädlicher auf das Protoplasma der höheren Thiere wirkt, als auf das der Drosera.

# Beobachtungen zu Sekreten

Ein anderer Punkt mag hier noch erwähnt werden. Ich habe gelegentlich beobachtet, dasz die Tropfen Secrets rings um die Drüsen durch gewisse Lösungen etwas trübe gemacht wurden, besonders aber durch einige Säuren, wobei sich ein Häutchen auf der Oberfläche der Tropfen bildete; aber niemals habe ich diese Wirkung in einer so auffallenden Weise hervorbringen sehen als durch das Gift der Brillenschlange. Wenn die stärkere Lösung angewendet wurde, erschienen die Tropfen in 10 Minuten wie kleine weisze abgerundete Wolken. Nach 48 Stunden hatte sich das Secret in Fäden und Platten einer häutigen Substanz verwandelt, welche sehr kleine Körnchen verschiedener Grösse einschlossen.

# Campher-Experimente

Campher. — Etwas abgekratzter Campher wurde einen Tag lang in einer Flasche mit destillirtem Wasser gelassen und dann filtrirt. Eine auf diese Weise dargestellte Lösung soll \frac {1}{1000} ihres Gewichts an Campher enthalten; sie roch und schmeckte nach dieser Substanz. Zehn Blätter wurden in diese Lösung eingetaucht; nach 15 Minuten waren fünf der selben gut eingebogen, zwei lieszen die erste Spur der Bewegung in 11 und 12 Minuten erkennen; das sechste Blatt fieng sich nicht eher zu bewegen an, als bis 15 Minuten verflossen waren, war aber in 17 Minuten ganz ordentlich eingebogen und in 24 Minuten vollständig geschlossen; das siebente fieng in 17 Minuten sich zu bewegen an und war in 26 Minuten vollständig geschlossen. Das achte, neunte und zehnte waren alte Blätter von sehr dunkelrother Färbung und diese waren nach einem Ein-tauchen von 24 Stunden nicht eingebogen, so dasz es beim Anstellen von Experimenten mit Campher nothwendig ist, solche Blätter zu vermeiden. Nachdem diese Blätter vier Stunden lang in der Lösung gelassen worden...# Campher und seine Wirkung auf Pflanzen

waren, wurden einige von ihnen ziemlich schmutzig rosa gefärbt, und
sonderten viel Schleim ab; obgleich ihre Tentakeln dicht eingebogen wur-
den, war das Protoplasma innerhalb der Zellen durchaus nicht zusammen-
geballt. Bei einer andern Gelegenheit indessen war nach einem längeren
Eintauchen von 24 Stunden gut ausgesprochene Zusammenballung vor-

## Beobachtungen von B. S. Barton

handen. Eine Lösung, welche so dargestellt worden war, dasz zwei Tropfen
Campherspiritus einer Unze Wasser zugesetzt wurde, wirkte auf ein Blatt
nicht ein; als dagegen dreiszig Minims einer Unze Wasser zugesetzt wurde,
wirkte diese Lösung auf zwei zusammen eingetauchte Blätter.
Vogel hat gezeigtGardener’s Chronicle, 1874, p. 671. Ziemlich ähnliche
Beobachtungen hat
im Jahre 1798 B. S. Barton gemacht., dasz die Blüthen verschiedener Pflanzen
nicht so
bald verwelken, wenn ihre Stengel in eine Lösung von Campher gestellt
werden, als wenn sie in Wasser stehen, und dasz sie sich, wenn sie
bereits leicht welk geworden sind, schneller wieder erholen. Auch das
Keimen gewisser Samen wird durch die Lösung beschleunigt. Es wirkt
daher Campher als Reizmittel, und es ist das einzige bekannte Reizmittel
für Pflanzen. Ich wünschte daher zu ermitteln, ob Campher die Blätter
der Drosera für mechanische Reizung empfindlicher machen würde, als
sie vorher waren. Sechs Blätter wurden 5 oder 6 Minuten lang in
destillirtem Wasser gelassen und dann, während sie noch unter Wasser
waren, sanft zwei- oder dreimal mit einem weichen Cameelhaarpinsel ge-
strichen; es folgte aber keine Bewegung. Dann wurden zunächst neun
Blätter, welche in der oben angegebenen Lösung eine verschieden
lange, in der unten folgenden Tabelle angeführte Zeit hindurch einge-
taucht worden waren, einmal mit demselben Pinsel und in derselben
Weise wie vorher bestrichen; die Resultate sind in der Tabelle mitge-
theilt. Meine ersten Versuche wurden so angestellt, dasz ich die Blätter
pinselte, während sie noch in der Lösung untergetaucht waren; es kam
mir aber der Gedanke, dasz dadurch das klebrige Secret rings um die
Drüsen entfernt werden und dann der Campher noch kräftiger auf sie
einwirken könnte. In allen folgenden Versuchen wurde daher jedes Blatt
aus der Lösung herausgenommen, ungefähr 15 Secunden lang in Wasser
umhergeschwenkt, dann in frisches Wasser gelegt und bepinselt, so dasz
das Pinseln keinen freieren Zutritt des Camphers gestatten kann; doch
machte diese Behandlungsweise keinen Unterschied in den Resultaten.

## Ergebnisse der Experimente

Drosera rotundifolia. Cap. 9.
Andere Blätter wurden in der Lösung gelassen, ohne bepinselt zu
werden; eines derselben zeigte eine Spur von Einbiegung nach 11 Mi-
nuten, ein zweites nach 12 Minuten, fünf wurden nicht eher eingebogen,
bis 15 Minuten verflossen waren und zwei noch ein paar Minuten später.
Andererseits wird man in der rechtsseitigen Columne der Tabelle sehen,
dasz die meisten von den der Lösung ausgesetzten Blättern, welche dann
bepinselt wurden, in einer viel kürzeren Zeit eingebogen wurden. Die
Bewegung der Tentakeln einiger dieser Blätter war so rapid, dasz sie
deutlich durch eine sehr schwache Lupe gesehen werden konnte.

## Weitere Experimente

Zwei oder drei andere Experimente sind noch der Mittheilung werth.
Ein groszes altes Blatt sah, nachdem es 10 Minuten in die Lösung ein-
taucht gewesen war, nicht so aus, als würde es bald eingebogen werden;
ich pinselte es daher, und in 2 Minuten fieng es an, sich zu bewegen
und war in 3 Minuten vollständig geschlossen. Ein anderes Blatt zeigte
nach einem Eintauchen von 17 Minuten kein Zeichen von Einbiegung;
es wurde denn nun bepinselt, bewegte sich aber eine Stunde lang nicht;
hier war ein Miserfolg. Es wurde nochmals bepinselt, und nun wurden
in 9 Minuten einige wenige Tentakeln eingebogen; das Mislingen war
daher nicht vollständig.

## Schlussfolgerung

Wir können wohl schlieszen, dasz eine kleine Dosis Campher in Lö-
sung ein kräftiges Reizmittel für Drosera ist. Es regt nicht blosz bald
die Tentakeln an, sich zu biegen, sondern macht auch allem Anscheine
nach die Drüsen für eine Berührung empfindlich, welche an und für sich
keine Bewegung bewirkt. Es könnte auch sein, dasz eine unbedeutende# Mechanische Reizung und Campher

mechanische Reizung, nicht stark genug, Einbiegung zu verursachen, doch ein gewisses Streben zur Bewegung mittheilt und dadurch die Wirkung des Camphers verstärkt. Diese letztere Ansicht würde mir als die wahrscheinlichere erschienen sein, wäre nicht von VOGEL gezeigt worden, dasz Campher auch auf andere Weise für verschiedene Pflanzen und Samen ein Reizmittel ist.

# Kümmel-Öl

Kümmel-Öl. — Es wird angegeben, dasz Wasser ungefähr ein Tausendstel seines Gewichts von diesem Öl auflöst. Ein Tropfen wurde zu einer Unze Wasser gesetzt und die Flasche während eines Tages gelegentlich geschüttelt; es blieben aber noch viele sehr kleine Kügelchen unaufgelöst. Fünf Blätter wurden in diese Mischung eingetaucht; innerhalb 4 bis 5 Minuten war etwas Einbiegung da, welche in zwei oder drei weiteren Minuten mäszig ausgesprochen wurde. Nach 4 Minuten waren alle fünf Blätter ordentlich, und einige von ihnen dicht eingebogen. Nach 6 Stunden waren die Drüsen weisz und viel Schleim abgesondert worden. Die Blätter waren nun welk, von einer eigenthümlichen trüb-rothen Färbung und offenbar todt. Eines der Blätter wurde nach einem Eintauchen von 4 Minuten gepinselt, wie die andern im Campher; dies brachte aber keine Wirkung hervor. Eine Pflanze, deren Wurzeln in Wasser standen, wurden nun unter einem Zehnunzen-Gefäsz dem Dampfe dieses Öls ausgesetzt, und in 1 Stunde 20 Minuten zeigte ein Blatt eine Spur von Einbiegung. Nach 5 Stunden 20 Minuten wurde die Decke abgenommen und die Blätter untersucht; bei einem waren alle Tentakeln dicht eingebogen, beim zweiten waren sie ungefähr halb in diesem Zustande, und beim dritten waren sie alle halb eingebogen. Die Pflanze wurde 42 Stunden lang an der freien Luft gelassen, es breitete sich aber nicht ein einziger Tentakel wieder aus; die sämmtlichen Drüsen erschienen todt, ausgenommen hier und da eine, welche noch immer absonderte. Offenbar ist dieses Öl in hohem Grade reizend und giftig für Drosera.

# Nelken-Öl

Nelken-Öl. — Es wurde in derselben Weise wie im letzten Falle eine Mischung gemacht und drei Blätter in dieselbe eingetaucht. Nach 30 Minuten war nur eine Spur von Einbiegung vorhanden, welche niemals zunahm. Nach 1 Stunde 30 Minuten waren die Drüsen blasz und nach 6 Stunden weisz. Ohne Zweifel waren die Blätter bedeutend beschädigt oder getödtet.

# Terpentin-Öl

Terpentin-Öl. — Kleine Tropfen auf die Scheiben einiger Blätter gelegt, tödteten dieselben, wie es gleichfalls Tropfen von Creosot thaten. Eine Pflanze wurde 15 Minuten lang unter einem Zwölfunzen-Glas gelassen, dessen innere Oberfläche mit zwölf Tropfen von Terpentin-Öl befeuchtet waren; es erfolgte aber keine Bewegung der Tentakeln. Nach 24 Stunden war die Pflanze todt.

# Glycerin

Glycerin. — Halbe Minims wurden auf die Scheiben von drei Blättern gebracht; in 2 Stunden waren einige der äuszeren Tentakeln unregelmäszig eingebogen; und in 19 Stunden waren die Blätter welk und allem Anscheine nach todt; die Drüsen, welche das Glycerin berührt hatten, waren farblos. Äuszerst kleine Tropfen (ungefähr \frac {1}{20} Minim) wurden an die Drüsen mehrerer Tentakeln gehalten, und in wenig Minuten bewegten sich diese und erreichten bald die Mitte. Ähnliche Tropfen einer Mischung von vier abgetropften Tropfen auf 1 Unze Wasser wurden in gleicher Weise an mehrere Drüsen gehalten; aber nur einige wenige Tentakeln bewegten sich und diese nur sehr langsam und unbedeutend.# Einleitung

Halbe Minims dieser selbigen Mischung auf die Scheiben einiger Blätter gebracht, verursachten zu meiner Überraschung im Verlaufe von 48 Stunden keine Einbiegung. Es wurden ihnen dann Stückchen Fleisch gegeben, und am nächsten Tage waren sie ordentlich eingebogen, trotzdem dasz einige der scheibenständigen Drüsen beinahe farblos gemacht worden waren. Zwei Blätter wurden in dieselbe Mischung, aber nur 4 Stunden lang eingetaucht; sie wurden nicht eingebogen, und nachdem sie später 2 Stunden 30 Minuten lang in einer Lösung (1 Gran auf 1 Unze) von kohlensaurem Ammoniak gelassen worden waren, wurden ihre Drüsen geschwärzt, ihre Tentakeln eingebogen, und das Protoplasma innerhalb ihrer Zellen zusammengeballt. Aus diesen Thatsachen geht hervor, dasz eine Mischung von vier Tropfen Glycerin auf eine Unze Wasser nicht giftig ist und sehr wenig Einbiegung anregt, dasz aber reines Glycerin giftig ist und, wenn es in sehr minutiösen Mengen an die Drüsen der äuszeren Tentakeln gebracht wird, deren Einbiegung verursacht.

# Wirkungen des Eintauchens in Wasser

Die Wirkungen des Eintauchens in Wasser und verschiedene Lösungen auf die spätere Einwirkung des phosphorsauren und kohlensauren Ammoniaks. — Wir haben im dritten und siebenten Capitel gesehen, dasz Eintauchen in destillirtes Wasser nach einiger Zeit einen gewissen Grad von Zusammenballung des Protoplasma und einen mäszigen Betrag von Einbiegung verursacht, besonders bei Pflanzen, welche in einer im Ganzen hohen Temperatur gehalten wor-
den sind. Wasser regt keine reichliche Absonderung von Schleim an. Wir haben hier die Wirkungen des Eintauchens in verschiedene Flüssig-
keiten auf die spätere Einwirkung der Ammoniaksalze und anderer Reiz-
mittel zu betrachten. Vier Blättern, welche 24 Stunden lang in Wasser gelassen worden waren, wurden Stückchen Fleisch gegeben; sie umfaszten sie aber nicht. Zehn Blätter wurden, nach einem ähnlichen Eintauchen, 24 Stunden lang in einer kräftigen Lösung (1 Gran auf 20 Unzen) von phosphorsaurem Ammoniak gelassen, und nur eines zeigte und selbst nur eine Spur von Einbiegung. Als drei dieser Blätter noch einen weiteren Tag lang in der Lösung gelassen worden waren, blieben sie noch immer nicht afficirt.

# Einfluss von Lösungen

Als indessen einige dieser Blätter, welche zuerst 24 Stunden lang in Wasser und dann 24 Stunden lang in eine Lösung des Phosphats eingetaucht worden waren, in eine Lösung von kohlensaurem Ammoniak (ein Theil auf 218 Theile Wasser) gebracht wurden, wurde das Protoplasma in den Zellen der Tentakeln in wenigen Stunden stark zusammengeballt, woraus hervorgieng, dasz dies Salz absorbirt worden war und Wirkung geäuszert hatte. Ein kurzes, 20 Minuten langes Eintauchen in Wasser verzögerte die spätere Wirkung des phosphorsauren Salzes oder von auf die Drüsen gelegten Glassplittern nicht; in zwei Fällen aber verhinderte ein 50 Minuten währendes Eintauchen jede Wirkung einer Campherlösung. Mehrere Blätter, welche 20 Minuten lang in einer Lösung von einem Theile weiszen Zuckers auf 218 Theile Wasser gelassen worden waren, wurden in die Lösung des phosphorsauren Salzes gebracht, deren Einwirkung verzögert wurde, während eine gemischte Lösung von Zucker und Phosphat die Wirkungen der letzteren nicht im Allermindesten störte.

# Zusammenfassung der Ergebnisse

Drei Blätter wurden, nachdem sie 20 Minuten lang in die Zuckerlösung eingetaucht gewesen waren, in eine Lösung von kohlensaurem Ammoniak (ein Theil auf 218 Theile Wasser) gebracht; in 2 oder 3 Minuten waren die Drüsen geschwärzt und nach 7 Minuten waren die Tentakeln beträchtlich eingebogen, so dasz die Zuckerlösung, obschon sie die Wirkung des Phosphats aufhielt, doch die des kohlensauren Salzes nicht verzögerte. Ein 20 Minuten langes Eintauchen des Blattes in eine ähnliche Lösung von arabischem Gummi hatte keine verzögernde Wirkung auf das phosphorsaure Salz. Drei Blätter wurden 20 Minuten lang in einer Mischung von einem Theile Alkohol auf sieben Theile Wasser gelassen und dann in die Lösung des phosphorsauren Salzes gebracht: in 2 Stunden 15 Minuten war eine Spur von Einbiegung an einem Blatte, und in 5 Stunden 30 Minuten eine unbedeutende Wirkung an einem zweiten vorhanden; die Einbiegung nahm später, wenn schon langsam, etwas zu. Verdünnter Alkohol, welcher, wie wir sehen werden, kaum irgendwie giftig ist, verzögert daher offenbar.# Die Wirkung des phosphorsauren Salzes

Im letzten Capitel wurde gezeigt, dasz Blätter, welche durch ein beinahe vierundzwanzigstündiges Eintauchen in Lösungen verschiedener Salze und Säuren nicht eingebogen wurden, sich sehr verschieden von einander verhielten, wenn sie später in die Lösung des phosphorsauren Salzes gebracht wurden. Ich gebe hier eine Tabelle, welche die Resultate zusammenfasst.

## Wirkungen der Eintauchung

In einer groszen Mehrzahl dieser zwanzig Fälle wurde ein wechselnder Grad von Einbiegung langsam durch das phosphorsaure Salz verursacht. Indessen war in vier Fällen die Einbiegung sehr schnell, indem sie in weniger als einer halben Stunde oder höchstens in 50 Minuten eintrat. In drei Fällen brachte das Phosphat nicht die geringste Wirkung hervor. Was haben wir nun aus diesen Thatsachen zu folgern?

## Einfluss von Lösungen auf die Wirkung des Phosphats

Wir wissen aus zehn Versuchen, dasz 24 Stunden langes Eintauchen in destillirtes Wasser die spätere Einwirkung der Phosphatlösung verhindert. Es dürfte daher hiernach scheinen, als wirkten die Lösungen von Manganchlorid, von Gerbsäure und Weinsteinsäure, welche nicht giftig sind, genau so wie Wasser; denn das phosphorsaure Ammoniak brachte keine Wirkung auf die Blätter hervor, welche vorher in diese drei Lösungen eingetaucht gewesen waren.

## Vergleich mit anderen Lösungen

Die Mehrzahl der anderen Lösungen verhielten sich bis zu einem gewissen Masze wie Wasser; denn das phosphorsaure Ammoniak brachte nach einem beträchtlichen Zeitintervall nur eine unbedeutende Wirkung hervor. Andererseits wirkte das phosphorsaure Ammoniak schnell auf die Blätter ein, welche in die Lösungen von Rubidiumchlorid und Chlormagnesium, von essigsaurem Strontian, salpetersaurem Baryt und Citronensäure gelegt worden waren.

## Hypothesen zur Erklärung der Ergebnisse

Wurde nun etwa aus diesen fünf schwachen Lösungen Wasser absorbiert und verhinderte es dennoch, in Folge der Gegenwart der Salze, die spätere Wirkung des phosphorsauren Ammoniaks nicht? Oder dürfen wir nicht annehmen, Dr. Traube’s merkwürdige Versuche über die Bildung künstlicher Zellen und über ihre Durchlässigkeit für verschiedene Salze in seinen Aufsätzen: „Experimente zur Theorie der Zellenbildung und Endosmose‟; Breslau, 1866, und „Experimente zur physicalischen Erklärung der Bildung der Zellhaut, ihres Wachsthums durch Intussusception u. s. w.‟ Breslau, 1874. Diese Untersuchungen erklären vielleicht meine Resultate.

## Membran und Durchlässigkeit

Traube wendete als Membran gewöhnlich den Niederschlag an, welcher sich bildet, wenn Gerbsäure mit einer Lösung von Gelatine in Berührung kommt. Lässt man zu derselben Zeit einen Niederschlag von schwefelsaurem Baryt stattfinden, so wird die Membran „infiltriert‟ mit diesem Salze; und in Folge der Einschaltung von Moleculen des schwefelsauren Baryts zwischen diejenigen des Gelatine-Niederschlags werden die Molecularzwischenräume in der Membran kleiner.

## Schlussfolgerungen zur Durchlässigkeit

In diesem veränderten Zustande gestattet die Membran nicht länger den Durchtritt weder von schwefelsaurem Ammoniak noch von salpetersaurem Baryt durch sie hindurch, obschon sie ihre Durchlässigkeit für Wasser und Chlorammonium behält. Es zeigt sich ferner, dasz die Zwischenräume der Drüsenwandungen durch Molecule dieser fünf Substanzen so verstopft waren, dasz sie für Wasser undurchgängig wurden; denn wäre Wasser eingetreten, so wissen wir von den zehn Versuchen her, dasz das phosphorsaure Ammoniak später keinerlei Wirkung hervorgebracht haben würde.

## Verhalten der Drüsen

Es zeigt sich ferner, dasz die Molecule des kohlensauren Ammoniaks schnell in Drüsen eintreten können, welche in Folge einer 20 Minuten währenden Eintauchung in eine schwache Auflösung von Zucker entweder das phosphorsaure Salz sehr langsam absorbieren oder von ihm sehr langsam beeinflusst werden. Andererseits scheinen Drüsen, wie sie auch immer behandelt worden sein mögen, leicht den späteren Eintritt der Molecule des kohlensauren Ammoniaks zu gestatten.

## Weitere Experimente

An Blättern, welche in eine Lösung (von einem Theile auf 437 Theile Wasser) von salpetersaurem Kali 48 Stunden lang, — von schwefelsaurem Kali 24 Stunden lang, — und von Chlorkalium 25 Stunden lang, —# Wirkung von Lösungen auf Drosera

den lang gelegt worden waren, wurden daher, als sie in eine Lösung von einem Theeile kohlensauren Ammoniaks auf 218 Theile Wasser gebracht wurden, die Drüsen unmittelbar schwarz und nach 1 Stunde waren die Tentakeln etwas eingebogen und das Portoplasma zusammengeballt. Es würde aber eine endlose Aufgabe sein, zu versuchen, die wunderbar verschiedenen Wirkungen verschiedener Lösungen auf Drosera zu ermitteln.

## Alkohol und seine Effekte

Alkohol (ein Theil auf sieben Theile Wasser). — Es ist bereits gezeigt worden, dasz halbe Minims von dieser Stärke auf die Scheiben von Blättern gelegt, durchaus keine Einbiegung verursachen; und dasz die Blätter, wenn ihnen zwei Tage später Stückchen Fleisch gegeben werden, stark eingebogen werden. Vier Blätter wurden in diese Mischung getaucht und zwei von ihnen wurden nach 30 Minuten mit einem Camelhaarpinsel bestrichen, wie die Blätter in der Lösung von Campher; dies brachte aber keine Wirkung hervor. Auch erlitten diese vier Blätter, als sie 24 Stunden in dem verdünnten Alkohol gelogen hatten, keine Einbiegung. Sie wurden dann entfernt; eines wurde in einen Aufgusz von rohem Fleisch gelegt, und auf die Scheiben der andern wurden, während ihre Stiele in Wasser standen, Stückchen Fleisch gebracht. Am folgenden Tage schien eines ein wenig beschädigt zu sein, während zwei andere blosz eine Spur von Einbiegung zeigten. Wir müssen im Sinne behalten, dasz ein Eintauchen in Wasser von 24 Stunden die Blätter verhindert, Fleisch zu umfassen. Es ist daher Alkohol der oben angegebenen Stärke nicht giftig, ebenso wenig reizt er die Blätter, wie es Campher thut.

## Dampf von Alkohol

Der Dampf von Alkohol wirkt hiervon verschieden. Eine Pflanze, welche drei gute Blätter trug, wurde 25 Minuten lang unter einer, neunzehn Unzen haltenden Glocke mit sechzig Minims Alkohol in einem Uhrglase stehen gelassen. Es erfolgte keine Bewegung, aber einige wenige von den Drüsen wurden geschwärzt und verschrumpft, während viele andere ganz blasz wurden. Diese waren über die ganzen Blätter in der allerunregelmäszigsten Weise zerstreut, was mich an die Art und Weise erinnerte, wie die Drüsen vom Dampfe des kohlensauren Ammoniaks afficirt wurden. Unmittelbar nach der Entfernung der Glasglocke wurden auf viele der Drüsen Stückchen rohen Fleisches gelegt, wobei besonders diejenigen ausgesucht wurden, welche ihre ordentliche Färbung bewahrt hatten. Aber im Verlaufe der nächsten 4 Stunden wurde nicht ein einziger Tentakel einge- bogen. Nach den ersten 2 Stunden fiengen die Drüsen an sämmtlichen Tentakeln zu. vertrocknen an, und am nächsten Morgen, nach 22 Stunden, schienen alle drei Blätter beinahe todt zu sein, ihre Drüsen waren trocken; nur die Tentakeln an einem einzigen Blatt waren theilweise eingebogen.

## Chloroform-Dämpfe

Chloroformdämpfe. — Die Wirkung dieser Dämpfe auf Drosera ist sehr schwankend und hängt, wie ich vermuthe, von der Constitution oder dem Alter der Pflanze oder von irgend welchen unbekannten Bedingungen ab. Zuweilen bewirken sie, dasz sich die Tentakeln mit ausserordentlicher Schnelligkeit bewegen, und zuweilen bringen sie keine derartige Wirkung hervor. Die Drüsen werden zuweilen für die Einwirkung# Chloroform und seine Wirkung auf Pflanzen

Eine Pflanze wurde 30 Minuten lang unter einer neunzehn Masz-Unzen (539,6 Cub. Cent.) haltenden Glasglocke mit acht Tropfen Chloroform gelassen, und ehe die Glocke entfernt war, waren die meisten Tentakeln bedeutend eingebogen, obschon sie die Mitte nicht erreichten. Nachdem die Decke entfernt worden war, wurden Stückchen Fleisch auf die Drüsen mehrerer der etwas einwärts gekrümmten Tentakeln gelegt; nach 6 Stunden 30 Minuten fand sich, dasz diese Drüsen bedeutend geschwärzt waren, es erfolgte aber keine weitere Bewegung. Nach 24 Stunden schienen die Blätter beinahe todt zu sein.

# Reaktion auf unterschiedliche Chloroform-Dosen

Es wurde nun eine kleinere Glasglocke, welche zwölf Masz-Unzen (340,8 Cub. Cent.) enthielt, angewendet und eine Pflanze 90 Secunden lang mit nur zwei Tropfen Chloroform unter ihr gelassen. Unmittelbar nach Entfernung der Glocke krümmten sich sämmtliche Tentakeln einwärts, so dasz sie senkrecht in die Höhe standen; man konnte sogar factisch sehen, wie sich einige von ihnen mit auszerordentlicher Schnelligkeit in kleinen Stöszen, und daher in einer unnatürlichen Weise bewegten; sie erreichten aber die Mitte nicht. Nach 22 Stunden breiteten sie sich vollständig wieder aus, und als Fleisch auf ihre Drüsen gelegt oder als sie selbst mit einer Nadel derb berührt wurden, wurden sie schnell eingebogen, so dasz diese Blätter nicht im mindesten beschädigt waren.

# Variabilität der Reaktionen

Eine andere Pflanze wurde unter dieselbe Glasglocke mit drei Tropfen Chloroform gebracht, und ehe zwei Minuten verflossen waren, fiengen die Tentakeln an, sich in kleinen rapiden Rucken einwärts zu krümmen. Die Glasglocke wurde dann entfernt und im Verlaufe von weiteren zwei oder drei Minuten erreichte beinahe jeder Tentakel die Mitte. Bei mehreren andern Gelegenheiten regten die Dämpfe durchaus keine Bewegung dieser Art an.

# Langsame Reaktionen und Erholung

In Bezug auf den Grad und auf die Art und Weise, in welchen Chloroform die Drüsen unempfindlich für eine später erfolgende Wirkung von Fleisch macht, scheint auch eine grosze Variabilität zu bestehen. Bei der zuletzt erwähnten Pflanze, welche zwei Minuten lang drei Tropfen Chloroform ausgesetzt gewesen war, bogen sich einige wenige Tentakeln zu einer senkrechten Stellung auf, und nun wurden Stückchen Fleisch auf ihre Drüsen gelegt; dies veranlaszte es, dasz sie sich in 5 Minuten zu bewegen begannen; sie bewegten sich aber so langsam, dasz sie die Mitte nicht vor Verlauf von 1 Stunde 30 Minuten erreichten.

# Weitere Experimente und Ergebnisse

Eine andere Pflanze wurde ähnlichen Verhältnissen ausgesetzt, d. h. 2 Minuten lang drei Tropfen Chloroform; und als dann Stückchen Fleisch auf die Drüsen von mehreren Tentakeln gelegt wurden, welche sich zu einer senk-
rechten Stellung aufgebogen hatten, fieng einer derselben in 8 Minuten an, sich zu biegen, bewegte sich aber später sehr langsam, während von den andern Tentakeln sich in den nächsten 40 Minuten keiner bewegte. Demungeachtet erreichten in 1 Stunde 45 Minuten, von der Zeit an, wo Stückchen Fleisch gegeben worden waren, sämmtliche Tentakeln die Mitte. Es war in diesem Falle allem Anscheine nach eine unbedeutende anaesthetische Wirkung hervorgerufen worden. Am folgenden Tage hatte sich die Pflanze vollkommen wieder erholt.

# Zusammenfassung der Beobachtungen

Eine andere Pflanze, welche zwei Blätter trug, wurde 2 Minuten lang unter der Neunzehn-Unzen-Glasglocke zwei Tropfen Chloroform ausgesetzt; dann wurde sie herausgenommen und untersucht; wieder 2 Minuten lang zwei Tropfen ausgesetzt; herausgenommen und wiederum 3 Minuten lang drei Tropfen ausgesetzt, so dasz sie im Ganzen abwech-
selnd der Luft und zusammengenommen 7 Minuten lang den Dämpfen von sieben Tropfen Chloroform ausgesetzt wurde. Nun wurden Stückchen Fleisch auf dreizehn Drüsen an den beiden Blättern gelegt. An einem dieser Blätter fieng ein einzelner Tentakel sich zuerst in 40 Minuten zu bewegen an, und zwei andere in 54 Minuten. Am zweiten Blatt bewegten sich einige Tentakeln zuerst in 1 Stunde 11 Minuten. Nach 2 Stunden waren viele Tentakeln an beiden Blättern eingebogen; aber innerhalb# Experimentelle Ergebnisse

dieser Zeit erreichte keiner die Mitte. In diesem Falle konnte nicht der geringste Zweifel bestehen, dasz das Chloroform einen anaesthetischen Einflusz auf die Blätter ausgeübt hatte. Auf der andern Seite wurde aber nun eine andere Pflanze unter derselben Glasglocke eine viel längere Zeit hindurch, nämlich 20 Minuten, zweimal so viel Chloroform ausgesetzt. Dann wurden Stückchen Fleisch auf die Drüsen vieler Tentakeln gelegt; und sie erreichten sämmtlich, mit einer einzigen Ausnahme, die Mitte in einer Zeit von 13 bis 14 Minuten. In diesem Falle war nur eine geringe oder gar keine anaesthetische Wirkung hervorgebracht worden; wie diese widersprechenden Resultate mit einander auszusöhnen sind, weisz ich nicht.

## Dämpfe von Schwefel-Äther

Eine Pflanze wurde in einem neunzehn Unzen haltenden Gefäsze 30 Minuten lang der Wirkung von dreiszig Minims dieses Äthers ausgesetzt; nachher wurden Stückchen rohen Fleisches auf viele Drüsen gelegt, welche blasz gefärbt worden waren; aber keiner der Tentakeln bewegte sich. Nach 6 Stunden 30 Minuten erschienen die Blätter kränkelnd und die scheibenständigen Drüsen waren beinahe trocken. Am nächsten Morgen waren viele von den Tentakeln todt, wie es alle die waren, auf welche Fleisch gelegt worden war; es zeigte sich hieraus, dasz Substanz aus dem Fleisch absorbirt worden war, welche die üblen Einwirkungen der Dämpfe noch vermehrt hatten. Nach vier Tagen starb die Pflanze selbst ab. Eine andere Pflanze wurde in demselben Gefäsz 15 Minuten lang vierzig Minims ausgesetzt. Bei einem jungen, kleinen und zarten Blatt waren alle Tentakeln eingebogen; das Blatt schien bedeutend beschädigt zu sein. Stückchen Fleisch wurden auf mehrere Drüsen an zwei andern und älteren Blättern gelegt. Diese Drüsen wurden nach 6 Stunden trocken und schienen verletzt zu sein; die Tentakeln bewegten sich gar nicht, ausgenommen einen, welcher schlieszlich ein wenig eingebogen wurde. Die Drüsen der andern Tentakeln fuhren fort, abzusondern und schienen unverletzt zu sein, aber nach drei Tagen kränkelte die ganze Pflanze bedeutend.

## Wirkung von Dosen

In den beiden vorstehend geschilderten Experimenten waren die Dosen offenbar zu grosz und giftig. Bei kleineren Dosen war die anaesthetische Wirkung schwankend, wie es beim Chloroform der Fall war. Eine Pflanze wurde unter einem Zwölf-Unzengefäsz 5 Minuten lang zehn Tropfen ausgesetzt und dann wurden Stückchen Fleisch auf viele Drüsen gelegt. Keiner der in dieser Weise behandelten Tentakeln fieng in einer entscheidenden Art sich zu bewegen an, ehe 40 Minuten verlaufen waren; aber dann bewegten sich einige von ihnen sehr schnell, so dasz zwei nach einem weiteren Verlauf von nur 10 Minuten die Mitte erreichten. In 2 Stunden 12 Minuten, von der Zeit an gerechnet, wo die Fleischstückchen aufgelegt worden waren, erreichten sämmtliche Tentakeln die Mitte. Eine andere Pflanze mit zwei Blättern wurde in demselben Gefäsz 5 Minuten lang einer etwas gröszeren Dosis von Äther ausgesetzt, und dann wurden Stückchen Fleisch auf mehrere Drüsen gelegt. In diesem Falle fieng ein Tentakel an jedem Blatte sich in 5 Minuten zu biegen an; und nach 12 Minuten erreichten an dem einen Blatte zwei Tentakeln und einer an dem zweiten Blatte die Mitte. In 30 Minuten, nachdem das Fleisch gegeben worden war, waren sämmtliche Tentakeln, sowohl diejenigen mit als die ohne Fleisch, dicht eingebogen, so dasz der Äther allem Anscheine nach diese Blätter gereizt und bewirkt hatte, dasz sich alle Tentakeln bogen.

## Dämpfe von Salpeter-Äther

Diese Dämpfe scheinen schädlicher zu sein als die Schwefeläther-Dämpfe. Eine Pflanze wurde 5 Minuten lang in einem Zwölf-Unzengefäsz der Einwirkung von acht in einem Uhrglas befindlichen Tropfen ausgesetzt, und ich sah deutlich einige wenige Tentakeln sich einwärts rollen, ehe das Glas entfernt wurde. Unmittelbar danach wurden Stückchen Fleisch auf die Drüsen gelegt; aber im Verlaufe von 18 Minuten erfolgte keine Bewegung. Dieselbe Pflanze wurde nochmals unter dasselbe Gefäsz 16 Minuten lang mit zehn Tropfen Äther gestellt. Keiner der Tentakeln bewegte sich, und am nächsten Morgen waren die mit dem Fleisch noch immer in derselben Stellung. Nach 48 Stunden schien das eine Blatt gesund zu sein, die andern aber# Verletzungen und Experimente

waren sehr verletzt. Eine andere Pflanze, welche zwei gute Blätter hatte, wurde 6 Minuten lang in einem Neunzehn-Unzengefäsz dem Dampfe von zehn Minims des Äthers ausgesetzt, und dann wurden Stückchen Fleisch auf die Drüsen vieler Tentakeln an beiden Blättern gelegt. Nach 36 Minuten wurden mehrere derselben an einem Blatte eingebogen, und nach 1 Stunde erreichten alle Tentakeln, diejenigen mit und die ohne Fleisch, beinahe den Mittelpunkt. An dem andern Blatte fiengen die Drüsen in 1 Stunde 40 Minuten an trocken zu werden, und nach mehreren Stunden war nicht ein einziger Tentakel eingebogen; am nächsten Morgen aber, nach 21 Stunden, waren viele eingebogen, obschon sie bedeutend verletzt zu sein schienen. In diesem und dem vorhergehenden Experiment ist es wegen der Verletzung, welche die Blätter erlitten hatten, zweifelhaft, ob irgend eine anaesthetische Wirkung hervorgebracht worden ist.

# Weitere Experimente

Eine dritte Pflanze mit zwei guten Blättern wurde nur 4 Minuten lang in dem Neunzehn-Unzengefäsz dem Dampfe von sechs Tropfen ausgesetzt. Stückchen Fleisch wurden dann auf die Drüsen von sieben Tentakeln an demselben Blatte gelegt. Ein einziger Tentakel bewegte sich nach 1 Stunde 23 Minuten; nach 2 Stunden 3 Minuten waren mehrere eingebogen; und nach 3 Stunden 3 Minuten waren die sämmtlichen sieben Tentakeln mit Fleisch gut eingebogen. Aus der Langsamkeit dieser Bewegungen geht klar hervor, dasz dies Blatt auf einige Zeit für die Wirkung des Fleisches unempfindlich geworden war. Ein zweites Blatt wurde ziemlich verschieden afficirt; Stückchen Fleisch wurden auf die Drüsen von fünf Tentakeln gelegt, von denen drei in 28 Minuten unbedeutend eingebogen waren; nach 1 Stunde 21 Minuten erreichte einer die Mitte, aber die andern zwei waren noch immer nur unbedeutend eingebogen; nach 3 Stunden waren sie viel stärker eingebogen; aber selbst nach 5 Stunden 16 Minuten hatten alle fünf nicht die Mitte erreicht. Obgleich einige der Tentakeln sich bald mäszig zu bewegen begannen, bewegten sie sich doch später mit äusserster Langsamkeit. Am nächsten Morgen, nach 20 Stunden, waren die meisten Tentakeln an beiden Blättern dicht eingebogen, aber nicht völlig regelmäszig. Nach 48 Stunden erschien keines der beiden Blätter verletzt zu sein, trotzdem die Tentakeln noch immer eingebogen waren; nach 72 Stunden war eines beinahe todt, während das andere im Begriffe war, sich wieder auszubreiten und zu erholen.

# Kohlensäure-Experiment

Kohlensäure. — Eine Pflanze wurde unter eine 122 Unzen haltende Glasglocke gestellt, welche mit diesem Gas gefüllt war und über Wasser stand; ich hatte aber die Absorption des Gases durch das Wasser nicht hinreichend mit in Rechnung gezogen, so dasz gegen den letzten Teil des Versuches hin etwas Luft eingezogen wurde. Nachdem die Pflanze 2 Stunden lang der Kohlensäure ausgesetzt gewesen war, wurde sie entfernt und Stückchen rohes Fleisch auf die Drüsen von drei Blättern gelegt. Eines dieser Blätter hieng etwas herab und wurde zuerst theilweise und bald später darauf vollständig vom Wasser bedeckt, welches innerhalb des Gefässes in dem Wasser stieg, als das Gas absorbirt wurde. An diesem letztern Blatte wurden die Tentakeln, denen Fleisch gegeben worden war, in 2 Minuten 30 Secunden, das ist ungefähr in der normalen Geschwindigkeit, ordentlich eingebogen, so dasz ich zu dem irrigen Schlusse kam, die Kohlensäure habe keine Wirkung hervorgebracht, bis ich mich daran erinnerte, dasz ja das Blatt vor dem Gase geschützt gewesen war und vielleicht aus dem Wasser Sauerstoff absorbirt haben könnte, das beständig nach innen gezogen wurde. An den andern beiden Blättern verhielten sich die Tentakeln mit Fleisch sehr verschieden von denen am ersten Blatt; zwei von ihnen fiengen zuerst in 1 Stunde 50 Minuten (immer von der Zeit an gerechnet, wo das Fleisch auf die Drüsen gebracht worden war) sich unbedeutend zu bewegen an, waren in 2 Stunden 22 Minuten deutlich eingebogen und erreichten in 3 Stunden 22 Minuten die Mitte. Drei andre Tentakeln fiengen nicht vor Ablauf von 2 Stunden 20 Minuten sich zu bewegen an, erreichten aber die Mitte ungefähr zu derselben Zeit wie die andern, nämlich in 3 Stunden 22.# Experimente mit Pflanzen

Minuten.
Dieser Versuch wurde mehrere Male mit nahezu denselben Resultaten wiederholt, ausgenommen, dasz die Zeitdauer, ehe die Tentakeln sich zu bewegen anfiengen, etwas schwankte. Ich will nur einen einzigen andern Fall anführen. Eine Pflanze wurde in demselben Gefäsz dem Gas 45 Minuten lang ausgesetzt, und dann wurden Stückchen Fleisch auf vier Drüsen gelegt. Die Tentakeln bewegten sich aber nicht in 1 Stunde 40 Minuten; nach 2 Stunden 30 Minuten waren alle vier gut eingebogen und erreichten nach 3 Stunden die Mitte.

# Beobachtungen zur Tentakelbewegung

Die folgende eigenthümliche Erscheinung kam zuweilen, aber durchaus nicht immer vor. Eine Pflanze wurde 2 Stunden lang in das Gas gestellt, und dann wurden Stückchen Fleisch auf mehrere Drüsen gelegt. Im Verlaufe von 13 Minuten wurden sämmtliche halbrandständige Tentakeln an dem einen Blatte beträchtlich eingebogen; diejenigen mit dem Fleische nicht im geringsten Grade mehr als die andern. An einem zweiten Blatte, welches wohl etwas alt war, wurden die Tentakeln mit Fleisch ebenso wie einige wenige andere, mäszig eingebogen. An einem dritten Blatte wurden alle Tentakeln dicht eingebogen, obschon auf keine einzige Drüse Fleisch gelegt worden war. Ich vermuthe, dasz diese Bewegung der Reizung in Folge der Absorption von Sauerstoff zugeschrieben werden kann. Das letzterwähnte Blatt, welchem kein Fleisch gegeben worden war, war nach 24 Stunden vollständig wieder ausgebreitet, während bei den andern beiden Blättern alle Tentakeln dicht über den Stückchen Fleisch eingebogen waren, welche in dieser Zeit nach der Mitte geschafft worden waren. Es hatten sich hiernach diese drei Blätter von den Wirkungen des Gases im Laufe von 24 Stunden vollständig wieder erholt.

# Einfluss von Kohlensäure auf die Pflanzen

Bei einer andern Gelegenheit wurden einigen schönen Pflanzen, nachdem sie 2 Stunden lang im Gase gelassen worden waren, unmittelbar darauf in der gewöhnlichen Art Stückchen Fleisch gegeben; und als sie der Luft ausgesetzt wurden, wurden die meisten ihrer Tentakeln in 12 Minuten zu einer senkrechten oder subverticalen Stellung aufgekrümmt, aber in einer äuszerst unregelmäszigen Art und Weise: einige nur an der einen Seite des Blattes, und einige an der andern. Sie blieben einige Zeit in dieser Stellung; dabei hatten sich die Tentakeln mit den Stückchen Fleisch zuerst nicht schneller oder weiter nach innen bewegt als die andern ohne Fleisch. Aber nach 2 Stunden 20 Minuten fiengen die ersteren an, sich zu bewegen und fuhren stetig fort, sich zu biegen bis sie die Mitte erreichten. Am nächsten Morgen, nach 22 Stunden, waren alle Tentakeln an diesen Blättern dicht über das Fleisch zusammengeschlagen, welches bei allen nach der Mitte gebracht worden war, während die senkrechten und subverticalen Tentakeln an den andern Blättern, denen kein Fleisch gegeben worden war, sich vollständig wieder ausgebreitet hatten. Indesz, nach der späteren Wirkung einer schwachen Lösung von kohlensaurem Ammoniak auf eines dieser letztern Blätter zu urtheilen, hatte es in 22 Stunden seine Reizbarkeit und sein Bewegungsvermögen nicht vollständig wieder erlangt; ein anderes Blatt aber war nach Verlauf weiterer 24 Stunden vollkommen wieder hergestellt, nach der Art und Weise, wie es eine auf seine Scheibe gesetzte Fliege umfaszte, zu urtheilen.

# Letzte Experimente und Beobachtungen

Ich will nur noch ein einziges anderes Experiment anführen. Nachdem eine Pflanze 2 Stunden lang dem Gase ausgesetzt worden war, wurde eines ihrer Blätter in eine ziemlich starke Lösung von kohlensaurem Ammoniak eingetaucht, und zwar zusammen mit einem frischen Blatt von einer andern Pflanze. An dem letzteren waren innerhalb 30 Minuten die meisten Tentakeln stark eingebogen; während das Blatt, welches der Kohlensäure ausgesetzt gewesen war, 24 Stunden in der Lösung blieb, ohne dasz irgend welche Einbiegung eintrat, mit Ausnahme zweier Tentakeln. Dies Blatt war beinahe vollständig gelähmt worden, und war nicht im Stande, seine Reizbarkeit wieder zu erlangen, so lange es noch in der Lösung war, welche, da sie mit destillirtem Wasser dargestellt worden war, wahrscheinlich wenig Sauerstoff enthielt.

# Schluszbemerkungen über die Wirkungen der vor-# Einleitung
stehend aufgeführten Agentien. — Da die Drüsen, wenn sie gereizt werden, einen Einflusz gewisser Art den umgebenden Tentakeln übermitteln, welche diese sich zu biegen veranlassen, und die Drüsen dazu anregen, eine vermehrte Menge eines modificirten Secrets zu ergieszen, so lag mir daran, zu ermitteln, ob die Blätter irgend ein Element von der Beschaffenheit des Nervengewebes enthielten, welches, wenn auch nicht ununterbrochen zusammenhängend, doch als Leitungs-canal diente.

# Versuche mit Alkaloiden
Dies führte mich darauf, die verschiedenen Alkoloide und andere Substanzen zu versuchen, von denen bekannt ist, dasz sie eine kräftige Wirkung auf das Nervensystem von Thieren äuszern. Anfangs wurde ich in meinen Versuchen dadurch ermuthigt, dasz ich fand, Strychnin, Digitalin und Nicotin, welche alle auf das Nervensystem wirken, waren für die Drosera giftig und bewirkten einen gewissen Grad von Einbiegung.

# Wirkung von Blausäure und anderen Substanzen
Ferner verursachte Blausäure, welche für Thiere ein so tödtliches Gift ist, rapide Bewegung der Tentakeln. Da aber mehrere unschädliche Säuren selbst in groszer Verdünnung, so Benzoësäure, Essigsäure u. s. w., ebenso wie einige ätherische Öle für die Drosera äuszerst giftig sind und schnell starke Einbiegung verursachen, so scheint es wahrscheinlich, dasz Strychnin, Nicotin, Digitalin und Blausäure Einbiegung durch Einwirkung auf Elemente verursachen, welche in keiner Weise den Nervenzellen der Thiere analog sind.

# Vergleich der Substanzen
Wenn Elemente dieser letzteren Natur in den Blättern vorhanden gewesen wären, so hätte man erwarten können, dasz Morphium, Hyoscyamus, Atropin, Veratrin, Colchicin, Curare und verdünnter Alkohol eine irgendwie ausgesprochene Wirkung hervorgebracht haben würden, während diese Substanzen nicht giftig sind und das Vermögen, Einbiegung zu verursachen, gar nicht oder nur in einem sehr unbedeutenden Grade besitzen.

# Muskelgifte und ihre Wirkung
Es ist indesz zu beachten, dasz Curare, Colchicin und Veratrin Muskelgifte sind, d. h. dasz sie auf Nerven wirken, welche in irgend einer speciellen Beziehung zu Muskeln stehn, so dasz man daher nicht erwarten konnte, dasz sie auf Drosera wirkten. Das Gift der Brillenschlange ist für Thiere äuszerst tödtlich, dadurch dasz es die Nervencentren lähmt, für Drosera ist es aber nicht im mindesten tödtlich, wenngleich es schnell starke Einbiegung verursacht.

# Parallelismus in der Wirkung
Trotz der vorstehend mitgetheilten Thatsachen, welche zeigen, wie weit von einander verschieden die Wirkung gewisser Substanzen auf die Gesundheit oder das Leben von Thieren und von Drosera ist, so besteht doch ein gewisser Grad von Parallelismus in der Wirkung gewisser anderer Substanzen. Wir haben gesehen, dasz dies in einer auffallenden Weise für die Natron- und Kali-Salze gilt.

# Metallische Salze und ihre Toxizität
Ferner sind verschiedene metallische Salze und Säuren, nämlich die von Silber, Quecksilber, Gold, Zinn, Arsenik, Chrom, Kupfer und Platin, von denen die meisten oder alle für Thiere in hohem Grade giftig sind, in gleicher Weise auch für Drosera giftig. Es ist aber eine eigen-thümliche Thatsache, dasz das Chlorblei und zwei Barytsalze für diese Pflanze nicht giftig sind.

# Merkwürdige Ausnahmen
Es ist eine in gleicher Weise befremdende Thatsache, dasz, obgleich Essig- und Propionsäure in hohem Grade giftig sind, die ihnen verwandte Ameisensäure dies nicht ist, und dasz, während gewisse vegetabilische Säuren, nämlich Oxalsäure, Benzoësäure u. s. w. in einem hohen Grade giftig sind, Gallus-, Tannin-, Weinstein- und Äpfelsäure (alle in einem gleichen Grade verdünnt) dies nicht sind.

# Einbiegung und Säuren
Äpfelsäure veranlaszt Einbiegung, während die drei andern oben genannten Pflanzensäuren dies Vermögen nicht besitzen. Es würde aber eine vollständige Pharmacopöe erfordern, die verschiedenartigen Wirkungen verschiedener Substanzen auf Drosera zu beschreiben.

# Fazit
Wenn man erwägt, dasz Essigsäure, Blausäure und Chromsäure, essigsaures Strychnin und Ätherdämpfe der Drosera giftig sind, so ist es merkwürdig, dasz Dr. Ransom, welcher viel stärkere Lösungen dieser Substanzen benutzte als ich, angibt, „dasz die rhythmische Contractilität.# Einflüsse von Giften auf Protoplasma

„Dotters (der Hechteier) nicht wesentlich von irgend einem der angewandten Gifte „beeinfluszt wird, welches nicht, mit Ausnahme des Chloroforms und der Kohlen- „säure, chemisch wirkte.‟ Ich finde bei mehreren Schriftstellern die Angabe, dasz Curare keinen Einflusz auf Sarcode oder Protoplasma hat, und wir haben gesehen, dasz Curare zwar einen gewissen Grad von Einbiegung verursacht, aber sehr wenig Zusammenballung des Protoplasma bewirkt.

# Alkaloide und deren Wirkung

Von den Alkaloiden und deren Salzen, welche versucht wurden, hatten mehrere nicht die geringste Kraft, Einbiegung zu verursachen; andere, welche sicherlich absorbirt wurden, wie aus der veränderten Farbe der Drüsen hervorgieng, hatten nur eine sehr mäszige Fähigkeit dieser Art; andere wiederum, wie das essigsaure Chinin und Digitalin, verursachten starke Einbiegung.

# Färbung der Drüsen

Die verschiedenen in diesem Capitel erwähnten Substanzen haben auf die Färbung der Drüsen einen sehr verschiedenen Einflusz. Dieselben werden häufig zuerst dunkel und dann sehr blasz oder weisz, wie es in auffallender Weise mit den Drüsen der Fall war, welche dem Gifte der Cobra und dem citronensauren Strychnin ausgesetzt worden waren. In andern Fällen werden sie von Anfang an weisz gemacht, wie es bei Blättern der Fall ist, die in heiszes Wasser und verschiedene Säuren getaucht werden; ich vermuthe, dasz dies das Resultat der Gerinnung des Eiweiszes ist.

# Zusammenballung des Protoplasma

An einem und demselben Blatte wurden einige Drüsen weisz und andere dunkel gefärbt, wie es bei Blättern vorkam, die in einer Lösung von schwefelsaurem Chinin und in Alkoholdämpfen lagen. Länger anhaltendes Eintauchen in Nicotin, Curare und selbst Wasser schwärzt die Drüsen; und dies ist, wie ich glaube, eine Folge der Zusammenballung des Protoplasma in ihren Zellen. Doch verursachte Curare nur sehr wenig Zusammenballung in den Zellen der Tentakeln, während Nicotin und schwefelsaures Chinin eine stark ausgeprägte Zusammenballung hinab bis zur Basis der Tentakeln bewirkte.

# Formveränderungen und Bewegungsfähigkeit

Die zusammengeballten Massen in Blättern, welche 3 Stunden 15 Minuten lang in einer gesättigten Lösung von schwefelsaurem Chinin eingetaucht gewesen waren, boten unaufhörliche Formveränderungen dar, waren aber nach 24 Stunden bewegungslos, wo das Blatt schlaff und allem Anscheine nach todt war. Andererseits waren bei Blättern, welche 48 Stunden lang einer starken Auflösung des Giftes der Brillenschlange ausgesetzt gewesen waren, die protoplasmatischen Massen ungewöhnlich lebendig, während bei höheren Thieren die Flimmerhaare und die weiszen Blutkörperchen von dieser Substanz schnell gelähmt zu werden scheinen.

# Physiologische Wirkung von Salzen

Bei den Salzen der Alkalien und Erden bestimmt die Natur der Basis und nicht die der Säure ihre physiologische Wirkung auf Drosera, wie es gleichfalls bei Thieren der Fall ist; diese Regel ist aber kaum auf die Chinin- und Strychnin-Salze anwendbar; denn das essigsaure Chinin verursacht viel mehr Einbiegung als das schwefelsaure, und beide sind giftig, während das salpetersaure Chinin nicht giftig ist und Einbiegung in einem viel langsamern Tempo veranlaszt als das essigsaure. Die Wirkung des citronensaureu Strychnins ist gleichfalls von der des schwefelsauren etwas verschieden.

# Einwirkung von Wasser und anderen Lösungen

Auf Blätter, welche 24 Stunden lang in Wasser oder nur 20 Minuten lang in verdünnten Alkohol oder in eine schwache Zucker- lösung eingetaucht gewesen waren, wirkt später das phosphorsaure Ammoniak sehr langsam ein oder gar nicht, obschon das kohlensaure Ammoniak schnell auf dieselben wirkt. Ein 20 Minuten langes Ein- tauchen in eine Lösung von arabischem Gummi hat keinen derartigen verzögernden Einflusz. Die Lösungen gewisser Salze und Säuren afficiren die Blätter, in Bezug auf die spätere Einwirkung des phosphorsauren Ammoniaks, genau so wie Wasser, während andere das Phosphat nachher schnell und energisch wirken lassen. In diesem letztern Falle könnten die Zwischenräume in den Zellwandungen durch Molecule der zuerst in Lösung angewandten Salze verstopft sein, so dasz das Wasser später nicht eindringen könnte, trotzdem die Mole-# Wirkung von Campher und ätherischen Ölen

Die Wirkung von in Wasser aufgelöstem Campher ist merkwürdig, denn er veranlasst nicht blosz bald Einbiegung, sondern macht auch allem Anscheine nach die Drüsen äuszerst empfindlich für mechanische Reizung; denn wenn sie nach einem Eintauchen in die Lösung für kurze Zeit mit einem weichen Pinsel bestrichen werden, so fangen die Tentakeln in ungefähr zwei Minuten an sich zu biegen. Es könnte indessen sein, dasz das Bepinseln, obschon an und für sich kein hinreichender Reiz, doch eine Bewegung dadurch zu erregen strebt, dasz es die directe Wirkung des Camphers verstärkt. Campher-dämpfe wirken andererseits narcotisch.

# Wirkung von Alkohol und Dämpfen

Einige ätherische Öle verursachen sowohl in Auflösung als auch in Dampfform rapide Einbiegung, andere haben dies Vermögen nicht; diejenigen, welche ich versuchte, waren sämmtlich giftig. Verdünnter Alkohol (ein Theil auf sieben Theile Wasser) ist nicht giftig, bewirkt keine Einbiegung und vermehrt auch nicht die Empfindlichkeit der Blätter für mechanische Reizung. Der Dampf wirkt als Narcoticum oder anaesthetisch, und ein langes Aussetzen tödtet die Blätter.

# Einfluss von Chloroform und anderen Dämpfen

Die Dämpfe von Chloroform, Schwefel- und Salpeter-Äther wirken in einer eigenthümlich schwankenden Weise auf verschiedene Blätter und selbst auf die verschiedenen Tentakeln an einem und demselben Blatte. Dies ist, wie ich vermuthe, Folge von Verschiedenheiten des Alters oder der Constitution der Blätter, und auch des Umstandes, ob gewisse Tentakeln vor Kurzem thätig gewesen sind. Dasz diese Dämpfe von den Drüsen absorbirt werden, beweist ihre Farbenveränderung, da aber auch andere, nicht mit Drüsen versehene Pflanzen von diesen Dämpfen afficirt werden, so ist es wahrscheinlich, dasz sie auch von den Spaltöffnungen der Drosera absorbirt werden.

# Reaktion der Blätter auf Kohlensäure

Wurden die Blätter 2 Stunden lang, in einem Falle nur 45 Minuten lang der Kohlensäure ausgesetzt, so wurden dadurch die Drüsen gleichfalls für eine Zeitlang gegen den mächtigen Reiz rohen Fleisches unempfindlich gemacht. Wurden indesz die Blätter 24 oder 48 Stunden in der Luft gelassen, so erhielten sie ihre volle Thätigkeit wieder und schienen nicht im mindesten beschädigt zu sein.

# Zusammenfassung des Kapitels

Wir haben im dritten Capitel gesehen, dasz der Procesz des Zusammenballens bei Blättern, welche 2 Stunden lang diesem Gase ausgesetzt und dann in eine Lösung von kohlensaurem Ammoniak gelegt wurden, sehr verzögert wird, so dasz eine beträchtliche Zeit vergeht, ehe das Protoplasma in den untern Zellen der Tentakeln zusammengeballt wird. In einigen Fällen bewegten sich, bald nachdem die Blätter aus dem Gas entfernt und in die Luft gebracht wor-den waren, die Tentakeln von selbst, wie ich vermuthe in Folge der durch den Zutritt des Sauerstoffs bewirkten Reizung. Indessen konnten diese eingebogenen Tentakeln einige Zeit lang nachher durch Reizung ihrer Drüsen zu keiner weiteren Bewegung angeregt werden.# Zehntes Kapitel
## Über die Empfindlichkeit der Blätter und über die Übermittlungsbahnen des motorischen Impulses

### Empfindlichkeit der Drüsen und Tentakeln
Die Drüsen und Spitzen der Tentakeln allein empfindlich. — Übermittelung des motorischen Impulses die Stiele der Tentakeln hinab und quer durch die Blattscheibe. — Zusammenballung des Protoplasma eine Reflexthätigkeit. — Erste Entladung des motorischen Impulses plötzlich. — Richtung der Bewegungen der Tentakeln. — Motorischer Impuls durch das Zellengewebe übermittelt. — Mechanismus der Bewegungen. — Natur des motorischen Impulses. — Wiederausbreitung der Tentakeln.

### Reizbarkeit und motorischer Impuls
Wir haben in den vorausgehenden Capiteln gesehen, dasz viele weit von einander verschiedene Reizmittel, mechanische wie chemische, die Bewegung der Tentakeln anregen, ebenso wie die der Blattscheibe; und wir müssen nun zuerst betrachten, welches die Punkte sind, welche reizbar oder empfindlich sind, und zweitens, wie der motorische Impuls von einem Punkte auf den andern übermittelt wird.

### Beobachtungen zur Reizbarkeit
Die Drüsen sind beinahe ausschlieszlich der Sitz der Reizbarkeit, und doch musz sich diese Reizbarkeit eine sehr kurze Strecke weit unterhalb derselben erstrecken; denn wenn sie mit einer scharfen Scheere abgeschnitten wurden, ohne selbst berührt zu werden, so wurden die Tentakeln häufig eingebogen. Diese kopflosen Tentakeln breiteten sich häufig wieder aus; und wenn später Tropfen der beiden stärksten bekannten Reizmittel auf die Schnittenden gebracht wurden, so wurde keine Wirkung hervorgebracht.

### Einfluss von Reizmitteln auf Tentakeln
Nichtsdestoweniger sind diese kopflosen Tentakeln einer späteren Einbiegung fähig, wenn sie durch einen ihnen von der Scheibe zugesandten Impuls gereizt werden. Es gelang mir bei verschiedenen Gelegenheiten, Drüsen zwischen feinen Pincetten zu zerquetschen; dies erregte aber durchaus keine Bewegung, ebenso wenig thaten es rohes Fleisch und Ammoniaksalze, wenn sie auf solche zerquetschte Drüsen gebracht wurden.

### Protoplasma und motorischer Impuls
Es ist wohl wahrscheinlich, dasz sie so augenblicklich getödtet wurden, dasz sie nicht mehr im Stande waren, irgend einen motorischen Impuls weiter zu senden; denn in sechs beobachteten Fällen (in zweien derselben wurde indessen die Drüse ganz weggeknippen) wurde das Protoplasma innerhalb der Zellen der Tentakeln nicht zusammengeballt, während in einigen angrenzenden Tentakeln, welche in Folge davon, dasz sie mit der Pincette roh berührt worden waren, eingebogen wurden, das Protoplasma gut zusammengeballt wurde.

### Reaktion auf Temperatur und mechanische Einwirkung
In gleicher Weise wird das Protoplasma nicht zusammengeballt, wenn ein Blatt durch Eintauchen in kochendes Wasser augenblicklich getödtet wird. Auf der andern Seite trat doch ein deutlicher, wenn auch mäsziger, Grad von Zusammenballung in mehreren Fällen ein, in denen die Tentakeln, nachdem ihre Drüsen mit einer scharfen Scheere abgeschnitten worden war, eingebogen wurden.

### Reizmittel und Bewegung der Tentakeln
Die Stiele der Tentakeln wurden heftig und wiederholt gerieben; rohes Fleisch oder andere reizende Substanzen wurden sowohl auf die obere Fläche in der Nähe der Basis als auch an andern Stellen auf sie gelegt; es erfolgte aber keine deutliche Bewegung. Einige Stückchen Fleisch wurden, nachdem sie eine beträchtliche Zeit lang auf den Stielen gelassen worden waren, nach oben geschoben, so dasz sie die Drüsen eben berührten; und in einer Minute fiengen die Tentakeln sich zu biegen an.

### Empfindlichkeit der Blattscheibe
Ich glaube, dasz die Blattscheibe nicht empfindlich für irgend welches Reizmittel ist. Ich stiesz die Spitze einer Lancette durch die Scheiben mehrerer Blätter und eine Nadel drei oder vier mal durch neunzehn Blätter; im erstern Falle erfolgte keine Bewegung; aber ungefähr bei einem Dutzend Blätter, welche wiederholt gestochen worden waren, wurden einige wenige Tentakeln unregelmäßig eingebogen. Da ındesz während der Operation ihre Rückseiten unterstützt werden muszten, so können vielleicht einige der äuszeren# Empfindlichkeit der Blätter

Drüsen ebenso wie diejenigen auf der Scheibe berührt worden sein; und dies genügte vielleicht, den unbedeutenden Grad von Bewegung, welcher beobachtet wurde, zu verursachen. NitschkeBotanische Zeitung, 1860, p. 234. sagt, dasz Schneiden und Stechen des Blattes keine Bewegung erregt. Der Blattstiel ist vollständig unempfindlich.

# Struktur der Blätter

Die Rückseite der Blätter trägt zahlreiche äuszerst kleine Papillen, welche nicht absondern, aber die Fähigkeit der Aufsaugung besitzen. Diese Papillen sind, wie ich glaube, Rudimente früher hier existirt habender Tentakeln, zusammen mit ihren Drüsen. Viele Experimente wurden angestellt, um zu ermitteln ob die Rückseite der Blätter in irgend welcher Weise gereizt werden könne; es wurden sieben und dreiszig Blätter dabei versucht. Einige wurden lange Zeit hindurch mit einer stumpfen Nadel gerieben; auf andere wurden Tropfen von Milch und andern reizenden Flüssigkeiten, rohes Fleisch, zerdrückte Fliegen und verschiedene andere Substanzen gebracht. Diese Substanzen wurden gern bald trocken, zum Beweise, dasz keine Absonderung angeregt worden war. Ich feuchtete sie daher mit Speichel, mit Ammoniaklösungen, schwacher Salzsäure und häufig mit dem Secrete aus den Drüsen anderer Blätter an. Ich hielt auch einige Blätter, auf deren Rückseite reizende Gegenstände gebracht worden waren, unter einer feuchten Glasglocke; aber bei aller meiner Sorgfalt sah ich doch niemals irgend eine wahre Bewegung.

# Anomalien in der Bewegung

Ich wurde dadurch dazu geführt, so viele Versuche zu machen, weil, im Gegensatz zu meinen früheren Erfahrungen, Nitschke angibtBotanische Zeitung, 1860, p. 437., dasz er, nachdem er Gegenstände mit Hülfe der klebrigen Absonderung an der Rückseite der Blätter befestigt habe, wiederholt die Tentakeln (und in einem Falle sogar die Blattscheibe) zurückgebogen gesehen habe. Wenn diese Bewegung eine wirkliche gewesen ist, würde sie eine äuszerst anomale sein; denn sie setzt voraus, dasz die Tentakeln einen motorischen Impuls von einer unnatürlichen Quelle her erhalten und das Vermögen haben, sich in einer Richtung zu biegen, welche zu der ihnen sonst gewohnten genau die umgekehrte ist; dies Vermögen wäre übrigens für die Pflanze auch nicht von dem mindesten Nutzen, da Insecten nicht an der glatten Rückseite der Blätter kleben bleiben können.

# Ergebnisse der Experimente

Ich habe gesagt, dasz in den oben erwähnten Fällen keine Wirkung hervorgebracht worden sei; dies ist aber nicht ganz streng richtig; denn in drei Fällen wurden zu den Stückchen rohen Fleisches auf der Rückseite der Blätter, um sie eine Zeit lang feucht zu erhalten, ein wenig Syrup hinzugefügt; und nach 36 Stunden war eine Spur von Zurückbiegen in den Tentakeln eines Blattes und sicher auch in der Scheibe eines andern vorhanden. Nach zwölf weiteren Stunden fiengen die Drüsen an zu trocknen, und alle drei Blätter schienen bedeutend verletzt zu sein. Es wurden dann vier Blätter unter eine Glasglocke gebracht, die Stiele in Wasser, und auf der Rückseite Tropfen von Zuckerlösung, aber ohne irgend welches Fleisch. Bei zweien dieser Blätter waren nach Verlauf eines Tages einige wenige Tentakeln rückwärts gebogen. Die Tropfen hatten nun beträchtlich an Grösze zugenommen, da sie Feuchtigkeit eingesaugt hatten, und zwar so, dasz sie die Rückseite der Tentakeln und Stiele hinab tröpfelten. Am zweiten Tage war bei einem Blatte die Scheibe bedeutend zurückgeschlagen: am dritten Tage waren die Tentakeln von zweien, ebenso wie die Scheiben aller vier, in einem bedeutenderen oder minderen Grade zurückgeschlagen. Die obere Seite des einen Blattes bot nun, anstatt wie zuerst unbedeutend concav zu sein, eine starke Convexität nach aufwärts dar. Selbst am fünften Tage schienen die Blätter nicht todt zu sein. Da nun Zucker die Drosera nicht im Mindesten reizt, so können wir das Zurückschlagen der Scheiben und Tentakeln der obigen Blätter getrost der Exosmose aus.# Zuckerlösung und Pflanzenreaktionen

den Zellen, welche mit der Zuckerlösung in Berührung waren, und der in Folge derselben eintretenden Contraction derselben zuschreiben. Wenn Tropfen einer dicken Zuckerlösung auf die Blätter von Pflanzen gebracht werden, deren Wurzeln sich noch immer in feuchter Erde befinden, so erfolgt keine Einbiegung; denn ohne Zweifel pumpen die Wurzeln Wasser so geschwind hinauf, als es durch Exosmose verloren wird. Wenn aber abgeschnittene Blätter in Syrup oder irgend eine andere dichte Flüssigkeit eingetaucht werden, so werden die Tentakeln bedeutend, wenn schon unregelmäszig, eingebogen, wobei einige die Form von Korkziehern annehmen; auch werden die Blätter bald welk. Wenn sie nun in eine Flüssigkeit von niedrigem spezifischem Gewicht eingetaucht werden, so strecken sich die Tentakeln wieder aus. Aus diesen Thatsachen können wir schlieszen, dasz auf die Rückseite von Blättern gebrachte Tropfen dichter Zuckerlösung nicht dadurch wirken, dasz sie einen motorischen Impuls anregen, welcher den Tentakeln übermittelt wird, sondern dadurch, dasz sie durch Herbeiführung von Exosmose das Zurückschlagen verursachen. Dr. Nitschke benutzte das Secret dazu, Insecten an die Rückseite von Blättern zu kleben; und ich vermuthe, er brauchte eine grosze Quantität, welche, da sie dicht war, Exosmose verursachte. Vielleicht experimentirte er auch mit abgeschnittenen Blättern oder an Pflanzen, deren Wurzeln nicht genügend mit Wasser versehen wurden.

# Empfindlichkeit der Drüsen

Soweit daher unsere gegenwärtige Kenntnis reicht, können wir schlieszen, dasz die Drüsen zusammen mit den unmittelbar darunter liegenden Zellen der Tentakeln der ausschlieszliche Sitz der Reizbarkeit oder Empfindlichkeit sind, mit welchen die Blätter begabt sind. Der Grad, bis zu welchem eine Drüse gereizt ist, kann nur durch die Zahl der umgebenden Tentakeln, welche eingebogen werden, und durch die Grösze und Geschwindigkeit ihrer Bewegungen gemessen werden. Gleich lebenskräftige Blätter, derselben Temperatur ausgesetzt (und dies ist eine wichtige Bedingung) werden unter den folgenden Umständen in verschiedenen Graden erregt. Eine minutiöse Menge einer schwachen Lösung bringt keine Wirkung hervor; man füge mehr hinzu, oder gebe eine etwas stärkere Lösung, und die Tentakeln biegen sich. Man berühre eine Drüse ein- oder zweimal und keine Bewegung erfolgt; man bewege sie drei- oder viermal, und die Tentakeln werden eingebogen. Aber die Beschaffenheit der den Blättern gegebenen Substanz ist ein sehr wichtiges Element: wenn gleich grosse Stückchen Glas (welches nur mechanisch wirkt), von Gelatine und rohem Fleisch auf die Scheiben mehrerer Blätter gelegt werden, so verursacht das Fleisch eine viel schnellere, energischere und weiter verbreitete Bewegung, als die zwei erstern Substanzen. Auch ruft die Zahl der Drüsen, welche gereizt werden, eine grosze Verschiedenheit im Resultate hervor: man lege ein Stückchen Fleisch auf eine oder zwei der Scheibendrüsen und nur einige wenige der umgebenden kurzen Tentakeln werden eingebogen; man lege es auf mehrere Drüsen, und die Wirkung wird sich auf viel mehr erstrecken; man lege es auf dreiszig oder vierzig, und alle Tentakeln, mit Einschlusz der äuszersten randständigen, werden dicht eingebogen. Wir sehen hieraus, dasz die von einer Anzahl von Drüsen ausgehenden Impulse einander kräftigen, sich weiter verbreiten und auf eine gröszere Anzahl von Tentakeln wirken, als der Impuls von irgend einer einzelnen Drüse.

# Übermittlung des motorischen Impulses

In einem jeden Falle hat der von einer Drüse ausgehende Impuls mindestens eine kurze Strecke weit zu den basalen Theilen des Tentakels zu wandern, da der obere Theil und die Drüse selbst einfach durch die Einbiegung des untern Theiles bewegt werden. Der Impuls wird in dieser Weise immer nahezu die ganze Länge des Stieles hinab gesandt. Wenn die centralen Drüsen gereizt und die äuszersten randständigen Tentakeln eingebogen werden, so wird der Impuls quer durch den halben Durchmesser der Scheibe übermittelt; und wenn# Motorische Impulse und Tentakeln

Die Drüsen an einer Seite der Scheibe gereizt werden, so wird der Impuls beinahe quer über die ganze Breite der Scheibe hinübergesandt. Eine Drüse übersendet ihren motorischen Impuls viel leichter und schneller ihren eigenen Tentakel hinab nach der sich biegenden Stelle als quer über die Scheibe an benachbarte Tentakeln. Wenn hiernach eine äuszerst kleine Dosis einer sehr schwachen Ammoniaklösung einer der Drüsen der äuszeren Tentakeln gegeben wird, so verursacht sie, dasz sich derselbe biegt und die Mitte erreicht; während ein groszer Tropfen derselben Lösung, wenn er zwanzig Drüsen auf der Scheibe gegeben wird, durch deren combinirten Einflusz doch nicht die mindeste Einbiegung der äuszern Tentakeln verursachen wird.

# Reaktion auf Reize

Wenn ferner ein Stückchen Fleisch auf die Drüse eines äuszeren Tentakels gethan wird, so habe ich Bewegung in zehn Secunden und wiederholt innerhalb einer Minute eintreten sehn; aber ein viel gröszeres Stück auf mehrere Drüsen auf der Scheibe gelegt, veran-
laszte die äuszeren Tentakeln nicht eher sich zu biegen als bis nach Verlauf einer oder mehrerer Stunden. Der motorische Impuls breitet sich von einer oder mehr gereizten Drüsen allmählich nach allen Seiten hin aus, so dasz die Tentakeln, welche am nächsten stehn, immer zuerst afficirt werden.

# Einfluss der zentralen Drüsen

Wenn daher die Drüsen im Mittelpunkte der Scheibe gereizt werden, so sind die äuszersten randständigen Tentakeln die zuletzt eingebo-
genen. Aber die Drüsen auf verschiedenen Theilen des Blattes übermitteln ihre motorische Kraft in einer etwas verschiedenen Art und Weise. Wenn ein Stückchen Fleisch auf die langköpfige Drüse eines randständigen Tentakels gelegt wird, so überliefert sie schnell einen Impuls dem sich biegenden Theil ihres eigenen Tentakels, niemals aber, so weit ich beobachtet habe, an benachbarte Tentakeln; denn diese werden nicht eher afficirt, als bis das Fleisch nach den centralen Drüsen hin geschafft worden ist, welche dann ihren vereinigten Impuls nach allen Seiten hin ausstrahlen.

# Experimentelle Beobachtungen

Bei vier Gelegenheiten wur-
den Blätter so präparirt, dasz einige Tage vorher alle Drüsen aus dem Centrum entfernt wurden, so dasz dieselben nicht durch Fleisch-
stückchen gereizt werden konnten, welche ihnen durch die Einbiegung der randständigen Tentakeln zugeführt wurden; und nun breiteten sich diese randständigen Tentakeln nach einiger Zeit wieder aus, ohne dasz irgend ein anderer Tentakel afficirt worden wäre. Andere Blätter wurden ähnlich präparirt, und Stückchen Fleisch wurden auf die Drüsen von zwei Tentakeln in der dritten Reihe von der Auszenseite her, und auf die Drüsen von zwei Tentakeln in der fünften Reihe gelegt.

# Verbreitung des Impulses

In diesen vier Fällen wurde der Impuls an erster Stelle seitwärts, d. h. in derselben concentrischen Reihe der Tentakeln, und dann nach dem Centrum hin weiter geschickt, aber nicht centrifugal oder nach den äuszeren Tentakeln hin. In einem dieser Fälle wurde nur ein einziger Tentakel auf jeder Seite des einen mit Fleisch afficirt. In den drei andern Fällen wurden von einem halben bis ganzen Dutzend Tentakeln, sowohl seitwärts als nach der Mitte hin, gut eingebogen oder halb eingebogen.

# Weitere Experimente

Endlich wurden in zehn andern Experimenten minutiöse Stückchen Fleisch auf eine einzige oder auf zwei Drüsen in der Mitte der Scheibe gelegt. Damit keine andere Drüse das Fleisch berühren solle, und zwar durch die Einbiegung der dicht anstoszenden kurzen Tentakeln, war vorher ungefähr ein halbes Dutzend Drüsen rings um die ausgewählten entfernt worden. Bei acht von diesen Blättern wurden im Laufe von ein oder zwei Tagen von sechzehn bis fünf und zwanzig der kurzen umgebenden Tentakeln eingebogen, so dasz der von einer oder zwei der scheibenständigen Drüsen ausstrahlende motorische Impuls im Stande ist, so viel Wir-
kung hervorzubringen.

# Schlussfolgerungen

Die Tentakeln, welche entfernt worden waren, sind in den angegebenen Zahlen eingeschlossen; denn da sie so dicht daneben standen, würden sie sicherlich afficirt worden sein. Bei den zwei noch übrigen Blättern wurden beinahe alle die kurzen Tentakeln auf der Scheibe eingebogen. Mit einem noch kräftigeren Reizmittel als Fleisch, nämlich ein wenig phosphorsauren Kalk mit Speichel be-# Übermittlung des motorischen Impulses

feuchtet, habe ich die Einbiegung sich von einer einzigen in dieser Weise behandelten Drüse noch weiter verbreiten sehen; aber selbst in diesem Falle wurden die drei oder vier äuszern Tentakelreihen nicht afficirt. Aus diesen Experimenten ergibt sich, dasz der Impuls von einer einzelnen Drüse auf der Scheibe aus auf eine gröszere Anzahl von Tentakeln wirkt, als der von einer Drüse der äuszeren verlängerten Tentakeln ausgehende; und dies ist wahrscheinlich, wenigsten zum Theil, Folge davon, dasz der Impuls, da er nur eine sehr kurze Strecke weit die Stiele der mittelständigen Tentakeln hinab zu wandern hat, im Stande ist, sich eine beträchtliche Entfernung rings herum zu verbreiten.

# Beobachtungen und Experimente

Als ich diese Blätter untersuchte, war ich von der Thatsache überrascht, dasz bei sechs, oder vielleicht sieben, von ihnen die Tentakeln an den nächsten und entferntesten Punkten des Blattes (d. h. nach der Spitze und der Basis, oder dem Stielende zu) viel mehr eingebogen waren, als auf den beiden Seiten; und doch standen die Tentakeln an den Seiten der Drüse, wo das Stückchen Fleisch lag, genau so nahe wie die an den beiden Enden. Es schien hiernach, als würde der motorische Impuls von dem Centrum aus quer über die Scheibe leichter in einer longitudinalen als in einer queren Richtung übermittelt; und da dies eine neue und interessante Thatsache in der Physiologie der Pflanzen zu sein schien, so wurden fünf und dreiszig frische Experimente angestellt, um ihre Richtigkeit zu prüfen. Minutiöse Stückchen Fleisch wurden auf eine einzelne oder auf einige wenige Drüsen auf der rechten oder linken Seite der Scheibe von achtzehn Blättern gelegt; während andere Stückchen von der nämlichen Grösze auf die nächsten und entfernten Ende von siebenzehn andern Blättern gethan wurden. Wenn nun der motorische Impuls mit gleicher Kraft oder mit gleicher Geschwindigkeit durch die Blatt- scheibe in allen Richtungen hin übermittelt würde, so müszte ein Stückchen Fleisch, welches auf eine Seite oder an das eine Ende der Scheibe gelegt wurde, gleichmäszig alle in gleicher Entfernung von ihm gelegene Tentakeln afficiren; dies war aber sicherlich nicht der Fall. Ehe ich die allgemeinen Resultate mittheile, ist es wohl der Mühe werth, drei oder vier ziemlich ungewöhnliche Fälle zu beschreiben.

# Ungewöhnliche Fälle

1. Ein äuszerst kleines Bruchstück einer Fliege wurde auf die eine Seite der Scheibe gelegt, und nach 32 Minuten waren sieben der äuszern Tentakeln in der Nähe des Bruchstücks eingebogen; nach 10 Stunden wurden es noch verschiedene mehr und nach 23 Stunden eine noch gröszere Anzahl; jetzt wurde auch die Scheibe des Blattes auf dieser Seite einwärts gebogen, so dasz sie zu der der andern Seite im rechten Winkel aufrecht stand. Weder die Scheibe des Blattes noch ein einziger Tentakel auf der gegenüberliegenden Seite war afficirt; die Trennungs- linie zwischen den beiden Hälften erstreckte sich vom Stiele bis zur Blattspitze. Das Blatt blieb drei Tage lang in diesem Zustande, am vierten Tage begann es sich wieder auszubreiten; auf der gegenüber- liegenden Seite war nicht ein einziger Tentakel eingebogen worden.

2. Ich will hier einen Fall mittheilen, der nicht mit in den oben erwähnten fünf und dreiszig Experimenten eingeschlossen ist. Eine kleine Fliege wurde gefunden, welche mit ihren Füszen der linken Seite der Scheibe anhieng. Die Tentakeln auf dieser Seite bogen sich bald dicht ein und tödteten die Fliege; wahrscheinlich in Folge des Kämpfens, so lange die Fliege lebendig war, war das Blatt so sehr gereizt, dasz in Drosera rotundifolia. unge- fähr 24 Stunden alle Tentakeln auf der entgegengesetzten Seite eingebogen wurden; da sie aber keine Beute fanden, — denn ihre Drüsen erreichten die Fliege nicht, — breiteten sie sich im Verlaufe von 15 Stunden wieder aus, während die Tentakeln auf der linken Seite mehrere Tage eingeschlagen blieben.

3. Ein Stückchen Fleisch, eher etwas gröszer als die gewöhnlich benutzten, wurde in der Medianlinie am basalen Ende der Scheibe in die Nähe des Stieles gelegt; nach 2 Stunden 30 Minuten waren einige der# Tentakeln und Fleischstücke

in der Nähe stehenden Tentakeln eingebogen; nach 6 Stunden waren die Tentakeln auf beiden Seiten des Blattstieles und eine Strecke weit an beiden Seiten hinauf mäszig eingebogen; nach 8 Stunden waren die Tentakeln an dem andern, ferneren oder Spitzenende mehr eingebogen als die auf beiden Seiten; nach 23 Stunden war das Fleisch ordentlich von allen Tentakeln umfaszt, ausgenommen von den äuszeren auf den beiden Seiten.

## Experimentelle Ergebnisse

Ein anderes Stückchen Fleisch wurde auf das andere, entferntere oder Spitzende eines andern Blattes gelegt mit genau denselben relativen Resultaten. Ein sehr kleines Stückchen Fleisch wurde auf die eine Seite der Scheibe gelegt; am nächsten Tage waren die in der Nähe stehenden kurzen Tentakeln eingebogen, ebenso wie auch drei oder vier auf der entgegengesetzten Seite in der Nähe des Stengels in einem unbedeutenden Grade. Am zweiten Tage boten diese letzteren Tentakeln Zeichen der Wiederausstreckung dar; ich that daher ein frisches Stückchen Fleisch auf nahezu denselben Fleck und nach zwei Tagen waren einige der kurzen Tentakeln auf der entgegengesetzten Seite der Scheibe eingebogen. So bald diese sich wieder auszubreiten anfiengen, fügte ich ein anderes Stückchen Fleisch zu, und am nächsten Tage waren alle Tentakeln auf der entgegengesetzten Seite der Scheibe nach dem Fleische zu eingebogen; während, wie wir gesehen haben, diejenigen auf derselben Seite durch das erste dem Blatte gegebene Stückchen Fleisch afficirt wurden.

## Allgemeine Resultate

Nun zu den allgemeinen Resultaten. Von den achtzehn Blättern, bei denen Stückchen Fleisch auf die rechte oder linke Seite der Scheibe gelegt wurden, war bei acht eine ungeheure Anzahl von Tentakeln auf derselben Seite eingebogen, und bei vier von ihnen war die Scheibe selbst auf dieser Seite gleichfalls eingebogen; während weder ein einziger Tentakel noch die Scheibe auf der entgegengesetzten Seite afficirt waren. Diese Blätter boten ein merkwürdiges Aussehn dar, als wenn nur die eingebogene Seite thätig und die andere ge-lähmt wäre. In den übrigen zehn Fällen wurden einige wenige Tentakeln jenseits der Mittellinie, auf der, der Seite wo das Fleisch lag entgegengesetzten Seite eingebogen; aber in einigen von diesen Fällen nur am Stiel- oder Spitzenende der Blätter. Die Einbiegung auf der entgegengesetzten Seite erfolgte immer beträchtliche Zeit nach der auf derselben Seite und in einem Falle nicht vor dem vierten Tage. Wir haben auch bei No. 5 gesehen, dasz dreimal Stückchen Fleisch nachgegeben werden muszten, ehe alle die kurzen Tentakeln auf der entgegengesetzten Seite der Scheibe eingebogen wurden.

## Vergleich der Ergebnisse

Das Resultat war sehr verschieden, wenn Stückchen Fleisch in der Medianlinie auf das nähere Stiel-, oder entferntere Spitzen-Ende der Scheibe gelegt wurde. In drei der in dieser Weise angestellten siebzehn Versuche waren entweder in Folge des Zustandes des Blattes oder in Folge der Kleinheit des Fleischstückchens nur die unmittelbar angrenzenden Tentakeln afficirt; aber in den andern vierzehn Fällen wurden die Tentakeln an dem entgegengesetzten Ende des Blattes eingebogen, obschon diese von dem Punkte, wo das Fleisch lag ebenso entfernt waren, wie es die auf der einen Seite der Scheibe vom Fleische auf der entgegengesetzten Seite waren. In einigen der vorliegenden Fälle wurden die Tentakeln auf den Seiten durchaus gar nicht afficirt, oder in einem geringeren Grade, oder nach einem längeren Zeitverlauf als die am entgegengesetzten Ende. Eine Reihe von Experimenten verdient in ausführlicherem Detail mitgetheilt zu werden. Würfel von Fleisch, nicht völlig so klein wie die gewöhnlich angewandten, wurden auf die eine Seite der Scheibe von vier Blättern gelegt, und Würfel von derselben Grösse auf das nähere oder entferntere (Stiel- oder Spitzen-) Ende vier anderer Blätter. Wenn nun diese beiden Reihen von Blättern nach Verlauf von 24 Stunden mit einander verglichen wurden, so boten sie einen auffallenden Unterschied dar. Diejenigen, welche die Würfel auf der einen Seite trugen, waren auf der entgegengesetzten Seite sehr unbedeutend.# Kapitel 10: Übermittlung des motorischen Impulses

afficirt; während bei denjenigen, welche die Würfel an einem der beiden Enden hatten, beinahe jeder Tentakel am entgegengesetzten Ende, selbst die randständigen, dicht eingebogen waren. Nach 48 Stunden war der Contrast in dem Zustand der beiden Reihen noch immer grosz; doch waren bei denen, welche das Fleisch auf einer Seite hatten, die scheiben- und randständigen Tentakeln auf der entgegengesetzten Seite etwas eingebogen, und zwar in Folge der bedeu-
tenden Grösze der Würfel. Endlich können wir aus diesen fünf und dreiszig Experimenten (die sechs oder sieben früheren gar nicht zu erwähnen) schlieszen, dasz der motorische Impuls von jeder einzelnen Drüse oder kleinen Gruppe von Drüsen durch die Scheibe der andern Drosera rotundifolia.

Tentakeln leichter und wirksamer in einer Längs- als in einer Quer-Richtung übermittelt wird.

So lange die Drüsen erregt bleiben, und dies kann viele Tage lang andauern, selbst elf Tage, so z. B. wenn sie mit phosphorsaurem Kalk in Berührung sind, übermitteln sie beständig einen motorischen Impuls den basalen und sich biegenden Theilen ihrer eigenen Stiele, denn sonst würden sie sich ja wieder ausbreiten. Der grosze Unter-
schied in der Länge der Zeit, während welcher Tentakeln über anor-
ganischen Körpern und über Gegenständen derselben Grösse, welche lösliche stickstoffhaltige Substanzen enthalten, eingebogen bleiben, beweist die nämliche Thatsache. Aber die Intensität des von einer gereizten Drüse ausgesandten Impulses, welche angefangen hat, ihr saures Secret zu ergieszen, und zu gleicher Zeit absorbirt, scheint sehr gering zu sein im Vergleich zu dem Impuls, den sie übermittelt, wenn sie zuerst gereizt wird.

So z. B., wenn mäszig grosze Stück-
chen Fleisch auf eine Seite der Scheibe gelegt wurden, und die scheiben- und halbrandständigen Tentakeln auf der entgegengesetzten Seite wurden eingebogen, so dasz ihre Drüsen zuletzt das Fleisch be-
rührten und Substanz aus ihm aufsaugten, so übersandten sie keinen motorischen Impuls an die äuszeren Reihen von Tentakeln auf der-
selben Seite; denn diese wurden niemals eingebogen. Wenn indessen Fleisch auf die Drüsen dieser nämlichen Tentakeln gelegt worden wäre, ehe sie angefangen hatten, reichlich abzusondern und zu absor-
bieren, so würden sie unzweifelhaft auch die äuszeren Reihen afficirt haben.

Trotzdem, wenn ich etwas phosphorsauren Kalk, welcher ein äuszerst wirksames Reizmittel ist, mehreren halbrandständigen Tentakeln gab, welche bereits beträchtlich eingebogen, aber noch nicht in Berührung waren mit etwas Phosphat, was vorher auf zwei Drüsen in dem Centrum der Scheibe gelegt worden war, so trat doch eine Wirkung auf die äuszeren Tentakeln auf derselben Seite ein.

Wenn eine Drüse zuerst gereizt wird, wird der motorische Im-
puls innerhalb weniger Secunden entladen, wie wir aus dem Biegen der Tentakeln erkennen; und er scheint zuerst mit viel gröszerer Kraft entladen zu werden als später. So wurde in dem oben angeführten Falle, wo eine kleine Fliege von einigen wenigen Drüsen auf einer Seite des Blattes auf natürliche Weise gefangen worden war, ein Impuls langsam von jenen aus quer durch die ganze Breite des Blattes ausgesandt, welcher die entgegengesetzten Tentakeln zeitweilig sich einzubiegen veranlaszte; aber die Drüsen, welche mit dem Insect in Berührung blieben, obschon sie mehrere Tage lang beständig einen Impuls ihre eigenen Stiele hinab zu der biegenden Stelle hinsandten, konnten doch nicht verhindern, dasz sich die Tentakeln auf der entgegengesetzten Seite schnell wieder ausbreiteten, so dasz der moto-
rische Impuls zuerst kräftiger gewesen sein musz als später.

Wenn ein Gegenstand irgend welcher Art auf die Scheibe gelegt wird, und die umgebenden Tentakeln werden eingebogen, so sondern ihre Drüsen reichlicher ab und das Secret wird sauer, so dasz ihnen ein gewisser Einflusz von den scheibenständigen Drüsen zugesandt wird. Diese Veränderung in der Beschaffenheit und Menge des Secrets kann nicht von der Beugung der Tentakeln abhängen, da die Drüsen der kurzen centralen Tentakeln eine Säure absondern, wenn ein Gegen-# Einleitung

stand auf sie gelegt wird, obschon sie sich nicht selbst biegen. Ich kam daher zu dem Schlusse, dasz die Drüsen der Scheibe einen gewissen Einflusz die umgebenden Tentakeln hinauf zu deren Drüsen sendeten, und dasz diese einen motorischen Impuls rückwärts an ihre basalen Theile reflectirten; diese Ansicht erwies sich jedoch bald als irrig. Es wurde durch viele Versuche ermittelt, dasz Tentakeln, deren Drüsen mit einer scharfen Scheere abgeschnitten worden waren, häufig eingebogen werden und sich wieder ausbreiten, dabei noch immer gesund erscheinend.

# Beobachtungen und Experimente

Einer, welcher genau beobachtet wurde, blieb augenscheinlich gesund, selbst zehn Tage lang nach der Operation. Ich schnitt daher die Drüsen von zwanzig Tentakeln zu verschiedenen Zeiten und an verschiedenen Blättern ab, und siebenzehn davon wurden bald eingebogen, und streckten sich später wieder aus. Die Wiederausstreckung begann in ungefähr 8 oder 9 Stunden und war in von 22 bis zu 30 Stunden von der Zeit der Einbiegung an gerechnet vollendet.

# Reaktion auf Reize

Nach einer Zwischenzeit von einem oder zwei Tagen wurde rohes Fleisch und Speichel auf die Scheiben dieser siebenzehn Blätter gelegt, und als sie am nächsten Tage beobachtet wurden, waren sieben von den kopflosen Tentakeln so dicht über dem Fleische eingebogen, wie die unverletzten Tentakeln an denselben Blättern; und nach weiteren drei Tagen wurde noch ein achter kopfloser Tentakel eingebogen. Das Fleisch wurde von einem der Blätter entfernt, und die Oberfläche mit einem sanften Wasserstrom gewaschen; nach drei Tagen streckte sich der kopflose Tentakel zum zweiten male wieder aus.

# Vergleich der Tentakeln

Diese Tentakeln ohne Drüsen waren Drosera rotundifolia. Cap. 10. indessen in einem verschiedenen Zustande von den mit Drüsen versehenen, welche Substanz aus dem Fleisch absorbirt hatten; denn das Protoplasma in den Zellen der ersten hatte viel weniger Zusammen-ballung erlitten. Nach diesen Experimenten mit kopflosen Tentakeln ist es sicher, dasz die Drüsen, so weit der motorische Impuls in Betracht kommt, in keiner Art von Reflexthätigkeit wirken, wie die Nervenganglien bei Thieren.

# Reflexartige Aktivitäten

Es findet sich aber eine andere Thätigkeit, nämlich die der Zusammenballung, welche in gewissen Fällen reflex genannt werden kann, und welche der einzige bekannte Fall im Pflanzenreich ist. Wir müssen im Sinne behalten, dasz der Procesz nicht von dem vorausgehenden Biegen der Tentakeln abhängt, wie wir deutlich sehen, wenn Blätter in gewisse starke Lösungen getaucht werden. Auch hängt er nicht von einer vermehrten Absonderung von den Drüsen ab; und dies zeigt sich durch mehrere Thatsachen, ganz besonders dadurch, dasz die Papillen, welche nicht absondern, doch eine Zusammenballung erfahren, wenn man ihnen kohlensaures Ammoniak oder einen Aufgusz von rohem Fleisch gibt.

# Reiz und Protoplasma

Wenn eine Drüse auf irgend welche Weise direct gereizt wird, so wie durch den Druck eines minutiösen Stückchen Glas, so wird zuerst das Protoplasma innerhalb der Zellen der Drüse, dann das in den Zellen unmittelbar unterhalb der Drüse zusammengeballt, und so immer tiefer und tiefer die Tentakeln hinab bis zu ihren Basen; — d. h. wenn der Reiz hinreichend stark und nicht schädlich war. Wenn nun die Drüsen der Scheibe gereizt werden, so werden die äuszeren Tentakeln in genau derselben Art und Weise afficirt: die Zusammenballung beginnt immer in ihren Drüsen, obschon diese nicht direct gereizt worden sind, sondern nur von der Scheibe einen gewissen Einflusz erhalten haben, wie sich durch ihre vermehrte saure Absonderung zeigt.

# Schlussfolgerung

Das Proto-plasma innerhalb der Zellen unmittelbar unterhalb der Drüsen wird zunächst afficirt und so weiter abwärts von Zelle zu Zelle bis zu den Basen der Tentakeln. Dieser Procesz verdient dem Anscheine nach eine Reflexthätigkeit genannt zu werden, in derselben Weise, wie, wenn ein sensorischer Nerv gereizt wird, derselbe einen Eindruck einem Ganglion zusendet, welches dann einen bestimmten Einflusz einem Muskel oder einer Drüse zurückgibt, welcher Bewegung oder vermehrte Absonderung verursacht; die Handlung selbst ist aber in den beiden Fällen wahrscheinlich von einer sehr verschiedenen Natur.# Richtung der eingebogenen Tentakeln

Nachdem das Protoplasma in einem Tentakel zusammengeballt worden ist, beginnt seine Wiederauflösung immer in dem unteren Teil und schreitet langsam den Stiel zur Drüse hinauf, so dass das zuletzt zusammengeballte Protoplasma das zuerst wieder aufgelöste ist. Dies hängt wahrscheinlich davon ab, dass das Protoplasma, je weiter und weiter in den Tentakeln hinab, umso weniger und weniger zusammengeballt ist, wie man deutlich sehen kann, wenn die Erregung gering gewesen ist. Sobald daher die zusammenballende Tätigkeit ganz und gar aufhört, beginnt naturgemäß die Wiederauflösung in der weniger stark zusammengeballten Masse in dem untersten Teil des Tentakels und wird dort zuerst vollendet.

## Bewegung der Tentakeln

Wenn ein Körperchen irgend welcher Art auf die Drüse eines der äußeren Tentakeln gelegt wird, so bewegt sich derselbe ausnahmslos nach dem Mittelpunkt des Blattes zu; und dasselbe ist der Fall mit allen Tentakeln eines in irgend eine erregende Flüssigkeit eingetauchten Blattes. Die Drüsen der äußeren Tentakeln bilden dann einen Ring rings um den mittleren Teil der Scheibe, wie es in einer früheren Figur dargestellt wurde (Fig. 4, S. 9). Die kurzen Tentakeln innerhalb dieses Ringes behalten noch immer ihre senkrechte Stellung, wie sie es auch tun, wenn ein großer Gegenstand auf ihre Drüsen gelegt wird oder wenn sie ein Insekt gefangen haben. In diesem letzteren Falle kann man sehen, dass die Einbiegung der kurzen zentralen Tentakeln nutzlos sein würde, da ihre Drüsen bereits mit der Beute in Berührung sind.

## Reaktion auf Reizung

Das Resultat ist sehr verschieden, wenn eine einzelne Drüse auf einer Seite der Scheibe gereizt wird, oder einige wenige zusammen in einer Gruppe. Diese senden einen Impuls an die umgebenden Tentakeln, welche sich nun nicht nach dem Mittelpunkt des Blattes hin, sondern nach dem Punkte der Reizung hin biegen. Wir verdanken diese äußerst wichtige Beobachtung NitschkeBotanische Zeitung, 1860, p. 240.; seitdem ich vor wenigen Jahren seinen Aufsatz gelesen habe, habe ich die Beobachtung wiederholt bestätigt. Wenn ein minutiöses Stückchen Fleisch mit Hilfe einer Nadel auf eine einzelne Drüse oder auf drei oder vier zusammen, halbwegs zwischen dem Zentrum und dem Umkreis der Scheibe gelegt wird, so zeigt sich die nach einem bestimmten Punkte hin gerichtete Bewegung der umgebenden Tentakeln sehr gut. Eine genaue Zeichnung eines Blattes mit Fleisch in dieser Lage wird hier mitgeteilt (Fig. 10); man sieht die Tentakeln, mit Einschluss einiger der äußeren, genau nach dem Punkte hin gerichtet, wo das Fleisch liegt.

## Experimentelle Beobachtungen

Eine viel bessere Methode ist aber die, ein Stückchen phosphorsauren Kalks mit Speichel angefeuchtet auf eine einzelne Drüse auf der einen Seite der Scheibe eines großen Blattes zu legen und ein anderes Stückchen auf eine einzelne der gegenüberliegenden Seite. In vier solchen Versuchen war die Reizung nicht hinreichend stark, um die äußeren Tentakeln zu affizieren, aber alle die den beiden Punkten nahe stehenden waren nach ihnen hingerichtet, so dass auf der Scheibe eines und desselben Blattes zwei Räder gebildet wurden: die Stiele der Tentakeln bildeten die Speichen und die über dem Phosphate zu einer Masse verbundenen Drüsen stellten die Achsen dar. Die Genauigkeit, mit welcher jeder Tentakel nach dem Stückchen hinwies, war wunderbar, so dass ich in einigen Fällen keine Abweichung von vollkommener Richtigkeit entdecken konnte. Wenn in dieser Weise die kurzen Tentakeln in der Mitte der Scheibe einen motorischen Impuls von irgend einem Punkte auf der einen Seite her erhalten, so richten sie sich doch, trotzdem.# Experimentelle Beobachtungen der Tentakeln

## Abweichungen der Tentakeln

## Motorischer Impuls und Bewegung

## Struktur der Tentakeln

## Vergleich mit anderen Pflanzenbewegungen# Über die Natur der Gewebe

## Verlauf der Gefäszbündel

## Schematische Darstellung der Verbreitung der Gefäszbündel

## Die leitenden Gewebe

## Motorischer Impuls und Versuche mit Fleisch# Beobachtungen der Tentakeln

40 Minuten (in allen Fällen von der Zeit an gerechnet, wo das Fleisch gegeben wurde) waren die Tentakeln am entfernten, Spitzen-, Ende ein wenig eingebogen, aber sonst nirgendwo anders; sie blieben drei Tage lang so und streckten sich am vierten Tage wieder aus. Das Blatt wurde dann zergliedert und der Stamm ebenso wie die beiden sublateralen Zweige wurden durchschnitten gefunden.

## Einbiegung der Tentakeln

Nach 4 Stunden 30 Minuten waren viele der Tentakeln am entfernten Blattende gut eingebogen. Am nächsten Tage waren die Scheibe und alle Tentakeln an diesem Ende stark eingebogen und wurden durch Darwin, Insectenfressende Pflanzen. (VIII.) 15 Drosera rotundifolia. Cap. 10. eine deutliche quere Linie von der basalen Hälfte des Blattes getrennt, welche nicht im mindesten afficirt war. Am dritten Tage waren indessen einige der kurzen Tentakeln auf der Scheibe in der Nähe der Basis unbedeutend eingebogen. Bei der Zergliederung ergab sich, dasz der Einschnitt sich quer über das Blatt erstreckte wie im letzten Falle.

## Beobachtungen nach 4 Stunden 30 Minuten

Nach 4 Stunden 30 Minuten war starke Einbiegung der Tentakeln am Spitzenende vorhanden, welche sich während der nächsten zwei Tage nicht im Allermindesten nach dem basalen Ende zu verbreitete. Der Einschnitt war wie früher.

## Langzeitbeobachtungen

Dies Blatt wurde nicht vor Verlauf von 15 Stunden beobachtet und dann wurden alle Tentakeln, mit Ausnahme der äuszersten randständigen, gleichmäszig rings um das ganze Blatt gut eingebogen gefunden. Bei sorgfältiger Untersuchung ergaben sich die Spiralgefässe des centralen Stammes als sicher durchschnitten; aber der Einschnitt war auf der einen Seite nicht durch das fasrige, die Gefässe umgebende Gewebe hindurchgegangen, obgleich er auf der andern Seite durch das Gewebe durchgedrungen war.

## Vergleich mit menschlicher Anatomie

Das von den Blättern 2 und 3 dargebotene Aussehen war sehr merkwürdig und kann passend mit dem eines Menschen verglichen werden, dessen Rückgrat gebrochen ist und dessen untere Extremitäten gelähmt sind. Ausgenommen, dasz die Trennungslinie zwischen den beiden Hälften hier quer war, statt longitudinal zu sein, waren diese Blätter in demselben Zustande wie einige der in den früheren Versuchen benutzten, mit Stückchen Fleisch, die auf die eine Seite der Scheibe gelegt waren.

## Motorische Impulse und Gewebe

Der Fall mit Blatt Nr. 4 beweist, dasz die Spiralgefässe des Hauptstammes durchschnitten sein können und dasz trotzdem der motorische Impuls vom Spitzen- zum Stiel-Ende des Blattes übermittelt werden kann. Dies führte mich zuerst zu der Vermuthung, dasz die motorische Kraft durch das dicht umgebende Fasergewebe fortgeleitet werde, und dasz, wenn die eine Hälfte dieses Gewebes ungetrennt erhalten wird, sie zur vollständigen Übermittlung genüge.

## Widersprüche und Beobachtungen

Aber in Widerspruch zu dieser Schluszfolgerung steht die Thatsache, dasz keine Gefässe direct von einer Seite des Blattes zur andern treten und dasz doch, wie wir gesehen haben, wenn ein etwas gröszeres Stückchen Fleisch auf die eine Seite gelegt wird, der motorische Impuls, wenn auch langsam und unvollkommen, in einer queren Richtung über die ganze Breite des Blattes hinübergeschickt wird. Man kann diese letztere Thatsache auch nicht dadurch erklären, dasz man annimmt, die Übermittelung werde durch die zwei Zusammenmündungen oder durch die am Blattumfang hinziehende Zickzacklinie der Gefäszverbindungen bewirkt; denn wäre dies der Fall gewesen, so würden die äuszeren Tentakeln auf der gegenüberliegenden Seite der Scheibe eher als die centraleren afficirt worden sein, was niemals vorkam.

## Fähigkeit der Tentakeln

Wir haben auch gesehen, dasz die äuszersten randständigen Tentakeln die Fähigkeit nicht zu besitzen scheinen, einen Impuls den benachbarten Tentakeln zu übermitteln; und doch gibt das kleine Bündel von Gefäszen, welches in jeden randständigen Tentakel eintritt, einen äuszerst kleinen Zweig an die zu beiden Seiten ab, und dies habe ich bei keinen andern Tentakeln beobachtet.# Motorischer Impuls und Tentakeln

Es sind daher die randständigen Tentakeln inniger durch Spiralgefäsze mit einander in Zusammenhang als die übrigen, und doch haben sie viel weniger Fähigkeit, einen motorischen Impuls einander mitzutheilen.

# Übermittlung des motorischen Impulses

Aber auszer diesen verschiedenen Thatsachen und Argumenten haben wir noch bündige Beweise, dasz der motorische Impuls wenigstens nicht ausschlieszlich durch die Spiralgefäsze oder durch das dieselbe unmittelbar umgebende Gewebe fortgeleitet wird.

# Reaktion der Tentakeln

Wir wissen, dasz, wenn ein Stückchen Fleisch auf eine Drüse (nach Entfernung der unmittelbar benachbarten) auf irgend einem Theile der Scheibe gebracht wird, sich alle die kurzen umgebenden Tentakeln beinahe gleichzeitig mit groszer Präcision nach ihm hin biegen.

# Struktur und Funktion der Tentakeln

Da der motorische Impuls nicht den Gefäszen entlang fortgeleitet wird, bleibt für seine Leitung nur das Zellgewebe übrig; und die Structur dieses Gewebes erklärt es bis zu einem gewissen Grade, woher es kommt, dasz der Impuls die langen äuszeren Tentakeln so schnell hinabgeht und so viel langsamer quer über die Scheibe des Blattes geht.

# Zusammenballung des Protoplasmas

Wir wissen, dasz ein und dasselbe Reizmittel Bewegung der Tentakeln und Zusammenballung des Protoplasma verursacht und dasz beide Einflüsse innerhalb desselben kurzen Zeitraums in den Drüsen ihren Ursprung nehmen und von den Drüsen ausgehen.# Mechanismus der Bewegungen und Natur des motorischen Impulses

langen äuszeren Tentakeln hinab geleitet wird, als quer über die Scheibe, kann zum groszen Theile dem Umstande zugeschrieben wer- den, dasz er dort dicht in den engen Stiel eingeschränkt ist, während er auf der Scheibe nach allen Seiten ausstrahlt. Aber abgesehen von dieser Einschränkung, sind die äuszeren Zellen der Tentakeln völlig zweimal so lang wie diejenigen der Scheibe, so dasz auf eine gegebene Länge eines Tentakels nur die halbe Anzahl von queren Scheidewänden kommt, welche zu durchsetzen sind, im Vergleich mit einem gleich groszen Raum auf der Scheibe; in demselben Verhältnis wird auch eine geringere Verlangsamung des Impulses eintreten. Überdies weisen Durchschnitte der äuszeren Tentakeln, welche Dr. War- ming mitgetheilt hat, nach, dasz die parenchymatösen Zellen noch mehr verlängert sind; und diese würden die allerdirecteste Communi- cationsbahn von der Drüse nach der Beugungsstelle des Tentakels hin sein. Wenn der Impuls die äuszeren Zellen hinabgeht, so würde er zwischen zwanzig und dreiszig Zellscheidewände zu durchsetzen haben, dagegen etwas weniger, wenn er durch das innere parenchymatöse Gewebe hinabläuft. In beiden Fällen ist es merkwürdig, dasz der Impuls im Stande ist, in zehn Secunden durch so viele Scheidewände nahezu die ganze Länge des Stiels hinabzugehen und auf die Beugungs- stelle zu wirken. Warum der Impuls, nachdem er einen der äuszer- sten randständigen Tentakeln (von ungefähr \frac {1}{20} Zoll Länge) so schnell hinabgelaufen ist, niemals, so weit ich es gesehen habe, die angren- zenden Tentakeln afficirt, verstehe ich nicht. Es kann vielleicht zum Theil dadurch erklärt werden, dasz bei der Schnelligkeit der Über- mittelung viel Energie verwandt worden ist.

# Zellenanordnung und Impulsverbreitung

Die meisten Zellen der Scheiben, sowohl die oberflächlichen als auch die gröszeren Zellen, welche die darunterliegenden fünf oder sechs Schichten bilden, sind ungefähr viermal so breit wie lang. Sie sind beinahe longitudinal angeordnet, vom Stiele strahlenförmig aus- gehend. Wenn daher der motorische Impuls quer über die Scheibe gesandt wird, so hat er nahezu viermal so viel Zellwandungen zu durchsetzen, wie wenn er in einer Längsrichtung übermittelt wird; er wird daher im erstern Falle bedeutend aufgehalten werden. Die Zellen der Scheibe convergiren nach den Basen der Tentakeln zu und sind daher geeignet, ihnen den motorischen Impuls von allen Seiten her zuzuführen. Im Ganzen wirft die Anordnung und die Form der Zellen, sowohl derjenigen der Scheibe als auch der der Tentakeln, viel Licht auf die Geschwindigkeit und Verbreitungsweise des motorischen Impulses. Warum aber derselbe von den Drüsen der Tentakeln der äuszeren Reihen seitwärts und nach dem Centrum des Blattes zu, und nicht centrifugal fortzuschreiten neigt, ist durchaus nicht klar.# Tentakelbewegungen und ihre Ursachen

Dem Falle, wo sich unter später noch zu erwähnenden Umständen ein Tentakel abnormerweise zu einem vollständigen Kreis gekrümmt hatte. Nicht alle Zellen erfahren eine Einwirkung, wennschon der motorische Impuls durch sie hindurchgeht. Wenn die Drüse eines der langen äußeren Tentakeln gereizt wird, so werden die oberen Zellen nicht im mindesten afficirt: ungefähr halbwegs hinab findet eine unbedeutende Biegung statt, aber die hauptsächlichste Bewegung ist auf einen kurzen Raum in der Nähe der Basis beschränkt, und kein Teil der inneren Tentakeln biegt sich, ausgenommen der basale Teil. Was die Scheibe des Blattes betrifft, so kann der motorische Impuls vom Mittelpunkt nach dem äußeren Umfang zu durch viele Zellen fortgeleitet werden, ohne dass sie im geringsten afficirt werden; oder es kann sich eine Wirkung auf sie sehr stark äußern und die Scheibe kann bedeutend eingebogen werden. Im letzteren Falle scheint die Bewegung zum Teil von der Stärke des Reizes, zum Teil von seiner Beschaffenheit abzuhängen, z. B. wenn Blätter in gewisse Flüssigkeiten eingetaucht werden.

## Mittel der Bewegung

Das Bewegungsvermögen, welches verschiedene Pflanzen besitzen, wenn sie gereizt werden, ist von bedeutenden Autoritäten dem rapiden Austritt von Flüssigkeit aus gewissen Zellen zugeschrieben worden, welche in Folge ihres vorausgehenden Spannungszustandes sich sofort zusammenziehen. Diese Ansicht sprach, glaube ich, zuerst Lamarck aus. Mag dies nun die primäre Ursache solcher Bewegungen sein oder nicht, so muss allerdings Flüssigkeit aus geschlossenen Zellen austreten, wenn sie sich zusammenziehen oder wenn sie in einer Richtung zusammengedrückt werden, vorausgesetzt, dass sie nicht in derselben Zeit sich in irgend einer anderen Richtung ausdehnen. So kann man z. B. sehen, dass Flüssigkeit aus der Oberfläche eines jeden jungen und lebenskräftigen Schößlings herausquillt, wenn er in einem Halbkreise gebogen wird. Was Drosera betrifft, so findet sicherlich viel Bewegung von Flüssigkeit durch die ganzen Tentakeln statt, während sie Einbiegung erleiden. Es lassen sich viele Blätter finden, an denen die purpurne Flüssigkeit innerhalb der Zellen auf der oberen und unteren Seite der Tentakeln von einer gleichmäßig dunklen Färbung ist und sich auch auf beiden Seiten gleichmäßig bis in die Nähe der Basen hinaberstreckt. Wenn die Tentakeln eines solchen Blattes zur Bewegung gereizt werden, so wird man allgemein nach einigen Stunden finden, dass die Zellen der concaven Seite viel blasser sind, als sie vorher waren, oder dass sie ganz farblos sind, während die auf der convexen Seite viel dunkler geworden sind. In zwei Fällen, wo Stückchen Haar auf Drüsen gelegt worden waren und wo im Laufe von 1 Stunde 10 Minuten die Tentakeln halbwegs nach dem Centrum des Blattes hin gekrümmt worden waren, war diese Veränderung der Färbung auf den beiden Seiten ganz auffallend deutlich. In einem anderen Falle wurde, nachdem ein Stückchen Fleisch auf eine Drüse gelegt worden war, beobachtet, wie die purpurne Färbung in Zeitabsätzen langsam von dem oberen nach dem unteren Teile, an der convexen Seite des sich biegenden Tentakels hinabwanderte. Es folgt aber aus diesen Beobachtungen nicht, dass die Zellen auf der convexen Seite mit mehr Flüssigkeit während des Actes der Einbiegung erfüllt wurden, als sie vorher enthielten; denn während der ganzen Zeit kann Flüssigkeit in die Scheibe oder in die Drüsen eintreten, welche nun reichlich absondern.

## Drosera rotundifolia

Die Beugung der Tentakeln, wenn Blätter in eine dichte Flüssigkeit eingetaucht werden, und ihr späteres Sichwiederausstrecken, wenn sie in eine weniger dichte Flüssigkeit gebracht werden, zeigt, dass der Übergang von Flüssigkeit aus oder in Zellen Bewegungen, ähnlich den natürlichen, verursachen kann. Aber die in dieser Weise verursachte Einbiegung ist häufig unregelmäßig; die äußeren Tentakeln werden zuweilen spiral aufgedreht.# Bewegungen und ihre Ursachen

wegungen werden gleichfalls durch Anwendung dichter Flüssigkeiten
verursacht, so in dem Falle, wo Tropfen dicker Zuckerlösungen auf
die Rückseite von Blättern und Tentakeln gebracht werden. Derartige
Bewegungen können mit den Verdrehungen verglichen werden, welche
viele pflanzliche Gewebe erleiden, wenn sie der Exosmose ausgesetzt
werden. Es ist daher zweifelhaft, ob sie irgend welches Licht auf
die natürlichen Bewegungen werfen.
Wenn wir annehmen, dasz der Austritt von Flüssigkeit aus Zellen
die Ursache der Beugung der Tentakeln ist, so müssen wir auch an-
nehmen, dasz die Zellen vor dem Acte der Einbiegung sich in einem
hohen Grade der Spannung befinden und dasz sie in einem ganz auszer-
ordentlichen Grade elastisch sind; denn im anderen Falle könnte ihre
Zusammenziehung nicht verursachen, dasz sich häufig die Tentakeln
durch einen Winkel von mehr als 180° bewegen. Professor Cohn
gibt in seinem interessanten AufsatzeAbhandlungen der Schlesischen Gesellsch.
für vaterländ. Cultur, 1861.
Heft 1. Ein ausgezeichneter Auszug aus diesem Aufsatz ist in den Annals and
Magazine of Nat. Hist., 3. Ser., 1863, Vol. XI, p. 188—197 gegeben. über die
Bewegungen der Staub-
fäden gewisser Compositen an, dasz diese Organe, wenn sie abgestor-
ben sind, so elastisch wie Fäden von Gummi elasticum sind und dasz
sie dann nur halb so lang sind wie sie waren, als sie noch lebten.
Er glaubt, dasz das lebende Protoplasma innerhalb ihrer Zellen sich
gewöhnlich in einem Zustande der Ausdehnung befindet, dasz es aber
durch Reizung gelähmt wird oder, wie man sagen kann, zeitweiligen
Tod erleidet; es kommt dann die Elasticität der Zellwandungen in’s
Spiel und verursacht die Zusammenziehung der Staubfäden. Nur
scheinen die Zellen auf der oberen oder concaven Seite des sich biegen-
den Theils der Tentakeln von Drosera sich nicht in einem Zustande
der Spannung zu befinden, auch nicht in hohem Grade elastisch zu
sein; denn wenn ein Blatt plötzlich getödtet wird oder langsam stirbt,
so sind es nicht die oberen, sondern die unteren Seiten der Tentakeln,

# Mittel der Bewegung

welche sich durch Elasticität zusammenziehen. Wir können daher
schlieszen, dasz ihre Bewegungen nicht durch die inhärente Elasticität
gewisser Zellen, welcher, so lange sie lebendig und nicht gereizt sind,
der ausgedehnte Zustand ihres Inhaltes entgegenwirkt, erklärt werden
können.
Eine etwas verschiedene Ansicht haben andere Physiologen vorge-
bracht, dasz nämlich das Protoplasma, wenn es gereizt wird, sich
wie die weiche Sarcode der Muskeln von Thieren zusammenzieht. Bei
Drosera erscheint die Flüssigkeit innerhalb der Zellen der Tentakeln
an der Beugungsstelle unter dem Mikroskope dünn und homogen, und
nach der Zusammenballung besteht sie aus weichen Massen von Sub-
stanz, welche beständige Änderungen der Form erleiden und in einer
beinahe farblosen Flüssigkeit schwimmen. Diese Massen werden voll-
ständig wieder aufgelöst, wenn sich die Tentakeln wieder ausstrecken.
Nun scheint es kaum möglich zu sein, dasz derartige Substanz
irgend welche mechanische Kraft äuszern könne; wenn sie aber
in Folge irgend einer molecularen Änderung weniger Raum ein-
nehmen sollte als vorher, so würden sich die Zellenwandungen
über ihnen schlieszen und zusammenziehen. In diesem Falle dürfte
man aber erwarten, dasz die Wände Faltungen darböten; und solche
konnten niemals beobachtet werden. Überdies scheint der Inhalt
aller Zellen von genau derselben Beschaffenheit zu sein, sowohl vor
als auch nach der Zusammenballung; und doch ziehen sich nur einige
wenige der basalen Zellen zusammen, während der übrige Tentakel
gerade bleibt.
Eine dritte, von einigen Physiologen vertretene Ansicht, die frei-
lich von den meisten andern verworfen wird, ist die, dasz die ganze
Zelle mit Einschlusz der Wandungen sich activ zusammenzieht. Wenn
die Zellwände nur aus nichtstickstoffhaltiger Cellulose bestehen, ist
diese Ansicht in hohem Grade unwahrscheinlich; es kann aber kaum
bezweifelt werden, dasz sie von protëinartiger Substanz durchdrungen# Zellwände und Bewegung

werden, wenigstens während sie wachsen. Auch scheint darin nicht von vornherein eine Unwahrscheinlichkeit zu liegen, dasz sich die Zellwände der Drosera zusammenziehen, wenn man den hohen Zustand ihrer Organisation in Betracht zieht: ein solcher zeigt sich, was die Drüsen betrifft, einmal in ihrem Vermögen der Aufsaugung und Absonderung, und darin, dasz sie so ausgesucht empfindlich sind, so dasz sie durch den Druck der minutiösesten Theilchen afficirt werden. Drosera rotundifolia. Cap. 10.

# Impulse und Protoplasma

Auch die Zellwandungen der Stiele gestatten verschiedenen Impulsen, durch sie hindurchzugehen und damit Bewegung, vermehrte Absonderung und Zusammenballung zu veranlassen. Im Ganzen stimmt die Ansicht, dasz die Wände gewisser Zellen sich zusammenziehen, wobei zu derselben Zeit etwas von der eingeschlossenen Flüssigkeit nach auszen gedrängt wird, vielleicht am besten mit den beobachteten Thatsachen überein. Wird diese Ansicht verworfen, so ist die nächstwahrscheinlichste die, dasz der flüssige Inhalt der Zellen in Folge einer Änderung in seinem molecularen Zustande zusammenschrumpft, dem dann ein Zusammenschlieszen der Wandungen folgt. Wie dem auch sei, die Bewegung kann kaum der Elasticität der Wandungen in Verbindung mit einem vorausgehenden Spannungszustande zugeschrieben werden.

# Motorischer Impuls und Tentakeln

In Bezug auf die Natur des motorischen Impulses, welcher von den Drüsen aus die Stiele hinab und quer über die Scheibe gesandt wird, scheint es nicht unwahrscheinlich zu sein, dasz er mit jenem Einflusse nahe verwandt ist, welcher das Protoplasma innerhalb der Zellen der Drüsen und Tentakeln sich zusammenzuballen verursacht. Wir haben gesehen, dasz beide Kräfte in den Drüsen ihren Ursprung nehmen und innerhalb weniger Secunden derselben Zeit von den Drüsen weiter gehen und auch durch die nämlichen Ursachen erregt werden.

# Zusammenballung des Protoplasma

Die Zusammenballung des Protoplasma dauert beinahe so lange, als die Tentakeln eingebogen bleiben, selbst wenn dies länger als eine Woche dauern sollte; aber das Protoplasma wird an der Beugungsstelle, kurz ehe sich die Tentakeln wieder ausstrecken, wieder aufge-löst, woraus hervorgeht, dasz die anregende Ursache des Processes der Zusammenballung dann völlig aufgehört hat. Wird das Blatt der Einwirkung der Kohlensäure ausgesetzt, so bewirkt dies, dasz der letztere Prozess, sowie der motorische Impuls die Tentakeln sehr langsam hinabgeht.

# Einfluss von Lösungen und Temperatur

Wir wissen, dasz der Procesz des Zusammen-ballens beim Durchschreiten der Zellwände aufgehalten wird, und haben guten Grund zu glauben, dasz dies auch für den motorischen Impuls gilt; denn hierdurch wird uns die Verschiedenheit in der Schnelligkeit der Übermittelung in einer longitudinalen und queren Richtung über die Scheibe verständlich. Unter einer starken Vergröszerung ist das erste Zeichen der Zusammenballung das Erscheinen einer Wolke und bald danach von äusserst feinen Körnchen in der homogenen purpurnen Flüssigkeit innerhalb der Zellen; und dies ist Cap. 10. Wiederausstrecken der Tentakeln.

# Molekulare Interaktionen

allem Anscheine nach eine Folge der Vereinigung von Moleculen von Protoplasma. Nun scheint es keine unwahrscheinliche Ansicht zu sein, dasz dieselbe Neigung, — nämlich die der Molecule sich einander zu nähern, — auch der inneren Oberfläche der Zellwandungen mitgetheilt wird, welche mit dem Protoplasma in Berührung stehen; und ist dies der Fall, so würden sich ihre Molecule einander nähern und die Zellenwandung würde sich zusammenziehen.

# Kritische Betrachtung

Dieser Ansicht kann mit Recht entgegen gehalten werden, dasz, wenn Blätter in verschiedene starke Lösungen eingetaucht oder einer Wärme von über 54,4° C. (130° F.) ausgesetzt werden, Zusammen-ballung zwar eintritt aber keine Bewegung erfolgt. Ferner verur-sachen verschiedene Säuren und einige andere Flüssigkeiten rapide Bewegung, aber keine Zusammenballung, oder nur eine solche von abnormer Beschaffenheit, oder nur nach Verlauf langer Zeit; da aber die meisten dieser Flüssigkeiten mehr oder weniger schädlich sind, so dürften sie den Procesz der Zusammenballung durch Verletzung oder Tödtung des Protoplasma unterbrechen oder verhindern. Es# Unterschiede zwischen den Prozessen

besteht auch ein anderer und bedeutungsvollerer Unterschied zwischen den beiden Processen: wenn die Drüsen auf der Scheibe gereizt werden, so senden sie einen Einflusz die umgebenden Tentakeln hinauf, welcher auf die Zellen an der Beugungsstelle wirkt, aber nicht eher Zusammenballung herbeiführt, bis er die Drüsen erreicht hat; diese senden dann einen andern Einflusz zurück, welcher die Zusammenballung des Protoplasma verursacht und zwar zuerst in den oberen und dann in den unteren Zellen.

# Wiederausstrecken der Tentakeln

Diese Bewegung ist immer langsam und allmählich. Wenn die Mitte des Blattes gereizt, oder ein Blatt in eine passende Lösung eingetaucht wird, so biegen sich alle Tentakeln direct nach der Mitte zu und später direct von ihr zurück. Wenn aber die Reizungsstelle auf einer Seite der Scheibe liegt, so biegen sich die umgebenden Tentakeln nach ihr hin, und daher mit Bezug auf ihre normale Richtung schräg; wenn sie sich später wieder ausstrecken, so biegen sie sich schräg zurück, so dasz sie ihre ursprüngliche Stellung wieder erlangen. Die von einem gereizten Punkt am weitesten abstehenden Tentakeln, wo sie auch stehen mögen, sind die zuletzt und am wenigsten afficirten, und wahrscheinlich in Folge hiervon sind sie die ersten, welche sich wieder ausstrecken.

# Experimentelle Beobachtungen

Die gebeugte Stelle eines dicht eingebogenen Tentakels findet sich in einem Zustande activer Zusammenziehung, wie sich aus dem folgenden Experimente ergibt. Es wurde Fleisch auf ein Blatt gebracht; nachdem die Tentakeln dicht eingebogen waren und vollständig aufgehört hatten sich zu bewegen, wurden schmale Streifen der Scheibe, an denen einige wenige äuszere Tentakeln saszen, herausgeschnitten und unter das Mikroskop gebracht. Nach mehrfachem Mislingen gelang es mir, die convexe Oberfläche des gebogenen Theils eines Tentakels abzuschneiden. Die Bewegung begann sofort wieder, und die bereits stark gebogene Stelle fuhr fort sich zu biegen, bis sie einen vollkommenen Kreis bildete; dabei gieng der entferntere gerade Theil des Tentakels an der einen Seite des Streifens hin. Die convexe Oberfläche musz sich daher vorher in einem Spannungszustande befunden haben, welcher hinreichend stark war, dem der concaven Oberfläche das Gegengewicht zu halten, welche, als sie frei wurde, sich zu einem vollständigen Ring aufrollte.

# Eigenschaften der Tentakeln

Die Tentakeln eines ausgebreiteten und nicht gereizten Blattes sind mäszig steif und elastisch; wenn sie mit einer Nadel gebogen werden, so gibt das obere Ende leichter nach als der basale und dickere Theil, welcher allein fähig ist, eingebogen zu werden. Die Rigidität dieses basalen Theiles scheint eine Folge der Spannung der äuszeren Oberfläche zu sein, welche einem Zustande der activen und beständigen Contraction der Zellen der inneren Oberfläche das Gleichgewicht hält. Dasz dies der Fall ist, glaube ich deshalb, weil, wenn ein Blatt in kochendes Wasser getaucht wird, die Tentakeln plötzlich zurückgebogen werden; dies weist allem Anscheine nach darauf hin, dasz die Spannung der äuszeren Oberfläche mechanisch ist, während die der inneren Fläche lebendig ist und durch das kochende Wasser augenblicklich zerstört wird.

# Alterung und Spannung der Tentakeln

Wir können hiernach auch verstehen, warum die Tentakeln, wenn sie alt und schwach werden, langsam stark zurückgebogen werden. Wenn ein Blatt mit dicht eingebogenen Tentakeln in kochendes Wasser getaucht wird, so erheben sich die Tentakeln ein wenig, aber breiten sich durchaus nicht vollständig aus. Dies mag eine Folge davon sein, dasz die Hitze die Spannung und Elasticität der Zellen der convexen Oberfläche schnell zerstört; ich kann aber kaum glauben, dasz ihre Spannung zu irgend einer Zeit hinreichen würde, die Tentakeln, oft sogar durch einen Winkel von über 180° in ihre ursprüngliche Stellung zurückzuführen. Wahr- scheinlicher ist es, dasz Flüssigkeit, von der wir wissen, dasz sie während des Actes der Einbiegung die Tentakeln entlang strömt, langsam wieder in die Zellen der convexen Oberfläche eingezogen wird, wodurch deren Spannung allmählich und beständig vermehrt wird.# Recapitulation der hauptsächlichsten Beobachtungen an Drosera rotundifolia

Eine Recapitulation der hauptsächlichsten Thatsachen und Erörterungen dieses Capitels wird am Schlusse des nächsten Capitels gegeben werden.

## Einleitung

Da Zusammenfassungen bei den meisten Capiteln gegeben worden sind, wird es genügen, hier so kurz als ich es thun kann, die hauptsächlichsten Punkte zu recapituliren.

## Struktur der Blätter und Insektenfang

Im ersten Capitel wurde eine vorläufige Skizze von der Structur der Blätter und von der Art und Weise gegeben, in welcher sie Insecten fangen. Dies wird durch Tropfen äusserst klebriger Flüssigkeit, welche die Drüsen umgibt, und durch die Einwärtsbewegung der Tentakeln bewerkstelligt. Da die Pflanzen ihre meiste Nahrung durch diese Mittel erlangen, sind ihre Wurzeln nur sehr spärlich entwickelt; auch wachsen sie häufig an Stellen, wo kaum irgend eine andere Pflanze, mit Ausnahme von Moosen, bestehen kann.

## Empfindlichkeit der Drüsen

Die Drüsen haben ausser der Fähigkeit der Absonderung auch noch die der Absorption. Sie sind äusserst empfindlich für verschiedene Reizmittel, nämlich für wiederholte Berührungen, den Druck äusserst kleiner Körperchen, die Absorption animaler Substanz und verschiedener Flüssigkeiten, für Wärme und Galvanismus. Man hat beobachtet, dasz ein Tentakel mit einem Bischen rohen Fleisches auf der Drüse in 10 Secunden sich zu biegen begann, dasz er in 5 Minuten stark eingebogen war, und in einer halben Stunde die Mitte des Blattes erreichte.

## Beugung und Reaktion der Tentakeln

Die Scheibe des Blattes wird häufig so stark eingebogen, dasz sie einen Becher bildet, der jeden auf sie gelegten Gegenstand einschlieszt. Wenn eine Drüse gereizt wird, so sendet sie nicht nur einen gewissen Einflusz ihren eigenen Tentakel hinab, der diesen zu biegen verursacht, sondern ebenso an die umgebenden Tentakeln, welche einwärts gekrümmt werden; die Beugungsstelle kann daher eine Einwirkung von einem aus den entgegengesetzten Richtungen herrührenden Impuls erhalten, nämlich von der Drüse am Gipfel des nämlichen Tentakels und von einer oder mehreren Drüsen der benachbarten Tentakeln.

## Wiederherstellung der Tentakeln

Sind Tentakeln eingebogen, so strecken sie sich nach einiger Zeit wieder aus, und während dieses Processes sondern die Drüsen weniger reichlich ab oder werden trocken. So bald sie wieder abzusondern anfangen, sind die Tentakeln bereit, wieder in Thätigkeit zu treten; und dies kann mindestens dreimal, wahrscheinlich viel häufiger, wiederholt werden.

## Einfluss animaler Substanzen

Im zweiten Capitel wurde gezeigt, dasz animale Substanzen, auf die Blattscheiben gelegt, eine viel raschere und energischere Einbie- gung verursachen, als unorganische Körper derselben Grösze oder blosze mechanische Reizung; es besteht aber ein noch ausgesprochenerer Unterschied in der gröszeren Länge der Zeit, während welcher die Tentakeln über Körpern, welche lösliche und ernährende Substanzen darbieten, eingebogen bleiben, in Vergleich zu solchen Körpern, welche derartige Substanzen nicht enthalten.

## Reaktion auf verschiedene Körper

Wenn äusserst minutiöse Stückchen Glas, Kohlen, Haar, Faden, präcipitirte Kreide u. s. w. auf die Drüsen der äusseren Tentakeln gethan werden, so werden diese sich zu biegen veranlaszt. Wenn ein Körperchen nicht durch die Absonderung hindurchsinkt und factisch die Oberfläche der Drüse mit irgend einem Punkte berührt, so bringt es durchaus keine Wirkung hervor. Ein kleines Stückchen dünnen menschlichen Haars, \frac {8}{1000} Zoll (0,203 Mm.) lang und nur \frac {1}{78740} Gran (0,000822 Milligr.) wiegend, reichte hin, obschon es reichlich von dem dichten Secrete unterstützt wurde, Bewegung zu veranlassen. Es ist nicht wahrscheinlich, dasz der Druck in diesem Falle ein Milliontel Gran betragen haben kann. Selbst kleinere Stückchen verursachen eine unbedeutende Bewegung, wie durch eine Lupe gesehen werden konnte.# Empfindlichkeit der Drüsen

mitgetheilt wurden, verursachen keine Empfindung, wenn sie auf die Zunge, einen der empfindlichsten Theile des menschlichen Körpers, gelegt werden. Bewegung erfolgt, wenn eine Drüse drei- oder viermal für einen Augenblick berührt wird; wird sie aber nur ein- oder zweimal berührt, wenn auch mit beträchtlicher Gewalt und mit einem harten Gegenstand, so biegt sich der Tentakel nicht. Die Pflanze wird hierdurch vor vieler nutzloser Bewegung bewahrt, da es kaum ausbleiben kann, dasz die Drüsen während eines starken Windes gelegentlich von den Blättern umgebender Pflanzen wie gebürstet werden. Obschon sie für eine einzelne Berührung unempfindlich sind, so sind sie doch, wie oben angegeben, für den leichtesten Druck, wenn er nur einige wenige Secunden anhält, ausgesucht empfindlich; und diese Fähigkeit ist offenbar für die Pflanzen beim Fangen kleiner Insecten von Nutzen. Selbst Mücken werden, wenn sie sich mit ihren zarten Füszen auf den Drüsen niederlassen, schnell und sicher gefangen. Die Drüsen sind gegen das Gewicht und die wiederholten Schläge schwerer Regentropfen unempfindlich; hierdurch wird gleicherweise den Pflanzen viel unnütze Bewegung erspart.

# Prozess der Zusammenballung

Die Beschreibung der Bewegungen der Tentakeln wurde im dritten Kapitel unterbrochen, um den Procesz der Zusammenballung zu beschreiben. Dieser Procesz beginnt immer in den Zellen der Drüsen, deren Inhalt zuerst wolkig wird; dies ist innerhalb 10 Secunden, nachdem eine Drüse gereizt worden war, beobachtet worden. Soeben noch unter einer sehr starken Vergröszerung auflösbare Körnchen, erscheinen bald, zuweilen innerhalb einer Minute, in den Zellen unterhalb der Drüsen, und diese ballen sich dann zu kleinen Kugeln zusammen. Der Procesz schreitet dann die Tentakeln hinab, wobei er bei jeder queren Scheidewand für eine kurze Zeit aufgehalten wird. Die kleinen Kugeln verschmelzen zu gröszern Kugeln oder zu ovalen, keulenförmigen, faden- oder perlschnurartigen oder sonst verschieden geformten Protoplasma-Massen, welche, in beinahe farbloser Flüssigkeit suspendirt, unaufhörliche freiwillig eintretende Formveränderungen darbieten. Diese verschmelzen häufig miteinander und trennen sich wieder. Wenn eine Drüse kräftig gereizt worden ist, so werden alle Zellen bis zur Basis des Tentakels hinab afficirt. In Zellen, besonders wenn sie mit dunkel rother Flüssigkeit gefüllt sind, ist der erste Schritt in diesem Vorgang die Bildung einer dunkel rothen, sackartigen Masse von Protoplasma, welche sich später theilt und die gewöhnlichen wiederholten Formveränderungen erleidet. Ehe irgend welche Zusammenballung angeregt worden ist, flieszt eine Schicht farblosen, Körnchen enthaltenden Protoplasmas (der Primordialschlauch Mohl’s) rings um die Wandungen der Zellen; und dies wird noch deutlicher, nachdem sich der Inhalt theilweise zu Kugeln oder sackähnlichen Massen zusammengeballt hat. Nach einiger Zeit aber werden die Körnchen nach den centralen Massen hingezogen und verbinden sich mit ihnen; und dann kann die circulirende Schicht nicht mehr erkannt werden, doch ist noch immer ein Strom durchsichtiger Flüssigkeit innerhalb der Zellen vorhanden.

# Reizmittel und deren Wirkung

Zusammenballung wird beinahe durch alle die Reizmittel angeregt, welche Bewegung veranlassen: so wenn die Drüsen zwei- oder dreimal berührt werden, durch den Druck minutiöser unorganischer Körperchen, die Absorption verschiedener Flüssigkeiten, selbst langes Ein-tauchen in destillirtes Wasser, Exosmose und Wärme. Von den vielen versuchten Reizmitteln ist kohlensaures Ammoniak das allerenergischste und am schnellsten wirkende: eine Dose von \frac {1}{134400} Gran (0,00048 Milligr.) einer einzigen Drüse gegeben, reicht hin, in einer Stunde wohl ausgesprochene Zusammenballung in den oberen Zellen des Tentakels zu verursachen. Der Procesz dauert nur so lange fort, als sich das Protoplasma in einem lebendigen, kräftigen und sauerstoffhaltigen Zustande befindet.# Einleitung
eine Drüse direct gereizt worden ist, oder wenn sie von andern und entfernt stehenden Drüsen her einen Reiz erhalten hat. Doch findet sich ein wichtiger Unterschied: wenn die centralen Drüsen gereizt werden, so senden sie centrifugal einen Reiz die Stiele der äuszern Tentakeln hinauf an deren Drüsen; aber der factische Procesz der Zusammenballung schreitet centripetal fort, von den Drüsen der äuszeren Tentakeln aus ihre Stiele hinab. Der erregende Einflusz, welcher von einem Theile des Blattes dem andern übermittelt wird, musz daher von dem verschieden sein, welcher thatsächlich Zusammenballung herbeiführt. Der Procesz hängt nicht davon ab, dasz die Drüsen reichlicher absondern als vorher, und ist auch unabhängig von der Einbiegung der Tentakeln. Er dauert so lange fort, als die Tentakeln eingebogen bleiben, und sobald diese wieder vollständig ausgestreckt sind, sind auch die kleinen Massen von Protoplasma sämmtlich wieder aufgelöst; die Zellen werden wieder von homogener purpurner Flüssigkeit erfüllt, wie sie es waren ehe das Blatt gereizt wurde.

# Prozess der Zusammenballung
Da der Procesz der Zusammenballung durch einige wenige Berührungen oder durch den Druck unlöslicher Körperchen angeregt werden kann, so ist er offenbar unabhängig von der Absorption irgend welcher Substanz und musz von einer molecularen Natur sein. Selbst wenn er durch die Absorption des kohlensauren oder eines andern Salzes von Ammoniak, oder eines Aufgusses von Fleisch verursacht wird, scheint der Procesz von genau derselben Natur zu sein. Die protoplasmatische Flüssigkeit musz sich daher in einem eigenthümlich unstäten Zustand befinden, um durch solche unbedeutende und verschiedenartige Ursachen beeinfluszt zu werden. Physiologen glauben, dasz, wenn ein Nerv berührt wird und er einen Einflusz andern Theilen des Nervensystems übermittelt, eine moleculare Veränderung in ihm angeregt wird, auch wenn sie uns nicht sichtbar ist. Es ist daher ein sehr interessantes Schauspiel, die Wirkungen des Druckes eines Stückchens Haar auf die Zellen einer Drüse zu beobachten, welches nur \frac {1}{78700} Gran wiegt und groszentheils von der dichten Absonderung der Drüse getragen wird; denn dieser ganz auszerordentlicher unbedeutende Druck verursacht bald eine sichtbare Veränderung in dem Protoplasma, welche Veränderung die ganze Länge des Tentakels hinab geleitet wird, demselben endlich ein geflecktes Ansehen gebend, was selbst für das blosze Auge zu unterscheiden ist.

# Temperatur und ihre Auswirkungen
Im vierten Capitel wurde gezeigt, dasz Blätter, welche für eine kurze Zeit in Wasser von einer Temperatur von 43,3° C. (110° F.) gelegt werden, etwas eingebogen werden; sie werden dadurch für die Einwirkung von Fleisch empfindlicher gemacht als sie vorher waren. Werden sie einer Temperatur von zwischen 46,1° und 51,6° C. (115° und 125° F.) ausgesetzt, so werden sie schnell eingebogen und ihr Protoplasma ballt sich zusammen; werden sie später in kaltes Wasser gelegt, so breiten sie sich wieder aus. Werden sie 54,4° C. (130° F.) ausgesetzt, so tritt keine sofortige Einbiegung ein, sondern die Blätter werden nur zeitweilig paralysirt; denn wenn sie in kaltem Wasser gelassen werden, werden sie häufig noch eingebogen und breiten sich später wieder aus. Bei einem in dieser Weise behandelten Blatte sah ich deutlich das Protoplasma in Bewegung. Bei andern in der nämlichen Weise behandelten und dann in eine Lösung von kohlensauren Ammoniak eingetauchten Blättern erfolgte starke Zusammenballung. Wurden Blätter, nachdem sie einer so hohen Temperatur wie 62,7° C. (145° F.) ausgesetzt worden waren, in kaltes Wasser gelegt, so wurden sie zuweilen unbedeutend, wenn auch langsam, einge-bogen; und später wurde der Inhalt ihrer Zellen durch kohlensaures Ammoniak stark zusammengeballt. Es ist aber die Dauer der Eintauchung ein wichtiges Element; denn werden sie so lange in Wasser von 62,7° C. (145° F.) oder nur von 60° C. (140° F.) gelassen, bis es abgekühlt ist, so werden sie getödtet und der Inhalt der Drüsen.# Einleitung zur Verdauung von Drosera

wird weisz und opak. Dies letztere Resultat scheint eine Folge der Gerinnung des Eiweiszes zu sein; es wurde beinahe immer herbei- geführt, wenn die Blätter auch nur kurze Zeit einer Temperatur von 65,5° C. (150° F.) ausgesetzt wurden; aber verschiedene Blätter und selbst die einzelnen Zellen in einem und demselben Tentakel weichen in ihrem Vermögen der Wärme zu widerstehen beträchtlich von einander ab. Wenn nicht die Wärme hinreichend stark war, das Eiweisz zum Gerinnen zu bringen, bewirkt kohlensaures Ammoniak später Zusammenballung.

# Versuche mit organischen Flüssigkeiten

Im fünften Capitel wurden die Resultate der Versuche mitge- teilt, wo Tropfen verschiedener stickstoffhaltiger und nicht stick- stoffhaltiger organischer Flüssigkeiten auf die Scheiben von Blättern gethan wurden; und es wurde gezeigt, dasz die Blätter mit beinahe irrthumsfreier Sicherheit die Gegenwart von Stickstoff entdecken. Eine Abkochung von grünen Erbsen oder von frischen Kohlblättern wirkt beinahe so kräftig als ein Aufgusz von rohem Fleisch, während ein Aufgusz von Kohlblättern, der nur so gemacht wurde, dasz man die Blätter eine lange Zeit in warmem Wasser liegen liesz, bei weitem weniger wirksam ist. Eine Abkochung von Grasblättern ist weniger wirksam als eine von grünen Erbsen oder Kohlblättern.

# Verdauungsfähigkeit der Drosera

Diese Resultate führten mich darauf, zu untersuchen, ob Drosera das Vermögen besäsze, solide animale Substanz aufzulösen. Die Expe- rimente, welche beweisen, dasz die Blätter einer wirklichen Verdauung fähig sind, und dasz die Drüsen die verdaute Substanz aufsaugen, sind im sechsten Capitel im Detail mitgetheilt. Diese sind vielleicht die interessantesten von allen meinen Beobachtungen über Drosera, da es früher nicht ausdrücklich bekannt war, dasz ein solches Ver- mögen im Pflanzenreiche existire. Es ist gleichfalls eine interessante Thatsache, dasz, wenn die Drüsen der Scheibe gereizt werden, sie einen gewissen Einflusz den Drüsen der äuszern Tentakeln über-mitteln, welcher bewirkt, dasz sie reichlicher absondern und dasz die Absonderung sauer wird, als ob sie direct durch irgend einen auf sie gelegten Gegenstand gereizt worden wären.

# Vergleich mit tierischem Mageninhalt

Der Magensaft der Thiere enthält, wie allgemein bekannt ist, eine Säure und ein Ferment, welche beide zur Verdauung unentbehrlich sind. Dasselbe ist der Fall mit der Absonderung der Drosera. Wenn der Magen eines Thieres mechanisch gereizt wird, so sondert er eine Säure ab, und wenn Stückchen Glas oder andere derartige Gegenstände auf die Drüsen der Drosera gelegt wurden, so nahm das Secret, ebenso wie das der umgebenden und nicht berührten Drüsen an Menge zu und wurde sauer. Der Angabe Schiff’s zufolge sondert aber der Magen eines Thieres sein eigenthümliches Ferment, das Pepsin, nicht eher ab, als bis gewisse Substanzen, welche er Peptogene nennt, absorbirt sind; und aus meinen Experimenten an Drosera scheint hervorzu- gehen, dasz etwas Substanz von den Drüsen absorbirt werden musz, ehe sie das ihnen eigenthümliche Ferment absondern.

# Eigenschaften des Sekrets

Dasz das Secret ein Ferment enthält, welches nur in Gegenwart einer Säure auf feste animale Substanzen wirkt, wurde ganz klar durch den Zu- satz äuszerst kleiner Dosen eines Alkali bewiesen, welche den Procesz der Verdauung gänzlich zum Stillstand brachten, während derselbe sofort wieder begann sobald das Alkali durch etwas schwache Salz- säure neutralisirt wurde. Nach Versuchen, die mit einer groszen Anzahl von Substanzen angestellt wurden, hat sich herausgestellt, dasz auf diejenigen, welche das Secret der Drosera entweder voll- ständig, oder nur theilweise oder durchaus gar nicht auflöst, auch der Magensaft in genau der nämlichen Art und Weise einwirkt. Wir können daher schlieszen, dasz das Ferment der Drosera dem Pepsin der Thiere nahe analog oder mit ihm identisch ist.

# Wirkung verschiedener Substanzen auf Drosera

Die Substanzen, welche von der Drosera verdaut werden, wirken sehr verschieden auf die Blätter. Einige verursachen eine viel ener- gischere und rapidere Einbiegung der Tentakeln als andere und hal- ten sie auch eine viel längere Zeit hindurch eingebogen. Wir wer-# Allgemeine Zusammenfassung

den hierdurch zu der Annahme geführt, dasz die ersteren nahrhafter sind als die letzteren, wie es bekanntlich mit einigen der nämlichen Substanzen der Fall ist, wenn sie Thieren gegeben werden; so z. B. Fleisch in Vergleich mit Gelatine. Da Knorpel eine so zähe Substanz ist und Wasser so wenig auf ihn einwirkt, so ist seine rasche Auflösung durch die Absonderung der Drosera und seine spätere Absorption vielleicht einer der auffallendsten Fälle. Es ist dies aber in der That nicht merkwürdiger als die Verdauung von Fleisch, welches durch dies Secret in derselben Art und Weise und in denselben Stadien aufgelöst wird, wie durch den Magensaft. Das Secret löst Knochen auf und selbst den Schmelz der Zähne; dies ist aber einfach eine Folge der groszen Menge abgesonderter Säure, was allem An- scheine nach dem Bedürfnis der Pflanze nach Phosphor zuzuschreiben ist. Was den Fall mit Knochen betrifft, so tritt das Ferment nicht eher in Wirksamkeit als bis der ganze phosphorsaure Kalk zersetzt worden und freie Säure vorhanden ist, worauf dann die fasrige Grundsubstanz schnell aufgelöst wird. Endlich greift das Secret auch lebende Samen an und löst Substanz aus ihnen auf; dabei tödtet es oder verletzt es dieselben zuweilen, wie aus dem kränklichen Zustand der Sämlinge hervorgeht. Es absorbirt auch Substanz aus Pollen und aus Bruchstücken von Blättern.

# Wirkung der Ammoniaksalze

Das siebente Capitel war der Wirkung der Ammoniaksalze gewidmet. Dieselben verursachen alle die Einbiegung der Tentakeln und häufig auch der Blattscheibe und die Zusammenballung des Protoplasma. Sie wirken mit sehr verschiedener Kraft; das citronensaure Salz ist das am wenigsten wirksame, und das phosphorsaure ist, ohne Zweifel in Folge der Gegenwart von Phosphor und Stickstoff, bei weitem das wirksamste. Es wurde aber die relative Wirksamkeit von nur drei Ammoniaksalzen sorgfältig bestimmt, nämlich vom kohlensauren, salpetersauren und phosphorsauren. Die Experimente wurden so angestellt, dasz halbe Minims (0,0296 Cub. Cent.) von Lösungen verschiedener Stärkegrade auf die Scheibe der Blätter gebracht wurden, — dasz ein äuszerst kleiner Tropfen (ungefähr \frac {1}{20} Minim oder 0,00296 Cub. Cent.) einige wenige Secunden lang an drei oder vier Drüsen gehalten wurde, — und dasz ganze Blätter in eine abgemessene Menge eingetaucht wurden. In Bezug auf diese Experi- mente war es zuerst nothwendig, die Wirkungen destillirten Wassers zu ermitteln, und es stellte sich, wie im Detail beschrieben worden ist, heraus, dasz die empfindlicheren Blätter von ihm afficirt werden, aber nur in einem unbedeutenden Grade.

# Absorption und Wirkung von Lösungen

Eine Lösung des kohlensauren Salzes wird von den Wurzeln aufgesaugt und bewirkt Zusammenballung in ihren Zellen, afficirt aber die Blätter nicht. Der Dampf wird von den Drüsen absorbirt und verursacht Einbiegung ebensowohl wie Zusammenballung. Ein \frac {1}{960} Gran (0,0675 Milligr.), in einem Tropfen einer Lösung enthalten, ist die geringste Menge, welche, wenn sie auf die Drüsen der Scheibe gebracht wird, die äuszeren Tentakeln zum Einwärtsbiegen anregt. Wenn aber ein äuszerst kleiner, \frac {1}{14400} Gran (0,00445 Milligr.) enthaltender Tropfen einige wenige Secunden lang an die eine Drüse umgebende Absonderung gehalten wird, so verursacht er die Einbiegung dieses näm- lichen Tentakels. Wenn ein in hohem Grade empfindliches Blatt in eine Lösung eingetaucht wird, und es ist reichlich Zeit zur Absorption vorhanden, so ist \frac {1}{268800} Gran (0,00024 Milligr.) genügend, einen ein- zigen Tentakel zur Bewegung zu reizen.

# Vergleich der Ammoniaksalze

Das salpetersaure Ammoniak veranlaszt Zusammenballung des Protoplasma viel weniger schnell als das kohlensaure, ist aber wirk- samer in Bezug auf das Verursachen von Einbiegung. Ein \frac {1}{2400} Gran (0,027 Milligr.) enthaltender, auf die Scheibe gebrachter Tropfen wirkt kräftig auf alle äuszeren Tentakeln, welche selbst nichts von der Lösung erhalten haben, während ein Tropfen mit \frac {1}{2800} Gran nur einige wenige dieser Tentakeln sich zu biegen veranlaszte, aber etwas.# Einleitung

# Wirkung von Ammoniaksalzen

# Empfindlichkeit der Drüsen

# Vergleich mit anderen Salzen

# Schlussfolgerungen# Metallsalze und ihre Wirkungen

Die meisten Metallsalze rapide und starke Einbiegung und sind in hohem Grade giftig; von dieser Regel gibt es aber einige merkwürdige Ausnahmen; so verursachten Blei- und Zink-Chlorid, ebenso wie zwei Barytsalze keine Einbiegung und waren auch nicht giftig.

# Drosera rotundifolia

Die meisten Säuren, welche versucht wurden, wirkten, obschon sie sehr verdünnt (ein Theil auf 437 Theile Wasser) und in kleinen Dosen gegeben wurden, kräftig auf Drosera ein; neunzehn von den vierundzwanzig veranlassten die Tentakeln sich mehr oder weniger einzubiegen. Die meisten von ihnen, selbst die organischen Säuren, sind giftig, häufig in hohem Grade; und dies ist merkwürdig, da die Säfte von so vielen Pflanzen Säuren enthalten. Benzoësäure, welche für Thiere unschädlich ist, scheint für Thiere so giftig zu sein wie Blausäure. Auf der andern Seite ist Salzsäure weder für Thiere noch für Drosera giftig und führt nur einen mäßigen Grad von Einbiegung herbei. Viele Säuren reizen die Drüsen so, dasz sie eine außergewöhnliche Menge von Schleim absondern; das Protoplasma innerhalb ihrer Zellen scheint oft getötet zu werden, wie man daraus schließen kann, dasz die umgebende Flüssigkeit bald rosa wird. Es ist fremdartig, dasz verwandte Säuren sehr verschieden von einander wirken: Ameisensäure bewirkt nur sehr unbedeutende Einbiegung und ist nicht giftig, während Essigsäure von derselben Stärke äußerst kräftig wirkt und giftig ist. Milchsäure ist gleichfalls giftig, verursacht indes Einbiegung nur nach Verlauf beträchtlicher Zeit. Äpfelsäure wirkt unbedeutend, während Citronen- und Weinsteinsäure gar keine Wirkung hervorbringen.

# Wirkungen der Absorption

Im neunten Capitel wurden die Wirkungen der Absorption verschiedener Alkaloide und gewisser anderer Substanzen beschrieben. Obgleich einige derselben giftig sind, so können wir doch, da mehrere derselben, welche auf das Nervensystem von Thieren mächtig einwirken, auf Drosera keine Wirkung hervorbringen, schließen, dasz die äußerste Empfindlichkeit der Drüsen und ihre Fähigkeit, einen, Bewegung oder modifizierte Absonderung oder Zusammenballung verursachenden Einfluss andern Teilen des Blattes zu übermitteln, nicht von dem Vorhandensein eines verbreiteten, dem Nervengewebe verwandten Elements abhängt. Eine der merkwürdigsten Thatsachen ist die, dasz langes Eintauchen in das Gift der Cobra-Schlange die freiwilligen Bewegungen des Protoplasma in den Zellen der Tentakeln nicht aufhält, sondern eher noch reizt. Lösungen verschiedener Salze und Säuren verhalten sich sehr verschieden in Bezug auf das Verzögern oder vollständige Unterbrechen der späteren Einwirkung einer Lösung von phosphorsaurem Ammoniak. In Wasser aufgelöster Campher wirkt als ein Reizmittel, wie es auch kleine Dosen gewisser ätherischer Öle thun, denn sie verursachen rapide und starke Einbiegung. Alkohol ist kein Reizmittel. Die Dämpfe von Campher, Alkohol, Chloroform, Schwefel- und Salpeter-Äther sind in mäßig großen Dosen giftig, dienen aber in kleinen Dosen als Narcotica oder Anaesthetica, welche die folgende Einwirkung von Fleisch bedeutend aufhalten. Einige dieser Dämpfe wirken aber auch als Reizmittel, rapide, beinahe krampfhafte Bewegungen in den Tentakeln erregend. Kohlenstoff ist gleichfalls ein Narcoticum und verzögert die Zusammenballung des Protoplasma, wenn später kohlensaures Ammoniak gegeben wird. Der erste Zutritt von Luft zu Pflanzen, welche in dieses Gas eingetaucht gehalten worden sind, wirkt zuweilen als Reizmittel und führt Bewegung herbei. Es würde aber, wie früher schon bemerkt, eine spezielle Pharmakopöe notwendig sein, die verschiedenartigen Wirkungen verschiedener Substanzen auf die Blätter der Drosera zu beschreiben.

# Empfindlichkeit der Blätter

Im zehnten Capitel wurde gezeigt, dasz die Empfindlichkeit der Blätter gänzlich auf die Drüsen und auf die unmittelbar darunterliegenden Zellen beschränkt zu sein scheint. Es wurde ferner gezeigt, dasz der motorische Impuls und andere von den Drüsen, wenn sie gereizt werden, ausgehende Kräfte oder Einflüsse durch das Zell-# Motorische Impulse und Tentakelfunktion

gewebe und nicht den fibrovasalen Bündeln entlang gehn. Eine Drüse sendet ihren motorischen Impuls mit groszer Rapidität den Stiel des nämlichen Tentakels nach dem basalen Theil hinab, welcher allein sich biegt. Der dann weiter gehende Impuls breitet sich nach allen Seiten auf die umgebenden Tentakeln aus, zuerst diejenigen afficirend, welche am nächsten und dann die, welche weiter wegstehn. Aber dadurch, dasz er auf diese Weise verbreitet wird, und weil die Zellen der Scheibe nicht so verlängert sind wie die der Tentakeln, verliert er an Kraft und schreitet hier viel langsamer fort, als die Tentakelstiele hinab. In Folge der Richtung und der Form der Zellen läuft er auch mit gröszerer Leichtigkeit und Geschwindigkeit in einer longitudinalen Richtung über die Scheibe als in einer queren. Der von den Drüsen der äuszersten randständigen Tentakeln ausgehende Impuls scheint nicht Kraft genug zu haben, die nächststehenden Tentakeln zu afficiren; und dies dürfte zum Theil Folge ihrer Länge sein. Der Impuls von den Drüsen der nächsten wenigen inneren Reihen breitet sich hauptsächlich nach den Tentakeln auf jeder Seite und nach der Mitte des Blattes hin aus; aber der von den Drüsen der kürzeren Tentakeln auf der Scheibe ausgehende strahlt beinahe gleichmäszig nach allen Seiten hin aus.

# Reizung und Impulsweiterleitung

Wenn eine Drüse durch die Quantität oder Qualität der auf sie gebrachten Substanz stark gereizt wird, so schreitet der motorische Impuls weiter fort als von einer nur unbedeutend gereizten Drüse; und wenn mehrere Drüsen gleichzeitig gereizt werden, so vereinigen sich die Impulse von allen und verbreiten sich noch weiter. Sobald eine Drüse gereizt wird, entladet sie einen Impuls, welcher sich eine beträchtliche Entfernung weit erstreckt; nachher aber, während die Drüse absondert und aufsaugt, reicht der Impuls nur hin, den nämlichen Tentakel eingebogen zu halten, wenn schon die Einbiegung viele Tage dauern kann.

# Beugung und Reflexion

Wenn die Beugungsstelle eines Tentakels einen Impuls von seiner eigenen Drüse erhält, so ist die Bewegung immer nach der Mitte des Blattes hingerichtet; dasselbe ist mit allen Tentakeln der Fall, wenn ihre Drüsen durch Eintauchen in eine passende Flüssigkeit gereizt werden. Die kurzen in dem mittleren Theile der Scheibe müssen ausgenommen werden, da sich diese durchaus gar nicht biegen, wenn sie so gereizt werden. Wenn auf der andern Seite der motorische Impuls von einer Seite der Scheibe herkommt, so biegen sich die umgebenden Tentakeln, mit Einschlusz der kurzen auf der Mitte der Scheibe, sämmtlich mit Präcision nach dem Reizungspunkte hin, wo nur immer derselbe gelegen sein mag, Dies ist auf alle Fälle eine merkwürdige Erscheinung; denn das Blatt erscheint irrthümlich so, als sei es mit den Sinnen eines Thieres begabt. Es ist nur um so merkwürdiger, da, wenn der motorische Impuls die Basis eines Tentakels schräg in Beziehung auf seine abgeplattete Oberfläche trifft, die Zusammenziehung der Zellen auf ein, zwei oder sehr wenig Reihen an dem einen Ende beschränkt sein musz. Und der Einflusz musz auf verschiedene Seiten der umgebenden Tentakeln einwirken, damit sich alle mit Präcision nach dem Reizungspunkte hin biegen.

# Reflexthätigkeit und Protoplasma

Wie sich der motorische Impuls von einer oder mehreren Drüsen aus über die Scheibe verbreitet, tritt er in die Basen der umgebenden Tentakeln ein und wirkt unmittelbar auf die Beugungsstelle. Er geht an erster Stelle nicht die Tentakeln zu den Drüsen hinauf, um diese zu reizen, dasz sie einen Impuls zurück auf ihre Basen reflec- tieren. Trotzdem wird aber doch etwas Einflusz zu den Drüsen hinauf geschickt, da ihre Absonderung bald vermehrt und sauer wird; und sind die Drüsen in dieser Weise gereizt, dann schicken sie irgend einen andern Einflusz zurück, (der weder von vermehrter Absonderung noch von der Einbiegung der Tentakeln abhängt), welcher die Zusammenballung des Protoplasma in Zelle unter Zelle verursacht. Dies mag eine Reflexthätigkeit genannt werden, obschon sie wahrscheinlich von der von einem Nervenganglion eines Thieres ausgehenden sehr.# Reflexionen über Pflanzenbewegungen

verschieden ist; es ist auch der einzige bekannte Fall einer Reflex-
thätigkeit im Pflanzenreich.
Über den Mechanismus der Bewegungen und die Natur des mo-
torischen Impulses wissen wir sehr wenig. Während des Actes der
Einbiegung läuft sicherlich Flüssigkeit von einem Theile der Ten-
takeln zu anderen. Aber die Hypothese, welche am besten mit den
beobachteten Thatsachen übereinstimmt ist die, dasz der motorische
Impuls seiner Natur nach mit dem Procesz der Zusammenballung
verwandt ist, und dasz hiernach die Molekule der Zellwandungen sich
einander zu nähern veranlaszt werden, in derselben Weise wie es die
Molekule des Protoplasma innerhalb der Zellen thun, so dasz sich die
Zellwände zusammenziehn. Aber einige starke Einwendungen können
gegen diese Ansicht erhoben werden. Das Wiederausstrecken der
Tentakeln ist zum groszen Theile Folge der Elasticität ihrer äuszeren
Zellen, welche in Thätigkeit tritt, sobald die Zellen auf der inneren
Seite aufhören, sich mit überwiegender Kraft zusammenzuziehn; wir
haben aber Grund zu vermuthen, dasz während des Actes der Wieder-
ausstreckung die äuszeren Zellen beständig und langsam Flüssigkeit
anziehn und dadurch ihre Spannung vermehren.
Ich habe nun eine kurze Recapitulation der hauptsächlichsten
von mir in Bezug auf die Structur, die Bewegungen, Constitution und
Gewohnheiten der Drosera rotundifolia beobachteten Punkte gegeben;
wir sehen daraus, wie wenig ermittelt ist in Vergleich zu dem, was
noch unerklärt und unbekannt bleibt.

# Bau und Bewegungen anderer Drosera-Arten

Zwölftes Capitel.
Über den Bau und die Bewegungen einiger anderen Arten
von Drosera.
Drosera anglica. — Drosera intermedia. — Drosera capensis. — Drosera spathu-
lata. — Drosera filiformis. — Drosera binata. — Schluszbemerkungen.
Ich untersuchte sechs andere Species von Drosera, einige von
ihnen Bewohner ferner Länder, hauptsächlich zum Zwecke, um zu er-
mitteln, ob sie Insecten fiengen. Dies schien um so nothwendiger zu
sein, als die Blätter von einigen der Arten in einem auszerordent-
lichen Grade der Form nach von den abgerundeten der Drosera
rotundifolia abweichen. In ihrer functionellen Fähigkeit weichen sie
indesz sehr wenig von einander ab.
Drosera anglica HudsonMrs. Treat hat in „The American Naturalist‟, Dezember,
1873, p. 705,
eine ausgezeichnete Schilderung der Drosera longifolia (was zum Theil ein Synon-
nym von Drosera anglica ist), Drosera rotundifolia und Drosera filiformis
gegeben.. — Die Blätter dieser Species, welche mir
von Irland zugeschickt wurde, sind sehr verlängert und verbreitern sich
allmählich vom Stiele aus bis zu dem stumpf zugespitzten Spitzenende.
Sie stehen beinahe aufrecht und ihre Scheiben sind zuweilen über 1 Zoll
lang, während ihre Breite nur ⅓ Zoll beträgt. Die Drüsen aller Tentakeln
haben denselben Bau, so dasz die äuszersten randständigen nicht von den
andern abweichen, wie es bei Drosera rotundifolia der Fall ist. Wenn
sie durch eine derbe Berührung oder durch den Druck äuszerst kleiner
anorganischer Körperchen oder durch die Berührung mit animaler Sub-
stanz oder durch die Absorption von kohlensaurem Ammoniak gereizt
werden, werden die Tentakeln eingebogen; der basale Theil ist der haupt-
sächliche Sitz der Bewegung. Schneiden oder Stechen der Blattscheibe
regte keine Bewegung an. Sie fangen häufig Insecten und die Drüsen
der eingebogenen Tentakeln ergieszen viel saure Absonderung. Stückchen
gerösteten Fleisches wurden auf einige Drüsen gelegt, und in 1 Minute
oder 1 Minute 30 Secunden fiengen die Tentakeln an, sich zu bewegen
und erreichten in 1 Stunde 10 Minuten die Mitte des Blattes. Zwei
Cap. 12. Drosera capensis.
Stückchen gekochten Korks, eines von gekochtem Garn und zwei Stück-
chen aus dem Feuer genommener Kohlenasche wurden mit Hülfe eines
Instruments, welches in kochendes Wasser eingetaucht worden war, auf
fünf Drüsen gelegt; diese überflüssigen Vorsichtsmaszregeln waren in Folge
der Angaben Ziegler’s genommen worden. Eines der Kohlenstückchen# Beobachtungen an Drosera

## Einleitung
verursachte in 8 Stunden 45 Minuten etwas Einbiegung, das andere Kohlenstückchen, das Stückchen Faden und beide Korkstückchen thaten es nach 23 Stunden. Drei Drüsen wurden ein halbes Dutzend mal mit einer Nadel berührt; einer der Tentakeln wurde in 17 Minuten gut einbogen und streckte sich nach 24 Minuten wieder aus; die beiden andern bewegten sich niemals. Die homogene Flüssigkeit innerhalb der Zellen der Tentakeln erleidet Zusammenballung, nachdem dieselben eingebogen worden sind, besonders wenn ihnen eine Lösung von kohlensaurem Ammoniak gegeben wurde; ich beobachtete die gewöhnlichen Bewegungen in den Protoplasma-Massen. In einem Falle folgte Zusammenballung in 1 Stunde 10 Minuten, nachdem ein Tentakel ein Stückchen Fleisch nach der Blattscheibe geschafft hatte. Nach diesen Thatsachen ist es klar, dasz sich die Tentakeln der Drosera anglica so wie die der Drosera rotundifolia verhalten.

## Reaktion auf Insekten
Wenn ein Insect auf die centralen Drüsen gebracht wird oder in naturgemäszer Weise dort gefangen worden ist, so rollt sich die Spitze des Blattes einwärts. Es wurden beispielsweise todte Fliegen auf drei Blätter in die Nähe ihrer Basen gelegt, und nach 24 Stunden waren die vorher geraden Spitzen so vollständig eingerollt, dasz sie die Fliegen umfaszten und verbargen; sie hatten sich daher durch einen Winkel von 180° bewegt. Nach drei Tagen fieng die Spitze eines Blattes, zusammen mit den Tentakeln, sich wieder auszustrecken an. So weit ich es aber gesehen habe, — und ich habe viele Versuche gemacht, — sind die Seiten des Blattes niemals eingebogen, und dies ist der eine functionelle Unterschied zwischen dieser Species und Drosera rotundifolia.

## Drosera intermedia Hayne
Drosera intermedia Hayne. — Diese Species ist in einigen Theilen von England völlig so gemein wie Drosera rotundifolia. Sie weicht, so weit die Blätter in Betracht kommen, von Drosera anglica nur in deren geringerer Grösze und darin ab, dasz ihre Spitzen allgemein ein wenig zurückgebogen sind. Sie fangen eine grosze Anzahl von Insecten. Die Tentakeln werden durch alle oben einzeln aufgeführten Ursachen zur Bewegung angeregt, und Zusammenballung tritt mit der Bewegung der protoplasmatischen Massen ein. Ich habe durch eine Lupe gesehen, wie sich ein Tentakel in weniger als einer Minute zu biegen begann, nachdem ein Stückchen rohen Fleisches auf die Drüse gebracht worden war. Die Spitze des Blattes rollt sich über einen reizenden Gegenstand in der selben Weise ein wie bei Drosera anglica. Saures Secret wird reichlich über gefangene Insecten ergossen. Ein Blatt, welches eine Fliege mit allen seinen Tentakeln umfaszt hatte, breitete sich nach nahezu drei Tagen wieder aus.

## Drosera capensis
Drosera capensis. — Diese Art, am Vorgebirge der Guten Hoffnung eingeboren, wurde mir von Dr. Hooker geschickt. Die Blätter sind verlängert, entlang der Mitte unbedeutend concav und verschmälern sich nach der Spitze zu, welche stumpf zugespitzt und zurückgebogen ist. Sie erheben sich von einer beinahe holzigen Achse, und ihre gröszte Eigenthümlichkeit besteht in ihren blättrigen grünen Stielen, welche beinahe so breit und selbst noch länger sind als die drüsentragende Scheibe. Diese Species zieht daher wahrscheinlich mehr Nahrung aus der Luft und weniger aus gefangenen Insecten als die anderen Arten der Gattung. Nichtsdestoweniger sind doch die Tentakeln auf der Scheibe zusammen- gedrängt und sind äusserst zahlreich, die an den Rändern sind viel länger als die mittleren. Alle Drüsen haben eine und dieselbe Form; ihr Secret ist äusserst klebrig und sauer.

## Gesundheitszustand und Reaktionen
Das Exemplar, welches ich untersuchte, hatte sich soeben erst von einem schwachen Gesundheitszustande erholt. Dies dürfte es erklären, dasz die Tentakeln sich sehr langsam bewegten, wenn Stückchen Fleisch auf die Drüsen gelegt wurden, und vielleicht auch die Thatsache, dasz es mir niemals gelang, irgend eine Bewegung durch wiederholte Berührung derselben mit einer Nadel zu verursachen. Aber bei allen Arten der Gattung ist dies letztere Reizmittel das wenigst wirksamste von allen. Stückchen von Glas, Kork, Kohlenasche wurden auf die Drüsen von sechs Tentakeln gebracht; und einer allein bewegte sich nach Verlauf von 2 Stunden 30 Minuten. Trotzdem aber waren zwei Drüsen äuszerst em-# Beobachtungen an Drosera

## Empfindlichkeit gegenüber Ammoniak
pfindlich gegen sehr kleine Dosen von salpetersaurem Ammoniak, nämlich gegen ungefähr \frac {1}{20} Minim einer Lösung (ein Theil auf 5250 Theile Wasser), welches nur \frac {1}{115200} Gran (0,000562 Milligr.) des Salzes enthielt. Fragmente von Fliegen wurden auf zwei Blätter in die Nähe ihrer Spitzen gelegt; in wenig Stunden umfaszten sie die Tentakeln auf jeder Seite, und in 8 Stunden war das ganze Blatt direct unterhalb der Fliege ein wenig quer gebogen. Am nächsten Morgen, nach 23 Stunden, war das Blatt so vollständig eingerollt, dasz die Spitze auf dem oberen Ende des Stieles lag. In keinem Falle wurden die Seiten des Blattes einge- bogen. Eine zerquetschte Fliege wurde auf den blattartigen Stiel gelegt, brachte aber keine Wirkung hervor.

## Drosera spathulata
Drosera spathulata (von Dr. Hooker mir geschickt). — Ich habe nur einige wenige Beobachtungen über diese australische Art gemacht, welche lange, schmale, sich allmählich nach der Spitze zu verbreiternde Blätter hat. Die Drüsen der äuszersten randständigen Tentakeln sind verlängert und weichen von den übrigen ab, wie es bei Drosera rotundifolia der Fall ist. Eine Fliege wurde auf ein Blatt gelegt, und in 18 Stunden war sie von den angrenzenden Tentakeln umfaszt. Gummi- wasser auf mehrere Blätter getropft, brachte keine Wirkung hervor. Ein Bruchstück eines Blattes wurde in einige Tropfen einer Lösung von einem Theil kohlensauren Ammoniaks auf 146 Theile Wasser eingetaucht; alle Drüsen waren augenblicklich geschwärzt; man konnte sehen, wie der Prozess der Zusammenballung sehr schnell die Zellen der Tentakeln hinab- gieng; die Protoplasma-Körnchen vereinigten sich bald zu Kugeln und verschieden geformten Massen, welche die gewöhnlichen Bewegungen darboten. Ein halbes Minim einer Lösung von einem Theil salpetersauren Ammoniaks auf 146 Theile Wasser wurde dann auf die Mitte eines Blattes gebracht; nach 6 Stunden waren einige randständige Tentakeln auf beiden Seiten eingebogen, und nach 9 Stunden trafen sie sich in der Mitte. Auch die seitlichen Ränder des Blattes wurden einwärts gekrümmt, so dasz es einen Halbeylinder bildete; aber in keinem meiner wenigen Versuche wurde die Spitze des Blattes eingebogen. Die obige Dose des salpetersauren Salzes (nämlich \frac {1}{320} Gran, oder 0,202 Milligr.) war zu stark, denn im Verlaufe von 23 Stunden starb das Blatt ab.

## Drosera filiformis
Drosera filiformis. — Diese nordamerikanische Species wächst in Theilen von Neu-Jersey in solchen Massen, dasz sie beinahe den Boden bedeckt. Sie fängt, der Angabe der Mrs. Treat zufolge, eine ausserordentliche Anzahl kleiner und groszer Insecten, — selbst grosze Fliegen aus der Gattung Asilus, Nacht- und Tagschmetterlinge. Das mir von Dr. Hooker geschickte Exemplar, welches ich untersuchte, hatte faden- ähnliche Blätter, von 6 bis 12 Zoll Länge, mit der oberen Fläche convex und der unteren flach und unbedeutend canellirt. Die ganze convexe Oberfläche bis hinab zu den Wurzeln, — denn es ist kein deutlicher Stiel vorhanden, — ist mit kurzen drüsentragenden Tentakeln bedeckt, wobei die an den Rändern die längsten und zurückgebogen sind. Stück- chen Fleisch auf die Drüsen einiger Tentakeln gelegt, bewirkten in 20 Minuten eine unbedeutende Einbiegung derselben; die Pflanze war aber in keinem recht lebenskräftigen Zustande. Nach 6 Stunden bewegten sie sich durch einen Winkel von 90° und erreichten in 24 Stunden die Mitte. In dieser Zeit fiengen die umgebenden Tentakeln an, sich einwärts zu krümmen. Endlich wurde ein groszer Tropfen äusserst klebriger, leicht saurer Absonderung aus den vereinigten Drüsen über das Fleisch ergossen. Mehrere andere Drüsen wurden mit ein wenig Speichel berührt und die Tentakeln wurden in weniger als 1 Stunde einwärts gebogen und streck- ten sich nach 18 Stunden wieder aus. Stückchen von Glas, Kork, Kohlen, Garn und Goldblättchen wurden an zwei Blättern auf zahlreiche Drüsen gelegt; in ungefähr 1 Stunde wurden vier Tentakeln gekrümmt und vier andere nach Verlauf von weiteren 2 Stunden 30 Minuten. Es gelang mir nicht ein einziges mal, irgend eine Bewegung durch wiederholtes Be- rühren der Drüsen mit einer Nadel zu veranlassen, und Mrs. Treat machte um meinetwillen ähnliche Versuche ohne Erfolg. Kleine Fliegen wurden auf mehrere Blätter in die Nähe ihrer Spitzen gelegt, aber die faden-# Pflanzenbewegungen und Insektenfängung

ähnliche Scheibe wurde nur bei einer Gelegenheit sehr unbedeutend direct
unterhalb des Insects gebogen. Vielleicht deutet dies an, dasz die Schei-
ben lebenskräftiger Pflanzen sich über gefangene Insecten einbiegen, und
Dr. Canby theilt mir mit, dasz dies der Fall ist; die Bewegung kann
aber nicht stark ausgesprochen sein, da sie von Mrs. Treat nicht beob-
achtet wurde.

## Drosera binata

Drosera binata (oder dichotoma). — Ich bin der Lady Dorothy
Nevill für eine schöne Pflanze dieser beinahe gigantischen Species aus
Australien sehr verbunden, welche in einigen interessanten Punkten von
den bis jetzt beschriebenen abweicht. An diesem Exemplar waren die
binsenartigen Stiele der Blätter 20 Zoll lang. Die Blattscheibe theilt
sich gabelförmig an ihrer Verbindung mit dem Stiel, und später noch
zwei oder dreimal, sich dabei in einer unregelmäszigen Art und Weise
umherwindend. Sie ist schmal, nur \frac {3}{20} Zoll in der Breite messend. Die
eine Scheibe war 7½ Zoll lang, so dasz das ganze Blatt mit Einschlusz
des Stengels über 27 Zoll an Länge masz. Beide Flächen sind unbe-
deutend ausgehöhlt. Die obere Fläche ist mit, in abwechselnden Reihen
angeordneten Tentakeln bedeckt; diejenigen in der Mitte sind kurz und
dicht zusammengedrängt, diejenigen nach den Rändern zu sind länger,
selbst zwei- oder dreimal so lang wie die Scheibe breit ist. Die Drüsen
der äuszeren Tentakeln sind von einem viel dunkleren Roth als die der
centralen. Die Stiele von allen sind grün. Die Spitze der Blattscheibe ist
verschmälert und trägt sehr lange Tentakeln. Dr. Copland theilt mir
mit, dasz die Blätter einer Pflanze, welche er einige Jahre lang hielt,
allgemein mit gefangenen Insecten bedeckt waren, ehe sie verwelkten.

## Struktur und Funktion der Blätter

Die Blätter weichen in keinen wesentlichen Punkten der Structur
oder der Function von denen der früher beschriebenen Species ab. Stück-
chen Fleisch oder ein wenig Speichel auf die Drüsen der äuszeren Ten-
takeln gebracht, verursachten gut ausgesprochene Bewegung in 3 Minuten,
und Stückchen Glas wirkten in 4 Minuten. Die Tentakeln mit den letz-
tern Körperchen streckten sich nach 22 Stunden wieder aus. An einem
Stücke eines Blattes, welches in einige wenige Tropfen einer Lösung von
einem Theil kohlensauren Ammoniaks in 437 Theilen Wasser eingetaucht
war, waren in 5 Minuten alle Drüsen geschwärzt und alle Tentakeln ein-
gebogen. Ein Stückchen rohen Fleisches auf mehrere Drüsen in der
mittleren Furche gelegt, war in 2 Stunden 10 Minuten von den rand-
ständigen Tentakeln auf beiden Seiten ordentlich eingeschlossen. Stück-
chen gerösteten Fleisches und kleine Fliegen wirkten nicht ganz so schnell,
und Eiweisz und Faserstoff noch weniger schnell. Eines der Stückchen
Fleisch erregte so starke Absonderung (welche immer sauer ist), dasz das
Secret eine Strecke weit die mittlere Furche hinabflosz und die Einbiegung
der Tentakeln auf beiden Seiten verursachte, so weit es sich erstreckte.

## Reaktion auf Reize

Stückchen Glas auf die Drüsen in der mittleren Furche gelegt, reizten
dieselben nicht stark genug, dasz irgend ein motorischer Impuls zu den
äuszeren Tentakeln gesandt worden wäre. In keinem Falle war die Scheibe
des Blattes, selbst nicht die verschmälerte Spitze, irgendwie eingebogen.
Auf beiden Flächen der Blattscheibe, der oberen und unteren, finden
sich zahlreiche minutiöse, beinahe sitzende Drüsen, welche aus vier,
acht oder zwölf Zellen bestehen. Auf der unteren Fläche sind sie blasz pur-
purn, auf der oberen grünlich. Nahezu ähnliche Organe kommen auf den
Blattstielen vor, sie sind da aber kleiner und häufig in einem verschrumpf-
ten Zustand. Die minutiösen Drüsen auf der Scheibe können rapid auf-
saugen: so wurde ein Stück eines Blattes in eine Lösung von einem Theile
kohlensauren Ammoniaks in 218 Theilen Wasser (1 Gran auf ½ Unze)
eingetaucht, und in 5 Minuten waren sie alle so bedeutend gedunkelt,
dasz sie beinahe schwarz waren, auch war ihr Zelleninhalt zusammen-
geballt. So weit ich es zu beobachten im Stande war, sondern sie nicht
aus freien Stücken ab; aber in einer Zeit von zwischen 2 und 3 Stun-
den, nachdem ein Blatt mit einem Stückchen, mit Speichel angefeuchteten
rohen Fleisches gerieben worden war, schienen sie reichlich abzusondern;
und diese Schluszfolgerung wurde später noch durch andere Erscheinun-
gen unterstützt. Sie sind daher mit den später zu beschreibenden
sitzenden Drüsen an den Blättern von Dionaea und Drosophyllum# Drosera binata

In der letzt genannten Gattung sind sie, wie in dem vorliegenden Falle mit Drüsen vergesellschaftet, welche spontan absondern, d. h. ohne dasz sie gereizt werden.

## Merkwürdige Eigenheiten

Drosera binata bietet eine andere und noch merkwürdigere Eigenthümlichkeit dar, nämlich die Anwesenheit einiger weniger Tentakeln auf dem Rücken der Blätter in der Nähe ihrer Ränder. Sie sind ihrem Baue nach vollkommen; Spiralgefässe laufen die Stiele hinauf; ihre Drüsen sind von Tropfen klebrigen Secrets umgeben und sie haben die Fähigkeit der Aufsaugung.

## Tentakeln und ihre Eigenschaften

Diese rückenständigen Tentakeln sind kurz, sie erreichen auch nicht nahezu die Länge der randständigen auf der oberen Fläche; einige von ihnen sind so kurz, dasz sie beinahe in die minutiösen sessilen Drüsen übergehen. Ihre Anwesenheit, Zahl und Grösse variirt an verschiedenen Blättern; sie sind ziemlich unregelmäszig angeordnet. Auf dem Rücken eines Blattes zählte ich einundzwanzig der einen Seite entlang.

## Bewegungsunfähigkeit der Tentakeln

Diese rückenständigen Tentakeln weichen in einer wichtigen Beziehung von denen der obern Fläche ab, nämlich darin, dasz sie durchaus keine Fähigkeit sich zu bewegen besitzen, in welcher Weise sie auch gereizt werden mögen. So wurden Stücke von vier Blättern zu verschiedenen Zeiten in Lösungen von kohlensaurem Ammoniak gebracht (ein Theil auf 437 oder 218 Theile Wasser) und alle Tentakeln auf der oberen Fläche wurden bald dicht eingebogen; aber die rückenständigen bewegten sich nicht, obschon die Blätter viele Stunden lang in den Lösungen gelassen wurden und obgleich ihre Drüsen, ihrer schwarzen Färbung nach zu urtheilen, offenbar etwas von dem Salz absorbirt hatten.

## Nutzen der rückenständigen Tentakeln

Obgleich sie nicht die Fähigkeit der Bewegung haben, so sind sie wahrscheinlich dadurch von etwas Nutzen, dasz sie aus irgend einem minutiösen Insect, welches etwa von ihnen gefangen wäre, animale Substanz aufsaugen, und dasz sie Ammoniak aus dem Regenwasser absorbiren. Aber ihre schwankende Anwesenheit und Grösse und ihre unregelmäszige Stellung weisen darauf hin, dasz sie nicht von bedeutendem Nutzen sind und dasz sie sich dem Verkümmern zuneigen.

## Schluszbemerkungen

Nach dem, was wir nun gesehen haben, kann kein Zweifel darüber bestehen, dasz die meisten oder wahrscheinlich alle Species von Drosera so eingerichtet sind, dasz sie Insecten mit nahezu denselben Mitteln fangen.# Pflanzen und ihre Eigenschaften

## Drosera Arten
undere Arten dieses Landes, nämlich Drosera pallida und Drosera sulphurea, „ihre Blätter mit groszer Rapidität über Insecten schlieszen: dieselbe Erscheinung wird von einer indischen Species, Dr. lunata, und von mehreren der Arten vom Vorgebirge der Guten Hoffnung, besonders von Dr. trinervis dargeboten.‟ Eine andere australische Art, Drosera heterophylla (welche Lindley zu einer besonderen Gattung, Sondera, macht), ist merkwürdig wegen der eigenthümlich geformten Blätter; ich weisz aber nichts von ihrer Fähigkeit, Insecten zu fangen, denn ich habe nur getrocknete Exemplare gesehen. Die Blätter bilden äuszerst kleine abgeplattete Becher, die Stiele sind nicht an dem einen Rande, sondern am Boden derselben befestigt. Die innere Fläche und die Ränder der Becher sind dicht mit Tentakeln besetzt, welche Gefäszfaserbündel einschlieszen, ziemlich verschieden von denen, die ich in irgend welchen andern Arten gesehen habe; denn einige von den Gefäszen sind gestreift und punktirt, anstatt spiral zu sein. Die Drüsen sondern reichlich ab, nach der Menge ihnen anhängenden eingetrockneten Secrets zu urtheilen.

## Dionaea muscipula
Dreizehntes Capitel. Structur der Blätter. — Empfindlichkeit der Filamente. — Rapide Bewegung der Lappen, durch Reizung der Filamente verursacht. — Drüsen, ihr Absonderungsvermögen. — Langsame Bewegung durch Absorption animaler Substanz ver-
ursacht. — Beweis der Aufsaugung in dem zusammengeballten Zustand der Drüsen. — Verdauende Kraft des Secrets. — Wirkung von Chloroform, Äther und Blausäure. — Die Art und Weise, wie Insecten gefangen werden. — Nutzen der randständigen Spitzen. — Arten der Insecten, die gefangen wer-
den. — Die Übermittelung des motorischen Impulses und der Mechanismus der Bewegungen. — Wiederausbreitung der Lappen. Diese gewöhnlich Venusfliegenfalle genannte Pflanze ist wegen der Rapidität und Kraft ihrer Bewegungen eine der wunderbarsten in der Welt. Dr. Hooker hat in seiner Adresse an die British Association in Belfast, 1874, einen so ausführlichen historischen Bericht über die Beobachtungen, welche über die Lebensweise dieser Pflanze veröffentlicht worden sind, gegeben, dasz es überflüssig für mich wäre, sie zu wiederholen. Sie ist ein Glied der kleinen Familie der Droseraceen und wird nur in dem östlichen Theil von Nord-Carolina, in feuchten Situationen wachsend, gefunden. Die Wurzeln sind klein; die einer mäszig schönen Pflanze, die ich untersuchte, bestanden aus zwei ungefähr 1 Zoll langen Zweigen, welche von einer knolligen Verdickung entsprangen. Sie dienen wahrscheinlich, wie bei Drosera, nur zur Aufsaugung von Wasser; denn ein Gärtner, welcher mit der Cultur dieser Pflanze sehr erfolgreich gewesen ist, zieht sie, wie eine schmarotzende Orchidee, in gut durchlassendem feuchten Moose ohne irgend welche Erde. Die Form des zweilappigen Blattes mit seinem blattartigen Stiele ist in der umstehenden Figur dargestellt (Fig. 12). Die beiden Lappen stehen in etwas weniger als einem rechten Winkel zu einander. Drei sehr kleine zugespitzte Fortsätze oder Filamente, die im Dreieck gestellt sind, springen von der oberen Fläche eines jeden vor; ich habe aber zwei Blätter gesehen mit vier Filamenten auf jeder Seite und ein anderes mit nur zweien. Diese Filamente sind wegen ihrer äuszersten Empfindlichkeit gegen eine Berührung merkwürdig, wie sie sich nicht durch ihre eigene Bewegung, sondern durch die der Lappen zeigt. Die Ränder des Blattes sind in scharfe starre Vorsprünge ausgezogen, welche ich Spitzen (oder Speichen) nenne; in jede derselben tritt ein Bündel von Spiralgefäszen ein. Dieselben haben eine solche Stellung, dasz, wenn sich die Blattlappen schlieszen, sie ineinander greifen wie die Zähne einer Rattenfalle.# Blattstruktur und Drüsen

Mittelrippe des Blattes ist auf der unteren Seite stark entwickelt und vorspringend. Die obere Fläche des Blattes ist, ausgenommen nach den Rändern zu, dicht mit minutiösen Drüsen von einer röthlichen oder purpurnen Färbung besetzt, während das Übrige des Blattes grün ist. An den Speichen finden sich keine Drüsen, ebenso wenig an dem blattartigen Stengel. Die Drüsen werden aus zwanzig bis dreiszig polygonalen Zellen gebildet, die mit purpurner Flüssigkeit gefüllt sind. Ihre obere Fläche ist convex. Sie stehen auf sehr kurzen Stielen, in welche keine Spiralgefäsze eintreten, in welcher Beziehung sie von den Tentakeln der Drosera abweichen. Sie sondern ab, aber nur, wenn sie durch die Absorption gewisser Substanzen gereizt werden; und sie haben die Fähigkeit der Absorption. Minutiöse Vorsprünge, die aus acht divergirenden Armen einer röthlich-braunen oder orangenen Färbung gebildet werden und unter dem Mikroskope wie elegante kleine Blumen erscheinen, sind in beträchtlicher Anzahl über den Stengel, die Rückenfläche der Blätter und die Speichen zerstreut; auch finden sich einige wenige auf der oberen Fläche der Lappen.

# Empfindlichkeit der Filamente

Die empfindlichen Filamente werden aus mehreren Reihen verlängerter, mit purpurähnlicher Flüssigkeit gefüllter Zellen gebildet. Sie sind ein wenig mehr als \frac {1}{20} Zoll lang, sind dünn und zart und verjüngen sich zu einer Spitze. Ich untersuchte die Basen von mehreren, indem ich Durchschnitte von ihnen machte, es war aber keine Spur des Eintritts irgend eines Gefäszes zu sehen. Die Spitze ist zuweilen zwei- oder selbst dreitheilig, in Folge einer leichten Trennung zwischen den endständigen zugespitzten Zellen. Nach der Basis zu findet sich eine Einschnürung, die aus breiteren Zellen gebildet wird, unterhalb deren ein von einer verbreiterten, aus verschiedent- lich geformten polygonalen Zellen bestehenden Basis getragenes Gelenk liegt. Da die Filamente in rechten Winkeln zu der Oberfläche des Blattes vorspringen, so würden sie sehr leicht abgebrochen werden, sobald sich nur immer die Lappen zusammenschließen, wenn ihnen nicht dies Gelenk gestattete, sich platt niederzulegen.

Diese Filamente sind von ihren Spitzen bis zu ihren Basen ganz ausgesucht empfindlich für eine momentane Berührung. Es ist kaum möglich, sie überhaupt je so leicht oder so schnell mit irgend einem harten Gegenstande zu berühren, ohne das Schlieszen der Lappen zu verursachen. Ein 2½ Zoll langes Stückchen sehr zarten menschlichen Haares, welches über einem Filamente hängend gehalten und hin und her geschwungen wurde, so dass es dasselbe berührte, erregte keine Bewegung. Wenn aber ein ziemlich dicker baumwollener Garnfaden von derselben Länge ähnlich geschwungen wurde, schlossen sich die Lappen. Prisen feinen Weizenmehls, aus einer ziemlichen Höhe fallen gelassen, brachten keine Wirkung hervor. Das oben erwähnte Haar wurde dann in einem Handgriff befestigt und so weit abgeschnitten, dass 1 Zoll vorragte; dieses Stück war lang genug und hinreichend steif, sich in einer nahezu horizontalen Linie zu halten. Das Ende wurde nun durch eine langsame Bewegung seitlich mit der Spitze eines Filaments in Berührung gebracht, und augenblicklich schloss sich das Blatt. Bei einer andern Gelegenheit waren zwei oder drei Berührungen derselben Art nötig, ehe irgend eine Bewegung erfolgte. Wenn wir bedenken, wie biegsam ein feines Haar ist, so können wir uns eine Idee davon machen, wie leicht die von dem Ende eines 1 Zoll langen, langsam bewegten Stückes verursachte Berührung gewesen sein muss.

Obgleich diese Filamente für eine momentane und zarte Berührung so empfindlich sind, so sind sie doch für länger anhaltenden# Empfindlichkeit der Filamente

Druck bei weitem weniger empfindlich als die Drüsen der Drosera. Mehreremale gelang es mir, mit Hülfe einer mit äusserster Langsamkeit bewegten Nadel Stückchen von ziemlich dickem menschlichen Haar auf die Spitze eines Filaments zu legen, und diese regten keine Bewegung an, obschon sie mehr als zehnmal so lang waren wie diejenigen, die die Tentakeln der Drosera sich zu biegen veranlassten; und trotzdem sie in diesem letztern Falle zum groszen Theile von der dicken Absonderung getragen wurden. Auf der andern Seite können die Drüsen der Drosera mit einer Nadel oder irgend einem harten Gegenstande einmal, zweimal oder selbst dreimal mit beträchtlicher Kraft gestoszen werden, und es folgt doch keine Bewegung. Dieser eigenthümliche Unterschied in der Natur der Empfindlichkeit der Filamente der Dionaea und der Drüsen der Drosera steht offenbar in Beziehung zu den Lebensgewohnheiten der beiden Pflanzen. Wenn ein äusserst kleines Insect sich mit seinen zarten Füszen auf den Drüsen der Drosera niederläszt, so wird es von dem klebrigen Secrete gefangen und der unbedeutende, indessen verlängerte Druck gibt die Notiz von der Anwesenheit der Beute weiter, welche nun durch das langsame Biegen der Tentakeln gesichert wird. Auf der andern Seite sind die empfindlichen Filamente der Dionaea nicht klebrig und das Fangen der Insecten kann nur durch ihre Empfindlichkeit für eine augenblickliche Berührung gesichert werden, welcher das schnelle Schlieszen der Lappen folgt.

# Vergleich der Pflanzen

Wie eben angeführt wurde, sind die Filamente nicht drüsig und sondern nicht ab. Auch haben sie die Fähigkeit der Absorption nicht, wie daraus geschlossen werden kann, dasz Tropfen einer Lösung von kohlensaurem Ammoniak (1 Theil auf 146 Theile Wasser), auf zwei Filamente gebracht, keine Wirkung auf den Inhalt ihrer Zellen hervorbrachte und auch nicht die Lappen zu schlieszen veranlaszte. Wenn indessen ein kleines Stück eines Blattes mit daran haftendem Filament abgeschnitten und in die nämliche Lösung eingetaucht wurde, so wurde die Flüssigkeit innerhalb der basalen Zellen beinahe augenblicklich zu purpurartigen oder farblosen, unregelmäszig geformten Massen von Substanz zusammengeballt. Der Procesz der Zusammenballung gieng allmählich von Zelle zu Zelle die Filamente hinauf bis zu ihren Spitzen; das ist also ein umgekehrter Lauf, verglichen mit dem, der in den Tentakeln der Drosera vorkommt, wenn sie gereizt worden sind. Mehrere andere Filamente wurden dicht an ihrer Basis abgeschnitten und 1 Stunde 30 Minuten lang in eine schwächere Lösung von einem Theile des kohlensauren Salzes auf 218 Theile Wasser gelegt; und dies verursachte Zusammenballung in allen Zellen, wieder wie vorher an den Basen der Filamente beginnend.

# Zusammenballung und Veränderungen

Langes Eintauchen der Filamente in destillirtes Wasser verursacht gleichfalls Zusammenballung. Es ist auch nicht selten, den Inhalt einiger wenigen endständigen Zellen in einem von selbst eingetretenen Zustand der Zusammenballung zu finden. Die zusammengeballten Massen erleiden unablässig langsame Formveränderungen, vereinigen sich und trennen sich wieder; und einige von ihnen drehen sich allem Anscheine nach rund um ihre eigene Achse. Es ist auch das Flieszen eines Stroms farblosen körnigen Protoplasmas rund um die Zellen den Wänden entlang zu sehen. Dieser Strom hört auf, sichtbar zu sein, sobald der Inhalt gut zusammengeballt ist; er dauert aber wahrscheinlich noch fort, obschon nicht länger mehr sichtbar, weil alle Körnchen in der strömenden Schicht sich mit den centralen Massen vereinigt haben. In allen diesen Beziehungen verhalten sich die Filamente der Dionaea genau so wie die Tentakeln der Drosera.

# Merkwürdige Unterschiede

Trotz dieser Ähnlichkeit besteht doch eine merkwürdige Verschiedenheit. Wenn die Drüsen der Tentakeln der Drosera wiederholt berührt worden sind oder wenn ein Körperchen irgend welcher Art auf sie gelegt worden ist, so werden sie eingebogen und ihr Zelleninhalt wird stark zusammengeballt. Keine solche Wirkung wird durch die Berührung der Filamente der Dionaea hervorgebracht; ich verglich nach einer oder zwei Stunden einige Filamente, welche berührt wor-# Empfindlichkeit der Filamente

den waren, mit andern, welche es nicht waren, und noch andere nach 25 Stunden, und es fand sich in dem Inhalte der Zellen keine Verschiedenheit. Die Blätter wurden während der ganzen Zeit durch Klemmer offen gehalten, so dasz die Filamente nicht gegen den Lappen der anderen Seite angepreszt wurden. Wassertropfen oder ein dünner, unterbrochener, aus einer gewissen Höhe auf die Filamente herabfallender Strom verursachte keinen Dionaea muscipula.

# Schlusz der Blattscheiben

Cap. 13 Schlusz der Blattscheiben; obschon die nämlichen Filamente später als in hohem Grade empfindlich erwiesen wurden. Ohne Zweifel ist, wie es auch bei der Drosera der Fall ist, die Pflanze gegen den schwersten Regenschauer ganz indifferent. Tropfen einer Lösung von einer halben Unze Zucker in einer flüssigen Unze Wasser wurden wiederholt aus einer gewissen Höhe auf die Filamente fallen gelassen; es wurde aber keine Wirkung hervorgebracht, wenn sie nicht an den Filamenten hängen blieben.

# Wirkung von Wasser und Zuckerlösung

Ferner blies ich viele male durch eine feine zugespitzte Röhre mit äuszerster Kraft gegen die Filamente, aber ohne irgend welche Wirkung; ein derartiges Blasen wurde mit so viel Gleichgültigkeit aufgenommen, wie es ohne Zweifel ein heftiger Sturmwind wurde. Wir sehen hieraus, dasz die Empfindlichkeit der Filamente von einer specialisirten Beschaffenheit ist und eher zu einer momentanen Berührung als zu einem länger andauernden Druck in Beziehung steht; auch darf der Druck nicht von Flüssigkeiten, wie z. B. Luft oder Wasser, sondern musz von irgend einem festen Gegenstände ausgehen.

# Eintauchen in Wasser

Obgleich Tropfen von Wasser und von einer mäszig starken Zuckerlösung, wenn sie auf die Filamente fallen, dieselben nicht reizen, so bewirkt doch die Eintauchung eines Blattes in reines Wasser zuweilen, dasz sich die Lappen schlieszen. Ein Blatt wurde 1 Stunde 10 Minuten lang und drei andere Blätter für einige Minuten in Wasser gelassen, dessen Temperatur zwischen 15° bis 18,3° C. (59° bis 65° F.) schwankte; indessen ohne Wirkung.

# Reaktion auf Temperaturänderungen

Als indessen eines dieser vier Blätter sanft aus dem Wasser gezogen wurde, schlosz es sich ziem- lich schnell. Die drei anderen Blätter wurden als im guten Zustande befindlich nachgewiesen, da sie sich schlossen, als ihre Filamente berührt wurden. Nichtsdestoweniger schlossen sich zwei frische Blätter augenblicklich, als sie in Wasser von 23,8° und 16,9° C. (75° und 62½° F.) getaucht wurden. Diese wurden dann mit ihren Stengeln in Wasser gestellt und breiteten sich nach 23 Stunden theilweise wieder aus; bei Berührung ihrer Filamente schlosz sich das eine.

# Langzeitwirkungen des Eintauchens

Nach Verlauf von weiteren 24 Stunden breitete sich dieses letztere Blatt nochmals wieder aus, und als nun die Filamente beider Blätter berührt wurden, schlossen sich beide. Wir sehen hiernach, dasz ein kurzes Eintauchen in Wasser die Blätter durchaus nicht verletzt, son- dern zuweilen die Lappen sich zu schlieszen reizt. Die Bewegung war in den oben erwähnten Fällen offenbar nicht durch die Temperatur des Wassers verursacht.

# Exosmose und Zuckerlösung

Es ist gezeigt worden, dasz langes Eintauchen es bewirkt, dasz die purpurne Flüssigkeit innerhalb der Zellen der empfindlichen Filamente zusammengeballt wird; und langes Eintauchen wirkt auf die Tentakeln der Drosera in der nämlichen Weise, häufig werden sie etwas eingebogen. In beiden Fällen ist das Resultat wahrscheinlich eine Folge eines leichten Grades von Exosmose.

# Bestätigung durch Zuckerlösung

Ich werde in dieser Annahme durch die Wirkungen des Eintauchens eines Blattes der Dionaea in eine mäszig starke Auflösung von Zucker bestärkt; das Blatt hatte vorher 1 Stunde 10 Minuten lang in Wasser gelegen ohne irgend welche Wirkung; nun aber schlossen sich die Lappen ziemlich geschwind, die Spitzen der rand- ständigen Speichen kreuzten sich in 2 Minuten 30 Secunden und das Blatt war in 3 Minuten vollständig geschlossen. Drei Blätter wurden dann in eine Lösung von einer halben Unze Zucker in einer flüssigen Unze Wasser eingetaucht, und alle drei Blätter schlossen sich schnell.# Exosmose und Zellreaktionen

kung die Exosmose auf die Zellen an der oberen Fläche der Lappen oder auf die empfindlichen Filamente eingewirkt habe, so wurde zuerst ein Blatt in der Weise versucht, dasz ein wenig von der nämlichen Lösung auf die Furche über der Mittelrippe zwischen den beiden Lappen, welches der hauptsächlichste Sitz der Bewegung ist, gegossen wurde. Es wurde einige Zeit da gelassen, es folgte aber keine Bewegung. Dann wurde die ganze obere Fläche des Blattes mit derselben Lösung bestrichen (ausgenommen dicht um die Basen der empfindlichen Filamente, wo ich es nicht ohne die Gefahr sie zu berühren thun konnte); es wurde aber keine Wirkung hervorgebracht. Die Zellen auf der oberen Fläche werden daher hierdurch nicht affi- cirt. Als es mir aber nach vielen Versuchen gelang, einen Tropfen der Lösung an einem der Filamente hängen bleiben zu lassen, schlosz sich das Blatt schnell. Wir können, wie ich meine, hieraus schlieszen, dasz die Lösung es verursacht, dasz Flüssigkeit aus den zarten Zellen der Filamente durch Exosmose austritt; und dasz dies irgend eine moleculare Veränderung in ihrem Inhalt veranlaszt, analog der, welche durch eine Berührung hervorgebracht werden musz.

# Wirkung von Zuckerlösungen

Das Eintauchen der Blätter in eine Lösung von Zucker wirkt eine viel längere Zeit auf dieselben, als es Eintauchen in Wasser oder eine Berührung der Filamente thut; denn in diesen letzteren Fällen fangen die Lappen an, sich in weniger als einem Tage wieder auszubreiten. Auf der anderen Seite breitete sich von den drei Blättern, welche eine kurze Zeit lang in die Lösung eingetaucht und dann mittels einer zwischen die Lappen eingeschobenen Spritze gewaschen wurden, das eine nach zwei Tagen wieder aus, ein zweites nach sieben Tagen und das dritte nach neun Tagen. Das Blatt, welches sich in Folge davon geschlossen hatte, dasz ein Tropfen der Lösung an einem der Filamente hängen geblieben war, öffnete sich nach zwei Tagen wieder.

# Einfluss von Wärme und Berührung

Ich war überrascht, bei zwei Gelegenheiten zu finden, dasz die Wärme der Sonnenstrahlen, durch eine Linse auf die Basen mehrerer Filamente concentrirt, so dasz sie versengt und entfärbt wurden, keine Bewegung verursachte, trotzdem dasz die Blätter lebendig waren, da sie sich, wenngleich etwas langsam, schlossen, als ein Filament der anderen Seite berührt wurde. Bei einem dritten Versuche schlosz sich ein frisches Blatt nach einiger Zeit, obschon sehr langsam; die Geschwindigkeit nahm nicht zu, als eines der Filamente, welches nicht verletzt worden war, berührt wurde. Nach Verlauf eines Tages öffneten sich diese Blätter wieder und waren ganz ordentlich empfind- lich, als die nicht verletzten Filamente berührt wurden. Das plötzliche Eintauchen eines Blattes in kochendes Wasser bewirkt nicht, dasz es sich schlieszt. Nach der Analogie mit Drosera zu schlieszen, war in diesen verschiedenen Fällen die Hitze zu grosz und wurde zu plötzlich angewendet.

# Empfindlichkeit der Blattscheibe

Die Oberfläche der Blattscheibe ist sehr un- bedeutend empfindlich; man kann sie reichlich und derb berühren, ohne dasz irgend eine Bewegung verursacht würde. Ein Blatt wurde ziemlich derb mit einer Nadel gekratzt, schlosz sich aber nicht; als aber der dreieckige Raum zwischen den drei Filamenten auf einem andern Blatte in ähnlicher Weise gekratzt wurde, schlossen sich die Lappen. Sie schlossen sich immer, wenn die Scheibe oder die Mittel- rippe tief gestochen oder geschnitten wurde.

# Reaktion auf organische und anorganische Körper

Unorganische Körper, selbst von bedeutender Grösze, sowie Stückchen Stein, Glas u. s. w., — oder organische Körper, welche keine lösliche stickstoffhaltige Substanz enthalten, wie Stückchen Kork, Holz, Moos, — oder stickstoffhaltige Substanz enthaltende Körper in vollkommen trockenem Zustand, wie Stückchen Fleisch, Eiweisz, Gelatine u. s. w. können lange Zeit (und es wurden viele versucht) auf den Lappen gelassen werden, ohne dasz eine Bewegung erregt wird. Das Resultat ist in- dessen sehr verschieden, wie wir sofort sehen werden, wenn stickstoff- haltige organische Körper, wenn sie nur überhaupt etwas feucht sind, auf den Blattlappen liegen gelassen werden; denn dieselben schlieszen.# Bewegung und Empfindlichkeit der Blattlappen

Die obere Fläche der Blattlappen ist, wie bereits angegeben wurde, dicht mit kleinen, purpurnen, beinahe sitzenden Drüsen bedeckt. Diese haben sowohl die Fähigkeit der Absonderung als auch die der Absorption; aber verschieden von denen der Drosera sondern sie nicht eher ab als bis sie durch Absorption stickstoffhaltiger Substanz gereizt sind. Kein anderes Reizmittel bringt, so weit ich es beobachtet habe, diese Wirkung hervor. Es können Gegenstände, wie Stückchen Holz, Kork, Moos, Papier, Stein oder Glas lange Zeit auf der Oberfläche eines Blattes gelassen werden, und es bleibt ganz trocken. Es macht auch keinen Unterschied, ob sich die Lappen über solchen Gegenständen schlieszen.

# Reaktion auf stickstoffhaltige Substanzen

Es wurden beispielsweise kleine Kugeln von Löschpapier auf ein Blatt gelegt und ein Filament berührt; und als sich nach 24 Stunden die Lappen wieder zu öffnen anfiengen, wurden die Kugeln mit Hülfe dünner Pincetten entfernt und stellten sich als vollkommen trocken heraus. Wenn auf der andern Seite ein Stückchen feuchten Fleisches oder eine zerdrückte Fliege auf die Oberfläche eines ausgebreiteten Blattes gelegt wird, so sondern nach einiger Zeit die Drüsen reichlich ab. In einem derartigen Falle war ein wenig Secret direct unter dem Fleisch in 4 Stunden vorhanden; und nach Verlauf von weiteren 3 Stunden fand sich eine beträchtliche Quantität sowohl unter ihm als auch rings um dasselbe herum.

# Unterschiedliche Absonderung bei Berührung

In einem andern Falle war das Stückchen Fleisch nach 3 Stunden 40 Minuten ganz nasz. Aber keine Drüse sonderte ab, ausgenommen diejenigen, welche factisch das Fleisch oder das aufgelöste animale Substanz enthaltene Secret berührten. Wenn indessen die Blattlappen durch ein Stückchen Fleisch oder ein Insect zum Schlieszen gebracht werden, so ist das Resultat verschieden; denn nun sondern die Drüsen über die ganze Oberfläche des Blattes reichlich ab.

# Intensität der Absonderung

Da in diesem Falle die Drüsen auf beiden Seiten gegen das Fleisch oder das Insect angedrückt werden, so ist die Absonderung von Anfang an zweimal so bedeutend, als wenn ein bischen Fleisch auf die Oberfläche eines Lappens gelegt wird; und da die Lappen in beinahe ganz dichte Berührung kommen, so verbreitet sich die aufgelöste animale Substanz enthaltende Absonderung durch Capillarattraction und veranlasst frische Drüsen auf beiden Seiten in sich beständig erweiternden Kreisen zur Absonderung; das Secret ist beinahe farblos, leicht schleimig, und nach der Art und Weise, wie es Lackmuspapier färbte, zu urtheilen, stärker sauer als das der Drosera.

# Beobachtungen zur Sekretion

Es ist so reichlich, dasz bei einer Gelegenheit, wo ein Blatt aufgeschnitten wurde, auf welches vor 45 Stunden ein kleines Eiweiszwürfelchen gelegt worden war, Tropfen vom Blatt herunterrollten. Bei einer andern Gelegenheit, wo ein Blatt, welches ein Stückchen gerösteten Fleisches eingeschlossen hatte, sich nach acht Tagen von selbst wieder öffnete, war so viel Secret in der Furche über der Mittelrippe, dasz es herabtröpfelte. Eine grosze zerdrückte Fliege (Tipula) wurde auf ein Blatt gelegt, aus welchem ein kleines Stück an der Basis des einen Lappens vorher herausgeschnitten worden war, so dasz eine Öffnung blieb; und durch diese lief das Secret neun Tage lang fortwährend den Blattstiel hinab, — d. i. während der ganzen Zeit, so lange überhaupt das Blatt beobachtet wurde.

# Schlussfolgerung zur Empfindlichkeit

Dadurch, dasz ich den einen Lappen gewaltsam aufhob, konnte ich eine Strecke weit zwischen ihnen hinsehn; und alle Drüsen, die ich sehen konnte, sonderten reichlich ab. Wir haben gesehen, dasz unorganische und nicht stickstoffhaltige Körper auf die Blätter gelegt keine Bewegung anregen; aber stickstoffhaltige Körper, wenn sie nur im allergeringsten Grade feucht sind, bewirken, dasz sich die Lappen nach mehreren Stunden lang-# Kapitel 13: Sekretion und Absorption

So wurden Stückchen von vollständig trockenem Fleisch und Gelatine auf die entgegengesetzten Ende eines und desselben Blattes gelegt und regten in 24 Stunden weder Absonderung noch Bewegung an. Sie wurden dann in Wasser getaucht, ihre Oberfläche mit Löschpapier abgetrocknet, und sie dann auf dasselbe Blatt zurückgebracht, während die Pflanze nun mit einer Glasglocke bedeckt wurde. Nach 24 Stunden hatte das feuchte Fleisch etwas saure Absonderung erregt und die Lappen waren an diesem Ende des Blattes beinahe geschlossen. Am andern Ende, wo die feuchte Gelatine lag, war das Blatt noch immer vollständig offen, auch war keine Absonderung angeregt worden; so dass, wie wir es bei Drosera sahen, Gelatine eine nicht annähernd so stark reizende Substanz ist wie Fleisch. Das Secret unterhalb des Fleisches wurde so geprüft, dass ein Streifen Lackmuspapier unter dasselbe geschoben wurde (ohne dass die Filamente berührt wurden), und dieser unbedeutende Reiz bewirkte, dass sich das Blatt schloss. Am elften Tage öffnete es sich wieder; aber das Ende, wo die Gelatine lag, breitete sich mehrere Stunden früher als das andere Ende mit dem Fleische aus.

Ein zweites Stückchen gerösteten Fleisches, welches dem Anscheine nach trocken war, obschon es nicht absichtlich getrocknet worden war, wurde 24 Stunden lang auf einem Blatte gelassen und verursachte weder Bewegung noch Absonderung. Die Pflanze in ihrem Topfe wurde nun mit einer Glasglocke bedeckt und das Fleisch absorbierte etwas Feuchtigkeit aus der Luft; dies reichte hin, eine saure Absonderung anzuregen, und am nächsten Morgen war das Blatt dicht geschlossen. Ein drittes Stückchen Fleisch, welches so getrocknet worden war, dass es ganz spröde und zerbrechlich war, wurde auf ein Blatt unter einer Glasglocke gelegt; auch dies wurde in 24 Stunden leicht feucht und regte etwas saure Absonderung an, aber keine Bewegung.

Ein ziemlich großes Stück vollkommen trockenen Eiweißes wurde auf dem einen Ende eines Blattes 24 Stunden ohne irgendwelche Wirkung liegen gelassen. Es wurde dann wenige Minuten lang in Wasser eingeweicht, auf Löschpapier umhergerollt und auf das Blatt zurückgebracht; in 9 Stunden war etwas unbedeutend saure Absonderung angeregt, und in 24 Stunden war dies Ende des Blattes teilweise geschlossen. Das Stückchen Eiweiß, was nun von viel Secret umgeben war, wurde sanft entfernt, und obschon kein Filament berührt wurde, schlossen sich die Lappen. Aus diesem und dem vorhergehenden Falle scheint hervorzugehen, dass die Aufsaugung animaler Substanz durch die Drüsen die Oberfläche des Blattes viel empfindlicher für eine Berührung macht, als sie es in ihrem gewöhnlichen Zustande ist; und dies ist eine merkwürdige Tatsache. Zwei Tage darauf fing das Ende des Blattes, wo nichts hingelegt worden war, an sich wieder zu öffnen und war am dritten Tage viel weiter offen als das entgegengesetzte Ende, wo das Eiweiß gelegen hatte.

Endlich wurden große Tropfen einer Lösung von einem Teil kohlensauren Ammoniaks auf 146 Teile Wasser auf einige Blätter Dionaea muscipula gebracht; es erfolgte aber keine sofortige Bewegung. Ich wusste damals nicht, dass animale Substanz eine langsame Bewegung verursachte, sonst würde ich die Blätter eine längere Zeit hindurch beobachtet haben, und sie würden dann wahrscheinlich geschlossen gefunden worden sein, obschon die Lösung (nach Drosera zu urteilen) vielleicht zu stark war.

Nach den vorstehend angeführten Tatsachen ist es sicher, dass Stückchen von Fleisch und Eiweiß, wenn sie nur im allergeringsten feucht sind, nicht nur die Drüsen zu sekretionieren veranlassen, sondern auch die Lappen zu schließen. Diese Bewegung ist von dem rapiden, durch die Berührung eines der Filamente verursachten Schließen sehr verschieden. Wir werden ihre Bedeutung erkennen, wenn wir von der Art und Weise handeln werden, wie Insekten gefangen werden. Es besteht ein großer Kontrast zwischen Drosera und Dionaea in# Mechanische Reizung und Absorption

den, einerseits durch mechanische Reizung, andererseits durch die Absorption animaler Substanz hervorgebrachten Wirkungen. Stückchen Glas, welche auf die Drüsen der äuszeren Tentakeln der Drosera gelegt werden, erregen Bewegung innerhalb nahezu derselben Zeit, wie es Stückchen Fleisch thun, und die letzteren sind ziemlich die wirksamsten Körper; wenn aber den Drüsen der Scheibe Stückchen Fleisch gegeben worden sind, so übermitteln sie den äuszern Tentakeln einen motorischen Impuls viel schneller, als es dieselben Drüsen thun, wenn sie anorganische Theilchen tragen, oder wenn sie durch wiederholte Berührungen gereizt worden sind. Auf der andern Seite erregt bei Dionaea eine Berührung der Filamente eine unvergleichlich schnellere Bewegung als Absorption animaler Substanz durch die Drüsen. Trotzdem ist in gewissen Fällen dieses letztere Reizmittel das wirksamere von den beiden. Bei drei Gelegenheiten wurden Blätter gefunden, welche aus irgend welcher Ursache torpid waren, so dasz sich ihre Lappen nur unbedeutend schloszen, wie sehr auch ihre Filamente gereizt werden mochten; als aber zerdrückte Insecten zwischen die Lappen gebracht wurden, wurden sie in einem Tage dicht geschlossen.

# Fähigkeit der Absorption

Die soeben mitgeteilten Thatsachen zeigen deutlich, dasz die Drüsen die Fähigkeit der Absorption besitzen; denn im andern Falle wäre es unmöglich, dasz die Blätter von nichtstickstoffhaltigen und von stickstoffhaltigen Körpern, und von den letzteren in einem feuchten und einem trockenen Zustande so verschieden afficirt werden sollten. Es ist überraschend, in wie unbedeutendem Grade ein Stückchen Fleisch oder Eiweisz feucht zu sein braucht, um Absonderung und später langsame Bewegung anzuregen, und in gleicher Weise überraschend ist es, eine wie minutiös kleine Menge animaler Substanz, wenn sie absorbirt wird, hinreicht, diese beiden Wirkungen hervorzubringen. Es erscheint kaum glaublich und ist doch sicherlich eine Thatsache, dasz ein Stückchen hart gekochten Eiereiweiszes, erst vollständig getrocknet und dann für ein paar Minuten in Wasser gelegt und auf Löschpapier herumgerollt, in wenigen Stunden genug animale Substanz an die Drüsen abgeben kann, um sie zum Abson- dern und später die Lappen zum Schlieszen zu veranlassen. Dasz die Drüsen die Fähigkeit der Absorption haben, zeigt sich gleichfalls in der sehr verschiedenen Länge Zeit (wie wir sofort sehen werden), während welcher die Lappen über Insecten und andern lösliche stickstoffhaltige Substanz darbietenden Körpern und über solchen, welche keine solche Substanz abgeben, geschlossen bleiben. Es liegt aber ein directer Beweis für die Absorption in dem Zustand der Drüsen, welche einige Zeit lang mit animaler Substanz in Berührung geblieben sind. So wurden Stückchen Fleisch und zerdrückte Insecten mehrere Male auf Drüsen gelegt und diese nach Verlauf einiger Stunden mit andern Drüsen von entfernten Stellen des Blattes verglichen. Die letzteren zeigten nicht eine Spur von Zusammenballung, während diejenigen, welche mit der animalen Substanz in Berührung gewesen waren, gut zusammengeballt waren.

# Zusammenballung und Reaktion

Man kann sehen, wie Zusammen- ballung sehr schnell eintritt, wenn ein Stückchen eines Blattes in eine schwache Lösung von kohlensaurem Ammoniak eingetaucht wird. Ferner wurden kleine Würfelchen von Eiweisz und Gelatine acht Tage lang auf einem Blatte gelassen, welches dann aufgeschnitten wurde. Die ganze Oberfläche war mit saurem Secrete benetzt, und eine jede Zelle in den vielen Drüsen, welche untersucht wurden, bot eine Zusammenballung des Inhalts dar, und zwar zeigten sich in einer wunderschönen Art dunkel oder blasz purpurne oder farblose kuglige Massen von Protoplasma. Diese erlitten unaufhörliche lang- same Formveränderungen, zuweilen trennten sie sich von einander und vereinigten sich dann wieder, genau so wie in den Zellen der Dro- sera. Kochendes Wasser macht den Inhalt der Drüsenzellen weisz und opak, aber nicht so rein weisz und porzellanartig, wie es bei Drosera der Fall ist. Wie lebende Insecten, wenn sie auf natür- Dionaea muscipula.# Verdauung und Drüsen

Ehe ich auf die Frage von der Verdauung übergehe, will ich anführen, dasz ich, aber ohne Erfolg, die Verrichtungen der kleinen achttheiligen Fortsätze, mit denen die Blätter übersäet sind, zu entdecken versuchte. Nach später in den Capiteln über Aldrovanda und Utricularia mitzutheilenden Thatsachen schien es wahrscheinlich zu sein, dasz sie dazu dienten, zerfallene von den gefangenen Insecten übrig bleibende Substanz zu absorbiren; aber ihre Stellung auf der Rückseite der Blätter und auf den Stielen machte dies beinahe unmöglich. Trotzdem wurden Blätter in eine Lösung von einem Theil Harnstoff auf 437 Theile Wasser eingelegt, und nach 24 Stunden erschien die orangerothe Schicht Protoplasma in den Armen dieser Fortsätze nicht mehr zusammengeballt als in andern, in Wasser gehaltenen Exemplaren. Ich machte dann den Versuch und hieng ein Blatt in einer Flasche über einem excessiv faul riechenden Aufgusz von rohem Fleisch auf, um zu sehen, ob diese Fortsätze den Dampf absorbirten; ihr Zelleninhalt wurde aber nicht afficirt.

# Verdauungskraft des Secrets

Dr. W. M. Canby von Wilmington, dem ich für Information in Bezug auf Dionaea in ihrem Heimathlande sehr verbunden bin, hat in „The Gardener’s Monthly‟, Philadelphia, August, 1868, einige interessante Beobachtungen veröffentlicht. Er ermittelte, dasz das Secret animale Substanz, wie den Inhalt der Insectenkörper, Stücken Fleisch u. s. w., verdaut und dasz die Absonderung wieder aufgesaugt wird. Er wuszte auch ganz gut, dasz die Lappen eine viel längere Zeit geschlossen bleiben, wenn sie mit animaler Substanz in Berührung waren, als wenn sie durch eine blosze Berührung zum Schlieszen gebracht wurden, oder über Gegenständen, die keine lösliche Nährsubstanz darbieten, ebenso, dasz in diesem letztern Falle die Drüsen nicht absondern. Dr. Curtis beobachtete zuerst die Absonderung aus den Drüsen (Boston Journal Nat. Hist. Vol. I. p. 123). Ich will hier nur noch hinzufügen, dasz, wie man sagt, ein Gärtner, W. Knight, gefunden haben soll (Kirby and Spence’s Introduction to Entomology, 1818, Vol. I. p. 295), dasz ein Exemplar der Dionaea, „auf deren Blätter er Fäden rohen Rindfleisches gelegt habe, in seinem Wachsthum viel üppiger gewesen sei, als andere nicht so behandelte.‟.

# Verdauungsprozess

Wenn sich ein Blatt über irgend einen Gegenstand schlieszt, so kann man sagen, dasz es sich zu einem zeitweiligen Magen umbilde; und wenn der Gegenstand auch noch so wenig animale Substanz abgibt, so dient dieselbe, um Schiff’s Ausdruck zu brauchen, als Peptogen, und die Drüsen an der Oberfläche ergieszen ihr saures Secret, welches wie der Magensaft der Thiere wirkt. Da so viele Versuche über die verdauende Kraft der Drosera angestellt worden waren, wurden nur einige wenige mit Dionaea gemacht: sie waren aber reichlich genügend, zu beweisen, dasz sie verdaut. Überdies ist diese Pflanze nicht so für Beobachtungen eingerichtet, wie Drosera, da der Procesz innerhalb der geschlossenen Lappen vor sich geht. Wenn Insecten, selbst Käfer, mehrere Tage lang der Einwirkung des Secrets ausgesetzt waren, sind sie in überraschender Weise erweicht, obschon ihre chitinhaltigen Hüllen nicht corrodirt sind.

# Versuch

Ein Eiweiszwürfel von ⅒ Zoll (2,54 Mm.) Seitenlänge wurde auf das eine Ende eines Blattes gelegt, auf das andere ein längliches Stückchen Gelatine ⅕ Zoll (5,08 Mm.) lang und ⅒ Zoll breit; dann wurde das Blatt zum Schlieszen gebracht. Nach 45 Stunden wurde es aufgeschnitten. Das Eiweisz war hart und zusammengedrückt, die Kanten nur ein wenig abgerundet; das Gelatinestückchen war zu einer ovalen Form corrodirt; beide waren in einer solchen Menge sauren Secrets eingetaucht, dasz es vom Blatt herabtropfte. Der Verdauungsprocesz ist# Experimente mit Eiweiß und Gelatine

## Versuch 1
allem Anscheine nach etwas langsamer als bei Drosera, und dies stimmt mit der Länge der Zeit überein, während welcher die Blätter über verdaulichen Gegenständen geschlossen bleiben.

## Versuch 2
Ein Stückchen Eiweisz von              ⅒     Zoll im Geviert, aber nur \frac {1}{20} Zoll dick, und ein Stückchen Gelatine von derselben Grösze wurden auf ein Blatt gelegt, welches acht Tage später aufgeschnitten wurde. Die Oberfläche war ganz benetzt mit einem unbedeutend klebri- gen, sehr sauren Secrete, und die Drüsen fanden sich sämmtlich in zusammengeballtem Zustande. Nicht eine Spur Eiweisz oder Gelatine war übrig geblieben. Ähnlich grosze Stücke waren zu gleicher Zeit auf feuchtes Moos in demselben Topfe gelegt worden, so dasz sie annähernd ähnlichen Bedingungen ausgesetzt waren; nach acht Tagen waren dieselben braun, im Zerfall begriffen und von Moderfasern bedeckt, waren aber nicht verschwunden.

## Versuch 3
Ein Stückchen Eiweisz, \frac {3}{20} Zoli (3,81 Mm.) lang und \frac {1}{20} Zoll breit und dick, und ein Stückchen Gelatine von derselben Grösse wie vorhin, wurden auf ein anderes Blatt gelegt, welches nach sieben Tagen aufgeschnitten wurde; nicht eine Spur von einer der beiden Substanzen war übrig geblieben, und nur eine mäszige Menge von Secret fand sich auf der Oberfläche.

## Versuch 4
Stücke von Eiweisz und Gelatine von derselben Grösze wie im letzten Experiment wurden auf ein Blatt gelegt, welches sich nach zwölf Tagen von freien Stücken öffnete; und hier wiederum war nicht eine Spur von beiden übrig, und nur ein wenig Secret fand sich an dem einen Ende der Mittelrippe.

## Versuch 5
Stückchen von Eiweisz und Gelatine von derselben Grösze wurden auf ein anderes Blatt gelegt, welches nach zwölf Tagen noch immer fest geschlossen war, aber angefangen hatte zu welken; es wurde aufgeschnitten und enthielt nichts, ausgenommen eine Spur brauner Masse da, wo das Eiweisz gelegen hatte.

## Versuch 6
Ein Eiweiszwürfel von             ⅒    Zoll und ein Stückchen Gelatine von derselben Grösze wie vorhin wurden auf ein Blatt gelegt, welches sich nach dreizehn Tagen von selbst wieder öffnete. Das Eiweisz, welches zweimal so dick wie in den letzten Experimenten gewesen war, war zu grosz; denn die Drüsen, welche mit ihnen in Berührung waren, waren verletzt und fielen ab; es war auch ein Eiweiszhäutchen von brauner Farbe, mit Moder überzogen, übrig geblieben. Das ganze Gelatine war absorbirt und es fand sich nur ein wenig sauren Secrets auf der Mittelrippe.

## Versuch 7
Ein Stückchen halbgerösteten Fleisches (nicht gemessen) und ein Stückchen Gelatine wurden auf die beiden Enden eines Blattes gelegt, welches sich nach elf Tagen von selbst wieder öffnete; eine Spur von dem Fleische war noch übrig gelassen, und an dieser Stelle war die Oberfläche des Blattes geschwärzt; das Gelatine war ganz verschwunden.

## Versuch 8
Ein Stückchen halbgerösteten Fleisches (nicht gemessen) wurde auf ein Blatt gelegt, welches durch einen Klemmer gewaltsam offen gehalten wurde, so dasz es nur an seiner untern Fläche vom Secret (sehr sauer) befeuchtet war. Nichtsdestoweniger war es nach nur 22½ Stunden in überraschendem Grade erweicht, wenn es mit einem an- dern Stückchen desselben Fleisches verglichen wurde, welches feucht ge- halten worden war.

## Versuch 9
Ein Würfel von           ⅒    Zoll sehr festen gerösteten Rindfleisches wurde auf ein Blatt gelegt, welches sich nach zwölf Tagen freiwillig wieder öffnete; es war so viel schwach saure Absonderung auf dem Blatte geblieben, dasz sie abtröpfelte. Das Fleisch war vollständig zersetzt, aber nicht ganz aufgelöst; es war kein Moder vorhanden. Die kleine Masse wurde unter das Mikroskop gebracht; einige der Muskel- fasern in der Mitte boten noch immer Querstreifen dar, andere zeigten nicht eine Spur von Streifen; und zwischen diesen beiden Zuständen konnte man jede mögliche Abstufung verfolgen.# Verdauungsexperimente

scheine nach Fett, und etwas unverdautes elastisches Fasergewebe blieb zurück. Das Fleisch fand sich daher in demselben Zustande, wie das früher beschriebene, welches von der Drosera halb verdaut war. Hier wiederum, wie in dem Fall mit dem Eiweisz, scheint der Verdauungsprocesz langsamer zu sein als bei Drosera. Auf das entgegengesetzte Ende desselben Blattes war ein fest zusammengedrücktes Brodkügelchen gelegt worden; dies war vollständig zerfallen, wie ich glaube, in Folge der Verdauung des Leimes, schien aber an Umfang nur sehr wenig abgenommen zu haben.

## Versuch 10

Ein Würfel von \frac {1}{20} Zoll von Käse und ein anderer von Eiweisz wurden auf die gegenüberliegenden Enden eines und desselben Blattes gelegt. Nach neun Tagen öffneten sich die Lappen von freien Stücken ein wenig an dem Ende, welches den Käse umschlossen hatte; es war aber kaum irgend etwas davon oder gar nichts aufgelöst, obgleich er erweicht und von Secret umgeben war. Zwei Tage später öffnete sich auch das Ende mit dem Eiweisz von selbst (d. i. also elf Tage, nachdem es darauf gelegt worden war); es war eine blosze Spur davon in einem geschwärzten und trockenen Zustande übrig geblieben.

## Versuch 11

Dasselbe Experiment mit dem Käse und dem Eiweisz wurde an einem andern und etwas torpiden Blatt wiederholt. Nach Verlauf von sechs Tagen öffneten sich die Blattlappen an dem Ende, wo der Käse lag, von selbst ein wenig; das Käsewürfelchen war bedeutend erweicht, aber nicht aufgelöst, und nur wenig, wenn überhaupt, an Grösze reducirt. Zwölf Stunden später öffnete sich das Ende mit dem Eiweisz, welches jetzt aus einem groszen Tropfen durchscheinender, nicht saurer, klebriger Flüssigkeit bestand.

## Versuch 12

Ein gleicher Versuch wie die beiden letzten; hier wiederum öffnete sich das Blatt an dem Ende, wo der Käse lag, vor dem andern mit dem Eiweisz; es wurden aber keine weiteren Beobachtungen gemacht.

## Versuch 13

Ein Kügelchen von chemisch dargestelltem Casëin, ungefähr ⅒ Zoll im Durchmesser, wurde auf ein Blatt gelegt, welches sich nach acht Tagen freiwillig wieder öffnete. Das Casëin bestand nun aus einer weichen klebrigen Masse, hatte in der Grösze nur sehr wenig, wenn überhaupt, abgenommen, war aber ganz von saurem Secrete umflossen. Diese Versuche genügen um zu zeigen, dasz das Secret aus den Drüsen der Dionaea Eiweisz, Gelatine und Fleisch auflöst, wenn keine zu grosze Stücke den Blättern gegeben werden. Fettkügelchen und elastisches Fasergewebe werden nicht verdaut. Das Secret mit der von ihm absorbirten Substanz wird später, wenn es nicht in Über-
schusz auftritt, wieder aufgesaugt. Obgleich aber andererseits chemisch präparirtes Casëin und Käse (wie es bei Drosera der Fall war) viel saure Absonderung anregen, wie ich vermuthe, in Folge der Absorp-
tion von etwas eingeschlossener albuminöser Substanz, so werden doch diese Substanzen nicht verdaut, und nicht wahrnehmbar, wenn über-
haupt, an Umfang reducirt.

# Wirkungen der Dämpfe

Wirkungen der Dämpfe von Chloroform, Schwefel-Äther und Blausäure. — Eine Pflanze, welche ein Blatt trug, wurde mit einer Drachme (3,549 Cub. Cent.) Chloroform in eine grosze Flasche gebracht, deren Öffnung nur unvollkommen mit Baumwolle geschlossen wurde. Der Dampf bewirkte, dasz sich in 1 Minute die Lappen mit einer nicht wahrnehmbar langsamen Geschwindigkeit zu bewegen begannen; aber in 3 Minuten kreuzten sich die Randspitzen, und bald war das Blatt vollkommen geschlossen. Die Dosis war indessen viel zu stark; denn nach 2 bis 3 Stunden erschien das Blatt wie verbrannt und starb bald ab.

## Dionaea muscipula

Zwei Blätter wurden 30 Minuten lang in einem Zwei-Unzengefäsz dem Dampfe von 30 Minims (1,774 Cub. Cent.) von Schwefel-Äther ausgesetzt. Ein Blatt schlosz sich nach einiger Zeit, ebenso das andere, während es, ohne berührt zu werden, aus der Flasche entfernt wurde.# Beschädigte Blätter und ihre Empfindlichkeit

Beide Blätter waren bedeutend beschädigt. Ein anderes Blatt, welches 20 Minuten lang 15 Minims Äther ausgesetzt wurde, schlosz seine Lappen bis zu einem gewissen Grade, und die empfindlichen Filamente waren nun völlig empfindungslos. Nach 24 Stunden erhielt dies Blatt seine Empfindlichkeit wieder, war aber noch immer etwas torpid. Ein Blatt, welches in einer groszen Flasche nur 3 Minuten lang zehn Tropfen ausgesetzt war, wurde unempfindlich gemacht. Nach 52 Minuten erhielt es seine Empfindlichkeit wieder, und als eines der Filamente berührt wurde, schlossen sich die Lappen. Nach 20 Stunden fieng es an, sich wieder zu öffnen. Zuletzt wurde noch ein anderes Blatt 4 Minuten lang nur vier Tropfen Äther ausgesetzt; es wurde unempfindlich gemacht und schlosz sich nicht, als seine Filamente wiederholt berührt wurden, schlosz sich aber, als das Ende des offenen Blattes abgeschnitten wurde. Dies beweist, entweder dasz die inneren Theile nicht unempfindlich gemacht worden waren, oder dasz ein Einschnitt ein kräftigerer Reiz ist als wiederholte Berührungen der Filamente. Ob die gröszeren Dosen von Chloroform und Äther, welche die Blätter sich langsam zu schlieszen veranlassten, auf die empfindlichen Filamente oder auf das Blatt selbst einwirkten, weisz ich nicht.

# Wirkung von Cyankali auf Blätter

Cyankali erzeugt, wenn es in einer Flasche gelassen wird, Cyanwasserstoff- oder Blausäure. Ein Blatt wurde 1 Stunde 35 Minuten lang dem dabei gebildeten Dampfe ausgesetzt; die Drüsen wurden in dieser Zeit so farblos und zusammengeschrumpft, dasz sie kaum sichtbar waren und ich zuerst glaubte, sie wären sämmtlich abgefallen. Das Blatt war nicht unempfindlich gemacht worden; denn sobald eines der Filamente berührt wurde, schlosz es sich. Es hatte indessen gelitten, denn es öffnete sich nicht eher wieder, als bis beinahe zwei Tage vergangen waren, und war selbst dann nicht im mindesten empfindlich. Nach Verlauf eines weiteren Tages erhielt es seine Fähigkeiten wieder und schlosz sich, wenn es berührt wurde, und öffnete sich später wieder. Ein anderes Blatt verhielt sich, nachdem es diesem Dampfe eine noch kürzere Zeit ausgesetzt war, in nahezu derselben Art und Weise.

# Verhalten der Blätter bei Insektenkontakt

Über die Art und Weise, in welcher Insecten gefangen werden. — Wir wollen nun das Benehmen der Blätter betrachten, wenn Insecten zufällig eines der empfindlichen Filamente berühren. Dies kam in meinem Gewächshause häufig vor, ich weisz aber nicht, ob die Insecten auf irgend eine besondere Art von den Blättern angezogen werden. In dem Heimathslande der Pflanze werden Insecten in groszer Anzahl von ihr gefangen. Sobald ein Filament berührt wird, schlieszen sich beide Lappen mit staunenerregender Schnelligkeit; und da sie in einem kleineren Winkel als in einem rechten zu einander stehen, so ist die Wahrscheinlichkeit, dasz sie einen Eindringling fangen, nicht gering. Der Winkel zwischen der Blattscheibe und dem Blattstiel ändert sich nicht, wenn sich die Lappen schlieszen. Der hauptsächliche Sitz der Bewegung ist in der Nähe der Mittelrippe, sie ist aber nicht auf diesen Theil beschränkt; denn wenn die beiden Lappen zusammenkommen, krümmt sich ein jeder quer über seine ganze Breite einwärts; die randständigen Speichen werden indesz nicht gekrümmt. Diese Bewegung des ganzen Lappens war an einem Blatte gut zu sehen, dem eine grosze Fliege gegeben worden war, und aus welchem am Ende des einen Lappens ein groszes Stück herausgeschnitten worden war, so dasz der Lappen der andern Seite, der an dieser Stelle auf keinen Widerstand stiesz, fortfuhr, sich weit über die Mittellinie nach innen zu krümmen. Später wurde noch der ganze Lappen, aus dem ein Stück herausgeschnitten worden war, entfernt, und nun rollte sich der gegenüberstehende Lappen vollständig über, indem er sich durch einen Winkel von 120 bis 130° bewegte, so dasz er beinahe unter rechtem Winkel zu der Stellung war, welche er eingenommen haben würde, wenn der andere Lappen noch vorhanden gewesen wäre.

# Einwärtskrümmung der Lappen

In Folge der Einwärtskrümmung der beiden Lappen, bei ihrer Bewegung auf einander zu, kreuzen sich die geraden randständigen Spitzen zuerst mit ihren freien Enden und schlieszlich mit ihren.# Die Schließmechanismen der Dionaea muscipula

Basen. Das Blatt ist dann vollständig geschlossen und umfaszt eine seichte Höhlung. Wenn es dadurch zum Schlieszen gebracht worden ist, dasz einfach eins der empfindlichen Filamente berührt worden ist, oder wenn es einen Gegenstand einschlieszt, welcher keine lösliche stickstoffhaltige Substanz abgibt, so behalten die beiden Lappen ihre nach innen concave Form, bis sie sich wieder ausbreiten. Die Wieder-ausbreitung unter solchen Umständen, — d. h. wenn keine organische Substanz eingeschlossen war, — wurde in zehn Fällen beobachtet. In diesen allen breiteten sich die Blätter bis auf ungefähr zwei Drittel ihrer völligen Öffnung in 24 Stunden von der Zeit der Schlieszung an gerechnet wieder aus. Selbst das Blatt, aus dessen einem Lappen ein Stück herausgeschnitten worden war, öffnete sich innerhalb der nämlichen Zeit in einem unbedeutenden Grade. In einem Falle brei-tete sich ein Blatt bis auf ungefähr zwei Drittel der vollständigen Öffnung in 7 Stunden, und vollständig in 32 Stunden wieder aus; doch war nur eines seiner Filamente einfach mit einem Haar eben hinreichend berührt worden, das Blatt zum Schlieszen zu veranlassen. Von diesen zehn Blättern breiteten sich nur ein paar vollständig in weniger als zwei Tagen wieder aus, und zwei oder drei gebrauchten selbst noch ein wenig längere Zeit. Ehe sie sich indessen völlig wieder ausbreiteten, sind sie bereit, sich augenblicklich zu schlieszen, wenn ihre empfindlichen Filamente berührt werden. Wie viele male ein Blatt fähig ist sich zu schlieszen und wieder zu öffnen, wenn keine animale Substanz eingeschlossen bleibt, weisz ich nicht; ein Blatt wurde aber viermal zum Schlieszen gebracht und öffnete sich später innerhalb sechs Tagen. Bei der letzten Gelegenheit fieng es eine Fliege und blieb dann viele Tage lang geschlossen.

# Die Bedeutung der schnellen Wiederöffnung

Diese Fähigkeit, sich schnell wieder zu öffnen, wenn die Filamente zufällig durch Grashalme oder vom Winde auf das Blatt ge-wehte fremde Körper berührt worden waren, wie es doch gelegentlich im Heimathlande der Pflanze vorkommt, musz für die Pflanze von einiger Bedeutung sein; denn so lange ein Blatt geschlossen bleibt, kann es natürlich kein Insect fangen. Wenn die Filamente gereizt werden und ein Blatt wird dazu gebracht, sich über ein Insect zu schlieszen, oder über ein Stückchen Fleisch, Eiweisz, Gelatine, Casëin oder zweifelsohne über irgend einen andern, lösliche stickstoffhaltige Substanz enthaltenden Körper, drücken die Lappen, anstatt concav zu bleiben, und dabei eine Concavität ein-zuschlieszen, langsam ihrer ganzen Breite nach gegen einander. Wenn dies stattfindet, werden die Ränder allmählich ein wenig nach auszen gekehrt, so dasz die Speichen, welche sich zuerst kreuzten, zuletzt in zwei parallelen Reihen vorspringen. Die Lappen drücken sich mit solcher Gewalt gegen einander, dasz ich gesehen habe, wie ein Eiweisz-würfel bedeutend abgeplattet wurde und deutliche Eindrücke der kleinen vorspringenden Drüsen erhielt; der letztere Umstand dürfte aber wohl theilweise durch die anätzende Wirkung des Secrets verursacht worden sein. Die Lappen werden so fest zusammengepreszt, dasz, wenn ein groszes Insect oder ein anderer gröszerer Gegenstand ge-fangen ist, eine entsprechende Hervorragung auf der Auszenseite des Blattes deutlich sichtbar wird. Wenn die beiden Lappen in dieser Weise vollständig geschlossen sind, so widerstehn sie einem künst-lichen Öffnen, wie z. B. durch einen dünnen zwischen sie hinein-getriebenen Keil, mit erstaunlicher Kraft, und werden meist eher durchbrochen, als dasz sie nachgäben. Werden sie nicht gebrochen, so schlieszen sie sich, wie mir Dr. Canby in einem Briefe mittheilt, „mit einem förmlichen lauten Schlage.‟ Wenn aber das Ende eines Blattes fest zwischen Daumen und Zeigefinger oder von einem Klemmer gehalten wird, so dasz die Lappen nicht anfangen können sich zu schlieszen, so äuszern sie, während sie sich in dieser Lage befinden, sehr wenig Kraft.# Einleitung
Ich glaubte zuerst, dasz das allmähliche Gegeneinanderdrücken der Lappen ausschlieszlich durch gefangene Insecten verursacht würde, welche über die empfindlichen Filamente wegkröchen und sie wiederholt reizten; diese Ansicht schien mir um so wahrscheinlicher zu sein, als ich von Dr. Burdon Sanderson hörte, dasz, sobald die Filamente eines geschlossenen Blattes gereizt würden, der normale elektrische Strom gestört würde.

# Reizung und Absorption
Es ist aber trotzdem eine solche Reizung durchaus nicht nothwendig, denn ein todtes Insect, oder ein Stückchen Fleisch oder Eiweisz, alles wirkt gleichmäszig gut; es wird dadurch bewiesen, dasz es in diesen Fällen die Absorption von animaler Substanz ist, welche die Lappen reizt, sich langsam gegen einander zu drücken.

# Funktionelle Bedeutung
Wir haben gesehen, dasz die Absorption einer äuszerst geringen Quantität solcher Substanz es auch bewirkt, dasz sich ein vollständig ausgebreitetes Blatt langsam schlieszt; und diese Bewegung ist dem langsamen Gegeneinanderdrücken der concaven Lappen offenbar analog. Diese letztere Thätigkeit ist für die Pflanze von hoher functioneller Bedeutung, denn es werden dadurch die Drüsen auf beiden Seiten mit einem gefangenen Insect in Berührung gebracht, und in Folge dessen sondern sie ab.

# Sekretion und Kapillarattraktion
Das Secret, welches nun animale Substanz gelöst enthält, wird dann durch Capillar-attraction über die ganze Fläche des Blattes gezogen, veranlaszt alle Drüsen abzusondern und läszt sie die diffundirte animale Substanz aufsaugen.

# Unterschiedliche Reaktionen
Es besteht noch ein anderer groszer Unterschied in der Thätig-keit der Blätter, welche solche Gegenstände wie Stückchen Holz, Kork, Papierkügelchen, einschlieszen, oder deren Filamente einfach berührt worden waren, und derjenigen, welche organische, lösliche stickstoff-haltige Substanz darbietende Körper einschlieszen.

# Schließverhalten der Blätter
Im erstern Falle öffnen sich die Blätter, wie wir gesehen haben, in weniger als 24 Stunden wieder und sind dann bereit, selbst noch ehe sie sich vollständig ausgebreitet haben, sich wieder zu schlieszen.

# Langsame Öffnung nach der Schließung
Haben sie sich aber über stickstoffabgebenden Körpern geschlossen, so bleiben sie viele Tage lang dicht geschlossen; nachdem sie sich dann wieder ausgebreitet haben, sind sie torpid, werden nie wieder thätig oder erst nach Verlauf einer beträchtlichen Zeit.

# Beispiele für Schließverhalten
In vier Fällen öffneten sich Blätter, nachdem sie Insecten gefangen hatten, niemals wieder, sondern fiengen an zu welken, dabei immer geschlossen bleibend — in einem Falle fünfzehn Tage lang über einer Fliege, in einem zweiten vierundzwanzig Tage lang, trotzdem die Fliege klein war, in einem dritten vierundzwanzig Tage lang über einer Holzlaus, und in einem vierten fünfunddreiszig Tage lang über einer groszen Tipula.

# Einfluss kleiner Insekten
In zwei andern Fällen blieben Blätter mindestens neun Tage über Fliegen geschlossen, und wie viel länger noch, weisz ich nicht. Es musz in-zwischen doch hinzugefügt werden, dasz in zwei Fällen, wo auf natür-liche Weise sehr kleine Insecten gefangen worden waren, das Blatt sich so schnell wieder öffnete, als wenn nichts gefangen worden wäre; ich vermuthe, dies war die Folge davon, dasz derartig kleine Insecten nicht zerdrückt worden waren, oder keine animale Substanz excernirt hatten, so dasz die Drüsen nicht gereizt wurden.

# Experimente mit Eiweiß und Gelatine
Kleine eckige Stückchen Eiweisz und Gelatine wurden auf die beiden Enden dreier Blätter gelegt, von denen zwei dreizehn und das dritte zwölf Tage lang geschlossen blieben. Zwei andere Blätter blieben über Stückchen Fleisch elf Tage lang, ein drittes Blatt acht Tage lang, und ein viertes (dies war indessen geknickt und beschädigt worden) nur sechs Tage lang geschlossen.

# Weitere Experimente
Stückchen Käse, oder Casëin, wurden auf das eine Ende, und Eiweisz auf das andere Ende von drei Blättern.# Insektenfänge und Verdauung

gelegt; die Enden mit den ersteren Substanzen öffneten sich nach sechs, acht und neun Tagen, während die anderen Enden sich etwas später öffneten. Keines der obigen Stückchen Fleisch, Eiweisz u. s. w. war gröszer als ein Würfel von ⅒ Zoll (2,54 Mm.) Seitenlänge; zuweilen waren sie kleiner; und doch reichten diese kleinen Portionen hin, die Cap. 13. Art Insecten zu fangen. Blätter viele Tage lang geschlossen zu halten. Dr. Canby theilt mir mit, dasz Blätter längere Zeit über Insecten geschlossen bleiben als über Fleisch; und nach dem, was ich gesehen habe, kann ich wohl glauben, dasz dies der Fall ist, besonders wenn die Insecten grosz sind.

# Beobachtungen zur Torpidity

In allen den oben angeführten Fällen und in vielen anderen, in denen Blätter eine lange aber unbekannte Zeit über natürlich gefangenen Insecten geschlossen blieben, waren sie, wenn sie sich wieder geöffnet hatten, mehr oder weniger torpid. Meistens waren sie während vieler folgender Tage so torpid, dasz keinerlei Reizung der Filamente die geringste Bewegung bewirkte. In einem Falle indessen schlosz sich ein Blatt mit äusserster Langsamkeit, als eines seiner Filamente berührt wurde, an dem Tage, nachdem es sich wieder geöffnet hatte; es hatte vorher eine Fliege umfaszt; und obgleich dies- mal kein Gegenstand eingeschlossen wurde, so war es doch so torpid, dasz es sich das zweite mal nicht vor Verlauf von 44 Stunden wie- der öffnete.

# Verdauungsfähigkeit der Pflanzen

In einem zweiten Falle bewegte ein Blatt, welches sich ausgebreitet hatte, nachdem es mindestens neun Tage über einer Fliege geschlossen geblieben war, als es stark gereizt wurde, nur einen seiner beiden Lappen und behielt diese ungewöhnliche Stellung die nächsten zwei Tage hindurch bei. Ein dritter Fall bietet die stärkste Ausnahme dar, welche ich beobachtet habe: nachdem ein Blatt eine unbekannte Zeit hindurch über einer Fliege geschlossen geblieben war, öffnete es sich, und als eines seiner Filamente berührt wurde, schlosz es sich wieder, wenn schon ziemlich langsam. Dr. Canby, welcher in den Vereinigten Staaten eine grosze Anzahl von Pflanzen beobachtet hat, welche, obgleich nicht an ihrem eingeborenen Standorte, doch wahrscheinlich kräftiger waren, als meine Pflanzen, theilt mir mit, „dasz er mehrere male erfahren habe, wie kräftige „Pflanzen ihre Beute mehreremale verschlungen hätten; gewöhnlich „war zweimal, oder sehr häufig, einmal schon hinreichend, sie untaug- lich zu machen.‟ Auch Mrs. Treat, welche in New-Jersey viele Pflanzen cultivirte, theilt mir mit, dasz „mehrere Blätter hinterein- ander jedes drei Fliegen fiengen, dasz aber die meisten von ihnen „nicht im Stande waren, die dritte Fliege zu verdauen, sondern über „dem Versuch abstarben. Fünf Blätter jedoch verdauten jedes drei Fliegen und schlossen sich über der vierten, starben aber bald nach dem vierten Fange. Viele Blätter verdauten nicht einmal ein einziges grosses Insect.‟ Es scheint hiernach, als sei das Verdauungsver- mögen etwas beschränkt; und sicher ist es, dasz Blätter über einem Insect immer viele Tage lang eingeschlagen bleiben und ihre Fähigkeit, sich von neuem zu schlieszen, nicht vor Ablauf vieler folgender Tage wieder erhalten.

# Funktion der randständigen Spitzen

In dieser Beziehung weicht Dionaea von Drosera ab, welche viele Insecten nach kürzeren Zeitintervallen fängt und verdaut. Wir sind nun vorbereitet, den Nutzen der randständigen Spitzen zu verstehen, welche einen so auffallenden Zug in der äuszeren Erscheinung der Pflanzen bilden (s. Fig. 12, p. 260) und welche mir in meiner Unkenntnis auf den ersten Blick nutzlose Anhänge zu sein schienen. In Folge der Einwärtskrümmung der sich einander nähern- den Lappen kreuzen sich zuerst die Spitzen der randständigen Speichen und schlieszlich auch ihre Basen. Bis die Ränder der Lappen in Berührung kommen, bleiben längliche Räume zwischen den Speichen, in der Breite von \frac {1}{15} bis zu ⅒ Zoll (1,693 bis 2,54 Mm.) schwan- kend, je nach der Grösse des Blattes, offen. Es kann daher ein In- sect, wenn sein Körper nicht dicker ist als die angegebenen Masze, leicht zwischen den gekreuzten Speichen hindurch entweichen, wenn es durch die sich schlieszenden Lappen und die zunehmende Dunkel-# Insekten und Pflanzeninteraktionen

heit beunruhigt wird; und einer meiner Söhne hat factisch ein kleines Insect auf diese Weise entweichen sehen. Wenn andererseits ein mäszig groszes Insect versucht, zwischen den Riegeln durch zu entkommen, so wird es sicherlich durch die sich schlieszenden Wände in sein schauerliches Gefängnis zurückgetrieben werden, denn die Speichen fahren fort, sich immer mehr und mehr zu kreuzen, bis die Ränder der Lappen selbst in Berührung kommen. Ein sehr starkes Insect indessen würde wohl im Stande sein, sich zu befreien; und Mrs. Treat sah einen Rosenkäfer der Vereinigten Staaten (Macro-dactylus subspinosus) dies wirklich ausführen. Es würde nun offen-bar ein groszer Nachtheil für die Pflanze sein, viele Tage dadurch zu verlieren, dasz sie über einem minutiösen Insecte geschlossen bliebe und dann später noch mehrere weitere Tage oder Wochen brauchte, ihre Empfindlichkeit wieder zu erlangen, insofern ja ein sehr kleines Insect nur wenig Nahrung darbieten würde. Es würde für die Pflanze viel besser sein, eine Zeit lang zu warten, bis ein mäszig groszes In-sect gefangen wäre, und die kleinen lieber entschlüpfen zu lassen; und dieser Vortheil ist der Pflanze durch die sich langsam kreuzen-den randständigen Speichen gesichert worden, welche wie die groszen Cap. 13. Übermittelung des motorischen Impulses. Maschen eines Fischernetzes der kleinen und nutzlosen Brut gestatten, zu entschlüpfen.

# Untersuchung der Insektenfänge

Da ich besorgt war, zu erfahren, ob diese Ansicht die richtige wäre, — und da der Fall auch eine gute Erläuterung dafür gibt, wie vorsichtig wir in der Annahme sein müssen, dasz irgend ein völlig entwickeltes Gebilde nutzlos sei, wie ich es in Bezug auf die randständigen Speichen angenommen hatte, — wandte ich mich an Dr. Canby. Er besuchte den natürlichen Standort der Pflanze zeitig im Jahre, ehe die Blätter zu ihrer vollen Grösse herangewachsen waren, und schickte mir vierzehn Blätter, welche natürlich gefangene Insecten enthielten. Vier derselben hatten ziemlich kleine Insecten gefangen, nämlich drei davon Ameisen und das vierte eine eher kleine Fliege; aber die andern zehn hatten alle grosze Insecten gefangen, nämlich fünf Elater, zwei Chrysomela, eins einen Curculio, eine dicke und breite Spinne und eine Scolopender. Unter diesen zehn Insecten fanden sich nicht weniger als acht Käfer. Dr. Canby bemerkt (Gardener’s Monthly, August, 1868), dasz „der all-gemeinen Regel nach Käfer und Insecten dieser Art zu hartschalig zu sein schei-nen, um zur Nahrung zu dienen, und dasz sie nach kurzer Zeit wieder ausgeworfen werden.‟ Ich bin über diese Angabe überrascht, wenigstens in Bezug auf solche Käfer wie die Elater; denn die fünf, welche ich untersuchte, waren in einem äuszerst zerbrechlichen und leeren Zustande, als wenn alle ihre inneren Theile verdaut worden wären. Mrs. Treat theilt mir mit, dasz die Exemplare, welche sie in New-Jersey cultivirte, hauptsächlich Diptern gefangen hätten., und unter den ganzen vierzehn war nur eins, nämlich ein zweiflügliges Insect, welches leicht fliegen konnte. Drosera lebt andererseits hauptsächlich von Insecten, welche gute Flieger sind, besonders von Diptern, die mittelst ihres klebrigen Secrets gefangen werden. Aber was uns hier am meisten angeht, ist die Grösse der zehn gröszeren Insecten. Ihre mittlere Länge von Kopf zu Schwanz war 0,256 Zoll, während die Lappen der Blätter im Mittel 0,53 Zoll lang waren, so dasz die Insecten nahebei halb so lang waren wie die Blätter, in welchen sie einge-schlossen wurden. Nur einige wenige dieser Blätter hatten daher ihre Kräfte durch das Fangen kleiner Beute verschwendet, obschon es ganz wahrscheinlich ist, dasz viele kleine Insecten über sie hin gekrochen und gefangen worden, aber dann noch zwischen den Speichen hindurch entkommen waren.

# Motorische Impulse und Bewegung

Die Übermittelung des motorischen Impulses und die Mittel der Bewegung. — Es genügt, irgend eines der sechs Dionaea muscipula. Cap. 13. Filamente zu berühren, um beide Lappen zum Schlieszen zu veran-lassen, wobei dieselben gleichzeitig ihrer ganzen Breite nach einwärts gekrümmt werden. Der Reiz musz daher von jedem der Filamente# Übermittlung des motorischen Impulses

nach allen Richtungen hin ausstrahlen. Er musz auch mit groszer
Geschwindigkeit quer über das Blatt gesandt werden, denn in allen
gewöhnlichen Fällen schlieszen sich die beiden Lappen, so weit es
das Auge beurtheilen kann, gleichzeitig. Die meisten Physiologen
glauben, dasz bei reizbaren Pflanzen der Reiz den Gefäszbündeln ent-
lang oder in nahem Zusammenhange mit ihnen fortgeleitet werde. Bei
Dionaea scheint auf den ersten Blick der Verlauf dieser Gefäsze (aus
spiralem und gewöhnlichem Gefäszgewebe zusammengesetzt) diese An-
nahme zu begünstigen; denn sie laufen die Mittelrippe in einem
groszen Bündel hinauf, auf jeder Seite kleine Bündel beinahe unter
rechtem Winkel abgebend. Diese spalten sich gelegentlich gabel-
förmig auf ihrem Verlaufe dem Rande zu, und dicht am Rande treten
kleine Zweige aus benachbarten Gefäszen zusammen und laufen in
die randständigen Speichen. An einigen dieser Vereinigungspunkte
bilden die Gefäsze merkwürdige Schlingen, wie die bei Drosera be-
schriebenen. Eine zusammenhängende Zickzacklinie läuft hiernach
rings um den ganzen Umfang des Blattes und in der Mittelrippe
sind sämmtliche Gefäsze in dichter Berührung, so dasz alle Theile des
Blattes in einen gewissen Grad von gegenseitiger Mittheilbarkeit ge-
bracht zu sein scheinen. Nichtsdestoweniger ist aber doch die Gegen-
wart von Gefäszen für die Übermittelung des motorischen Impulses
nicht nothwendig, denn er wird auch von den Spitzen der empfind-
lichen Filamente (dieselben sind ungefähr \frac {1}{20} Zoll lang), in welche
keine Gefäsze eintreten, weitergeleitet; und die letzteren hätten nicht
übersehen werden können, da ich dünne senkrechte Durchschnitte
durch das Blatt bei den Basen der Filamente machte.

# Experimente mit Schlitzen

Bei mehreren Gelegenheiten wurden ungefähr               ⅒     Zoll lange Schlitze
mit einer Lancette dicht an der Basis der Filamente, parallel mit der
Mittelrippe gemacht, daher direct quer auf den Lauf der Gefäszbündel.
Dieselben wurden zuweilen auf der inneren und zuweilen auf der
äuszeren Seite der Filamente gemacht; mehrere Tage, nachdem sich
die Blätter wieder geöffnet, wurden nun diese Filamente derb berührt
(denn sie wurden immer durch die Operation in einem gewissen Grade
tropid gemacht), und die Lappen schlossen sich darauf in der gewöhn-
lichen Art, wennschon langsam und zuweilen nicht vor Ablauf einer
Cap. 13. Übermittelung des motorischen Impulses.
beträchtlichen Zeit. Diese Fälle zeigen, dasz der motorische Impuls
nicht den Gefäszbündeln entlang fortgeleitet wird; sie zeigen ferner,
dasz keine Nöthigung zur Annahme eines directen Communications-
weges von dem Filamente, welches berührt worden ist, nach der
Mittelrippe und dem gegenüberliegenden Lappen oder nach den äusze-
ren Theilen eines und desselben Lappens besteht.

# Weitere Beobachtungen

Es wurden nun zunächst zwei Schlitze nahe an einander und
beide der Mittelrippe parallel in derselben Art und Weise, wie vor-
hin erwähnt, jeder auf einer Seite der Basis eines Filaments an fünf
verschiedenen Blättern gemacht, so dasz ein kleiner, ein Filament
tragender Streifen mit dem übrigen Blatte nur an seinen beiden
Enden zusammenhieng. Diese Streifchen waren nahezu von der näm-
lichen Grösse; eines wurde sorgfältig gemessen: es war 0,12 Zoll
(3,048 Mm.) lang und 0,08 Zoll (2,032 Mm.) breit; in der Mitte
stand das Filament. Nur einer dieser Streifen welkte und starb ab.
Nachdem sich das Blatt von der Operation wieder erholt hatte, trotz-
dem aber die Schlitze noch immer offen waren, wurden die in solche
Umstände versetzten Filamente derb berührt, und beide Lappen, oder
einer allein schlosz sich langsam. In zwei Fällen brachte die Be-
rührung des Filaments keine Wirkung hervor; als aber die Spitze
einer Nadel in den Blattstreifen an der Basis des Filaments einge-
stochen wurde, schlossen sich die Lappen langsam. In diesen Fällen
nun musz der Impuls dem Streifen entlang in einem der Mittelrippe
parallelen Zuge fortgeschritten und dann entweder von beiden Enden
oder nur von einem Ende des Streifens über die ganze Oberfläche der
beiden Lappen ausgestrahlt sein.

# Schlussfolgerungen

Es wurden ferner zwei parallele Schlitze, gleich den früheren,
einer auf jeder Seite der Basis eines Filaments, aber unter rechtem# Motorischer Impuls und Zellgewebe

Winkel zur Mittelrippe gemacht. Nachdem die Blätter (der Zahl nach zwei) sich wieder erholt hatten, wurden die Filamente derb berührt und die Lappen schlossen sich langsam; hier muss der Impuls eine kurze Strecke weit in rechtem Winkel nach der Mittelrippe zu fortgeschritten und dann nach allen Seiten über beide Lappen ausgestrahlt sein. Diese verschiedenen Fälle beweisen, dasz der motorische Impuls in allen Richtungen hin durch das Zellgewebe läuft, unabhängig vom Verlaufe der Gefäsze.

# Untersuchung von Dionaea muscipula

Bei Drosera haben wir gesehen, dasz der motorische Impuls in gleicher Weise durch das Zellgewebe nach allen Richtungen hin übermittelt wird, dasz aber die Geschwindigkeit seines Fortschreitens in hohem Masze von der Länge der Zellen und der Richtung ihrer längeren Achsen bestimmt wird. Mein Sohn fertigte dünne Durchschnitte eines Blattes von Dionaea an, und wir fanden, dasz die Zellen, sowohl die der centralen als auch die der oberflächlicheren Schichten, bedeutend verlängert waren und ihre längeren Achsen nach der Mittelrippe hingerichtet hatten; und gerade in dieser Richtung musz der motorische Impuls mit groszer Geschwindigkeit von einem Lappen zum andern gesandt werden, da sich beide gleichzeitig schlieszen. Die centralen, parenchymatösen Zellen sind gröszer, lockerer an einander geheftet und haben zartere Wandungen als die oberflächlicheren Zellen. Eine dicke Masse von Zellgewebe bildet die obere Fläche der Mittelrippe oberhalb des groszen centralen Gefäszbündels.

# Reaktion der Lappen auf Berührung

Als die Filamente derb berührt wurden, an deren Basen Schlitze gemacht worden waren und zwar entweder auf beiden Seiten oder nur an einer Seite, entweder parallel mit der Mittelrippe oder in rechtem Winkel zu ihr, bewegten sich beide Lappen oder nur der eine. In einem dieser Fälle bewegte sich der Lappen auf der Seite, welche das Filament trug, das berührt worden war, in drei anderen Fällen aber bewegte sich allein der gegenüberliegende Lappen; eine Beschädigung also, welche hinreichte, die Bewegung eines Lappens zu hindern, verhinderte die Weiterleitung eines Reizes von ihm aus nicht, welcher den gegenüberliegenden Lappen sich zu bewegen anregte. Wir lernen hieraus auch, dasz, obgleich sich normal beide Lappen zusammen bewegen, jeder die Fähigkeit unabhängiger Bewegung hat. Es ist allerdings bereits der Fall von einem torpiden Blatte mitgetheilt worden, welches sich kürzlich, nachdem es eine Fliege gefangen hatte, wieder geöffnet hatte, und an dem sich ein Lappen allein bewegte, als es gereizt wurde. Überdies kann sich auch ein Ende eines und desselben Lappens schlieszen und wieder ausbreiten, unabhängig vom anderen Ende, wie wir es in einigen der vorstehend angeführten Experimente gesehen haben.

# Beobachtungen zur Faltenbildung

Wenn sich die Blattlappen, die ziemlich dick sind, schlieszen, so ist keine Spur von Faltenbildung auf irgend einem Theile ihrer obern Fläche zu sehen. Es müssen sich daher allem Anscheine nach die Zellen zusammenziehen. Der hauptsächlichste Sitz der Bewegung ist offenbar die dicke Zellenmasse, welche auf dem centralen Gefäszbündel in der Mittelrippe aufliegt. Um zu ermitteln, ob sich dieser Teil zusammenzieht, wurde ein Blatt in einer solchen Weise an dem Tische des Mikroskops befestigt, dasz die beiden Lappen nicht vollständig geschlossen werden konnten; und nachdem ich zwei sehr kleine schwarze Punkte auf die Mittelrippe, in einer queren Reihe und ein wenig nach einer Seite hin, gemacht hatte, stellte es sich mittels des Mikrometers heraus, dasz sie \frac {17}{1000} Zoll von einander entfernt standen. Nun wurde eines der Filamente berührt und die Lappen schlossen sich; da sie aber daran verhindert waren, sich zu berühren, so konnte ich noch immer die beiden Punkte sehen, welche nun \frac {15}{1000} Zoll auseinander standen, so dasz eine kleine Partie der oberen Fläche der Mittelrippe sich in einer Querlinie um \frac {2}{1000} Zoll (0,0508 Mm.) zusammengezogen hatte.

# Krümmung der Lappen

Wir wissen, dasz die Lappen, während sie sich schlieszen, ihrer ganzen Breite nach unbedeutend nach innen gekrümmt werden. Diese# Bewegung und Contraction

Bewegung ist dem Anscheine nach eine Folge der Contraction der oberflächlichen Zellenschichten über die ganze obere Fläche hin. Um ihre Zusammenziehung zu beobachten, wurde aus dem einen Lappen ein schmaler Streifen unter rechtem Winkel auf die Mittelrippe ausgeschnitten, so dasz die Oberfläche des entgegengesetzten Lappens an dieser Stelle gesehen werden konnte, wenn das Blatt geschlossen war. Nachdem sich das Blatt von der Operation erholt und wieder ausgebreitet hatte, wurden drei kleine schwarze Flecken auf die dem Schlitz oder Fenster gegenüberliegende Fläche in einer Linie rechtwinklig auf die Mittelrippe gemacht. Die Entfernung zwischen den Flecken wurde als \frac {40}{1000} Zoll betragend ermittelt, so dasz die beiden äuszersten Punkte \frac {80}{1000} Zoll auseinander standen. Nun wurde eines der Filamente berührt und das Blatt schlosz sich. Als die Entfernungen zwischen den Punkten wiederum gemessen wurden, ergab sich, dasz die beiden der Mittelrippe am nächsten gelegenen um \frac {1—2}{1000} Zoll näher an einander waren als früher und die beiden ferneren Punkte um \frac {3—4}{1000} Zoll, so dasz nun die beiden äuszersten Punkte der Reihe ungefähr \frac {5}{1000} Zoll (0,127 Mm.) näher an einander standen als vorher. Wenn wir annehmen, dasz die ganze obere Fläche des Lappens, welcher \frac {40}{1000} Zoll breit war, sich in demselben Verhältnis zusammengezogen hat, so wird die Gesammtcontraction ungefähr \frac {25}{1000} oder \frac {1}{40} Zoll (0,635 Mm.) betragen haben; ob dies aber hinreichend ist, die unbe-deutende Einwärtskrümmung des ganzen Lappens zu erklären, bin ich nicht im Stande zu sagen.

# Entdeckung von Dr. Burdon Sanderson

Endlich ist nun die wunderbare, von Dr. Burdon Sanderson gemachte EntdeckungProceed. Royal Society, Vol. XXI, p. 495, und Lecture at the Royal Institution, June 5, 1874, mitgetheilt in „Nature‟, 1874, p. 105 und 127. in Bezug auf die Bewegung der Blätter allgemein bekannt, dasz nämlich in der Blattscheibe und dem Blattstiel ein normaler elektrischer Strom besteht, und dasz, wenn die Blätter gereizt werden, der Strom in derselben Art und Weise gestört wird, wie es während der Contraction des Muskels eines Thieres stattfindet.

# Wiederausbreitung der Blätter

Die Wiederausbreitung der Blätter. — Diese wird in einem unmerkbar langsamen Tempo bewirkt, mag nun ein Gegenstand eingeschlossen sein oder nichtNuttall sagt in seinen Genera of American Plants, p. 277 (Anmerkung): „ich hatte (während ich diese Pflanze in ihrer eigentlichen Heimath sammelte) Gelegenheit zu beobachten, dasz ein losgetrenntes Blatt wiederholte Anstrengungen machte, sich dem Einflusse der Sonne auszusetzen; diese Versuche bestanden in einer wellenförmigen Bewegung der randständigen Wimpern, welche von einem theilweisen Öffnen und darauf folgenden Zusammensinken der Blattscheibe begleitet wurde und endlich in einer vollständigen Ausbreitung und einer Zerstörung der Empfindlichkeit ausgieng.‟ Ich bin dem Professor Oliver für dies Citat verbunden; ich verstehe aber nicht, was hier stattfand. Ein Lappen kann sich für sich selbst wieder ausbreiten, wie es mit dem torpiden Blatte vorkam, bei dem sich nur ein Lappen allein geschlossen hatte. Auch haben wir in den Versuchen mit Käse und Eiweisz gesehen, dasz die beiden Enden eines und desselben Blattes bis zu einem gewissen Grade sich unabhängig von einander wieder ausbreiten können. Aber in allen gewöhnlichen Fällen öffnen sich beide Lappen zu der nämlichen Zeit. Die Wiederausbreitung wird nicht durch die empfindlichen Filamente bestimmt; alle drei Filamente auf einem Lappen wurden dicht an ihrer Basis abgeschnitten; und die drei so behandelten Blätter breiteten sich wieder aus und zwar das eine in theilweiser Ausdehnung in 24 Stunden, — das zweite in gleichem Grade in 48 Stunden, — und das dritte, welches vorher verletzt worden war, vor dem sechsten Tage. Nach ihrer Wiederausbreitung schlossen sich diese Blätter schnell, als die Filamente auf dem andern Lappen gereizt wurden.# Wiederausbreitung der Blätter

Diese wurden dann bei einem Blatte auch noch abgeschnitten, so dasz keine mehr vorhanden waren. Dieses verstümmelte Blatt breitete sich trotz des Verlustes aller seiner Filamente in zwei Tagen in der gewöhnlichen Weise wieder aus. Wenn die Filamente durch Eintauchen in eine Zuckerlösung gereizt worden waren, so breiten sich die Lappen nicht so bald wieder aus, als wenn die Filamente blosz berührt worden waren; und dies ist, wie ich vermuthe, Folge davon, dasz sie stark durch Exosmose afficirt worden sind, so dasz sie einige Zeit lang fortdauernd einen motorischen Impuls der oberen Fläche des Blattes zuleiten.

# Mechanische Zustände der Zellenschichten

Die folgenden Thatsachen lassen mich glauben, dasz die verschiedenen Zellenschichten, welche die untere Fläche des Blattes bilden, sich immer in einem Zustande der Spannung befinden, und dasz es eine Folge dieses mechanischen Zustandes ist — wahrscheinlich noch dadurch unterstützt, dasz frische Flüssigkeit in die Zellen gezogen wird, — dasz die Lappen sich zu trennen oder auszubreiten anfangen, so bald die Contraction der oberen Flächen sich vermindert.

# Experimente mit kochendem Wasser

Ein Blatt wurde abgeschnitten und plötzlich senkrecht in kochendes Wasser geworfen; ich erwartete, dasz sich die Lappen schlieszen würden, aber statt dessen divergirten sie ein wenig. Ich nahm dann ein anderes schönes Blatt, dessen Lappen in einem Winkel von nahezu 80° zu einander standen; und als ich es wie das vorige eintauchte, erweiterte sich der Winkel plötzlich auf 90°. Ein drittes Blatt hatte sich kürzlich wieder ausgebreitet, nachdem es eine Fliege gefangen hatte, und war in Folge desen torpid, so dasz wiederholte Berührungen der Filamente nicht die geringste Bewegung bewirkten; als es in ähnlicher Weise in kochendes Wasser getaucht wurde, giengen die Lappen trotzdem ein wenig auseinander. Da diese Blätter senk- recht in das kochende Wasser gehalten wurden, müssen beide Oberflächen und die Filamente gleichmäszig afficirt worden sein; und ich kann mir die Divergenz der Lappen nur dadurch verständlich machen, dasz ich annehme, die Zellen auf der unteren Seite hätten in Folge ihres Spannungszustandes mechanisch eingewirkt und somit die Lappen plötzlich ein wenig auseinander gezogen, sobald die Zellen auf der oberen Fläche getödtet wurden und ihr Contractionsvermögen verloren.

# Vergleich mit Droseraceen

Wir haben gesehen, dasz kochendes Wasser in gleicher Weise die Tentakeln der Drosera rückwärts biegen macht, und dies ist eine der Divergenz der Blattlappen bei Dionaea analoge Bewegung. In einigen Schluszbemerkungen zum fünfzehnten Capitel über die Droseraceen werden die verschiedenen Arten von Irritabilität, welche die verschiedenen Gattungen besitzen, und die verschiedenen Arten, in welchen sie Insecten fangen, mit einander verglichen werden.

# Aldrovanda vesiculosa

Vierzehntes Capitel. Aldrovanda vesiculosa. Fängt Krustenthiere. — Structur der Blätter im Vergleich mit denen der Dionaea. — Aufsaugung der Drüsen, der viertheiligen Fortsätze und der Spitzen an den nach innen gefalteten Rändern. — Aldrovanda vesiculosa, var. australis — Fängt sich Beute. — Aufsaugung thierischer Substanz. — Aldrovanda vesiculosa, var. verticillata. — Schluszbemerkungen.

Diese Pflanze kann eine kleine, im Wasser wachsende Dionaea genannt werden. Stein entdeckte 1873, dasz die zweilappigen Blätter, welche in Europa gewöhnlich geschlossen gefunden werden, sich unter einer genügend hohen Temperatur öffnen und wenn sie berührt werden, plötzlich schlieszen. Seit seiner ersten Publication hat Stein gefunden, dasz die Reizbarkeit der Blätter von De Sassus beobachtet worden ist, was im „Bullet. Soc. de Bot. de France‟, 1861, mitgetheilt wird. Delpino gibt in einem, 1871 publicirten Aufsatz an (Nuovo Giornale Bot. Ital. Vol. III, p. 74), dasz „una quantità di chioc- cioline e di altri animalcoli acquatici‟ gefangen und von den Blättern erstickt werden. Chioccioline sind Süszwasser-Schalthiere. Es wäre interessant, zu wissen,# Aldrovanda vesiculosa

## Einleitung
ob ihre Schalen überhaupt von der Säure des verdauenden Secrets angegriffen wurden.. Sie breiten sich in von 24 bis 36 Stunden wieder aus; aber, wie es scheint, nur wenn unorganische Gegenstände eingeschlossen wurden. Die Blätter enthalten zuweilen Luftblasen und wurden früher für Blasen gehalten; daher der specifische Name „vesiculosa‟.

## Beobachtungen und Experimente
Stein beobachtete, dasz Wasser-Insecten manchmal gefangen wurden, und Prof. Cohn hat wiederholt in den Blättern natür-lich wachsender Pflanzen viele Arten von Krustenthieren und Larven gefunden. Ich bin diesem ausgezeichneten Naturforscher zu Dank verpflichtet, dasz er mir seine Abhandlung über Aldrovanda noch vor ihrer Veröffentlichung in den „Beiträgen zur Biologie der Pflanzen‟ 5. Heft, 1875, p. 71 geschickt hat. Pflanzen, die in filtrirtem Wasser gehalten worden waren, wurden von ihm in ein Gefäsz, welches zahlreiche Krustenthiere der Gattung Cypris enthielt, gethan, und am nächsten Morgen wurden viele gefangen gefunden, noch lebendig und in den geschlossenen Blät-tern herumschwimmend, aber zu gewissem Tode verurtheilt.

## Abbildungen und Vergleiche
Gleich nachdem ich Prof. Cohn’s Abhandlung gelesen hatte, erhielt ich durch Dr. Hooker’s Güte lebende Pflanzen aus Deutschland. Da ich nichts zu Prof. Cohn’s ausgezeichneter Beschreibung hinzufügen kann, so will ich nur zwei Abbildungen geben, die eine von einem Wirtel von Blättern aus seiner Abhandlung copirt, und die andere von einem flach offen gedrückten Blatte, von meinem Sohne Francis gezeichnet. Ich will jedoch einige Bemerkungen über die Verschiedenheiten zwischen dieser Pflanze und der Dionaea daran knüpfen.

## Morphologie der Aldrovanda
Aldrovanda besitzt keine Wurzeln und schwimmt frei im Wasser. Die Blätter sind in Wirteln rings um den Stamm angeordnet. Ihre breiten Stiele enden in von vier bis sechs steifen Vorsprüngen. Man hat die homologen Beziehungen dieser Vorsprünge unter den Botanikern vielfach erörtert. Dr. Nitschke (Botan. Zeitung, 1861, p. 146) glaubt, dasz sie den gefransten schuppenartigen Körpern, die sich an den Basen der Blattstiele bei Drosera finden, entsprechen, jeder an der Spitze mit einer steifen kurzen Borste versehen.

## Struktur der Blätter
Das zwei-lappige Blatt, dessen Mittelrippe gleichfalls an der Spitze mit einer kurzen Borste versehen ist, steht in der Mitte dieser Vorsprünge und wird augenscheinlich von ihnen geschützt. Die Lappen werden von einem sehr zarten Gewebe gebildet, so dasz sie durchsichtig sind; sie öffnen sich, wie Cohn sagt, ungefähr eben so viel als die beiden Klappen einer lebenden Muschelschale, daher selbst noch weniger als die Lappen der Dionaea; und dies musz das Fangen von im Wasser lebenden Thieren noch leichter machen.

## Oberflächenstruktur
Die Auszenseite der Blätter und Stiele ist mit sehr kleinen, zweiarmigen Papillen bedeckt, augenscheinlich den achtstrahligen Papillen der Dionaea entsprechend. Jeder Lappen ist etwas gröszer als ein Halbkreis in der Convexität und besteht aus zwei sehr verschiedenen concentrischen Thei-len; die innere und kleinere Partie oder die der Mittelrippe nähere ist leicht concav und wird, nach Cohn, von drei Zellenschichten gebildet.

## Drüsen und Fortsätze
Seine obere Fläche ist mit farblosen Drüsen, gleich denen der Dionaea, aber einfacher als diese, dicht besetzt; sie werden von bestimmten Stielen, welche aus zwei Reihen von Zellen bestehen, getragen. Der äuszere und breitere Theil des Lappens ist flach und sehr dünn und wird immer von zwei Zellenschichten gebildet. Seine obere Fläche trägt keine Drüsen, aber an ihrer Stelle kleine vierspal-tige Fortsätze, von denen jeder aus vier spitz zulaufenden Vorsprüngen besteht, welche sich von einer gemeinsamen Hervorragung erheben. Diese Fortsätze werden von einer sehr zarten Membran gebildet, welche mit einer Schicht von Protoplasma ausgekleidet ist; sie enthalten zuweilen zusammengeballte kuglige Massen von hyaliner Substanz.# Aldrovanda vesiculosa

## Struktur und Funktion der Blätter

## Vergleich mit Dionaea

## Empfindliche Haare und ihre Rolle

## Experimente mit Aldrovanda vesiculosa

## Schlussfolgerungen über die Verdauung# Einleitung

das Secret folglich nicht zu verdünnt zum Einwirken sein. In Bezug auf die viertheiligen Fortsätze an den äuszeren Theilen der Lappen war ich nicht im Stande zu entscheiden, ob der Aufgusz auf sie ein- gewirkt hatte; denn die Auskleidung von Protoplasma war etwas eingeschrumpft, ehe sie eingetaucht wurden. Bei vielen der Spitzen auf den umgebogenen Rändern war das auskleidende Protoplasma gleichfalls eingeschrumpft, und enthielt kuglige Körner von hyaliner Substanz.

# Verwendung von Harnstoff

Eine Lösung von Harnstoff wurde zunächst angewendet. Diese Substanz wurde zum Theil mit deshalb gewählt, weil sie von den Drüsen der Utricularia — einer Pflanze, welche, wie wir später sehen werden, sich von zerfallener thierischer Substanz nährt, absorbirt wird. Da der Harnstoff eines der letzten Producte der chemischen im lebenden Körper vor sich gehenden Verwandlungen ist, so scheint er dazu passend zu sein, die ersten Stadien des Zerfallens des todten Körpers darzustellen.

# Beobachtungen und Ergebnisse

Ich wurde auch noch durch eine sonderbare kleine Thatsache, die Prof. Cohn erwähnt, darauf geführt, den Harnstoff zu versuchen, nämlich dasz, wenn ziemlich grosze Kruster zwischen den sich schlieszenden Lappen gefangen werden, sie während ihres Entkommens so stark gedrückt werden, dasz sie oft ihre wurstförmigen Excremente aus- leeren, welche in den meisten der Blätter gefunden wurden. Diese Massen enthalten ohne Zweifel Harnstoff. Sie werden entweder auf den breiten äuszeren Flächentheilen der Lappen, wo die viertheiligen Fortsätze sitzen, oder in der geschlossenen Concavität gelassen. In dem letzteren Fall wird mit excrementitieller und verwesender Sub- stanz getränktes Wasser langsam nach auszen gepreszt und die vier- Cap. 14. Aldrovanda vesiculosa.

# Untersuchung der Blätter

Ein Blatt wurde aufgeschnitten und untersucht, und es fand sich, dasz die äuszeren Zellen der Drüsen nur durchsichtige Flüssigkeit enthielten. Einige der viertheiligen Fortsätze umschlossen einige wenige sphärische Körner, aber mehrere waren durchsichtig und leer, und deren Stellungen wurden bezeichnet. Dieses Blatt wurde nun in ein wenig Lösung von einem Theil Harnstoff auf 146 Theile Wasser oder drei Gran auf eine Unze gethan. Nach 3 Stunden 40 Minuten war noch keine Veränderung weder in den Drüsen, noch in den vier- theiligen Fortsätzen da; noch war nach 24 Stunden irgend eine sichere Veränderung in den Drüsen vorhanden, so dasz, soweit ein Versuch reicht, Harnstoff nicht in derselben Weise auf die Drüsen einwirkt, wie ein Aufgusz von rohem Fleisch.

# Veränderungen in den viertheiligen Fortsätzen

Die viertheiligen Fort- sätze verhielten sich anders; denn die Protoplasma-Auskleidung war, anstatt ein gleichmäsziges Gefüge darzubieten, nun leicht zusammen- geschrumpft und stellte an vielen Stellen kleine, verdickte, unregel- mäszige, gelbliche Flecken und Leisten dar, genau wie die, welche in den viertheiligen Fortsätzen der Utricularia erscheinen, wenn sie mit derselben Lösung behandelt wird.

# Weitere Beobachtungen

Überdies enthielten mehrere der vier- theiligen Fortsätze, welche vorher leer waren, jetzt mäszig grosze oder sehr kleine, mehr oder weniger zusammengeballte Körnchen gelblicher Substanz, wie es gleichfalls unter denselben Umständen bei Utricularia vorkommt. Einige der Spitzen an den eingebogenen Rändern der Lappen waren genau so afficirt; denn ihre Auskleidung von Protoplasma war etwas eingeschrumpft und umschlosz gelbliche Flecken; und diejenigen, welche vorher leer waren, enthielten nun kleine Kugeln und unregelmäszige Massen von hyaliner Substanz, mehr oder weniger zusammengeballt, so dasz Beides, die Spitzen auf den Rändern und die viertheiligen Fortsätze, im Laufe von 24 Stunden Substanz aus der Lösung auf- gesaugt hatten; aber ich werde auf diesen Gegenstand wieder zurück- kommen.

# Fazit

In einem andern ziemlich alten Blatt, welchem nichts ge- geben, welches aber in faulem Wasser gelassen worden war, enthiel- ten einige der viertheiligen Fortsätze zusammengeballte, durchsich-# Botanische Beobachtungen

## Aldrovanda vesiculosa, var. australis

## Schluszbemerkungen

## Aldrovanda vesiculosa var. verticillata# Pflanzenbeschreibung

Namen verticillata. Sie gleicht der australischen Form viel mehr als der europäischen; nämlich darin, dasz die Vorsprünge am oberen Ende des Stieles viel mehr verdünnt und mit nach oben gebogenen Stacheln bedeckt sind; sie enden auch in geraden kleinen Stacheln. Die zweigelappten Blätter sind, glaube ich, gröszer und sicherlich breiter als selbst die der australischen Form; so dasz die gröszere Convexität ihrer Ränder augenfällig war. Die Länge eines offenen Blattes zu 100 genommen, war die Breite der bengalischen Form beinahe 173, die der australischen Form 147 und die der deutschen 134. Die Spitzen an den eingebogenen Rändern sind ähnlich denen in der australischen Form. Von den wenigen Blättern, welche untersucht wurden, enthielten drei entomostrake Krustenthiere.

# Schluszbemerkungen

Schluszbemerkungen. — Die Blätter der drei vorstehend erwähnten nahe verwandten Species oder Varietäten sind offenbar zum Aldrovanda vesiculosa. Cap. 14. Fangen von lebenden Geschöpfen eingerichtet. Was die Functionen der verschiedenen Theile betrifft, so kann wenig Zweifel sein, dasz die langen gegliederten Haare sensitiv sind, wie die der Dionaea, und dasz sie, wenn sie berührt werden, verursachen, dasz sich die Lappen schlieszen. Dasz die Drüsen eine wahre verdauende Flüssigkeit absondern, und später die verdaute Substanz aufsaugen, ist sehr wahrscheinlich, einmal nach der Analogie der Dionaea, — dann weil die durchsichtige Flüssigkeit in ihren Zellen in sphärische Massen zusammengeballt wird, nachdem sie einen Aufgusz von rohem Fleisch aufgesaugt hatten, — ferner, weil die Zellen des Blattes, welches lange Zeit einen Käfer eingeschlossen hatte, sich in einem undurchsichtigen und körnigen Zustand befanden, — und endlich, weil die Integumente dieses Insects, eben sowohl wie die der Kruster (wie Cohn beschrieben hat) welche lange gefangen gewesen sind, so rein waren. Ferner ist es nach der Wirkung, welche ein Eintauchen von 24 Stunden in eine Lösung von Harnstoff auf die viertheiligen Fortsätze hervorbrachte, — nach der Anwesenheit von brauner körniger Substanz in den viertheiligen Fortsätzen des Blattes, worin der Käfer gefangen worden war, — und nach der Analogie der Utricularia — wahrscheinlich, dasz diese Fortsätze excrementitielle und zerfallende thierische Substanz aufsaugen. Es ist ein noch merkwürdigerer Fall, dasz die Spitzen auf den eingebogenen Rändern augenscheinlich dazu dienen, zerfallene thierische Substanz in derselben Weise wie die viertheiligen Fortsätze aufzusaugen. Wir können hier noch die Bedeutung der eingebogenen Ränder der Lappen, die mit zarten nach innen gerichteten Spitzen versehen sind, und der breiten flachen äuszeren Theile, welche viertheilige Fortsätze tragen, verstehen; denn diese Flächen müssen dem ausgesetzt sein, von faulem Wasser benetzt zu werden, welches von der Concavität des Blattes abflieszt, wenn es todte Thiere enthält. Dieses würde aus verschiedenen Ursachen erfolgen: — wegen der allmählichen Contraction der Concavität, — weil Flüssigkeit im Übermasz abgesondert wird, — und wegen der Entstehung von Luftblasen. Mehr Beobachtungen sind über diesen Punkt nöthig, aber wenn diese Ansicht richtig ist, so haben wir den merk-
würdigen Fall, dasz verschiedene Theile eines und desselben Blattes sehr verschiedenen Zwecken dienen, — der eine Theil zu wahrer Verdauung, und ein andrer zur Aufsaugung zerfallener thierischer Substanz. Wir können auch hiernach verstehen, wie eine Pflanze durch den allmählichen Verlust einer der beiden Fähigkeiten, nach und nach der einen Thätigkeit angepaszt werden kann, mit Ausschlusz der andern; und es wird später gezeigt werden, dasz zwei Gattungen, nämlich Pinguicula und Utricularia, die zu derselben Familie gehören, diesen zwei verschiedenen Functionen angepaszt worden sind.

# Fünfzehntes Kapitel

Drosophyllum. — Roridula. — Byblis. — Drüsige Haare anderer Pflanzen. — Schluszbemerkungen über die Droseraceen.# Drosophyllum

## Struktur der Blätter

## Natur des Secrets

## Art und Weise, Insecten zu fangen

## Vermögen der Absorption

## Verdauung animaler Substanzen

## Zusammenfassung über Drosophyllum

## Roridula

## Byblis

## Drüsige Haare anderer Pflanzen, ihr Absorptionsvermögen

## Saxifraga

## Primula

## Pelargonium

## Erica

## Mirabilis

## Nicotiana

## Zusammenfassung über drüsige Haare

## Schlussbemerkungen über die Droseraceen

## Drosophyllum lusitanicum

## Cap. 15. Struktur der Blätter

## Beschreibung der Drüsen

## Kleinere Drüsen und ihre Eigenschaften# Drosophyllum lusitanicum und seine Drüsen

## Absonderung und Eigenschaften der Drüsen

## Vergleich mit Drosera

## Funktionale Unterschiede zwischen den Drüsen# Drüsen von Drosophyllum

Die Drüsen von Drosophyllum fahren doch beständig fort zu secerniren, so dass sie den durch Verdunstung eintretenden Verlust ersetzen.

## Absorption von Secret

Die Drüsen, denen stickstoffhaltige Substanzen gegeben wurden, sonderten nicht reichlicher ab; im Gegenteil, sie absorbirten die Tropfen ihres eigenen Secrets mit überraschender Schnelligkeit.

## Experimentelle Beobachtungen

Stückchen von feuchtem Faserstoff wurden auf fünf Drüsen gelegt, und nach einer Zwischenzeit von 1 Stunde 12 Minuten war das Fibrin beinahe trocken, da das Secret ganz absorbiert worden war.

## Einfluss von organischen Substanzen

Das gleiche Resultat erfolgte, als Stückchen sowohl von Knorpel als auch von Fleisch auf mehrere Drüsen gelegt wurden.

## Wirkung von salpetersauren Ammoniaks

Ein sehr kleiner Tropfen einer Lösung von salpetersauren Ammoniaks wurde auf drei Drüsen umgebende Secret vertheilt, und doch waren alle drei nach 2 Stunden trocken.

## Vergleich mit anorganischen Substanzen

Sieben Stückchen Glas und drei Kohlentheilchen wurden auf zehn Drüsen gelegt; es war aber nicht das geringste Zeichen vorhanden, dass Secret absorbiert worden wäre.

## Schlussfolgerungen zur Absorption

Es muss daher in den ersteren Fällen die Aufsaugung des Secrets Folge des Vorhandenseins irgend einer stickstoffhaltigen Substanz gewesen sein.

## Fähigkeit zur schnellen Absonderung

Die Drüsen haben nicht nur das Vermögen rapider Absorption, sondern sind auch fähig, wiederum schnell abzusondern.

## Beobachtungen zur Wiederabsonderung

Die genaue Zeitperiode der wieder eintretenden Absonderung wurde nur in einigen wenigen Fällen notiert.

## Tentakeln und Bewegung

Es wurden viele von den langen Tentakeln, mit ihnen anhängenden Insecten, sorgfältig beobachtet; es konnte aber niemals auch nur eine Spur von Bewegung festgestellt werden.# Entdeckung und Beobachtungen

## Absorptionsvermögen der Drüsen

## Farbveränderungen und Reaktionen

## Wirkung organischer Substanzen# Verdauung

In einigen wenigen Fällen indessen war kein solcher Unterschied zu bemerken, und dies war dem Anscheine nach Folge davon, dasz die Insecten schon vor langer Zeit gefangen wor- den waren, so dasz die Drüsen ihren früheren Zustand wieder erlangt hatten. In einem Falle hatte eine Gruppe der direct aufsitzenden farblosen Drüsen, an denen eine kleine Fliege hieng, ein eigenthümliches Ansehn; sie waren nämlich purpurn geworden in Folge einer Auskleidung ihrer Zellenwände mit granulöser purpurner Substanz. Ich will hier nur zur Vorsicht erwähnen, dasz, bald nachdem einige meiner Pflanzen im Frühjahr von Portugal angekommen waren, Stück-

# Verdauung fester thierischer Substanz

Während ich den Versuch machte, auf zwei der längeren Drüsen kleine Würfel von Eiweisz zu legen, schlüpften dieselben hinab und blieben, mit dem Secrete beschmiert, auf einigen der kleinen sitzenden Drüsen liegen. Nach 24 Stunden fand sich, dasz einer dieser Würfel voll- ständig verflüssigt worden war, wobei indesz noch immer einige we- nige weisze Streifen sichtbar waren; der andere war bedeutend abge- rundet, aber nicht völlig aufgelöst. Zwei andere Würfel wurden 2 Stunden 45 Minuten lang auf langen Drüsen gelassen, in welcher Zeit das ganze Secret absorbirt war; eine Einwirkung auf die Würfel war aber nicht bemerkbar, obschon ohne Zweifel eine geringe Menge von animaler Substanz aus ihnen absorbirt worden war. Sie wurden dann auf die kleinen sitzenden Drüsen gebracht, welche nun, da sie dadurch gereizt wurden, im Laufe von 7 Stunden reichlich absonder- ten. Innerhalb dieser kurzen Zeit wurde einer der Würfel bedeutend verflüssigt, und beide waren nach Verlauf von 21 Stunden 15 Minu- ten völlig flüssig geworden; die kleinen flüssigen Massen zeigten in- zwischen noch immer einige weisze Streifen. Nach Verlauf von weiteren 6 Stunden 30 Minuten verschwanden diese Streifen, und am nächsten Morgen (d. h. 48 Stunden von der Zeit an, wo die Würfel zuerst auf die Drüsen gelegt wurden) war die verflüssigte Masse vollständig aufgesaugt. Es wurde ein Eiweiszwürfel auf einer andern langen Drüse gelassen, welche zuerst das Secret absorbirte und nach 24 Stunden eine frische Menge ergosz. Dieser nun von Absonderung um- gebene Würfel wurde weitere 24 Stunden lang auf der Drüse ge- lassen; es erfolgte aber, wenn überhaupt irgend welche, nur eine sehr unbedeutende Einwirkung. Wir können daher schlieszen, entweder dasz das Secret von den hohen Drüsen, trotzdem es stark sauer ist, doch nur eine geringe Verdauungskraft hat, oder dasz die von einer einzigen Drüse ergossene Menge nicht genügt, ein Stückchen Eiweisz aufzulösen, welches innerhalb derselben Zeit von dem Secrete aus mehreren der kleinen sitzenden Drüsen aufgelöst worden sein würde. Wegen des Absterbens meiner letzten Pflanze war ich nicht im Stande zu ermitteln, welche von diesen beiden Alternativen die rich- tige ist.

# Drosophyllum lusitanicum

Vier äuszerst kleine Stückchen reinen Fibrins wurden so gelegt, dasz jedes auf einer, zwei oder drei der längeren Drüsen ruhte. Im Laufe von 2 Stunden 30 Minuten war das Secret ganz absorbirt und die Stückchen waren beinahe ganz trocken gelassen. Sie wurden dann auf die sitzenden Drüsen geschoben. Ein Stückchen schien nach 2 Stunden 30 Minuten ganz aufgelöst zu sein, dies könnte indesz ein Irrthum gewesen sein. Als ein zweites nach 17 Stunden 25 Minuten untersucht wurde, war es verflüssigt, die Flüssigkeit liesz aber unter dem Mikroskope noch immer flottirende Körnchen von Fibrin erkennen. Die andern beiden Stückchen waren nach 21 Stunden 30 Minuten vollständig verflüssigt; aber in einem der Tropfen waren noch einige wenige Körnchen zu entdecken. Diese waren indessen nach Verlauf von weiteren 6 Stunden 20 Minuten aufgelöst; und die Oberfläche des# Verdauung und Unterschiede zwischen Drosophyllum und Drosera

Blattes war in einiger Entfernung rings herum mit klarer Flüssigkeit bedeckt. Hieraus ergibt sich, dasz Drosophyllum Albumin und Fibrin eher noch schneller verdaut als es Drosera kann; und dies ist vielleicht dem Umstande zuzuschreiben, dasz die Säure, wahrscheinlich in Verbindung mit einer kleinen Menge des Ferments, schon in der Absonderung vorhanden ist, ehe die Drüsen gereizt worden sind, so dasz die Verdauung sofort beginnt.

## Schluszbemerkungen

Die linearen Blätter von Drosophyllum weichen nur unbedeutend von denen gewisser Species von Drosera ab; die hauptsächlichsten Unterschiede bestehen erstens in dem Vorhandensein äuszerst kleiner, beinahe direct aufsitzender Drüsen, welche gleich denen der Dionaea nicht eher absondern, als bis sie durch die Aufsaugung stickstoffhaltiger Substanz gereizt worden sind. Aber Drüsen dieser Art sind auf den Blättern der Drosera binata vorhanden und scheinen durch die Papillen auf den Blättern der Drosera rotundifolia repräsentirt zu werden. Zweitens sind bei Drosophyllum Tentakeln auf der Rückseite der Blätter vorhanden; Wir haben aber gesehen, dasz einige wenige Tentakeln, unregelmäszig vertheilt und dem Verkümmern zuneigend, auf der Rückenseite der Blätter von Drosera binata übrig geblieben sind. Gröszere Verschiedenheiten bestehen zwischen beiden Gattungen in den Functionen; die bedeutungsvollste ist die, dasz die Tentakeln von Drosophyllum kein Bewegungsvermögen besitzen; dieser Verlust ist theilweise dadurch ersetzt worden, dasz die Tropfen klebrigen Secrets leicht von den Drüsen abgezogen werden können; so dasz ein Insect, wenn es mit einem Tropfen in Berührung kommt, im Stande ist wegzukriechen, aber bald noch andere Tropfen berührt und dann, von dem Secrete erstickt, auf die sitzenden Drüsen hinabsinkt und stirbt. Ein anderer Unterschied liegt darin, dasz das Secret von den langen Drüsen, noch ehe sie in irgend einer Weise gereizt worden sind, stark sauer ist und vielleicht eine geringe Menge des gehörigen Ferments enthält. Ferner sondern diese Drüsen in Folge ihrer Reizung durch die Absorption stickstoffhaltiger Substanz nicht reichlicher ab; im Gegen-theil absorbiren sie dann mit auszerordentlicher Schnelligkeit ihre eigene Absonderung. Nach kurzer Zeit fangen sie von Neuem an abzusondern. Alle diese Umstände hängen wahrscheinlich mit der Thatsache zusammen, dasz Insecten gewöhnlich nicht an den Drüsen hängen bleiben, mit denen sie zuerst in Berührung kommen, obschon dies zuweilen vorkommt, und dasz es hauptsächlich das Secret aus den sitzenden Drüsen ist, welches animale Substanz aus den Insecten-körpern auflöst.

## Roridula

Roridula dentata. — Diese Pflanze, ein Bewohner der westlichen Theile des Vorgebirges der guten Hoffnung, wurde mir aus Kew in getrocknetem Zustande geschickt. Sie hat beinahe holzigen Stamm und Zweige und erreicht allem Anscheine nach die Höhe von einigen Fuszen. Die Blätter sind linear mit bedeutend verschmälerten Spitzen. Ihre obere und untere Fläche sind concav mit einer Leiste in der Mitte, und beide sind mit Tentakeln besetzt, welche in der Länge bedeutend von einander abweichen: einige sind sehr lang, besonders die an den Spitzen der Blätter, und einige sehr kurz. Auch die Drüsen sind von sehr verschiedener Grösse und sind etwas länglich. Sie werden von vielzelligen Stielen getragen.

Es stimmt daher diese Pflanze in mehrfachen Beziehungen mit Drosophyllum überein, weicht aber in den folgenden davon ab. Ich habe keine sessilen Drüsen entdecken können: auch würden diese von keinerlei Nutzen gewesen sein, da die obere Fläche der Blätter dicht mit zugespitzten, einzelligen, aufwärts gerichteten Haaren bedeckt ist. Die Stiele der Tentakeln enthalten keine Spiralgefässe, ebensowenig finden sich irgend welche Spiralzellen innerhalb der Drüsen. Die Blätter entspringen häufig in Büscheln und sind fiederspaltig, wobei die Blättchen unter rechten Winkeln zu der mittleren linealen Scheibe.# Pflanzen und ihre Eigenschaften

entspringen. Diese seitlichen Blättchen sind oft sehr kurz und tragen nur einen einzigen endständigen Tentakel mit einem oder zwei kurzen an den Seiten. Zwischen den Stielen der langen endständigen Tentakeln und den bedeutend verschmälerten Enden der Blätter läszt sich keine bestimmte Grenzlinie ziehn. Wir können allerdings willkürlich hier den Punkt als solche herausgreifen, bis zu welchem sich die Spiralgefäsze von der Blattscheibe aus erstrecken; es ist aber keine andere Unterscheidungslinie vorhanden.

# Beobachtungen zu Insekten und Drüsen

Aus den vielen Schmutztheilchen, welche an den Drüsen hiengen, gieng offenbar hervor, dasz sie viel klebrige Substanz absondern. Auch eine grosze Zahl von Insecten von vielerlei Art hieng an den Blättern. Ich konnte nirgends irgend welche Zeichen dafür entdecken, dasz die Tentakeln über den gefangenen Insecten eingebogen worden wären; und dies wäre doch wahrscheinlich selbst an den getrockneten Exemplaren zu sehen gewesen, wenn sie Bewegungsvermögen besessen hätten. In diesem negativen Character ist daher Roridula ihrem nordischen Repräsentanten, Drosophyllum, ähnlich.

# Byblis gigantea

Byblis gigantea (West-Australien). — Ein getrocknetes, ungefähr 18 Zoll hohes Exemplar mit einem starken Stamm wurde mir von Kew geschickt. Die Blätter sind einige Zoll lang, linear, unbe-deutend abgeplattet, mit einer kleinen vorspringenden Rippe an der unteren Fläche. Sie sind von allen Seiten mit Drüsen von zweierlei Art bedeckt: — sitzende, welche in Reihen angeordnet sind, und andere von mäszig langen Stielen getragene. Nach den schmalen Enden der Blätter zu sind die Stiele länger als irgendwo anders, und sind hier dem Durchmesser der Blätter gleich.

# Struktur der Drüsen

Die Drüsen sind purpurn, bedeutend abgeplattet und werden von einer einzigen Schicht strahlenförmig angeordneter Zellen gebildet, welche in den gröszeren Drüsen vierzig bis fünfzig an Zahl sind. Die Stiele bestehn aus einzelnen verlängerten Zellen mit farblosen, äuszerst zarten Wandungen, welche mit den feinsten sich kreuzenden Linien gezeichnet sind. Ob diese Linien das Resultat einer Zusammenziehuug durch das Eintrocknen der Wände ist, weisz ich nicht; häufig war aber der ganze Stiel spiral aufgerollt. Diese drüsigen Haare sind weit einfacher in ihrem Bau als die sogenannten Tentakeln der vorher erwähnten Gattungen und weichen nicht wesentlich von denen ab, welche von unzähligen anderen Pflanzen getragen werden.

# Blütenstiele und Insektenfang

Die Blüthenstiele tragen ähnliche Drüsen. Der eigenthümlichste Character an den Blättern ist der, dasz die Spitze zu einem kleinen mit Drüsen bedeckten Knopfe erweitert ist, welcher ungefähr um ein Drittel breiter ist als der daran-stoszende Theil des verschmälerten Blattes. An zwei Stellen hiengen todte Fliegen an den Drüsen. Da kein Beispiel bekannt ist, dasz einzellige Bildungen Bewegungsvermögen besäszen, so fängt Byblis ohne Zweifel die Insecten lediglich mit Hülfe ihres klebrigen Secrets.

# Absorptionsvermögen der Drüsen

Zusätzliche Bemerkungen über das Absorptionsvermögen der drüsigen Haare andrer Pflanzen. — Einige wenige Beobachtungen über diesen Gegenstand dürften passenderweise hier eingeführt werden. Da die Drüsen vieler, wahrscheinlich aller Species der Droseraceen, verschiedene Flüssigkeiten absorbiren, oder mindestens gestatten, dasz dieselben leicht eindringen. Der Unterschied zwischen echter Absorption und bloszer Durchdringung oder Imbibition ist durchaus nicht klar erkannt; so schien es wünschenswerth zu sein, zu ermitteln, wie weit die Drüsen andrer Pflanzen, welche nicht speciell zum Fangen von Insecten eingerichtet sind, dasselbe Vermögen haben. Es wurden ganz nach Zufall Pflanzen versucht, mit Ausnahme zweier Species von Saxifraga, welche.# Einleitung
deshalb gewählt wurden, weil sie zu einer mit den Droseraceen verwandten Familie gehören.

# Versuche mit Drüsen
Die meisten Versuche wurden so ange-stellt, dasz die Drüsen entweder in einen Aufgusz von rohem Fleisch oder noch gewöhnlicher in eine Lösung von kohlensaurem Ammoniak eingetaucht wurden, da diese letztere Substanz so kraftvoll und schnell auf das Protoplasma wirkt.

# Absorption und Sekretion
Es schien auch besonders wünschenswerth zu sein zu ermitteln, ob Ammoniak absorbirt würde, da eine geringe Menge im Regenwasser enthalten ist.

# Drüsen und ihre Funktionen
Bei den Drosera-ceen verhindert die Absonderung einer klebrigen Flüssigkeit durch die Drüsen nicht deren Absorption, so dasz die Drüsen anderer Pflanzen wohl überflüssige Substanz ausscheiden oder eine riechende Flüssigkeit als Schutzmittel gegen die Angriffe von Insecten oder zu irgend einem andern Zwecke absondern, und doch das Vermögen zu absorbiren haben könnten.

# Schwierigkeiten bei Experimenten
Ich bedaure, dasz ich in den folgenden Fällen nicht versucht habe, ob das Secret animale Substanz verdauen oder löslich machen kann; derartige Versuche würden aber wegen der geringen Grösze der Drüsen und der geringen Menge Secret schwierig gewesen sein.

# Pinguicula und ihre Eigenschaften
Wir werden im nächsten Capitel sehen, dasz das Secret von den drüsigen Haaren der Pinguicula sicher animale Substanz auflöst.

# Saxifraga umbrosa
Saxifraga umbrosa. — Die Blüthenstengel und Blattstiele sind mit kurzen Haaren bekleidet, welche rosa gefärbte Drüsen tragen, die aus mehreren polygonalen Zellen gebildet sind und deren Stiele durch Scheide-wände in einzelnen Zellen abgetheilt sind; diese sind meistens farblos, aber zuweilen rosa.

# Insektenfänge bei Saxifraga
Die Drüsen sondern eine gelbliche klebrige Flüssig-keit ab, mit welcher zuweilen, wennschon nicht häufig, sehr kleine Dip-tern gefangen werden.

# Beobachtungen zu Saxifraga tridactylites
In Bezug auf Saxifraga tridactylites sagt Druce (Pharmaceutical Journal, May, 1875), dasz er einige Dutzend Pflanzen untersucht und beinahe in jedem einzelnen Falle Reste von Insecten an den Blättern hängend gefunden habe.

# Protoplasma und seine Veränderungen
Die Zellen der Drüsen enthalten hell rosa Flüssig-keit, welche mit Körnchen oder kugligen Massen blaszröthlicher breiiger Substanz dicht erfüllt ist.

# Experimentelle Beobachtungen
Ein, noch mit der Pflanze zusammenhängender Blüthenstengel wurde (29. Mai) so gebogen, dasz er 23 Stunden 30 Minuten in einem starken Aufgusz von rohem Fleisch eingetaucht blieb.

# Farbveränderungen und Zellinhalt
Die Farbe des Inhalts der Drüsen war unbedeutend verändert, indem er jetzt von einem trüberen und mehr purpurartigen Farbenton war wie vorher.

# Bewegungen des Protoplasmas
Kurz, die Bewegungen waren genau gleich denen, welche bei der Drosera beschrieben wurden.

# Absorptions-Vermögen
Die Zellen der Stiele wurden durch den Aufgusz nicht afficirt, ebenso-wenig wurden sie es in dem folgenden Versuche.

# Weitere Experimente
Ein anderer Blüthenstengel wurde in derselben Weise gebogen und eben so lange in eine Lösung von einem Theile salpetersauren Ammoniaks.# Experimentelle Beobachtungen

auf 146 Theile Wasser (oder ein Gran auf 1 Unze) getaucht; die Drüsen wurden in genau derselben Art und Weise entfärbt, wie durch den Aufgusz rohen Fleisches. Ein anderer Blüthenstengel wurde ganz wie früher in eine Lösung von einem Theile kohlensauren Ammoniaks auf 109 Theile Wasser ge- taucht. Die Drüsen waren nach 1 Stunde 30 Minuten nicht entfärbt, aber nach 3 Stunden 45 Minuten waren die meisten schmutzig purpurn, einige von ihnen schwärzlich-grün geworden; einige wenige waren noch gar nicht afficirt. Es wurde beobachtet, dasz die kleinen Protoplasma- Massen innerhalb der Zellen in Bewegung waren. Die Zellen der Stiele waren unverändert. Der Versuch wurde wiederholt; ein frischer Blüthen- stengel wurde 23 Stunden lang in der Lösung gelassen und nun wurde ein bedeutender Effect hervorgebracht. Alle Drüsen waren bedeutend ge- schwärzt und die vorher durchsichtige Flüssigkeit in den Zellen der Stiele, selbst bis hinab zu ihren Basen, enthielten sphärische Massen körniger Substanz. Aus einer Vergleichung vieler verschiedener Haare gieng offen- bar hervor, dasz die Drüsen zuerst das kohlensaure Ammoniak absorbiren, und dasz der hierdurch bewirkte Effect von Zolle zu Zelle die Haare hinabgeht. Die erste Veränderung, welche beobachtet werden konnte, war ein wolkiges Aussehen der Flüssigkeit in Folge der Bildung sehr feiner Körnchen, welche sich später zu gröszeren Massen zusammenballen. Im Ganzen genommen besteht in dem Dunkelwerden der Drüsen und in dem Hinabgehen des Zusammenballungsprocesses die Zellen der Stiele hinunter die gröszte Ähnlichkeit zu dem, was stattfindet, wenn ein Ten- takel der Drosera in eine schwache Lösung desselben Salzes eingetaucht wird. Die Drüsen absorbiren aber viel langsamer als die der Drosera. Auszer den Drüsen-Haaren sind noch sternförmige Organe vorhanden, welche nicht abzusondern scheinen und welche durch die obigen Lösungen nicht im mindesten afficirt wurden.

# Wirkung des kohlensauren Ammoniaks

Obschon das kohlensaure Ammoniak in den Versuchen mit den un- verletzten Blüthenstengeln und Blättern nur durch die Drüsen aufgesaugt zu werden scheint, so tritt es doch durch eine Schnittfläche viel schneller ein als durch eine Drüse. Rindenstreifen eines Blüthenstiels wurden ab- gerissen, und man konnte sehen, dasz die Zellen der Drüsenstiele nur farblose durchscheinende Flüssigkeit enthielten, die der Drüsen enthielten wie gewöhnlich etwas körnige Substanz. Die Streifen wurden nun in dieselbe Lösung wie vorher gethan (ein Theil kohlensauren Ammoniaks auf 109 Theile Wasser), und in wenig Minuten erschien körnige Substanz in den unteren Zellen aller Stiele. Die Wirkung begann ausnahms- los (denn ich wiederholte den Versuch mehreremale) in den untersten Zellen, und daher dicht an der abgerissenen Oberfläche, und gieng dann allmählich in den Haaren aufwärts, bis sie die Drüsen erreichte, in um- gekehrter Richtung also zu der, welche in unverletzten Exemplaren statt- findet. Die Drüsen wurden dann entfärbt und die vorher in ihren Zellen vorhanden gewesene körnige Substanz wurde zu gröszeren Massen zu- Drüsen-Haare.

# Untersuchung der Drüsen

Es wurden auch zwei kurze Stückchen eines Blüthen- stengels 2 Stunden 40 Minuten lang in einer schwächeren Lösung von einem Theile des kohlensauren Ammoniaks auf 218 Theile Wasser liegen gelassen; in beiden Exemplaren enthielten nun die Stieltheile der Haare in der Nähe der abgeschnittenen Enden viel körnige Substanz und die Drüsen waren vollständig entfärbt. Endlich wurden Stückchen Fleisch auf einige Drüsen gelegt; die- selben wurden nach 23 Stunden untersucht, ebenso wie andere, welche allem Anscheine nach nicht lange erst sehr kleine Fliegen gefangen hatten; sie boten aber durchaus keine Verschiedenheit von den Drüsen anderer Haare dar. Vielleicht war nicht Zeit genug vorhanden zur Absorption. Ich glaube dies deshalb, weil einige Drüsen, auf denen todte Fliegen offenbar schon lange gelegen hatten, von einer blassen schmutzig pur- purnen Färbung oder selbst farblos waren und die körnige Substanz innerhalb derselben ein ungewöhnliches und etwas eigenthümliches An- sehen darboten. Dasz diese Drüsen wahrscheinlich durch Exosmose in die klebrige Absonderung animale Substanz aus den Fliegen aufgesaugt hatten, können wir nicht allein aus ihrer veränderten Färbung, sondern# Einleitung zur Untersuchung der Drüsen

auch daraus schlieszen, dasz einige der Zellen in den Stielen, als das Präparat in eine Lösung von kohlensaurem Ammoniak gelegt wurde, mit körniger Substanz erfüllt wurden, während die Zellen anderer Haare, welche keine Fliegen gefangen hatten, nachdem sie ebenso lange Zeit mit derselben Lösung behandelt worden waren, nur eine geringe Menge körniger Substanz enthielten. Es sind aber noch weitere Beweise nöthig, ehe wir vollständig zugeben können, dasz die Drüsen der Saxifraga selbst unter Gestattung reichlicher Zeit aus den minutiösen Insecten, welche sie gelegentlich und zufällig fangen, animale Substanz absorbiren können.

# Saxifraga rotundifolia

Saxifraga rotundifolia (?). — Die Haare an den Blüthenstengeln dieser Species sind viel länger als die eben beschriebenen und tragen braune Drüsen. Es wurden viele untersucht; die Zellen der Stiele waren völlig durchscheinend. Ein gebogener Stamm wurde 30 Minuten lang in eine Lösung von einem Theile kohlensauren Ammoniaks auf 109 Theile Wasser eingetaucht, und zwei oder drei der obersten Zellen in den Stielen enthielten nun körnige oder zusammengeballte Substanz; die Drüsen waren nun hell gelblich-grün geworden. Es absorbiren daher die Drüsen dieser Species das kohlensaure Salz viel schneller, als es die der Saxifraga umbrosa thun, und auch die oberen Zellen der Stiele werden viel schneller afficirt. Stücke des Stammes wurden abgeschnitten und in dieselbe Lösung eingetaucht; und nun gieng der Procesz der Zusammenballung die Haare in umgekehrter Richtung hinauf, wobei die Zellen dicht an der Schnittfläche zuerst afficirt wurden.

# Primula sinensis

Primula sinensis. — Die Blüthenstengel, die obere und die untere Fläche der Blätter und ihre Stiele sind sämmtlich mit einer Menge von längeren und kürzeren Haaren bekleidet. Die Stieltheile der längeren Haare sind durch quere Scheidewände in acht oder neun Zellen getheilt. Die vergrösserte endständige Zelle ist kuglig und bildet eine Drüse, welche eine schwankende Menge einer dicken, unbedeutend klebrigen, nicht sauren, bräunlich-gelben Substanz absondert.

# Absorptions-Vermögen

Cap. 15. Absorptions-Vermögen. Ein Stück eines jungen Blüthenstengels wurde zuerst 2 Stunden 30 Minuten lang in destillirtes Wasser getaucht; davon wurden die drüsi- gen Haare durchaus nicht afficirt. Ein anderes, fünfundzwanzig kurze und neun lange Haare tragendes Stück wurde sorgfältig untersucht. Die Drüsen dieses letzteren enthielten keine feste oder halbfeste Substanz; und nur die von zweien der fünfundzwanzig kurzen Haare enthielten einige Körnchen. Das Stück wurde dann zwei Stunden lang in eine Lösung von einem Theil kohlensauren Ammoniaks auf 109 Theile Wasser gethan, und nun enthielten die Drüsen der fünfundzwanzig kürzeren Haare mit zwei oder drei Ausnahmen entweder eine grosze sphärische Masse oder von zwei bis fünf kleine Massen halbfester Substanz. Drei von den Drüsen der neun längeren Haare enthielten gleichfalls ähnliche Massen. An einigen wenigen Haaren fanden sich auch Kügelchen in den Zellen unmittelbar unterhalb der Drüsen. Betrachtet man alle vierunddreiszig Haare, so konnte kein Zweifel bestehen, dasz die Drüsen etwas von dem kohlensaurem Ammoniak aufgesaugt hatten. Ein anderes Stück wurde nur 1 Stunde lang in derselben Lösung gelassen, und in allen Drüsen erschien zusammengeballte Substanz. Mein Sohn Francis untersuchte einige Drüsen der längeren Haare, welche kleine Substanzmassen enthielten, ehe sie in irgend eine Lösung gethan wurden; diese Massen veränderten langsam ihre Form, so dasz sie ohne Zweifel aus Protoplasma bestanden. Er befeuchtete dann diese Haare 1 Stunde 15 Minuten lang, während sie unter dem Mikroskop waren, mit einer Lösung von einem Theil kohlensauren Ammoniaks auf 218 Theile Wasser; die Drüsen wurden nicht wahrnehmbar afficirt, auch konnte dies nicht erwartet werden, da ihr Zelleninhalt bereits zusammengeballt war. Aber in den Zellen der Stiele erschienen zahlreiche, beinahe farblose Kugeln von Substanz, welche ihre Form änderten und langsam verschmolzen; das Aussehen der Zellen wurde daher in aufeinander folgenden Zeitabschnitten gänzlich verändert. Die Drüsen an einem jungen Blüthenstengel enthielten, nachdem sie 2 Stunden 45 Minuten lang in einer starken Lösung von einem Theile kohlensauren Ammoniaks auf 109 Theile Wasser liegen gelassen worden# Experimentelle Beobachtungen

waren, eine bedeutende Menge zusammengeballter Massen; ob dieselben
aber durch Einwirkung des Salzes entstanden waren, weisz ich nicht. Dies
Stück wurde nochmals in die Lösung getaucht, so dasz es im Ganzen
6 Stunden 15 Minuten eingetaucht war, und nun war eine grosze Ver-
änderung zu bemerken; denn beinahe alle die sphärischen Massen inner-
halb der Drüsenzellen waren verschwunden und waren durch körnige Sub-
stanz von einem dunkleren Braun ersetzt. Dieser Versuch wurde dreimal
wiederholt mit nahezu demselben Resultat. Bei einer Gelegenheit wurde
das Stengelstück 8 Stunden 30 Minuten eingetaucht gelassen, und ob-
gleich beinahe alle sphärische Massen in die braune körnige Substanz
verwandelt worden waren, so blieben doch noch einige wenige übrig.
Wenn die sphärischen Massen zusammengeballter Substanz ursprünglich
blosz durch irgend eine chemische oder physikalische Einwirkung hervor-
gebracht worden wären, so würde es befremdlich erscheinen, dasz ein
etwas längeres Eintauchen in dieselbe Lösung ihren Character so voll-
ständig verändern sollte. Da aber die Massen, welche langsam und ganz
von selbst ihre Form änderten, aus lebendigem Protoplasma bestanden
haben müssen, so liegt darin nichts überraschendes, dasz sie durch ein
langes Eintauchen in eine so starke Lösung des kohlensauren Salzes, wie
die angewandte, verletzt oder getödtet werden und dasz dadurch ihr Aus-
sehen gänzlich verändert wird. Eine Lösung von dieser Stärke lähmt bei
der Drosera jede Bewegung, aber tödtet das Protoplasma nicht; eine
noch stärkere Lösung verhindert die Zusammenballung des Protoplasma
zu den gewöhnlichen kugligen Massen der gehörigen Grösse und diese
werden, wenn sie auch nicht zerfallen, granulös und undurchsichtig. In
nahezu derselben Weise bewirken auch heiszes Wasser und gewisse Lösun-
gen (so z. B. von Natron- und Kali-Salzen) zuerst eine unvollkommene Art
von Zusammenballung in den Zellen der Drosera; die kleinen Massen zer-
theilen sich später zur Bildung körniger oder breiiger brauner Substanz.
Alle die vorstehend angeführten Versuche wurden an Blüthenstengeln ge-
macht; es wurde aber auch ein Stück von einem Blatte 30 Minuten lang
in eine starke Lösung des kohlensauren Ammoniaks (ein Theil auf 109
Theile Wasser) |eingelegt, und nun erschienen in allen Drüsen, welche
vorher nur klare Flüssigkeit enthalten hatten, kleine kuglige Massen von
Substanz.

# Wirkung des Dampfes

Ich machte auch mehrere Versuche über die Wirkung des Dampfes
der kohlensauren Salzlösung auf die Drüsen, will aber nur einige wenige
Fälle mittheilen. Das abgeschnittene Ende des Stieles eines jungen
Blattes wurde mit Siegellack bedeckt und das Blatt dann mit einer kleinen
Prise kohlensauren Ammoniaks unter eine kleine Glasglocke gelegt. Nach
10 Minuten lieszen die Drüsen einen beträchtlichen Grad von Zusammen-
ballung erkennen und das die Stielzellen auskleidende Protoplasma war
ein wenig von den Wandungen gelöst. Ein anderes Blatt wurde 50 Mi-
nuten lang mit demselben Resultat eingelegt, ausgenommen, dasz die
Haare in ihrer ganzen Länge bräunlich wurden. An einem dritten Blatte,
welches 1 Stunde 50 Minuten dem Dampfe ausgesetzt wurde, fand sich
viel zusammengeballte Substanz in den Drüsen; und einige von den
Massen lieszen Anzeichen einer Zertheilung in braune körnige Substanz
erkennen. Das Blatt wurde noch einmal in den Dampf gelegt, so dasz
es ihm im Ganzen 5 Stunden 30 Minuten ausgesetzt wurde; und obschon
ich eine grosze Anzahl von Drüsen untersuchte, fanden sich zusammenge-
ballte Massen doch nur in zweien oder dreien; in allen übrigen waren
die Massen, welche vorher kuglig gewesen waren, in braune, undurch-
sichtige, körnige Substanz umgewandelt. Wir sehen hieraus, dasz, wenn
die Blätter eine ansehnliche Zeit lang dem Dampfe ausgesetzt werden,
dies dieselben Wirkungen hervorbringt wie ein langes Eintauchen in eine
starke Lösung. In beiden Fällen konnte kaum bezweifelt werden, dasz
das Salz hauptsächlich oder ausschlieszlich von den Drüsen absorbirt
worden war.

# Weitere Experimente

Bei einer anderen Gelegenheit wurden Stückchen feuchten Fibrins,
Tropfen eines schwachen Aufgusses von rohem Fleisch und von Wasser
24 Stunden lang auf einigen Blättern gelassen; die Haare wurden dann
untersucht, sie waren aber zu meiner Überraschung in keiner Hinsicht# Kapitel 15: Absorptions-Vermögen

## Pelargonium zonale

## Erica tetralix

## Mirabilis longiflora# Beobachtungen über Drüsen-Haare

kurz, von ungleicher Länge, werden aus einer einzigen Reihe von Zellen gebildet und von einer vergröszerten Zelle überragt, welche klebrige Substanz absondert. Diese endständigen Zellen oder Drüsen enthalten Körnchen und häufig Kugeln von körniger Substanz. Innerhalb einer Drüse, welche ein kleines Insect gefangen hatte, wurde eine derartige Masse beobachtet, welche unaufhörliche Formveränderungen erlitt; dabei traten gelegentlich Vacuolen auf. Ich glaube aber nicht, dasz dieses Protoplasma aus Substanz entstanden war, die aus dem todten Insect absorbirt wor­den war; denn als mehrere Drüsen mit einander verglichen wurden, welche Insecten gefangen und welche keine gefangen hatten, konnte nicht eine Spur von Verschiedenheit zwischen ihnen wahrgenommen werden; sie ent­hielten sämmtlich feine körnige Substanz. Ein Blattstück wurde 24 Stun­den lang in eine Lösung von einem Theil kohlensauren Ammoniaks auf 218 Theile Wasser eingelegt, aber die Haare schienen von ihr sehr wenig afficirt zu werden, ausgenommen, dasz vielleicht die Drüsen etwas un­durchsichtiger gemacht wurden. Im Blatte selbst waren indessen in der Nähe der Schnittflächen die Chlorophyllkörner in einander gelaufen, oder waren zusammengeballt. Ebensowenig waren die Drüsen an einem an­deren Blatte nach einem Eintauchen von 24 Stunden in einem Aufgusz von rohem Fleisch im mindesten afficirt; aber das die Zellen der Stiele auskleidende Protoplasma war bedeutend von den Wandungen abge­schrumpft. Diese letztere Wirkung könnte eine Folge der Exosmose ge­wesen sein, da der Aufgusz stark war. Wir können daher schlieszen, dasz die Drüsen dieser Pflanze entweder kein Absorptionsvermögen be­ sitzen oder dasz eine Lösung von kohlensaurem Ammoniak (und dies scheint kaum glaublich zu sein) oder ein Aufgusz von rohem Fleisch nicht auf das Protoplasma, was sie enthalten, einwirkt.

# Nicotiana tabacum

Diese Pflanze ist von unzähligen Haaren un­gleicher Länge bedeckt, welche viele minutiöse Insecten fangen. Die Stiele der Haare sind durch quere Scheidewände getheilt, und die ab­sondernden Drüsen werden aus vielen, grünliche Masse mit kleinen Kügel­chen irgend einer Substanz enthaltenden Zellen gebildet. Blätter wurden 26 Stunden lang in einem Aufgusz von rohem Fleisch und in Wasser gelassen, boten aber keine Verschiedenheiten dar. Einige von den nämlichen Blättern wurden dann länger als 2 Stunden in einer Lösung von kohlensaurem Ammoniak gelassen, es wurde aber keine Wirkung hervorgebracht. Ich bedaure, dasz nicht noch andere Versuche mit noch mehr Sorgfalt angestellt wurden, da Schloesing gezeigt hat, dasz mit dem Dampfe von kohlensaurem Ammoniak versehene Tabakspflanzen bei der Analyse eine gröszere Menge von Stickstoff ergeben als andere nicht so behandelte Pflanzen; und nach dem, was wir gesehen haben, ist es wahrscheinlich, dasz etwas von dem Dampfe von den drüsigen Haaren absorbirt worden sein könnte.

# Zusammenfassung der Beobachtungen über Drüsen-Haare

Aus den vorstehenden Beobachtungen, so wenig es auch sind, sehen wir, dasz die Drüsen von zwei Arten von Saxifraga, einer Primula und eines Pelargonium das Vermögen rapider Aufsaugung besitzen, während die Drüsen einer Erica, Mirabilis und Nicotiana entweder diese Fähigkeit nicht haben, oder der Inhalt der Zellen von den angewandten Flüssigkeiten, nämlich einer Lösung von kohlen­saurem Ammoniak und einem Aufgusz von rohem Fleisch nicht afficirt wird. Da die Drüsen der Mirabilis Protoplasma enthalten, welches, als es der Einwirkung der oben genannten Flüssigkeiten ausgesetzt wurde, — trotzdem dasz der Inhalt der Zellen in der Blattscheibe durch das kohlensaure Ammoniak bedeutend afficirt wurde, — nicht zusammengeballt wurde, so dürfen wir wohl schlieszen, dasz sie nicht absorbiren können. Wir dürfen ferner folgern, dasz die unzähligen von dieser Pflanze gefangenen Insecten ihr von keinem weiteren Nutzen sind, als es die sind, welche den hinfälligen und klebrigen Schuppen der Blattknospen der Roszkastanie anhängen. Der für uns interessanteste Fall ist der der zwei Species von# Einleitung zur Gattung Saxifraga

Saxifraga, da diese Gattung entfernt mit Drosera verwandt ist. Ihre Drüsen absorbiren Substanz aus einem Aufgusz von rohem Fleisch, aus Lösungen des salpetersauren und kohlensauren Ammoniaks und dem Anscheine nach aus zerfallenden Insecten. Dies gieng hervor aus der veränderten schmutzig purpurnen Färbung des Protoplasma innerhalb der Zellen der Drüsen, aus seinem zusammengeballten Zustand und allem Anscheine nach aus seinen rapideren selbständigen Bewegungen. Der Procesz der Zusammenballung breitet sich von der Drüse die Stiele der Haare hinab aus; nnd wir dürfen annehmen, dasz eine jede Substanz, welche absorbirt worden ist, schlieszlich die Gewebe der Pflanzen erreicht. Andererseits geht derselbe Procesz die Haare hinauf, sobald nur immer eine Fläche durchschnitten ist und einer Lösung von kohlensaurem Ammoniak ausgesetzt wird.

# Drüsen-Haare und ihre Funktion

Die Drüsen an den Blüthenstengeln und Blättern der Primula sinensis absorbiren schnell eine Lösung von kohlensaurem Ammoniak, und das Protoplasma, welches sie enthalten, wird zusammengeballt. In einigen Fällen sah man, dasz der Procesz von den Drüsen aus in die oberen Zellen der Stiele hinaufgieng. Wurden die Drüsen 10 Minuten dem Dampfe dieses Salzes ausgesetzt, so bewirkte auch dies Zusammenballung. Wenn Blätter von 6 bis 7 Stunden in einer starken Lösung gelassen oder dem Dampfe ausgesetzt wurden, so wurden die kleinen Massen von Protoplasma zersetzt, wurden braun und körnig, und waren offenbar getödtet. Ein Aufgusz von rohem Fleisch brachte keine Wirkung auf die Drüsen hervor.

# Beobachtungen zu Pelargonium zonale

Der klare Inhalt der Drüsenzellen von Pelargonium zonale wurde in einer Zeit von 3 bis 5 Minuten wolkig und körnig, wenn sie in eine schwache Lösung von kohlensaurem Ammoniak eingetaucht wurden, und im Verlauf von 1 Stunde erschienen Körnchen in den oberen Zellen der Drüsenstiele. Da die zusammengeballten Massen langsam ihre Form veränderten und da sie Zersetzung erlitten, wenn sie beträchtliche Zeit lang in einer starken Lösung liegen gelassen wurden, so kann kaum bezweifelt werden, dasz sie aus Protoplasma bestanden. Es ist zweifelhaft, ob ein Aufgusz von rohem Fleisch irgend welche Wirkung hervorbrachte.

# Physiologische Betrachtungen

Die drüsigen Haare gewöhnlicher Pflanzen sind allgemein von Physiologen so angesehen worden, als fungirten sie nur als absondernde oder aussondernde Organe; wir wissen aber, dasz sie, wenigsten in einigen Fällen, das Vermögen besitzen, eine Lösung und den Dampf von Ammoniak zu absorbiren. Da Regenwasser einen unbe- deutenden Procentsatz von Ammoniak und die Atmosphäre eine äuszerst geringe Menge von Kohlensäure enthält, so ist es kaum anders zu erwarten, als dasz jenes Vermögen der Pflanze vortheilhaft ist. Auch kann der Vortheil nicht völlig so unbedeutend sein, als man auf den ersten Blick glauben möchte; denn eine mäszig schöne Pflanze von Primula sinensis trägt die staunenerregende Zahl von über zwei und einer halben Million drüsiger Haare.

# Zählung der Drüsenhaare

Mein Sohn Francis zählte die Haare auf einem mittelst des Micrometers gemessenen Raume und fand, dasz auf einem Quadratzoll der oberen Fläche eines Blattes 35336 und auf der unteren Fläche 30035 standen; d. h. also ungefähr in dem Verhältnis von 100 auf der oberen zu 85 auf der unteren Fläche. Auf einem Quadratzoll beider Flächen standen 65371 Haare. Eine mäszig schöne Pflanze, welche zwölf Blätter trug (von denen die gröszeren ein wenig mehr als 2 Zoll im, welche sämmtlich im Stande sind, ihnen durch den Regen zugeführtes Ammoniak zu absorbiren.

# Schlußbemerkungen über die Droseraceen

Es ist überdies noch wahrscheinlich, dasz die Drüsen einiger der oben genannten Pflanzen animale Substanz aus den Insecten erlangen, welche sich gelegentlich in der klebrigen Flüssigkeit fangen. Die sechs bekannten Gattungen, welche diese Familie bilden, sind nun in Bezug auf unsern vorliegenden Gegenstand beschrieben worden, so weit meine Mittel es gestattet haben. Sie fangen alle Insec- ten. Dies wird bei Drosophyllum, Roridula und Byblis allein durch# Bewegungen und Mechanismen der Pflanzen

die von ihren Drüsen abgesonderte klebrige Flüssigkeit bewirkt,
bei Drosera durch dasselbe Mittel zusammen mit den Bewegungen
der Tentakeln, bei Dionaea und Aldrovanda durch das Schlieszen der
Blattlappen. In diesen beiden letztgenannten Gattungen ersetzt rapide
Bewegung den Verlust des klebrigen Secrets. In allen Fällen ist es
aber irgend ein Theil des Blattes, welcher sich bewegt. Bei Aldro-
vanda scheinen es allein die basalen Theile zu sein, welche sich zu-
sammenziehn und die breiten, dünnen Ränder der Blattlappen mit
sich ziehn. Bei Dionaea krümmt sich der ganze Lappen, mit Aus-
nahme der randständigen Verlängerungen oder Speichen, einwärts,
obschon der hauptsächliche Sitz der Bewegung in der Nähe der
Mittelrippe liegt. Bei Drosera liegt der hauptsächliche Sitz im un-
teren Theile der Tentakeln, welche, der Homologie nach, als Ver-
längerungen des Blattes angesehen werden können; aber häufig rollt
sich auch die ganze Scheibe einwärts und verwandelt das Blatt in
einen temporären Magen.

# Pflanzen und ihre Drüsen

Es läszt sich kaum bezweifeln, dasz alle zu diesen sechs Gat-
tungen gehörenden Pflanzen das Vermögen haben, mit Hülfe ihres
Secrets, welches eine Säure und zusammen damit ein seiner Natur
Durchmesser maszen) wurde nun ausgewählt und die Oberfläche aller Blätter zu-
sammen mit ihren Stielen (ohne Einschlusz der Blüthenstengel) mittelst eines
Planimeters als 39,285 Quadratzoll grosz ermittelt, so dasz der Flächeninhalt
bei-
der Oberflächen 78,75 Quadratzoll betrug. Es musz hiernach die Pflanze (mit
Ausschlusz der Blüthenstengel, die staunenerregende Zahl von 2,568,099 drüsiger
Haare getragen haben. Die Haare wurden spät im Herbste gezählt; und im fol-
genden Frühjahre (Mai) fand sich, dasz die Blätter einiger andern Pflanzen der-
selben Sammlung von ein Viertel bis ein Drittel breiter und länger als früher
waren, so dasz auch ohne Zweifel die drüsigen Haare an Zahl zugenommen hatten
und wahrscheinlich nun weit über drei Millionen betrugen.

# Verdauung und Nahrungsaufnahme

nach mit dem Pepsin beinahe identisches Ferment enthält, animale
Substanz aufzulösen, und dasz sie später die in dieser Weise verdaute
Substanz absorbiren. Dies ist sicher bei Drosera, Drosophyllum und
Dionaea, beinahe sicher bei Aldrovanda, und der Analogie nach sehr
wahrscheinlich bei Roridula und Byblis der Fall. Wir können hier-
nach einsehen, woher es kommt, dasz die drei zuerst genannten Gat-
tungen mit so kleinen Wurzeln versehen sind, und dasz Aldrovanda
völlig wurzellos ist; in Bezug auf die Wurzeln der andern beiden
Gattungen ist nichts bekannt. Es ist ohne Zweifel eine überraschende
Thatsache, dasz eine ganze Gruppe von Pflanzen (und, wie wir gleich
sehen werden, einige andere, nicht mit den Droseraceen verwandte
Pflanzen) zum Theil sich dadurch erhalten, dasz sie animale Substanz
verdauen und zum Theil dadurch, dasz sie Kohlensäure zersetzen,
statt ausschlieszlich durch das letzte Mittel zu leben in Verbindung
mit der Absorption von Substanz aus dem Boden mittelst der Wur-
zeln.

# Anomalien im Tierreich

Wir haben indessen einen in gleicher Weise anomalen Fall im
Thierreich; die rhizocephalen Krustenthiere ernähren sich nicht wie
andere Thiere durch den Mund, denn ihnen fehlt ein Darmcanal, son-
dern sie leben so, dasz sie mittelst wurzelartiger Fortsätze die Säfte
der Thiere, auf welchen sie Parasiten sind, absorbirenFritz Müller,
Für Darwin. Leipzig, 1864. p. 63. Die Wurzelfüszer sind
mit den Rankenfüszern verwandt. Es ist kaum möglich, sich einen gröszern Un-
terschied vorzustellen als den zwischen einem Thiere mit greifenden Gliedmaszen,
einem gut gebildeten Mund und Nahrungscanal, und einem, welchem alle diese
Teile fehlen, und welches sich durch Aufsaugung mittelst verästelter wurzel-
artiger Fortsätze ernährt. Wenn ein seltner Cirripede, Anelasma squalicola,
extinct
geworden wäre, so würde es sehr schwierig gewesen sein zu vermuthen, auf welche
Weise eine so enorme Veränderung allmählich bewirkt worden sein könnte. Wir
haben aber, wie Fritz Müller bemerkt, in Anelasma ein Thier vor uns, wel-
ches sich in einem beinahe genau intermediären Zustand befindet; denn seine
wurzelartigen Fortsätze sind in der Haut des Haies eingebettet, auf dem es para-# Pflanzen und ihre Anpassungen

sitisch lebt, und seine prehensilen Cirren und sein Mund (in meiner Monographie der Lepadiden, Ray Society, 1851, p. 169, beschrieben) sind in einem äusserst schwachen und rudimentären Zustand. Dr. R. Kossmann hat eine sehr interessante Erörterung über diesen Gegenstand gegeben in seinen „Suctoria und Lepadidae‟, 1873. S. auch Dohrn, Der Ursprung der Wirbelthiere, 1875, p. 77.

# Die Gattung Drosera

Von den sechs Gattungen ist Drosera ganz ausser allem Vergleich die erfolgreichste in dem Kampfe um’s Dasein gewesen, und ein groszer Theil ihres Erfolges kann der Art und Weise zugeschrieben werden, wie sie Insecten fängt. Es ist eine herrschende Form, Cap. 15. über die Droseraceen. denn es wird angenommen, dasz sie ungefähr 100 Arten umfaszt Bentham and Hooker, Genera Plantarum. Australien ist der Mittelpunkt der Gattung, indem, wie mir Prof. Oliver mittheilt, einundvierzig Arten von dort beschrieben sind.

# Verbreitung der Gattungen

welche in der Alten Welt von den arctischen Gegenden bis nach dem südlichen Indien, nach dem Vorgebirge der Guten Hoffnung, Madagascar und Australien, und in der Neuen Welt von Canada bis zum Feuerlande verbreitet sind. In dieser Beziehung bietet sie einen auffallenden Gegensatz zu den fünf andern Gattungen dar, welche allem Anscheine nach abnehmende Gruppen sind. Dionaea enthält nur eine einzige Species, welche auf einen Bezirk in Carolina beschränkt ist. Die drei Varietäten oder nahe verwandte Arten von Aldrovanda haben wie so viele Wasserpflanzen eine weitere Verbreitung von Central-Europa bis nach Bengalen und Australien. Drosophyllum hat nur eine Species, welche auf Portugal und Marocco beschränkt ist. Roridula und Byblis haben jede (wie ich von Prof. Oliver höre) zwei Species, die der ersten Gattung auf die westlichen Theile des Vorgebirgs der Guten Hoffnung, die der letztern auf Australien beschränkt.

# Die Bedrohung der Dionaea

Es ist eine befremdende Thatsache, dasz Dionaea, welche eine der am wundervollsten angepaszten Pflanzen im ganzen Pflanzenreiche ist, allem Anscheine nach auf dem Wege zum Erlöschen ist. Dies ist um so befremdender, als die Organe der Dionaea höher differenzirt sind als diejenigen der Drosera; ihre Filamente dienen ausschlieszlich als Gefühlsorgane, die Lappen zum Fangen von Insecten, und die Drüsen, wenn sie gereizt werden, zur Absonderung ebensowohl wie zur Aufsaugung, während bei Drosera die Drüsen allen diesen Zwecken dienen und absondern, ohne gereizt zu sein.

# Vergleich der Blattstrukturen

Wenn man die Structur der Blätter, den Grad ihrer Complication und ihre rudimentäre Theile in den sechs Gattungen mit einander vergleicht, so wird man zu der Schluszfolgerung geführt, dasz ihre gemeinsame elterliche Form an Characteren von Drosophyllum, Roridula und Byblis Theil hatte. Die Blätter dieser alten Form waren beinahe sicher linear, vielleicht getheilt, und trugen an ihren oberen und unteren Flächen Drüsen, welche die Fähigkeit der Absonderung und Aufsaugung hatten. Einige dieser Drüsen waren auf Stiele gestellt, andere waren beinahe sitzend, die letzteren sonderten nur ab, wenn sie durch die Absorption von stickstoffhaltiger Substanz gereizt wurden.

# Drüsenstrukturen und ihre Funktionen

Bei Byblis bestehn die Drüsen aus einer einzigen Zellenschicht, die von einem einzelligen Stiele getragen wird; bei Roridula haben sie eine complicirtere Structur und werden von Stielen getragen, welche aus mehreren Zellenreihen gebildet werden; bei Drosophyllum enthalten sie ferner Spiralzellen und die Stiele umschlieszen ein Bündel von Spiralgefäszen. Aber in diesen drei Gattungen besitzen diese Organe kein Bewegungsvermögen, und es besteht kein Grund, daran zu zweifeln, dasz sie hier die Natur von Haaren oder Trichomen haben. Obgleich sich blattartige Organe in unzähligem Fällen bewegen, wenn sie gereizt werden, so ist doch kein Fall von einem Trichom bekannt, was eine derartige Fähigkeit hätte.

# Untersuchung der Tentakeln

Wir werden hierdurch veranlaszt, zu untersuchen, auf welche Weise die sogenannten Tentakeln der Drosera, welche offenbar von derselben allgemeinen Beschaffenheit sind wie die drüsigen Haare der obigen# Einleitung
drei Gattungen, das Vermögen sich zu bewegen erlangt haben können. Viele Botaniker behaupten, dasz diese Tentakeln aus Verlängerungen des Blattes bestehn, weil sie Gefäszgewebe einschlieszen; dies kann aber nicht länger als zuverlässiger Unterscheidungscharacter geltenDr. Warming, Sur la Différence entre les Trichomes etc. Copenhague, 1873. p. 6. Auszug aus den „Videnskab. Meddelelser fra de Naturhist. Forening. No. 10—12, 1872..

# Bewegungsvermögen und Tentakeln
Der Besitz des Bewegungsvermögens bei Reizung würde ein sichrerer Beweis gewesen sein. Wenn wir aber die ungeheure Anzahl von Tentakeln auf beiden Flächen der Blätter von Drosophyllum betrach-
ten, ebenso wie die auf der oberen Fläche der Blätter von Drosera, so scheint es kaum möglich zu sein, dasz jeder Tentakel ursprünglich als Verlängerung des Blattes existirt haben sollte. Roridula zeigt uns vielleicht, wie wir diese schwierigen Widersprüche in Bezug auf die Homologien der Tentakeln mit einander versöhnen.

# Homologien der Tentakeln
Die seitlichen Abschnitte der Blätter dieser Pflanze enden in langen Tentakeln, und diese umschlieszen Spiralgefäsze, welche sich nur eine kurze Strecke weit in ihnen hinauf erstrecken, ohne eine Trennungslinie zwischen dem, was deutlich die Verlängerung des Blattes ist, und dem Stiele eines drüsigen Haares. Es würde daher nichts Anomales oder Unge-
wöhnliches darin liegen, wenn der basale Theil dieser Tentakeln, welche den randständigen Tentakeln der Drosera entsprechen, das Vermögen sich zu bewegen erlangte; und wir wissen, dasz es bei Drosera nur der untere Theil ist, welcher eingebogen wird.

# Entwicklung der Tentakeln
Aber um nun noch zu verstehen, wie in dieser letzteren Gattung nicht blosz die randständigen, sondern auch alle inneren Tentakeln der Bewegung fähig geworden sind, müssen wir noch weiter annehmen, ent-
weder dasz dies Vermögen nach dem Principe der correlativen Ent-
wickelung auf die basalen Theile der Haare übertragen wurde, oder dasz die Oberfläche des Blattes an zahlreichen Punkten in Verlänger-
ungen ausgezogen worden ist, so dasz sie sich mit den Haaren ver-
band und damit die Basen der inneren Tentakeln bildete.

# Gattungen und ihre Merkmale
Die oben genannten drei Gattungen, nämlich Drosophyllum, Roridula und Byblis, welche einen ursprünglichen Zustand beibehal-
ten zu haben scheinen, tragen noch immer drüsige Haare auf beiden Oberflächen ihrer Blätter; aber die an der untern Fläche sind seitdem in den höher entwickelten Gattungen verschwunden, mit theilweiser Ausnahme einer Species, Drosera binata.

# Veränderungen in den Gattungen
Die kleinen sessilen Drüsen sind gleichfalls in einigen der Gattungen verschwunden; bei Roridula sind sie durch Haare und in den meisten Species von Drosera durch absorbirende Papillen ersetzt. Drosera binata findet sich mit ihren linearen und sich gablig theilenden Blättern auf einem intermediären Zustande. Sie trägt noch einige sitzende Drüsen auf beiden Flächen der Blätter und auf der untern Fläche einige wenige unregelmäszig gestellte Tentakeln, welche nicht fähig sind, sich zu bewegen.

# Evolution der Blätter
Eine weitere unbedeutende Veränderung würde die linearen Blätter dieser letztern Art in die oblongen Blätter der Drosera anglica verwandeln, und diese dürften dann leicht in kreisförmige mit Stielen übergehen, wie die der Drosera rotundifolia. Die Blattstiele dieser letztern Species tragen vielzellige Haare, von denen wir guten Grund haben anzunehmen, dasz sie fehlgeschlagene Tentakeln repräsentiren.

# Verwandtschaft der Gattungen
Die Stammform der Dionaea und Aldrovanda scheint mit Dro-
sera nahe verwandt gewesen zu sein, und runde, auf deutlichen Stielen getragene, und rings um ihren ganzen Umfang mit Tentakeln ver-
sehene Blätter besessen zu haben, welche letztere auch auf der oberen Fläche noch andere Tentakeln und sessile Drüsen gehabt haben.

# Schlussfolgerungen
Ich glaube dies deshalb, weil die randständigen Spitzen der Dionaea dem Anscheine nach die äuszersten randständigen Tentakeln, die sechs (zu-
weilen acht) empfindlichen Filamente auf der oberen Blattfläche, ebenso
wie die zahlreicheren bei Aldrovanda, die centralen Tentakeln der Drosera repräsentiren, deren Drüsen zwar fehlgeschlagen sind, deren
Empfindlichkeit aber erhalten worden ist. Von diesem Gesichtspunkte Schluszbemerkungen.# Einleitung zur Droseraceae

aus müssen wir noch im Auge behalten, dasz die Spitzen der
Tentakeln bei der Drosera, dicht unterhalb der Drüsen, empfind-
lich sind.

# Merkwürdige Eigenschaften der Droseraceae

Die drei merkwürdigsten Eigenthümlichkeiten, welche die ver-
schiedenen Glieder der Familie der Droseraceae darbieten, bestehen
darin, dasz die Blätter von einigen derselben die Fähigkeit haben,
sich zu bewegen, wenn sie gereizt werden; ferner darin, dasz ihre
Drüsen eine Flüssigkeit absondern, welche animale Substanz verdaut,
und endlich in der Absorption der verdauten Substanz. Kann irgend
welches Licht auf die Schritte geworfen werden, auf denen diese
merkwürdigen Fähigkeiten allmählich erlangt wurden?

# Absorption und Drüsenfunktion

Da die Zellwände nothwendigerweise für Flüssigkeiten durchgängig
sind, um den Drüsen zu gestatten abzusondern, so ist es nicht über-
raschend, dasz sie auch den Durchtritt von Flüssigkeiten nach innen
leicht gestatten; und dieser nach innen gerichtete Durchtritt würde
ein Act der Absorption genannt zu werden verdienen, wenn die
Flüssigkeiten sich mit dem Drüseninhalte verbänden. Nach den oben
angeführten Thatsachen zu urtheilen, können die absondernden Drüsen
vieler anderer Pflanzen Ammoniaksalze absorbiren, von welchen sie
aus dem Regenwasser geringe Mengen erhalten müssen. Dies ist der
Fall mit zwei Species von Saxifraga; und die Drüsen einer derselben
absorbiren augenscheinlich Substanz aus gefangenen Insecten und
sicher aus einem Aufgusz von rohem Fleisch. Es liegt daher nichts
Abnormes darin, dasz die Droseraceen das Absorptionsvermögen in
einem viel höher entwickelten Grade erlangt haben.

# Verdauungsfähigkeiten der Pflanzen

Es ist ein bei weitem merkwürdigeres Problem, wie die Glieder
dieser Familie, ferner Pinguicula, und, wie Dr. Hooker vor Kurzem
gezeigt hat, Nepenthes, alle das Vermögen erlangt haben dürften, eine,
animale Substanz auflösende oder verdauende Flüssigkeit abzusondern.
Die sechs Gattungen der Droseraceen haben diese Fähigkeit wahr-
scheinlich von einem gemeinsamen Urerzeuger ererbt; dies läszt sich
aber auf Pinguicula und Nepenthes nicht anwenden; denn diese Pflan-
zen sind durchaus nicht nahe mit den Droseraceen verwandt. Die
Schwierigkeit ist aber nicht annähernd so grosz, als sie auf den ersten
Blick erscheint.

# Chemische Prozesse in Pflanzen

Erstens enthalten die Säfte vieler Pflanzen eine Säure und allem Anscheine nach dient jede Säure zur Verdauung.
Zweitens sondern, wie Dr. Hooker mit Bezug auf den vorliegenden
Gegenstand in seiner Rede in Belfast (1874) bemerkt hat und wie
Cap. 15. über die Droseraceen.
Sachs wiederholt hervorhebtLehrbuch der Botanik, 4. Aufl. 1874, p. 688. Wegen
der folgenden That-
sachen s. auch p. 57, 63, 678, 679., die Embryonen einiger Pflanzen eine
Flüssigkeit ab, welche eiweiszartige Substanzen aus dem Endosperm
auflöst, obgleich das Endosperm nicht mit dem Embryo verbunden
ist, sondern nur mit ihm in Berührung steht. Überdies haben die
Pflanzen das Vermögen, eiweiszartige oder protëinartige Substanzen,
wie Protoplasma, Chlorophyll, Leim, Aleurone aufzulösen und sie von
einem Theil zu andern Theilen ihrer Gewebe fortzuschaffen. Dies
musz durch ein Auflösungsmittel bewirkt werden, was wahrscheinlich
aus einem Ferment in Verbindung mit einer Säure besteht.

# Entdeckung von Fermenten

Nachdem dieser Satz geschrieben war, habe ich einen Aufsatz von Gorup-
Besanez erhalten (Berichte der deutschen chem. Gesellschaft, Berlin, 1874,
p. 1478), welcher mit Unterstützung des Dr. Will factisch die Entdeckung
gemacht hat, dasz die Samen der Wicke ein Ferment enthalten, welches, wenn es
mit Glycerin ausgezogen ist, albuminöse Substanzen, so z. B. Fibrin, auflöst und
sie in echte Peptone umwandelt.

# Wechselwirkungen in der Verdauung

Nun wird bei denjenigen Pflanzen, welche fähig sind, bereits lösliche Sub-
stanz aus gefangenen Insecten zu absorbiren, wennschon sie keiner
wahren Verdauung fähig sind, das eben erwähnte Lösungsmittel, wel-
ches gelegentlich in den Drüsen vorhanden sein musz, gern in
Verbindung mit dem klebrigen Secrete aus den Drüsen ausschwitzen,
insofern ja Endosmose von Exosmose begleitet ist. Wenn eine solche
Ausschwitzung je eintritt, wird das Lösungsmittel auf die innerhalb
der gefangenen Insecten enthaltenen animalen Substanz einwirken, und# Verdauung und Pflanzen

dies wird dann ein Act wahrer Verdauung sein. Da nicht bezweifelt werden kann, dasz dieser Procesz für Pflanzen, welche in sehr armem Boden wachsen, von groszem Nutzen sein würde, so wird es danach streben, durch natürliche Zuchtwahl immer weiter vervollkommnet zu werden. Es könnte daher jede gewöhnliche Pflanze, welche kleb- rige Drüsen besitzt und damit gelegentlich Insecten fängt, in dieser Weise unter günstigen Umständen in eine Species verwandelt werden, welche das Vermögen wahrer Verdauung besitzt. Es hört daher auf, irgend ein groszes Geheimnis zu sein, wie mehrere, in keiner Weise nahe mit einander verwandte Pflanzen, unabhängig von einander dieses selbe Vermögen erlangt haben.

# Entwicklung der Verdauungsfähigkeit

Da mehrere Pflanzen existiren, deren Drüsen, so viel bis jetzt bekannt ist, animale Substanz nicht verdauen können, aber doch Ammoniaksalze und thierische Flüssigkeiten absorbiren können, so ist es wahrscheinlich, dasz dieses letztere Vermögen die erste Stufe zur Entwickelung wirklicher Verdauung bildet. Es könnte sich indessen unter gewissen Bedingungen ereignen, dasz eine Pflanze, nachdem sie die Verdauungsfähigkeit erlangt gehabt hatte, zu einer solchen rück- schreiten könnte, welche nur das Vermögen besäsze, animale Substanz in Lösung oder im Zustande des Zerfallens, oder die endlichen Zer- setzungsproducte, nämlich die Ammoniaksalze, zu absorbiren. Es möchte scheinen, als sei dies factisch in einer gewissen Ausdehnung bei den Blättern der Aldrovanda eingetreten; die äuszeren Theile derselben besitzen absorbirende Organe, aber keine zur Absonderung irgend einer verdauenden Flüssigkeit eingerichtete Drüsen, während solche auf die inneren Theile beschränkt sind.

# Bewegungsvermögen der Pflanzen

Nur wenig Licht kann über das allmähliche Erlangen der dritten merkwürdigen Eigenthümlichkeit, welche die höher entwickelten Gattungen der Droseraceen besitzen, verbreitet werden, nämlich über das Vermögen, sich zu bewegen, wenn sie gereizt werden. Man musz indessen im Sinne behalten, dasz Blätter und deren Homologa, eben- so wie Blüthenstiele, diese Fähigkeit in unzähligen Beispielen unabhängig von einer Vererbung von einer gemeinsamen elterlichen Form erhalten haben: so z. B. bei Rankenträgern und Blattkletterern (d. h. bei Pflanzen, deren Blätter, Blattstiele und Blüthenstiele u. s. w. zur Ergreifung modificirt sind), die zu einer groszen Zahl der aller- verschiedensten Ordnungen gehören, — bei Blättern der vielen Pflan- zen, welche des Abends, oder wenn sie erschüttert werden, einschlafen, — und bei den reizbaren Staubfäden und Pistillen nicht weniger Species. Wir können daher schlieszen, dasz das Bewegungsvermögen auf mehrfache Weise leicht erlangt werden kann. Derartige Bewe- gungen setzen Reizbarkeit oder Empfindlichkeit voraus; wie aber Cohn bemerkt hats. den Auszug aus seiner Abhandlung über die contractilen Gewebe der Pflanzen, in den „Annals and Mag. of Nat. Hist.‟ 3. Series, Vol. XI. p. 188., weichen die Gewebe der in solcher Weise be- gabten Pflanzen in keiner irgendwie gleichförmigen Weise von denen gewöhnlicher Pflanzen ab; es ist daher wahrscheinlich, dasz alle Blätter in einem unbedeutenden Grade reizbar sind. Selbst wenn sich ein Insect auf ein Blatt niederläszt, wird eine unbedeutende molecu- lare Veränderung wahrscheinlich eine Strecke weit quer durch sein Gewebe fortgeleitet, mit dem einzigen Unterschiede, dasz keine wahr- nehmbare Wirkung hervorgebracht wird.

# Schluszbemerkungen

Zu Gunsten dieser Meinung haben wir einige Belege; denn wir wissen, dasz eine einmalige Be- rührung der Drüsen der Drosera keine Einbiegung erregt; und doch musz sie eine Wirkung hervorbringen, denn wenn die Drüsen in einer Campherlösung eingetaucht gewesen waren, so erfolgt die Einbiegung innerhalb einer kürzeren Zeit als sie der Einwirkung des Camphers allein gefolgt sein würde. So können ferner bei Dionaea die Blatt- scheiben in ihrem gewöhnlichen Zustande derb berührt werden, ohne dasz sie sich schlieszen; und doch musz hierdurch eine Wirkung her- vorragend und quer über das ganze Blatt fortgeleitet werden, denn# Empfindlichkeit und Bewegungsvermögen der Droseraceen

Wenn die Drüsen vor Kurzem animale Substanz absorbirt hatten, veranlaszt selbst eine zarte Berührung, dasz sie sich augenblicklich schlieszen. Im Ganzen können wir schlieszen, dasz das Erlangen eines hohen Grades von Empfindlichkeit und das Bewegungsvermögen bei gewissen Gattungen der Droseraceen keine gröszere Schwierigkeit darstellt, als ähnliche aber schwächere Fähigkeiten bei einer Menge anderer Pflanzen darbieten.

# Spezialisierte Empfindlichkeit der Drosera und Dionaea

Die specialisirte Beschaffenheit und Art der Empfindlichkeit, welche Drosera und Dionaea und gewisse andere Pflanzen besitzen, verdient wohl Beachtung. Eine Drüse der Drosera kann einmal, zwei- oder selbst dreimal kräftig geschlagen werden, ohne dasz irgend eine Wirkung hervorgebracht wird, während der fortdauernde Druck eines äuszerst minutiösen Theilchens Bewegung erregt. Andererseits kann ein vielmal schwereres Theilchen leise auf eines der Filamente der Dionaea gelegt werden, ohne eine Wirkung; wird es aber nur einmal durch die langsame Bewegung eines zarten Haares berührt, so schlieszen sich die Blattlappen; und dieser Unterschied in der Natur der Empfindlichkeit dieser beiden Pflanzen steht in offenbarem Anpassungsverhältnis zu der Art und Weise, wie sie Insecten fangen.

# Absorption und motorische Impulse

Dasselbe gilt für die Thatsache, dasz, wenn die centralen Drüsen der Drosera stickstoffhaltige Substanz absorbiren, sie einen motorischen Impuls viel schneller nach den äuszeren Tentakeln hinsenden, als wenn sie mechanisch gereizt werden; während bei Dionaea die Absorption stickstoffhaltiger Substanz es verursacht, dasz die Blattlappen sich mit äuszerster Langsamkeit gegen einander drücken, wogegen eine Berührung rapide Bewegung erregt. Etwas analoge Thatsachen kann man, wie ich in einem andern Werke gezeigt habe, bei den Ranken verschiedener Pflanzen beobachten; einige werden durch die Berührung mit feinen Fasern, andere durch Berührung mit Borsten, andere mit einer ebenen oder gefurchten Oberfläche am meisten gereizt.

# Anpassung an Umweltfaktoren

Die empfindlichen Organe der Drosera und Dionaea sind auch in sofern spezialisiert, als sie nicht durch das Gewicht oder das Auffallen von Regentropfen oder Luftstößen nutzlos afficirt werden. Dies kann man so erklären, dasz man annimmt, diese Pflanzen und ihre Erzeuger seien an die wiederholte Einwirkung von Regen und Wind gewöhnt worden, so dasz keine molecularen Veränderungen dadurch veranlasst werden; während sie mittelst natürlicher Zuchtwahl gegen den seltneren Auffall oder Druck fester Körper empfindlicher gemacht worden sind.

# Unterschiede in der Wirkung von Flüssigkeiten

Obgleich die Absorption verschiedener Flüssigkeiten durch die Drüsen der Drosera Bewegung erregt, so besteht doch ein groszer Unterschied zwischen der Wirkung verwandter Flüssigkeiten, so beispielsweise zwischen gewissen vegetabilischen Säuren und zwischen citronensaurem und phosphorsaurem Ammoniak. Die specialisirte Natur und Vollkommenheit der Empfindlichkeit bei diesen zwei Pflanzen ist um so überraschender, als Niemand vermuthet, dasz sie Nerven besitzen; und aus Versuchen an Drosera mit Substanzen, welche kraftvoll auf das Nervensystem von Thieren wirken, geht nicht hervor, dasz sie irgend eine dem Nervengewebe analoge Substanz durch den Körper diffundirt enthalten.

# Vergleich mit höheren Tieren

Obgleich die Zellen der Drosera und Dionaea vollständig so empfindlich gegen gewisse Reizmittel sind, wie die Gewebe, welche die Endigungen der Nerven in den höheren Thieren umgeben, so stehen diese Pflanzen doch niedriger als selbst tief auf der Stufenleiter stehende Thiere, und zwar darin, dasz sie nicht afficirt werden, ausgenommen durch Reize in Berührung mit ihren empfindlichen Theilen. Sie werden indessen wahrscheinlich durch strahlende Wärme beeinflußt, denn warmes Wasser erregt energische Bewegung.

# Motorische Impulse und Reizverarbeitung

Wenn eine Drüse der Drosera oder eines der Filamente der Dionaea gereizt wird, so strahlt der motorische Impuls nach allen Richtungen hin und wird nicht, wie es bei Thieren der Fall ist, nach speciellen Punkten oder Organen hingelenkt. Dies gilt bei Drosera selbst für den Fall, wenn eine reizende Substanz auf zwei Punkte der Scheibe gelegt worden ist und wenn alle Tentakeln ringsherum mit wunderbarer Genauigkeit...# Einleitung in die Pflanzenphysiologie

Die Schnelligkeit, mit welcher der motorische Impuls fortgeleitet wird, ist, obschon rapid bei Dionaea, viel geringer als bei den meisten oder allen Thieren. Diese Thatsache ebenso wie die, dasz der motorische Impuls nicht speciell nach gewissen Punkten hingerichtet wird, sind ohne Zweifel beide eine Folge des Fehlens von Nerven. Demungeachtet können wir vielleicht eine Vorbildung eigentlicher Nervenentwickelung bei Thieren darin erblicken, dasz der motorische Impuls in dem beschränkten Raume innerhalb der Tentakeln der Drosera so viel rapi- der abwärts geleitet wird als irgendwo anders, und etwas schneller in einer Längsrichtung als in der Richtung quer über die Scheibe.

# Reflexthätigkeit und Centralorgane

Noch deutlicher lassen diese Pflanzen ihre niedrigere Entwickelung den Thieren gegenüber in dem Fehlen jeder Reflexthätigkeit erkennen, den Fall ausgenommen, wo die Drüsen der Drosera, wenn sie aus einer gewissen Entfernung gereizt werden, einen Reiz zurücksenden, welcher es verursacht, dasz der Inhalt der Zellen hinab bis zu den Basen der Tentakeln zusammengeballt wird. Aber der bedeutendste Beweis dieser Inferiorität unter allen ist die Abwesenheit eines Centralorgans, welches fähig wäre, Eindrücke von allen Punkten her aufzunehmen, deren Wirkungen in bestimmten Richtungen fortzuleiten, sie aufzusammeln und sie zu reproduciren.

# Sechszehntes Kapitel: Pinguicula

Pinguicula vulgaris. — Bau der Blätter. — Grosze Zahl der gefangenen Insecten und anderer Gegenstände. — Bewegung der Blattränder. — Nutzen dieser Bewegung. — Absonderung, Verdauung und Aufsaugung. — Wirkung des Secrets auf verschiedene animale und vegetabilische Substanzen. — Die Wirkungen von Substanzen, welche keine löslichen stickstoffhaltigen Substanzen enthalten, auf die Drüsen. — Pinguicula grandiflora. — Pinguicula lusitanica, fängt Insecten. — Bewegung der Blätter, Absonderung und Verdauung.

# Beschreibung der Pinguicula vulgaris

Diese Pflanze wächst an feuchten Stellen, meistens auf Bergen. Sie trägt im Mittel acht, ziemlich dicke, oblonge, hellgrüne Blätter, welche kaum irgend einen Stiel haben. Ein die volle Grösse erreichendes Blatt miszt ungefähr 1½ Zoll in der Länge und ¾ Zoll in der Breite. Die jungen mittleren Blätter sind tief concav und ragen nach oben vor; die älteren, nach der Auszen- seite hin stehenden, sind eben oder concav und liegen dicht am Boden, wo sie eine Rosette von 3 bis 4 Zoll im Durchmesser bilden. Die Ränder der Blätter sind einwärts gekrümmt.

# Drüsige Haare und ihre Funktion

Ihre obere Fläche ist dicht mit zweierlei Art drüsiger Haare besetzt, welche in der Grösze der Drüsen und der Länge ihrer Stiele von einander abweichen. Die gröszeren Drüsen haben einen kreisförmigen Umfang, wenn sie von oben betrachtet werden, und sind mäszig dick; sie sind durch strahlen- förmig angeordnete Scheidewände in sechszehn Zellen getheilt, welche hellgrüne, homogene Flüssigkeit enthalten. Sie werden von läng- lichen, einzelligen Stielen (welche einen Kern und ein Kernkörperchen enthalten) getragen, die auf leichten Hervorragungen stehen.

# Eigenschaften der Drüsen

Die kleinen Drüsen weichen nur darin ab, dasz sie nur von der halben Anzahl von Zellen gebildet werden, welche viel blässere Flüssigkeit enthalten und von viel kürzeren Stielen getragen werden. Nahe der Mittelrippe nach der Basis des Blattes zu sind die Stiele vielzellig, sind länger als irgendwo anders und tragen kleinere Drüsen. Alle Drüsen sondern eine farblose Flüssigkeit ab, welche so klebrig ist, dasz man, wie ich gesehen habe, einen Faden von 18 Zoll Länge ausziehen kann; in diesem Falle wurde aber die Flüssigkeit von einer Drüse abgesondert, welche gereizt worden war.

# Anatomie der Blätter

Der scharfe Blattrand ist durchscheinend und trägt keinerlei Drüsen; hier enden die aus der Mittelrippe heraus- tretenden Spiralgefäsze in Zellen, welche mit einer Spirallinie gezeich- net sind, denen innerhalb der Drüsen der Drosera ziemlich ähnlich. Die Wurzeln sind kurz. Drei Pflanzen wurden in Nord-Wales am 20. Juni ausgegraben und sorgfältig gewaschen; jede hatte fünf.# Untersuchung der Pflanzen und Insekten

oder sechs nicht verzweigte Wurzeln, von denen die längste nur 1,2 Zoll masz. Zwei ziemlich junge Pflanzen wurden am 28. September untersucht; diese hatten eine gröszere Zahl von Wurzeln, nämlich acht und achtzehn, sämmtlich unter 1 Zoll lang und sehr wenig verzweigt.

# Lebensweise der Pflanzen

Ich war dadurch dazu veranlaszt worden, die Lebensweise dieser Pflanzen zu untersuchen, dasz mir Mr. W. Marshall erzählte, auf den Bergen von Cumberland hiengen viele Insecten an den Blättern derselben. Ein Freund schickte mir am 23. Juni aus Nord-Wales neununddreiszig Blätter, welche ausgewählt worden waren, weil ihnen Gegenstände irgend welcher Art anhiengen.

# Insektenfänge und Beobachtungen

Von diesen Blättern hatten zweiunddreiszig 142 Insecten gefangen, oder im Mittel jedes Blatt 4,4, wobei minutiöse Bruchstücke von Insecten nicht mitgezählt wurden. Auszer den Insecten hiengen noch kleine, zu vier verschiedenen Arten von Pflanzen gehörige Blätter, unter denen die der Erica tetralix weitaus die häufigsten waren, und drei äuszerst kleine keimende Pflänzchen, die vom Winde verweht waren, neunzehn Blättern an.

# Weitere Sammlungen und Ergebnisse

Eines hatte sogar zehn Blätter des Haidekrautes gefangen. Samen oder Früchte, meistens von Riedgräsern und einer von Juncus, hiengen auszer Stückchen Moos und ande-
rem Abfall gleichfalls noch an sechs Blättern unter den neununddreiszig. Derselbe Freund sammelte am 27. Juni neun Pflanzen, welche zusammen vierundsiebenzig Blätter trugen; und diese hatten sämmtlich, mit Ausnahme von drei jungen Blättern, Insecten gefangen; auf einem Blatte wurden dreiszig Insecten gezählt, auf einem zweiten achtzehn und auf einem dritten sechszehn.

# Vergleichende Studien in Irland

Ein anderer Freund untersuchte am 22. August einige Pflanzen in Donegal in Irland und fand unter 157 Blättern Insecten auf 70; fünfzehn dieser Blätter wurden mir zugeschickt, ein jedes Blatt hatte im Mittel 2,4 Insecten gefangen. An neun derselben hiengen Blätter (meist von Erica tetralix); sie waren aber dieses letzteren Umstandes wegen ausgelesen worden.

# Beobachtungen in der Schweiz

Ich will noch hinzufügen, dasz zeitig im August mein Sohn Blätter dieser selben Erica und die Früchte einer Carex an den Blättern einer Pinguicula in der Schweiz hängen fand, wahrschein-
lich Pinguicula alpina; auch einige Insecten, aber nicht in groszer An-
zahl, hiengen an den Blättern dieser Pflanze, welche viel besser ent-
wickelte Wurzeln hatte als die Pinguicula vulgaris.

# Zusammenfassung der Insektenfänge

In Cumberland untersuchte Mr. Marshall am 3. September mir zu Gefallen sorgfältig zehn Pflanzen, welche achtzig Blätter trugen; auf dreiundsechs-
zig von diesen (d. h. auf 79 Procent) fand er Insecten, 143 an der Zahl, so dasz jedes Blatt im Mittel 2,27 Insecten hatte. Wenige Tage später schickte er mir einige Pflanzen mit sechszehn Samen oder Früchten an vierzehn Blättern hängend.

# Schlussfolgerungen über die Insekten

Es fand sich dabei ein Same auf drei Blättern einer und derselben Pflanze. Die sechszehn Samen gehörten zu neun verschiedenen Arten, welche nicht bestimmt werden konnten, ausgenommen einer von Ranunculus und mehrere zu drei oder vier verschiedenen Species von Carex gehörig. Es zeigt sich, dasz spät im Jahre weniger Insecten gefangen werden als früher; so wurden in Cumberland in der Mitte des Juli auf mehren Blättern von zwanzig bis vierundzwanzig Insecten beobachtet, während im September die mittlere Anzahl nur 2,27 betrug.

# Artenvielfalt der Insekten

Die meisten Insecten in sämmtlichen vorstehend erwähnten Fällen waren Diptern, daneben aber viele sehr kleine Hymenoptern, mit Einschlusz einiger Ameisen, einige wenige kleine Käfer, Larven, Spinnen, und selbst kleine Motten.

# Bedeutung der Insekten für die Pflanzen

Wir sehen hieraus, dasz zahlreiche Insecten und andere Gegenstände von den klebrigen Blättern gefangen werden; wir haben aber kein Recht, aus dieser Thatsache zu schlieszen, dasz diese Gewohnheit wohlthätig für die Pflanze ist, ebensowenig wie in dem früher angeführten Falle bei der Mirabilis oder bei der Roszkastanie.

# Einfluss von toten Insekten auf die Pflanzen

Wir werden aber sofort sehen, dasz todte Insecten und andere stickstoffhaltige Körper die Drüsen zu vermehrter Absonderung anregen, und dasz das Secret dann sauer wird und die Fähigkeit hat, animale Substanzen, wie Eiweisz, Faserstoff u. s. w. zu verdauen. Überdies wird die aufgelöste stickstoffhaltige Substanz von den Drüsen aufgesaugt, was sich darin zeigt, dasz ihr klarer Zelleninhalt zu sich langsam bewegenden körnigen Protoplasma-Massen zusammengeballt wird.# Bewegungen der Blätter

Dasz solche dicke, grosze Blätter wie die der Pinguicula vulgaris die Fähigkeit haben würden, sich einwärts zu krümmen, wenn sie gereizt werden, ist niemals auch nur vermuthet worden. Es ist nothwendig, zum Versuch Blätter aus- zuwählen, deren Drüsen reichlich absondern und welche verhindert worden sind, viele Insecten zu fangen, da alte Blätter, wenigstens diejenigen, die im Naturzustande wachsen, ihre Ränder bereits so be- deutend einwärts gekrümmt haben, dasz sie wenig Bewegungsvermögen darbieten oder sich sehr langsam bewegen. Ich will zuerst die wich- tigeren Experimente, welche angestellt wurden, im Detail anführen und dann einige Schluszbemerkungen machen.

## Versuch 1

Ein junges und beinahe aufrecht stehendes Blatt wurde ausgewählt, dessen beide seitlichen Blätter gleichmäszig und sehr unbedeutend einwärts gekrümmt waren. Eine Reihe kleiner Fliegen wurde dem einen Rande entlang auf das Blatt gelegt. Als es am andern Tage angesehen wurde, nach 15 Stunden, fand sich, dasz dieser Rand, aber nicht der andere, nach innen gefaltet war, wie der Rand des mensch- lichen Ohres, und zwar in einer Breite von ⅒ Zoll, so dasz er zum Theil auf der Reihe Fliegen drauf lag (Fig. 15). Die Drüsen, auf denen die Fliegen lagen, ebenso wie diejenigen auf dem sich einfaltenden Rand- stück, welche mit den Fliegen in Berührung gebracht worden waren, sonderten sämmtlich reichlich ab.

## Versuch 2

Eine Reihe von Fliegen wurde auf den einen Rand eines etwas alten Blattes gebracht, welches platt auf dem Boden lag; in diesem Falle hatte sich der Rand nach Verlauf einer gleich langen Zeit, nämlich nach 15 Stunden, eben erst nach innen einzu- rollen begonnen; es war aber so viel Secret ergossen worden, dasz die löffelförmige Spitze des Blattes damit angefüllt war.

## Versuch 3

Stücke einer groszen Fliege wur- den nahe der Spitze auf ein kräftiges Blatt gelegt, ebenso der Hälfte des einen Randes entlang. Nach 2 Stunden 20 Minuten war eine entschiedene Einwärts- krümmung eingetreten, welche während des Nachmittags (Pinguicula vulgaris.) Umriszzeichnung eines Blattes, dessen linker Rand über eine Reihe Fliegen eingebogen ist. noch ein wenig zunahm, aber sich am folgenden Morgen noch in dem- selben Zustande befand. In der Nähe der Blattspitze waren beide Rän- der nach innen gebogen. Ich habe niemals einen Fall gesehen, wo sich die Spitze selbst auch nur im geringsten gegen die Basis des Blattes zu gekrümmt hätte. Nach 48 Stunden (immer von der Zeit an gerechnet, wo die Fliegen zuerst auf das Blatt gelegt wurden) hatte der Rand überall angefangen, sich wieder zu entfalten.

## Versuch 4

Ein groszes Stück einer Fliege wurde in der Mittellinie etwas unterhalb der Spitze auf ein Blatt gelegt. In 3 Stun- den waren beide seitlichen Ränder wahrnehmbar, und nach 4 Stunden 20 Minuten bis zu einem solchen Grade einwärts gekrümmt, dasz das Stück von beiden Rändern umfaszt wurde. Nach 24 Stunden wurden die beiden eingefalteten Ränder in der Nähe der Spitze (denn der untere Theil des Blattes war durchaus nicht afficirt) gemessen; es fand sich,# Bewegungen der Blätter

## Experiment 1
dasz sie 0,11 Zoll (2,795 Mm.) auseinander standen. Die Fliege wurde nun entfernt und ein Wasserstrom über das Blatt gegossen, um die Oberfläche zu waschen; nach 24 Stunden standen die Ränder 0,25 Zoll (6,349 Mm.) auseinander, so dasz sie also bedeutend entfaltet waren. Nach Verlauf von weiteren 24 Stunden waren sie vollständig wieder ausge- breitet. Nun wurde eine andere Fliege auf dieselbe Stelle gelegt, um zu sehen, ob sich das Blatt, auf welchem die erste Fliege 24 Stunden gelegen hatte, wieder bewegen würde; nach 10 Stunden war eine Spur von Ein- krümmung vorhanden, dieselbe nahm aber während der nächsten 24 Stunden nicht zu. Desgleichen wurde ein Stückchen Fleisch auf den Rand eines Blattes gelegt, welches vier Tage früher über einem Stück Fliege stark eingekrümmt worden war und sich dann wieder ausgebreitet hatte; das Fleisch verursachte auch nicht einmal eine Spur von Einkrümmung. Im Gegentheil bogen sich die Ränder etwas zurück, als wären sie be- schädigt, und blieben so die nächstfolgenden drei Tage lang, so lange das Blatt beobachtet wurde.

## Experiment 2
Ein groszes Stück einer Fliege wurde halbwegs zwischen die Mittelrippe und den einen Rand gelegt. Ein kurzer Ab- schnitt dieses Randes der Fliege gerade gegenüber zeigte nach 3 Stunden eine Spur von Einkrümmung, und war nach 7 Stunden stark eingebo- gen. Nach 24 Stunden war der einwärts gefaltete Rand nur 0,16 Zoll (4,064 Mm.) von der Mittelrippe entfernt. Der Rand fieng nun an, sich wieder auszubreiten, trotzdem die Fliege auf dem Blatte liegen gelassen wurde, so dasz am nächsten Morgen (d. h. 48 Stunden von der Zeit an, wo die Fliege zuerst aufgelegt wurde) der eingefaltete Rand beinahe vollständig seine ursprüng- liche Stellung wieder erlangt hatte, da er nun 0,3 Zoll (7,62 Mm.) (anstatt 0,16 Zoll) von der Mittelrippe ent- fernt war. Indessen war immer noch eine Spur von Bie- gung sichtbar.

## Experiment 3
Ein junges und concaves Blatt wurde ausgesucht, dessen Ränder unbedeutend und auf na- türliche Weise eingekrümmt waren. Zwei ziemlich grosze, längliche, rechteckige Stückchen gerösteten Fleisches wurden nun, 0,46 Zoll (11,68 Mm.) von einander ent- fernt, so aufgelegt, dasz ihre Enden den eingefalteten Rand berührten. Nach 24 Stunden war der Rand be- deutend und gleichmäszig eingebogen (s. Fig. 16), und zwar über die ganze Strecke und noch 0,12 oder 0,13 Zoll (3,048 oder 3,302 Mm.) oberhalb und unterhalb eines jeden Stückes; es war daher der Rand zwischen den beiden Stücken in einer gröszeren Ausdehnung affi- cirt worden, in Folge ihrer verbundenen Einwirkung.

## Experiment 4
Umrisz eines Blattes, dessen rechter Rand sich gegen zwei viereckige Stückchen Fleisch ein- gebogen hatte. Die Fleischstückchen waren zu grosz, um vom Rande umfaszt werden zu können, sie wurden aufgerichtet, eines von ihnen so, dasz es beinahe senkrecht stand. Nach 48 Stunden war der Rand beinahe ausgebreitet und die Fleischstückchen waren herab- gesunken. Als das Blatt nach zwei Tagen wieder untersucht wurde, war der Rand vollständig wieder ausgebreitet, mit Ausnahme des naturgemäsz eingekrümmten Randes, und eines der Fleischstückchen, deren Ende zuerst die Kante berührt hatte, war nun 0,067 Zoll (1,70 Mm.) von ihr ent- fernt, so dasz dies Stückchen um so viel quer über die Blattscheibe ge- schoben worden war.

## Experiment 5
Ein Stückchen Fleisch wurde dicht an den einge- krümmten Rand eines ziemlich jungen Blattes gelegt und wurde, nach- dem sich der Rand wieder ausgebreitet hatte, 0,11 Zoll (2,795 Mm.)# Experimente mit Pflanzen

## Versuch 8
Die Entfernung vom Rande bis zur Mittelrippe des völlig ausgebreiteten Blattes betrug 0,35 Zoll (8,89 Mm.), so dasz das Fleischstückchen nahezu ein Drittel des halben Durchmessers des Blattes nach innen und quer über die Scheibe geschoben worden war.

## Versuch 9
Eine zusammenhängende Reihe Fasern von geröstetem Fleisch, so dünn wie Borsten und mit Speichel befeuchtet, wurde einer ganzen Seite entlang dicht an dem naturgemäßen eingekrümmten Rande eines Blattes hingelegt.

## Versuch 10
Sechs Kohlsamen, welche eine Nacht hindurch in Wasser gelegen hatten, wurden in einer Reihe dicht an den schmalen eingekrümmten Rand eines Blattes gebracht.

## Versuch 11
Glasstückchen wurden auf die Ränder zweier schöner junger Blätter gelegt.# Experimente mit Blättern

## Versuch 12
Stückchen Kohlenasche, die auf ein Blatt gelegt wurde, brachten keine Wirkung hervor, entweder in Folge ihrer Leichtigkeit oder weil das Blatt torpid war.

## Versuch 13
Ich wende mich jetzt zur Wirkung von Flüssigkeiten. Eine Reihe von Tropfen eines starken Aufgusses von rohem Fleisch wurde den Rändern zweier Blätter entlang gelegt, während mit demselben Aufguss getränkte Schwammstückchen auf den gegenüberliegenden Rand gebracht wurden. Meine Absicht war, zu ermitteln, ob eine Flüssigkeit so energisch einwirken würde wie ein Körper, welcher dieselbe lösliche Substanz den Drüsen abgibt. Es war kein deutlicher Unterschied nachweisbar, sicherlich keiner in Bezug auf den Grad der Einwärtskrümmung; es blieb aber die Einbiegung um die Schwammstückchen länger bestehen, wie sich vielleicht aus dem Grunde hätte erwarten lassen, dass der Schwamm längere Zeit feucht blieb und stickstoffhaltige Substanz darbot. Die Ränder mit den Tropfen wurden in 2 Stunden 17 Minuten deutlich eingebogen. Die Einwärtskrümmung nahm später etwas zu, hatte aber nach 24 Stunden bedeutend abgenommen.

## Versuch 14
Tropfen desselben starken Aufgusses von rohem Fleisch wurden der Mittelrippe eines jungen und ziemlich tief concaven Blattes entlang aufgelegt. Die Entfernung quer über den breitesten Teil des Blattes zwischen den naturgemäß einwärts gebogenen Rändern betrug 0,55 Zoll (13,97 Mm.). In 3 Stunden 27 Minuten war die Entfernung kleiner; in 6 Stunden 27 Minuten betrug sie genau 0,45 Zoll (11,43 Mm.) und hatte daher um ⅒ Zoll (2,54 Mm.) abgenommen. Nach nur 10 Stunden 37 Minuten fing der Rand an, sich wieder auszubreiten, denn die Entfernung von Kante zu Kante war nun eine Spur größer, und nach 24 Stunden 20 Minuten war sie innerhalb einer Haaresbreite so groß, wie sie es war, als die Tropfen zuerst auf das Blatt gebracht wurden. Aus diesem Versuche sehen wir, dass der motorische Impuls bis zu einer Entfernung von 0,22 Zoll (5,59 Mm.) in querer Richtung von der Mittelrippe nach beiden Rändern hin fortgeleitet werden kann; es würde aber sicherer sein, zu sagen, 0,2 Zoll (5,08 Mm.), da die Tropfen sich ein wenig über die Mittelrippe hinaus ausbreiten. Die hierdurch verursachte Einwärtskrümmung währte eine ungewöhnlich kurze Zeit.

## Versuch 15
Drei Tropfen einer Lösung von einem Teil kohlensauren Ammoniaks auf 218 Teile Wasser (2 Gran auf 1 Unze) wurden auf den Rand eines Blattes gelegt. Diese regten eine so beträchtliche Absonderung an, dass in 1 Stunde 22 Minuten alle drei Tropfen zusammenflossen; obgleich aber das Blatt 24 Stunden lang beobachtet wurde, trat doch keine Spur von Einbiegung ein. Wir wissen, dass eine ziemlich starke Lösung dieses Salzes, wenngleich sie die Blätter der Drosera nicht verletzt, ihr Bewegungsvermögen lähmt, und ich zweifle nach diesem und dem folgenden Falle nicht daran, dass dies auch für Pinguicula gilt.

## Versuch 16
Eine Reihe Tropfen einer Lösung von einem Teil kohlensauren Ammoniaks auf 875 Teile Wasser (1 Gran auf 2 Unzen) wurde auf den Rand eines Blattes gebracht. In 1 Stunde war augenscheinlich eine unbedeutende Einwärtskrümmung da, und in 3 Stunden 30 Minuten war dieselbe gut ausgesprochen. Nach 24 Stunden war der Rand beinahe vollständig wieder ausgebreitet.

## Versuch 17
Eine Reihe großer Tropfen einer Lösung von einem Teil phosphorsauren Ammoniaks auf 4375 Teile Wasser (1 Gran auf 10 Unzen) wurde dem Rande eines Blattes entlang gelegt. Es trat keine Wirkung ein, und nach 8 Stunden wurden demselben Rande entlang frische Tropfen hinzugesetzt, aber ohne den mindesten Erfolg. Wir wissen, dass eine Lösung dieser Stärke kräftig auf Drosera einwirkt, und es ist eben möglich, dass die Lösung zu stark war. Ich bedaure, dass ich nicht eine schwächere Lösung versucht habe.

## Versuch 18
Da der Druck kleiner Glasstückchen Einwärtskrümmung verursacht, so kratzte ich die Ränder zweier Blätter einige Minuten lang mit einer stumpfen Nadel; es wurde aber keine Wirkung hervorgerufen. Die Oberfläche eines Blattes unterhalb eines Tropfens eines starken Aufgusses von rohem Fleisch wurde gleichfalls 10 Minuten lang mit dem Ende einer Borste gerieben, um die sträubenden Bewegungen zu stimulieren.# Bewegungen der Blätter

## Einleitung
gen eines Insects nachzuahmen; es bog sich aber dieser Theil des Blatt-
randes nicht eher als die anderen Stellen, auf denen die Aufgusztropfen
ungestört gelassen wurden.

## Ursachen der Bewegung
Aus den vorstehend mitgetheilten Versuchen sehen wir, dasz die
Ränder der Blätter sich nach innen rollen, wenn sie durch den
bloszen Druck von Gegenständen, welche keinerlei Substanz abgeben,
gereizt werden, wenn sie durch Gegenstände, welche solche Substanz
darbieten, und wenn sie durch einige Flüssigkeiten gereizt werden,
nämlich durch einen Aufgusz von rohem Fleisch und eine schwache
Auflösung von kohlensaurem Ammoniak. Eine stärkere Lösung von
zwei Gran dieses Salzes auf eine Unze Wasser regt zwar eine reich-
liche Absonderung an, aber paralysirt das Blatt. Tropfen von Wasser
oder von einer Zucker- oder Gummilösung verursachten keinerlei Be-
wegung. Ein einige Minuten anhaltendes Kratzen der Oberfläche des
Blattes brachte keine Wirkung hervor. Es regen daher, so viel wir
bis jetzt wissen, nur zwei Ursachen Bewegung an, — nämlich leich-
ter fortdauernder Druck und die Absorption stickstoffhaltiger Substanz.

## Beobachtungen zu Pinguicula vulgaris
Pinguicula vulgaris. Cap. 16.
Es sind allein die Ränder des Blattes, welche sich biegen; denn die
Blattspitze krümmt sich niemals nach der Basis zu. Die Stiele der
drüsigen Haare haben kein Bewegungsvermögen. Ich beobachtete bei
mehreren Gelegenheiten, dasz die Oberfläche des Blattes da, wo Stück-
chen Fleisch oder grosze Fliegen lange gelegen hatten, unbedeutend
concav wurde; dies kann aber Folge einer durch Überreizung herbei-
geführten Verletzung gewesen sein.

## Zeitliche Aspekte der Bewegung
Die kürzeste Zeit, in welcher deutlich ausgesprochene Bewegung
beobachtet wurde, war 2 Stunden 17 Minuten; und dies trat ein,
wenn stickstoffhaltige Substanzen oder Flüssigkeiten auf die Blätter
gebracht wurden; ich glaube aber, dasz in einigen Fällen eine Spur
von Bewegung schon in 1 Stunde oder 1 Stunde 30 Minuten da war.
Der Druck von Glassplitterchen erregt Bewegung beinahe ebenso schnell
wie die Absorption stickstoffhaltiger Substanz, aber der Grad der hier-
durch verursachten Einwärtskrümmung ist geringer. Nachdem ein
Blatt ordentlich einwärts gekrümmt gewesen war und sich wieder
ausgebreitet hat, antwortet es nicht bald einem frischen Reize. Der
Rand wurde in der Längenrichtung, aufwärts oder abwärts, in einer
Entfernung von 0,13 Zoll (3,302 Mm.) von dem gereizten Punkte, aber
in einer Entfernung von 0,46 Zoll zwischen zwei gereizten Stellen,
und quer über das Blatt bis zu 0,2 Zoll (5,08 Mm.) afficirt. Der
motorische Impuls wird nicht, was bei Drosera der Fall ist, von
irgend einer, eine vermehrte Absonderung verursachenden Einwirkung
begleitet; denn wenn eine einzeln Drüse stark gereizt wurde und
reichlich absonderte, so wurden die umgebenden Drüsen nicht im
mindesten afficirt. Die Einwärtskrümmung des Randes ist von einer
vermehrten Absonderung unabhängig; denn Glassplitterchen verursachen
nur geringe oder gar keine Absonderung und regen doch Bewegung
an, während eine starke Lösung von kohlensaurem Ammoniak schnell
reichliche Absonderung, aber keine Bewegung erregt.

## Dauer der Bewegung
Eine der merkwürdigsten Thatsachen in Bezug auf die Bewegung
der Blätter ist die kurze Zeit, während welcher sie eingekrümmt blei-
ben, wenn auch der reizende Gegenstand auf ihnen liegen gelassen
wird. In der Mehrzahl der Fälle war eine gut ausgesprochene Wieder-
ausbreitung innerhalb 24 Stunden von der Zeit an, wo selbst grosze
Stückchen Fleisch u. s. w. auf die Blätter gelegt worden war, ein-
getreten und in allen Fällen innerhalb 48 Stunden. In einem Falle
blieb der Rand eines Blattes 32 Stunden lang dicht rund um dünne
Fasern von Fleisch eingebogen; in einem anderen Falle, wo ein Stück-
chen in einem starken Aufgusz von rohem Fleisch eingeweichten
Schwammes angewendet worden war, fieng der Rand sich in 35 Stun-
den wieder zu entfalten an. Glasstückchen halten den Rand kürzere
Zeit eingekrümmt als stickstoffhaltige Körper; denn im ersteren Falle
trat vollständige Wiederausbreitung in 16 Stunden 30 Minuten ein.# Stickstoffhaltige Flüssigkeiten und ihre Wirkung

Stickstoffhaltige Flüssigkeiten wirken eine kürzere Zeit als stickstoffhaltige feste Substanzen; als z. B. Tropfen eines Aufgusses von rohem Fleische auf die Mittelrippe eines Blattes gebracht waren, fieng der eingebogene Rand sich in nur 10 Stunden 37 Minuten wieder zu entfalten an, was überhaupt der schnellste Act der Wiederausbreitung war, der beobachtet wurde; es kann dies aber zum Theil Folge der gröszeren Entfernung der Ränder von der Mittelrippe, wo die Tropfen lagen, gewesen sein.

# Nutzen der Bewegung

Wir werden naturgemäsz darauf geführt, zu untersuchen, was der Nutzen dieser Bewegung ist, welche nur so kurze Zeit währt. Wenn sehr kleine Gegenstände, wie Fleischfasern, oder mäszig kleine Gegenstände, wie kleine Fliegen oder Kohlsamen, dicht an den Rand gelegt werden, so werden sie entweder vollständig oder theilweise von ihm umfaszt. Die Drüsen des sich umschlagenden Randes werden dabei mit derartigen Gegenständen in Berührung gebracht und ergieszen ihr Secret, während sie später die verdaute Substanz aufsaugen. Da aber die Einwärtskrümmung eine so kurze Zeit dauert, so kann jeder derartige Vortheil nur von unbedeutender Wichtigkeit sein, vielleicht aber doch gröszer als er auf den ersten Blick erscheint.

# Insekten und Regen

Die Pflanze lebt in feuchten Bezirken, und die Insecten, welche an allen Stellen des Blattes hängen bleiben, werden von jedem Regenschauer in den schmalen, von den natürlich einwärts gebogenen Blatträndern gebildeten Canal gewaschen. So legte z. B. mein Freund in Nord-Wales mehrere Insecten auf einige Blätter und nach zwei Tagen (in der Zwischenzeit war starker Regen gefallen) fand er, dasz einige vollständig weggewaschen worden waren, während viele andere unter den nun dicht eingebogenen Rändern in Sicherheit geborgen waren, deren Drüsen rings um die Insecten sämmtlich ohne Zweifel absonderten. Wir können auch verstehen, woher es kommt, dasz so viele Insecten und Stücke von Insecten meist innerhalb der eingekrümmten Blattränder liegend angetroffen werden.

# Bedeutung der Einwärtskrümmung

Die in Folge der Gegenwart eines reizenden Gegenstandes eintretende Einwärtskrümmung musz noch auf eine andere und wahrscheinlich bedeutungsvollere Weise von Nutzen sein. Wir haben gesehen, dasz, wenn grosze Stückchen Fleisches oder in Fleischsaft eingeweichten Schwammes auf ein Blatt gelegt wurden, der Rand nicht im Stande war, sie zu umfassen, dasz er sie aber während des Actes seiner Einwärtskrümmung langsam nach der Mitte des Blattes hinschob, in einer Entfernung von der äuszeren Seite her von völlig 0,1 Zoll (2,54 Mm.), d. h. also quer über einen Raum, der zwischen einem Drittel und einem Viertel des Abstandes vom Rande bis zur Mittelrippe betrug.

# Vorteile für die Pflanze

Ein jeglicher Gegenstand, so z. B. ein mäszig groszes Insect, würde auf diese Weise langsam in Berührung mit einer bei weitem gröszeren Anzahl von Drüsen kommen und eine viel bedeutendere Absonderung und Aufsaugung veranlassen, als es sonst der Fall gewesen sein würde. Dasz dies für die Pflanze von groszem Vortheil sein wird, dies können wir aus der Thatsache schlieszen, dasz Drosera ein bedeutend entwickeltes Bewegungsvermögen lediglich zu dem Zwecke erlangt hat, ihre sämmtlichen Drüsen mit den gefangenen Insecten in Berührung zu bringen.

# Mechanismus der Beutefang

Wenn ferner ein Blatt der Dionaea ein Insect gefangen hat, so dient das langsame Aneinanderpressen der beiden Lappen lediglich dazu, die Drüsen beider Seiten mit jenem in Berührung zu bringen, womit gleichfalls bewirkt wird, dasz das mit animaler Substanz durchdrungene Secret durch Capillaranziehung über die ganze Oberfläche ausgebreitet wird. Was die Pinguicula betrifft, so würde, sobald ein Insect eine kleine Strecke weit nach der Mittelrippe zu geschoben worden ist, sofortige Wieder-ausbreitung von Vortheil sein, da die Ränder keine frische Beute fangen können, bis sie wieder ausgebreitet sind. Der durch diese schiebende Bewegung ebenso wie der durch den Umstand erlangte Vortheil, dasz die randständigen Drüsen eine kurze Zeit lang mit der Oberfläche kleiner gefangener Insecten in Berührung gebracht werden, dürfte vielleicht die eigenthümlichen Bewegungen der Blätter er-# Bewegungen der Blätter

# Absonderung, Absorption und Verdauung

# Wirkungen von Gegenständen, welche lösliche stickstoffhaltige Substanz enthalten# Absonderung, Absorption und Verdauung

1.
zusondern und wurden dann beinahe trocken. Von diesem Blatte wurde ein schmaler Streifen abgeschnitten; die Drüsen der längeren und kürzeren Haare, welche vier Tage lang mit der Fliege in Berührung gelegen hatten, und diejenigen, welche die Fliege nicht berührt hatten, wurden unter dem Mikroskope mit einander verglichen: sie boten einen wunderbaren Contrast dar. Diejenigen, welche in Berührung gestanden hatten, waren mit bräunlicher körniger Substanz erfüllt, die andern mit homogene Flüssigkeit. Es konnte daher darüber kein Zweifel bestehn, dasz die ersteren Stoffe aus der Fliege absorbirt hatten.

2.
Kleine Stückchen gerösteten Fleisches verursachten, auf ein Blatt gelegt, immer im Laufe von wenig Stunden viel saure Absonderung, — in einem Falle innerhalb 40 Minuten. Wenn dünne Fleischfasern dem Rande eines Blattes entlang gelegt wurden, welches beinahe aufrecht stand, lief das Secret auf den Boden. Eckige Stückchen Fleisch, die in die kleinen Secrettümpel in der Nähe des Randes gelegt wurden, waren im Verlaufe von zwei oder drei Tagen sehr in der Grösze reducirt, abge-rundet, mehr oder weniger farblos und durchsichtig geworden und so bedeutend erweicht, dasz sie bei der leisesten Berührung in Stücke zerfielen. Nur in einem einzigen Falle wurde ein sehr kleines Theilchen vollständig aufgelöst, und zwar trat dies innerhalb 48 Stunden ein. Wenn nur eine kleine Menge von Secret durch die Reizung entstanden war, wurde dies meistens in von 24 bis 48 Stunden absorbirt, wobei die Drüsen trocken zurückblieben. Wenn aber der Zuflusz von Secret reichlich war, entweder rings um ein einzelnes verhältnismäszig groszes Stück Fleisch oder um mehrere kleine Stückchen, so wurden die Drüsen vor dem Ablauf von sechs oder sieben Tagen trocken. Der rapideste Fall von Aufsaugung, den ich beobachtet habe, trat ein, als ein kleiner Tropfen eines Aufgusses von rohem Fleisch auf ein Blatt gebracht wurde, denn hier wurden die Drüsen schon in 3 Stunden 20 Minuten beinahe trocken. Drüsen, welche durch kleine Stückchen Fleisch gereizt wurden, und ihr eigenes Secret schnell absorbirt hatten, fiengen im Laufe des siebenten oder achten Tages von der Zeit an, wo ihnen das Fleisch gegeben worden war, wieder abzusondern an.

3.
Drei sehr kleine Würfelchen derben Knorpels von dem Schenkel-beine eines Schafes wurden auf ein Blatt gelegt. Nach 10 Stunden 30 Minuten war etwas saure Absonderung angeregt, der Knorpel erschien aber nur wenig oder durchaus gar nicht afficirt zu sein. Nach 24 Stunden waren die Würfel abgerundet und in der Grösze bedeutend reducirt; nach 32 Stunden waren sie bis zu ihrem Mittelpunkte hinein erweicht und einer war vollständig verflüssigt; nach 35 Stunden waren nur Spuren festen Knorpels noch zurück; und nach 48 Stunden konnte eine Spur davon noch immer durch eine Lupe in nur einem derselben gesehen wer-den. Nach 82 Stunden waren nicht blosz alle drei Würfel vollständig verflüssigt, sondern das ganze Secret war absorbirt und die Drüsen trocken geworden.

4.
Kleine Würfel von Eiweisz wurden auf ein Blatt gelegt; in 8 Stunden breitete sich ein schwach saures Secret in einer Entfernung von nahezu ⅒ Zoll rund um sie aus, und die Kanten des einen Würfels waren abgerundet. Nach 24 Stunden waren die Kanten aller Würfel abgerundet, auch waren sie durchaus sehr weich geworden; nach 30 Stunden fieng die Absonderung an abzunehmen, und nach 48 Stunden waren die Drüsen trocken; es waren aber äuszerst kleine Stückchen Eiweisz noch immer ungelöst zurückgeblieben.

5.
Kleinere Würfel von Eiweisz (ungefähr \frac {1}{50} oder \frac {1}{60} Zoll, oder 0,508 bis 0,423 Mm. Seitenlänge) wurden auf vier Drüsen gelegt; nach 18 Stunden war ein Würfelchen vollständig aufgelöst, die andern waren bedeutend kleiner geworden, erweicht und durchscheinend. Nach 24 Stunden waren zwei Würfelchen vollständig aufgelöst und das Secret auf diesen Drüsen war bereits beinahe ganz aufgesaugt. Nach 42 Stunden waren die zwei andern Würfel vollständig aufgelöst. Diese vier Drüsen fiengen nach acht oder neun Tagen wieder an abzusondern.

6.
Zwei grosze Würfel von Eiweisz (völlig \frac {1}{20} Zoll, 1,27 Mm.) wur-# Experimentelle Beobachtungen

## Absonderung und Auflösung von Substanzen

## Fibrin und seine Wirkung

## Einfluss von Leim auf die Drüsen

## Gelatine und ihre Eigenschaften

## Casëin und seine Reaktion

## Wirkung von abgerahmter Milch

## Behandlung mit kohlensaurem Ammoniak# Absonderung, Absorption und Verdauung

## Experimentelle Beobachtungen

## Wirkung von Pollen auf Drüsen

## Einfluss verschiedener Pflanzen auf die Sekretion

## Samenuntersuchungen# Absonderung und ihre Ursachen

als sauer ergab. Die fünf in der vorstehenden Aufzählung zuerst ge-
nannten Samen reizten die Drüsen mehr als die andern. Die Absonderung
war selten früher reichlich als bis ungefähr 24 Stunden verflossen waren,
ohne Zweifel in Folge des Umstandes, dasz die Samenhüllen nicht leicht
durchgängig waren. Nichtsdestoweniger veranlassten Kohlsamen etwas
Absonderung in 4 Stunden 30 Minuten; und diese nahm in 18 Stunden
so stark zu, dasz das Secret an den Blättern hinablief. Die Samen, oder
richtiger die Früchte von Carex, werden viel häufiger im Naturzustand
an den Blättern hängen gefunden als die irgend einer andern Gattung;
und die Früchte von Carex sylvatica erregten eine so starke Absonderung,
dasz das Secret in 15 Stunden die eingebogenen Ränder hinablief; nach
40 Stunden hörten aber die Drüsen auf abzusondern. Andererseits fuhren
die Drüsen, auf welchen die Samen von Rumex und Avena lagen, neun
Tage lang fort zu secreniren.

# Geringe Absonderung bei bestimmten Samen

Die neun folgenden Arten von Samen erregten nur einen unbedeu-
tenden Grad von Absonderung, nämlich Sellerie, Petersilie, Kümmel,
Linum grandiflorum, Cassia, Trifolium pannonicum, Plantago, Zwiebel
und Bromus. Die meisten dieser Samen erregten keinerlei Absonderung
bis nach Verlauf von 48 Stunden, und was das Trifolium betrifft, so
wirkte nur ein Samenkorn, und dies nicht vor dem dritten Tage. Obgleich
die Samen der Plantago sehr wenig Absonderung hervorriefen, so fuhren
doch die Drüsen sechs Tage lang abzusondern fort. Endlich riefen die fünf fol-
genden Samen keine Absonderung hervor, trotzdem sie zwei oder drei
Tage lang auf den Blättern gelassen wurden, nämlich Salat, Erica tetra-
lix, Atriplex hortensis, Phalaris canariensis und Weizen. Als aber die
Samen des Salats, Weizens und der Melde aufgeschnitten und nun auf
die Blätter gebracht wurden, wurde in 10 Stunden Secret in beträcht-
licher Menge erregt, und ich glaube, dasz schon in 6 Stunden etwas her-
vorgerufen war. In dem Falle mit dem Samen der Atriplex lief das
Secret am Rande hinab, und nach 24 Stunden erwähne ich es in meinen
Notizen als »ungeheuer der Quantität nach und sauer.« Die aufge-
schnittenen Samen der Kleeart und des Sellerie wirkten kräftig und
geschwind, trotzdem dasz die ganzen Samen, wie wir gesehen haben, sehr
wenig Absonderung und nur nach Verlauf einer langen Zeit erregten.
Ein Schnittchen der gemeinen Erbse, welche indessen nicht im Ganzen
versucht wurde, bewirkte Absonderung in 2 Stunden. Aus diesen That-
sachen können wir schlieszen, dasz die grosze Verschiedenheit im Grade
und der Schnelligkeit, mit welcher verschiedene Arten von Samen Abson-
derung anregten, hauptsächlich oder ganz und gar eine Folge der ver-
schiedenen Durchlässigkeit ihrer Hüllen sind.

# Einfluss der Einwirkung des Secrets

Einige dünne Schnittchen der gemeinen Erbse, welche vorher eine
Stunde lang in Wasser aufgeweicht worden waren, wurden auf ein Blatt
gelegt und riefen schnell viel saure Absonderung hervor. Nach 24 Stunden
wurden diese Schnittchen unter einer starken Vergröszerung mit andern
verglichen, welche eine gleich lange Zeit in Wasser liegen gelassen wor-
den waren. Die letzteren enthielten so viole feine Körnchen von Legumin,
dasz der Objectträger milchig wurde, während die Schnittchen, welche der
Einwirkung des Secrets ausgesetzt gewesen waren, viel reiner und durch-
sichtiger waren, da sich die Leguminkörnchen offenbar aufgelöst hatten.
Ein Kohlsamen, welcher zwei Tage lang auf einem Blatte gelegen und
viel saures Secret veranlaszt hatte, wurde in Scheibchen zerschnitten, und
diese wurden mit denen eines Samens verglichen, welche die nämliche
Zeit lang in Wasser gelegen hatten. Diejenigen, welche der Einwirkung
des Secrets ausgesetzt gewesen waren, waren von einer blässeren Färbung,
ihre Hüllen boten die gröszten Verschiedenheiten dar, denn sie waren von
einer blaszen schmutzigen Färbung, anstatt kastanienbraun zu sein. Die
Drüsen, auf welchen die Kohlsamen gelegen hatten, ebenso wie die welche
von dem umgebenden Secret benetzt wurden, wichen in dem Aussehn be-
deutend von den andern Drüsen an demselben Blatte ab; denn sie ent-
hielten alle bräunlich-grauliche Substanz, damit beweisend, dasz sie Stoffe
aus den Samen absorbirt hatten.
Dasz das Secret auf die Samen einwirkt, zeigte sich auch dadurch,
dasz einige von ihnen getödtet oder dasz die Sämlinge beschädigt wur-# Kohlsamen und ihre Keimung

den. Vierzehn Kohlsamen wurden drei Tage lang auf Blättern liegen ge-
lassen und erregten starke Absonderung; sie wurden dann auf feuchten
Sand gebracht unter Bedingungen, von denen bekannt war, dasz sie der
Keimung günstig wären. Drei von ihnen keimten niemals; und dies war
ein viel bedeutenderes Sterblichkeitsverhältnis als es bei Samen aus der-
selben Gruppe eintrat, welche der Einwirkung des Secrets nicht ausgesetzt,
aber im Übrigen in derselben Weise behandelt worden waren. Von den
elf so erzielten Sämlingen hatten drei die Ränder ihrer Cotyledonen leicht
gebräunt, als wenn sie versengt wären; und die Cotyledonen des einen
wuchsen zu einer merkwürdig eingeschnittenen Form heran. Zwei Senf-
samen keimten; aber ihre Cotyledonen waren mit braunen Flecken ge-
zeichnet und ihre Würzelchen waren misgestaltet. Von zwei Rettichsamen
keimte keiner, während von vielen Samen derselben Partie, welche der
Einwirkung des Secrets nicht ausgesetzt worden waren, alle, mit Aus-
nahme eines, keimten. Von den zwei Rumex-Samen starb einer ab, der
andere keimte; aber sein Würzelchen war braun und verwelkte bald.
Beide Samenkörner der Avena keimten; der eine wuchs ganz ordentlich
weiter, am andern war das Würzelchen braun und verwelkt. Von sechs
Samen der Erica keimte nicht einer, und als sie, nachdem sie fünf Mo-
nate lang auf feuchtem Sande liegen gelassen worden waren, aufgeschnitten
wurden, schien nur einer allein noch lebendig zu sein. Zweiundzwanzig
Samen verschiedener Arten fand man an den Blättern von im Natur-
zustande wachsenden Pflanzen hängen; und obgleich diese fünf Monate
Pinguicula vulgaris. Cap. 16.
lang auf feuchtem Sande gelassen wurden, keimte doch keiner; mehrere
waren offenbar abgestorben.

# Wirkungen von Gegenständen ohne lösliche stickstoffhaltige Substanz

Die Wirkungen von Gegenständen, welche keine lösliche stickstoffhaltige Substanz
enthalten.
16. Es ist bereits gezeigt worden, dasz Stückchen Glas auf Blätter
gebracht wenig oder gar keine Absonderung erregen. Die geringe Menge,
welche unter den Glasstückchen lag, wurde geprüft und als nicht sauer
befunden. Ein Stückchen Holz erregte keine Absonderung; ebensowenig
thaten es verschiedene Arten von Samen, deren Hüllen für das Secret
nicht durchgängig waren, welche daher wie anorganische Körper wirkten.
Würfel von Fett, welche zwei Tage lang auf einem Blatte gelassen wur-
den, brachten keine Wirkung hervor.

# Zuckers und seine Auswirkungen

17. Ein Stückchen weiszen Zuckers, auf ein Blatt gelegt, bewirkte
in 1 Stunde 10 Minuten die Bildung eines groszen Tropfens von Flüssig-
keit, welcher im Verlaufe von 2 weiteren Stunden in den natürlich ein-
gebogenen Rand hineinlief. Diese Flüssigkeit war nicht im mindesten
sauer und fieng in 5 Stunden 30 Minuten einzutrocknen an, oder war
noch wahrscheinlicher aufgesaugt. Der Versuch wurde wiederholt. Es
wurden Stückchen auf ein Blatt gelegt und andere ebenso grosze auf ein
Glasplättchen in angefeuchtetem Zustande; beide wurden mit einer Glas-
glocke zugedeckt. Dies wurde deshalb gethan, um zu sehen, ob die ver-
mehrte Flüssigkeitsmenge auf den Blättern einfach eine Folge des Zer-
flieszens sein könnte; es zeigte sich jedoch, dasz dies nicht der Fall war.
Das Stückchen auf dem Blatte verursachte eine so starke Absonderung,
dass das Secret im Verlaufe von 4 Stunden quer über zwei Drittel des
Blattes hinablief. Nach 8 Stunden war das Blatt, welches concav war,
factisch mit sehr klebriger Flüssigkeit angefüllt; und es verdient noch
besondere Erwähnung, dasz dieselbe, wie bei der früheren Gelegenheit,
nicht im mindesten sauer war. Man kann die grosze Menge von Secret
der Exosmose zuschreiben. Die Drüsen, welche 24 Stunden lang von dieser
Flüssigkeit bedeckt gewesen waren, wichen, als sie unter dem Mikroskop
untersucht wurden, von andern an demselben Blatte nicht ab, welche
nicht in Berührung mit ihr gekommen waren. Im Gegensatz zu dem aus-
nahmslos beobachteten Zustande der Zusammenballung des Zelleninhalts
der Drüsen, welche von dem Secrete, wenn es animale Substanz in Lösung
gehalten hat, benetzt gewesen waren, ist dies eine interessante Thatsache.

# Arabisches Gummi und seine Wirkung

18. Zwei Stückchen arabischen Gummi’s wurden auf ein Blatt
gelegt, und in 1 Stunde 20 Minuten bewirkten sie sicher eine unbedeu-
tende Zunahme der Absonderung. Diese fuhr in den nächsten 5 Stunden
fort zuzunehmen, d. h. so lange als das Blatt beobachtet wurde.# Absonderung und Absorption

19. Sechs kleine Stückchen Stärke, wie sie im Handel ist, wurden auf ein Blatt gelegt; eines derselben bewirkte in 1 Stunde 15 Minuten etwas Absonderung, die andern in einer Zeit von 8 bis 9 Stunden. Die Drüsen, welche hierdurch zur Absonderung gereizt worden waren, wurden bald trocken und fiengen nicht vor dem sechsten Tage wieder abzusondern an. Ein gröszeres Stück Stärke wurde dann auf ein Blatt gebracht; in 5 Stunden 30 Minuten wurde keine Secretion erregt; aber nach 8 Stunden war ein beträchtlicher Zuflusz da, welcher in 24 Stunden so bedeutend zunahm, dasz er bis in eine Entfernung von ¾ Zoll das Blatt hinablief. Dies Secret war, trotzdem es in solcher Menge erschien, nicht im mindesten sauer. Da es so reichlich erregt wurde, und da Samen nicht selten an Blättern von natürlich wachsenden Pflanzen anhängend gefunden werden, so kam mir der Gedanke, dasz die Drüsen vielleicht das Vermögen haben könnten, ein Ferment, ähnlich dem Ptyalin, abzusondern, welches im Stande ist, Stärke aufzulösen; ich beobachtete demgemäsz sorgfältig die oben erwähnten sechs Stärkestückchen während mehrerer Tage; sie schienen aber im Umfang nicht im mindesten reducirt zu werden. Es wurde auch ein Stückchen zwei Tage lang in einem kleinen Tümpel von Secret gelassen, welches von einem Stück Spinatblatt abgeflossen war; obgleich aber das Stückchen so minutiös klein war, konnte doch keine Verminderung der Grösse wahrgenommen werden. Wir können daher schlieszen, dasz das Secret Stärke nicht auflösen kann. Die Zunahme der Absonderung unter der Einwirkung dieser Substanz kann, wie ich vermuthe, der Exosmose zugeschrieben werden. Ich bin aber überrascht, dasz Stärke so schnell und so kräftig einwirkt, wennschon in einem geringeren Grade als Zucker. Es ist bekannt, dasz Colloide ein unbedeutendes Vermögen der Dialyse besitzen; als die Blätter einer Primula in Wasser, andere in Zuckerlösung und diffundirte Stärke gelegt wurden, wurden diejenigen in der Stärke welk, aber in einem geringeren Grade und in einem viel langsameren Tempo welk als die Blätter in der Zuckerlösung; die im Wasser blieben die ganze Zeit über frisch.

# Beobachtungen und Schlussfolgerungen

Aus den vorstehenden Versuchen und Beobachtungen ersehen wir, dasz Gegenstände, welche keine lösliche animale Substanz enthalten, wenig oder gar keine Kraft haben, die Drüsen zur Absonderung anzuregen. Nichtstickstoffhaltige Flüssigkeiten bewirken, wenn sie dicht sind, dasz die Drüsen eine grosze Menge klebriger Flüssigkeit ergieszen, dieselbe ist aber nicht im mindesten sauer. Andererseits ist das von Drüsen, welche durch die Berührung mit stickstoffhaltigen festen Körpern oder Flüssigkeiten gereizt sind, ausgehende Secret ausnahmslos sauer und so reichlich, dasz es häufig die Blätter hinabläuft und sich innerhalb der naturgemäsz eingerollten Ränder ansammelt. Das Secret in diesem Zustande hat die Fähigkeit, die Muskeln von Insec- ten, Fleisch, Knorpel, Eiweisz, Faserstoff, Gelatine und Casëin, wie es in den geronnenen Theilen der Milch existirt, schnell aufzulösen, d. h. zu verdauen. Die Drüsen werden durch chemisch präparirtes Casëin und durch Leim stark gereizt; es werden aber diese Substanzen (und zwar die letztere, wenn sie nicht in schwacher Salzsäure eingeweicht ist) nur theilweise aufgelöst, was gleichfalls bei der Drosera der Fall ist. Wenn das Secret animale Substanz in Lösung enthält, mag dieselbe aus festen oder flüssigen Körpern, wie z. B. einem Aufgusse von rohem Fleisch, Milch oder einer Lösung von kohlensaurem Ammoniak herrühren, so wird es schnell absorbirt; und die Drüsen, welche vorher klar und von einer grünlichen Färbung waren, werden bräunlich und enthalten Massen von zusammengeballter granulirter Substanz. Nach ihrer freiwilligen Bewegung zu urtheilen, besteht diese Substanz ohne Zweifel aus Protoplasma. Durch die Einwirkung nichtstickstoffhaltiger Flüssigkeiten wird keine solche Wirkung hervorgebracht. Nachdem die Drüsen gereizt worden sind, reichlich abzusondern, hören sie eine Zeit lang zu secreniren auf, fangen aber im Laufe weniger Tage wieder an.

# Einfluss von Pollen und Pflanzen

Drüsen in Berührung mit Pollen, mit den Blättern anderer Pflanzen und mit verschiedenen Arten von Samen ergieszen viel saures.# Geheimnisse der Pinguicula

## Pinguicula vulgaris
Secret und absorbiren nachher Substanz, wahrscheinlich von einer eiweiszartigen Natur, aus ihnen. Es kann auch der dadurch erlangte Vortheil nicht bedeutungslos sein; denn es musz eine beträchtliche Menge Pollen von den vielen durch den Wind befruchteten Ried-gräsern, Gräsern u. s. w., welche da wo Pinguicula lebt wachsen, auf die dicht mit klebrigen Drüsen besetzten und grosze Rosetten bildenden Blätter geweht werden. Selbst einige wenige Körner Pollen auf einer einzelnen Drüse bewirken, dasz diese reichlich absondert. Wir haben auch gesehen, wie häufig die kleinen Blätter der Erica tetralix und anderer Pflanzen, ebenso wie verschiedene Arten von Samen und Früchten, besonders von Carex an den Blättern hängen. Ein einzel-nes Blatt der Pinguicula hatte zehn von den kleinen Blättern der Erica gefangen; und drei Blätter an der nämlichen Pflanze hatten jedes einen Samen gefangen. Samen, welche der Einwirkung des Se-crets ausgesetzt werden, werden zuweilen getödtet oder die Sämlinge verletzt. Wir können daher schlieszen, dasz Pinguicula vulgaris mit ihren kleinen Wurzeln nicht blosz in einem hohen Grade durch die auszerordentliche Anzahl von Insecten erhalten wird, welche sie ge-wöhnlich fängt, sondern gleichfalls etwas Nahrung aus dem Pollen, den Blättern und Samen anderer Pflanzen zieht, welche häufig ihren Blättern anhängen. Sie ist daher zum Theil ein Pflanzenfresser, zum Theil ein Fleischfresser.

## Pinguicula grandiflora
Diese Species ist mit der letztgeschilderten so nahe verwandt, dasz sie von Dr. Hooker nur als eine Unterart classificirt wird. Sie weicht hauptsächlich durch die bedeutendere Grösze ihrer Blätter und dadurch von jener ab, dasz die drüsigen Haare in der Nähe des ba-salen Theiles der Mittelrippe länger sind. Sie weicht aber in der Constitution ab; ich höre von Herrn Ralfs, welcher so freundlich war, mir Pflanzen aus Cornwall zu schicken, dasz sie an ziemlich verschiedenen Lagen wächst; und Dr. Moore, vom botanischen Garten in Glasnevin, theilt mir mit, dasz sie im Culturzustande viel besser zu behandeln ist, reichlich wächst und jährlich blüht, während Pinguicula vulgaris jedes Jahr erneuert werden musz. Herr Ralfs fand zahlreiche Insecten und Fragmente von Insecten beinahe an allen Blättern hängen. Dieselben waren hauptsächlich Diptern, daneben einige Hymenoptern, Homoptern, Coleoptern und eine Motte. An einem Blatte fanden sich neun todte Insecten auszer einigen wenigen noch lebenden. Er beobachtete auch einige Früchte von Carex puli-caris, ebenso wie die Samen dieser selben Pinguicula, welche an den Blättern hiengen. Ich stellte nur zwei Versuche mit dieser Species an; zuerst wurde eine Fliege in die Nähe des Randes eines Blattes gebracht, und nach 16 Stunden fand sich, dasz dasselbe ordentlich eingebogen war. Zweitens wurden mehrere kleine Fliegen in einer Reihe dem einen Rande eines andern Blattes entlang gelegt; und am nächsten Morgen war dieser ganze Rand nach innen gerollt, wie es bei der Pinguicula vulgaris der Fall war.

## Pinguicula lusitanica
Diese Species, von welcher mir lebende Exemplare von Herrn Ralfs aus Cornwall gesandt wurden, ist von den beiden vorstehend erwähnten sehr verschieden. Die Blätter sind im Ganzen kleiner, viel durchscheinender, und sind mit purpurnen verzweigten Adern gezeichnet. Die Ränder der Blätter sind viel bedeutender eingerollt; diejenigen der älteren Blätter erstrecken sich über ein Drittel des Raumes zwischen der Mittelrippe und der äuszeren Kante. Wie in den beiden andern Species bestehn die drüsigen Haare aus zwei For-men, längeren und kürzeren, und haben dieselbe Structur; die Drüsen weichen aber dadurch ab, dasz sie purpurn sind und häufig granulöse Substanz enthalten, ehe sie gereizt worden sind. Im untern Theile des Blattes ist beinahe der halbe Raum auf jeder Seite zwischen der Mittelrippe und dem Rande ohne Drüsen; diese sind durch lange, ziemlich steife, vielzellige Haare ersetzt, welche sich über der Mittel-# Pinguicula lusitanica

## Einleitung
rippe kreuzen. Es dienen diese Haare vielleicht dazu, zu verhüten, dasz sich Insecten auf diesem Theile des Blattes niederlassen, wo sich keine klebrigen Drüsen finden, mittelst deren sie gefangen werden könnten; es ist aber kaum wahrscheinlich, dasz sie zu diesem Zwecke entwickelt worden sind. Die von der Mittelrippe ausgehenden Spiral-gefässe endigen am äussersten Rande des Blattes in Spiralzellen; diese sind aber nicht so gut entwickelt, wie in den beiden vorausgehenden Arten. Die Blüthenstiele, Kelchblätter und Blumenblätter sind dicht mit drüsigen Haaren bedeckt, ähnlich denen auf den Blättern.

## Insektenfang
Die Blätter fangen viele kleine Insecten, welche hauptsächlich unterhalb der eingerollten Ränder gefunden werden, wohin sie vom Regen gewaschen worden sind. Die Farbe der Drüsen, auf denen In-secten lange gelegen haben, ist verändert, sie ist entweder bräunlich oder blasz purpurn, ihr Inhalt ist grob granulirt, so dasz sie also offenbar Substanz aus ihrer Beute aufsaugen. Blätter der Erica tetralix, Blüthen eines Labkrautes, Schuppen von Gräsern u. s. w. hiengen gleichfalls an einigen von den Blättern.

## Versuche mit Pinguicula lusitanica
Mehrere von den an Pinguicula vulgaris angestellten Versuchen wurden an der Pinguicula lusitanica wiederholt; und diese werden nun mitgetheilt werden.

### Versuch 1
1. Ein eckiges Stück Eiweisz von mäsziger Grösse wurde auf die eine Seite eines Blattes gelegt, halbwegs zwischen die Mittelrippe und den natürlich eingerollten Rand. In 2 Stunden 15 Minuten ergossen die Drüsen viel Secret und es wurde diese Seite stärker eingefaltet als die gegenüberliegende. Die Einbiegung nahm zu und erstreckte sich in 3 Stunden 30 Minuten beinahe bis zur Blattspitze hinauf. Nach 24 Stun-den war der Rand zu einem Cylinder aufgerollt, dessen äuszere Oberfläche die Scheibe des Blattes berührte und bis innerhalb \frac {1}{20} Zoll von der Mittel-rippe reichte. Nach 48 Stunden fieng er an, sich zu entfalten und war in 72 Stunden vollständig wieder ausgebreitet. Der Würfel war abge-rundet und in der Grösse bedeutend vermindert; der Rest fand sich in einem halbverflüssigten Zustande.

### Versuch 2
2. Ein mäszig groszes Stück Eiweisz wurde in die Nähe der Spitze eines Blattes unter den natürlich einwärtsgekrümmten Rand gelegt. In 2 Stunden 30 Minuten war starke Absonderung erregt, und am nächsten Morgen war der Rand auf dieser Seite des Blattes stärker eingerollt als der entgegengesetzte, aber in keinem so bedeutenden Grade wie in dem letzten Falle. Der Rand entfaltete sich in derselben Schnelligkeit wie vorher. Ein bedeuteuder Theil des Eiweiszes war aufgelöst, es blieb aber noch ein Rest übrig.

### Versuch 3
3. Grosze Stückchen Eiweisz wurden in einer Reihe den Mittel-rippen zweier Blätter entlang gelegt, brachten aber im Verlaufe von 24 Stunden keine Wirkung hervor; es hätte eine solche auch nicht erwartet werden können; denn selbst wenn Drüsen hier existirt hätten, so würden doch die langen Borsten es verhindert haben, dasz das Eiweisz mit ihnen in Berührung käme. Auf beiden Blättern wurden nun die Stückchen bis dicht an den einen Rand geschoben, und in 3 Stunden 30 Minuten wurde dieser so bedeutend eingebogen, dasz die äuszere Oberfläche die Blatt-scheibe berührte; dabei war der gegenüberliegende Rand nicht im min-desten afficirt. Nach drei Tagen waren die Ränder beider Blätter mit dem Eiweisz noch immer so stark eingerollt wie je, und auch die Drüsen sonderten noch reichlich ab. Bei Pinguicula vulgaris habe ich die Ein-biegung niemals so lange andauern sehn.

### Versuch 4
4. Zwei Kohlsamen wurden, nachdem sie 1 Stunde lang in Wasser eingeweicht waren, in die Nähe des Randes eines Blattes gelegt und ver-ursachten in 3 Stunden 20 Minuten verstärkte Absonderung und Ein-wärtskrümmung. Nach 24 Stunden war das Blatt theilweise entfaltet, die Drüsen sonderten aber noch immer reichlich ab. Dieselben fiengen in 48 Stunden an abzutrocknen und waren in 72 Stunden beinahe trocken. Die beiden Samen wurden dann auf feuchten Sand gelegt unter dem Wachsthum günstigen Bedingungen; sie keimten aber niemals und nach einiger Zeit fand sich, dasz sie gefault waren. Sie waren ohne Zweifel# Beobachtungen an Pinguicula lusitanica

## Wirkung von Spinatblättern
Durch das Secret getödtet worden. Kleine Stückchen eines Spinatblattes verursachten in 1 Stunde 20 Minuten vermehrte Absonderung und nach 3 Stunden 20 Minuten deutliche Einwärtskrümmung des Randes. Der Rand war nach 9 Stunden 15 Minuten ordentlich eingebogen, hatte sich aber nach 24 Stunden beinahe vollständig wieder ausgebreitet. Die mit dem Spinat in Berührung stehenden Drüsen wurden in 72 Stunden trocken. Stücke Eiweisz waren am Tage vorher auf den entgegengesetzten Rand des nämlichen Blattes gelegt worden, ebenso wie auf den Rand eines Blattes mit Kohlsamen; und diese Ränder blieben 72 Stunden lang dicht eingebogen, was bewies, um wie viel andauernder die Wirkung des Eiweiszes ist als die der Spinatblätter oder der Kohlsamen.

## Einfluss von Glasstückchen
Eine Reihe kleiner Glasstückchen wurde dem Rande eines Blattes entlang gelegt; in 2 Stunden 10 Minuten war keine Wirkung hervorgebracht, aber nach 3 Stunden 25 Minuten schien eine Spur von Einbiegung da zu sein, und diese war nach 6 Stunden deutlich, wenn schon nicht scharf ausgesprochen. Die Drüsen in Berührung mit den Glasstückchen sonderten jetzt reichlicher ab als früher; so dasz sie augenscheinlich durch den Druck anorganischer Gegenstände leichter gereizt zu werden scheinen als die Drüsen der Pinguicula vulgaris. Die erwähnte unbedeutende Einbiegung hatte nach 24 Stunden nicht zugenommen; auch fiengen die Drüsen jetzt an trocken zu werden. Die Oberfläche eines Blattes wurde in der Nähe der Mittelrippe und nach der Basis zu einige Zeit lang gerieben und gekrazt, es erfolgte aber keine Bewegung. Die langen Haare, welche hier stehen, wurden in derselben Weise behandelt, aber ohne Wirkung. Der letzte Versuch wurde deshalb angestellt, weil ich glaubte, dasz die Haare vielleicht gegen eine Berührung empfindlich sein könnten, wie die Filamente der Dionaea.

## Untersuchung der Blüthenstiele
Die Blüthenstiele, Kelch- und Kronenblätter tragen Drüsen, welche dem allgemeinen Ansehen nach denen auf den Blättern gleich sind. Es wurde deshalb ein Stück eines Blüthenstiels 1 Stunde lang in einer Lösung von einem Theile kohlensauren Ammoniaks auf 437 Theile Wasser gelassen, und dies bewirkte, dasz sich die Farbe der Drüsen von einem hell Rosa in ein trübes Purpurn verwandelte; der Inhalt der Zellen bot aber keine deutliche Zusammenballung dar. Nach 8 Stunden 30 Minuten wurden sie farblos. Zwei minutiöse Eiweiszwürfel wurden auf die Drüsen eines Blüthenstiels und ein andrer Würfel auf die Drüsen eines Kelchblattes gelegt; sie wurden aber zu keiner vermehrten Absonderung angeregt; auch war das Eiweisz nach 2 Tagen nicht im mindesten erweicht. Es sind daher augenscheinlich diese Drüsen in ihrer Function bedeutend von denen auf den Blättern verschieden.

## Zusammenfassung der Beobachtungen
Aus den vorstehenden Beobachtungen an Pinguicula lusitanica sehen wir, dasz die schon naturgemäsz bedeutend eingekrümmten Ränder der Blätter durch die Berührung mit organischen und anorganischen Körpern dazu gereizt werden, sich noch weiter einwärts zu krümmen; dasz Eiweisz, Kohlsamen, Stückchen von Spinatblättern und Glassplitter es verursachen, dasz die Drüsen reichlicher absondern; — dasz Eiweisz von dem Secrete aufgelöst wird, und dasz Kohlsamen von ihm getödtet werden; — und endlich, dasz Substanz aus den Insecten, welche mittelst des klebrigen Secrets in groszer Anzahl gefangen werden, von den Drüsen aufgesaugt wird. Die Drüsen auf den Blüthenstielen scheinen keine solche Fähigkeit zu haben. Diese Art weicht von Pinguicula vulgaris und grandiflora darin ab, dasz die Ränder der Blätter, wenn sie durch organische Körper gereizt worden sind, bis zu einem stärkern Grade eingebogen werden, und dasz die Einbiegung eine längere Zeit anhält. Auch scheinen die Drüsen leichter durch Körper, welche keine lösliche stickstoffhaltige Substanz abgeben, zu vermehrter Absonderung angeregt zu werden. In andern Beziehungen stimmen, so weit meine Beobachtungen reichen, alle drei Species hinsichtlich ihrer functionellen Fähigkeiten überein.

## Siebenzehntes Capitel# Utricularia

## Utricularia neglecta

### Structur der Blase

### Der Gebrauch der verschiedenen Theile

### Anzahl der gefangenen Thiere

### Art und Weise des Fanges

### Die Blasen können animale Substanz nicht verdauen

### Versuche über die Aufsaugung gewisser Flüssigkeiten

### Aufsaugung durch die Drüsen

### Zusammenfassung der Beobachtungen über Aufsaugung

### Entwickelung der Blasen

### Utricularia vulgaris

### Utricularia minor

### Utricularia clandestina

## Lebensweise und Bau der Species

## Wichtige Abhandlung von Professor Cohn

## Beschreibung der Utricularia neglecta

### Allgemeine Erscheinung eines Zweiges

### Structur der Blase

### Wurzeln und Wachstumsperiode

### Lebensraum der Pflanzen

### Interessante Punkte der Blasen# Struktur der Blase

Stielen. Wenn sie völlig ausgewachsen sind, sind sie nahezu ⅒ Zoll (2,54 Mm.) lang. Sie sind durchscheinend, von einer grünen Färbung und die Wandungen werden aus zwei Schichten von Zellen gebildet. Die äuszeren Zellen sind polygonal und ziemlich grosz; aber an vielen von den Punkten, wo sich die Winkel treffen, finden sich kleinere rundliche Zellen. Diese letzteren tragen kurze kegelförmige Vorsprünge, welche von zwei hemisphärischen Zellen in so dichter Aneinanderlagerung, dasz sie vereinigt zu sein scheinen, überragt werden; häufig trennen sich die letztern ein wenig von einander, wenn sie in gewisse Flüssigkeiten eingetaucht werden. Die in dieser Weise gebildeten Papillen sind denen genau gleich, welche sich auf der Oberfläche der Blätter finden. Diejenigen an einer und derselben Blase sind der Grösse nach sehr verschieden; auch finden sich einige wenige, besonders an sehr jungen Blättern, welche einen elliptischen, statt eines kreisförmigen, Umrisz haben. Die zwei endständigen Zellen sind durchsichtig, müssen aber viel Substanz in Lösung enthalten, nach der Menge zu urtheilen, welche durch längeres Eintauchen in Alkohol oder Äther zur Gerinnung gebracht wird.

# Inhalt der Blasen

Die Blasen sind mit Wasser angefüllt. Sie enthalten meistens, aber durchaus nicht immer, Luftblasen. Je nach der in ihnen enthaltenen Wasser- oder Luftmenge sind sie in der Dicke sehr verschieden, sie sind aber immer etwas zusammengedrückt. Auf einem früheren Wachsthumsstadium ist die platte oder ventrale Oberfläche nach der Axe oder dem Stengel hin gerichtet; es musz aber der Stiel ein gewisses Bewegungsvermögen haben; denn an Pflanzen, welche ich in meinem Gewächshause hielt, war die ventrale Fläche meistens entweder gerade oder schräg niederwärts gedreht. Mr. H. M. Wilkinson untersuchte meinetwegen Pflanzen im Naturzustande und fand, dasz dies gewöhnlich der Fall ist; aber die jüngeren Blasen hatten häufig ihre Klappen nach oben gekehrt.

# Äußeres Erscheinungsbild

Das allgemeine äuszere Ansehn einer Blase von der Seite betrachtet ist in der beistehenden Figur wiedergegeben, wobei die Anhänge der dem Beschauer zugekehrten Seite allein dargestellt sind (Fig. 18). Die untere Seite, wo der Stiel entspringt, ist nahezu gerade; ich habe sie die ventrale Oberfläche genannt. Die andere dorsale Oberfläche ist convex und endigt in zwei langen, aus mehreren Reihen von Chlorophyll enthaltenden Zellen gebildeten und, hauptsächlich an der äuszeren Seite, sechs oder sieben lange, zugespitzte, vielzellige Borsten tragenden Verlängerungen. Diese Verlängerungen der Blase können passenderweise die Antennen genannt werden, denn die ganze Blase (vergl. Fig. 17) ist einem entomostraken Krustenthiere merkwürdig ähnlich, wobei der kurze Stiel den Schwanz darstellt. In Fig. 18 ist nur die nähere, dem Beschauer zu gelegene Antenne dargestellt. Unterhalb der beiden Antennen ist das Ende der Blase leicht abgestutzt und hier liegt der allerwichtigste Theil des ganzen Gebildes, nämlich der Eingang und die Klappe.

# Eingang und Klappe

Auf jeder Seite des Eingangs ragen von drei bis (selten) sieben lange, vielzählige Borsten nach außen vor; aber nur diejenigen (vier an Zahl) auf der näheren, dem Beschauer zugekehrten Seite sind in der Zeichnung wiedergegeben. Diese Borsten bilden zusammen mit den von den Antennen getragenen eine Art von hohlem, den Eingang umgebenden Kegel. Die Klappe senkt sich in die Höhlung der Blase hinein, oder aufwärts in Fig. 18. Sie ist auf allen Seiten an die Blase angeheftet, mit Ausnahme ihres hinteren Randes, oder des unteren in Fig. 19, welcher frei ist und die eine Seite der schlitzförmigen in die Blase führenden Mündung bildet. Dieser Rand ist scharf, dünn und glatt und ruht auf dem Rande einer Leiste oder eines Kragens, welcher tief in die Blase hineinragt, wie der Längsschnitt des Kragens und# Struktur der Blase

Fig. 19. (Utricularia neglecta.) Klappe der Blase; bedeutend vergröszert. der Klappe zeigt (Fig. 20); er ist auch bei c in Fig. 18 zu sehen. Der Rand der Klappe kann sich hiernach nur nach innen öffnen. Da beides, sowohl die Klappe als auch der Kragen, in die Blase hinein-

# Vertikaler Längsschnitt

Fig. 20. (Utricularia neglecta.) Verticaler Längsschnitt durch den ventralen Theil einer Blase, der die Klappe und den Kragen zeigt; v Klappe; der ganze Vorsprung oberhalb c bildet den Kragen; b zweispaltige Fortsätze; s ventrale Oberfläche der Blase. ragen, so bildet sich hier eine Höhlung oder Vertiefung, an deren Basis die schlitzförmige Mündung liegt.

# Eigenschaften der Klappe

Die Klappe ist farblos, in hohem Grade durchsichtig, biegsam und elastisch. Sie ist in querer Richtung convex, ist aber hier (Fig. 19) in abgeplattetem Zustande gezeichnet worden, wodurch ihre scheinbare Breite vergröszert ist. Sie wird nach Cohn aus zwei Schichten kleiner Zellen gebildet, welche continuirlich mit den beiden Schichten gröszerer Zellen zusammenhängen, welche die Wandungen der Blase bilden, von welchen sie offenbar eine Verlängerung ist. Zwei Paar durchsichtiger spitzer Borsten, ungefähr so lang wie die Klappe selbst, entspringen in der Nähe ihres freien hinteren Randes (Fig. 19) und weisen schräg nach auszen in der Richtung der Antennen. Auch finden sich auf der Oberfläche der Klappe zahlreiche Drüsen, wie ich sie nennen will; denn sie haben die Fähigkeit zu absorbiren, obschon ich zweifle, ob sie jemals absondern. Sie bestehen aus dreierlei Arten, welche bis zu einem gewissen Grade in einander übergehen.

# Drüsenarten

Diejenigen, welche rund um den vorderen Rand der Klappe (obere Rand in Fig. 19) herumstehen, sind sehr zahlreich und stehen dicht ge- drängt; sie bestehen aus einem oblongen Köpfchen auf einem langen Stiele. Der Stiel selbst wird von einer verlängerten Zelle gebildet, auf welcher eine kurze sitzt. Die Drüsen nach dem freien hinteren Rande zu sind viel gröszer, wenig an Zahl und beinahe sphärisch; sie haben kurze Stiele. Das Köpfchen wird durch das Verschmelzen zweier Zellen gebildet, die untere entspricht der kurzen oberen Zelle des Stiels der oblongen Drüsen. Die Drüsen der dritten Art haben quer verlängerte Köpfchen und sitzen auf sehr kurzen Stielen, so dasz sie parallel mit und dicht an der Oberfläche der Klappe stehen; sie können zweiarmige Drüsen genannt werden. Die Zellen, welche alle diese Drüsen bilden, enthalten einen Kern und sind mit einer Schicht mehr oder weniger körnigen Protoplasmas, dem Primordialschlauch Mohl’s, ausgekleidet. Sie sind mit Flüssigkeit erfüllt, welche viel Substanz in Lösung halten musz, nach der Menge der geronnenen Masse nach einem langen Eintauchen in Alkohol oder Äther zu ur- theilen.

# Der Kragen

Die Vertiefung, in welcher die Klappe liegt, ist gleichfalls mit unzähligen Drüsen bekleidet; diejenigen an den Seiten haben oblonge Köpfchen und verlängerte Stiele, genau so wie die Drüsen auf den anstoszenden Theilen der Klappe. Der Kragen (von Cohn Peristom genannt) wird offenbar, wie auch die Klappe, durch einen Vorsprung der Wandungen der Blase nach innen gebildet. Die die äuszere oder die nach der Klappe hin- sehende Fläche zusammensetzenden Zellen haben ziemlich dicke Wände, sind von einer bräunlichen Farbe, sehr klein, sehr zahlreich und verlän- gert; die untern sind durch verticale Scheidewände getheilt. Das Ganze bietet ein complicirtes und elegantes Ansehen dar. Die die innere Oberfläche bildenden Zellen sind in continuirlichem Zusammen- hange mit den über die ganze innere Oberfläche der Blase ver- breiteten.

# Gewebe zwischen den Oberflächen

Der Raum zwischen der äuszeren und inneren Oberfläche besteht aus grobem zelligen Gewebe (Fig. 20). Die innere Seite ist dicht mit zarten zweispaltigen, hernach zu beschreibenden Fortsätzen bedeckt. Hierdurch wird der Kragen dick; und er ist so steif, dasz er denselben Umrisz beibehält, mag die Blase wenig oder viel Wasser oder Luft enthalten. Dies ist von groszer Bedeutung, da sonst die dünne und biegsame Klappe nicht gehörig fungiren würde.# Einleitung
Alles zusammengenommen, bietet der Eingang in die Blase, ge-
bildet von der durchsichtigen Klappe mit ihren vier schräg vorsprin-
genden Borsten, ihren zahlreichen verschieden geformten Drüsen, um-
geben von dem Kragen, auf der Innenseite Drüsen und auf der Auszen-
seite Borsten tragend, in Verbindung mit den von den Antennen ge-
tragenen Borsten, eine auszerordentlich complicirte Erscheinung dar,
wenn sie unter dem Mikroskop beobachtet wird.

# Innere Struktur der Blase
Wir wollen nun die innere Structur der Blase betrachten. Unter
einer mäszig starken Vergröszerung betrachtet zeigt sich die ganze
innere Oberfläche, mit Ausnahme der Klappe, von einer dicht zu-
sammengedrängten Masse von Fortsätzen bedeckt (Fig. 21). Jeder
derselben besteht aus vier divergirenden Armen; daher ihr Name der
viertheiligen oder vierspaltigen Fortsätze. Sie entspringen von kleinen
eckigen Zellen an den Verbindungsstellen der Winkel der gröszeren
Zellen, welche das Innere der Blase bilden. Der mittlere Theil der
oberen Fläche dieser kleinen Zellen springt ein wenig vor und zieht
sich dann zu einem kurzen und schmalen Stiel zusammen, welcher
die vier Arme trägt (Fig. 22). Von diesen sind zwei lang, aber häufig
nicht von gleicher Länge, und springen schräg nach innen und nach
dem hinteren Ende der Blase vor. Die zwei andern sind viel kürzer
und springen in einem kleineren Winkel vor, d. h. sie sind mehr oder
beinahe horizontal und sind nach dem vordern Ende der Blase hin
gerichtet. Diese Arme sind nur mäszig scharf zugespitzt; sie wer-
den von einer äuszerst dünnen Membran gebildet, so dasz sie in jed-
weder Richtung gebogen oder eingefaltet werden können, ohne zu zer-
brechen. Sie werden von einer zarten Schicht von Protoplasma aus-
gekleidet, was gleichfalls bei den kurzen kegelförmigen Fortsätzen
der Fall ist, von denen sie entspringen. Jeder Arm enthält meistens
(aber nicht ausnahmslos) ein äuszerst kleines, schwach braunes Kör-
perchen, entweder rundlich oder häufiger länglich, welches unaufhör-
liche Brown’sche Bewegung zeigt. Diese Körperchen ändern langsam
ihre Stellung und wandern von einem Ende der Arme zum andern,
werden aber gewöhnlich in der Nähe ihrer Basen gefunden. Sie sind
in den viertheiligen Fortsätzen junger Blasen vorhanden, wenn diese
nur ungefähr ein Drittel ihrer vollen Grösse erreicht haben. Ge-
wöhnlichen Zellenkernen sind sie nicht ähnlich; ich glaube aber, dasz
es Kerne in einem modificirten Zustande sind; denn wenn sie fehlen,
konnte ich gelegentlich an ihrer Stelle eben noch eine zarte Wolke
von Substanz erkennen, welche einen dunkleren Fleck einschlosz.
Überdies enthalten die viertheiligen Fortsätze von Utricularia montana
eher etwas gröszere und viel regelmäsziger sphärische, aber im Übri-
gen ähnliche Körperchen, welche den Kernen in den, die Wandungen
der Blasen bildenden Zellen sehr ähnlich sind. Im vorliegenden Falle
fanden sich zuweilen zwei, drei, oder selbst noch mehr nahezu ähn-
liche Körperchen innerhalb eines einzelnen Arms; es scheint indessen,
wie wir nachher sehen werden, die Gegenwart von mehr als einem
immer mit der Absorption sich zersetzender Substanz zusammenzu-
hängen.

# Fortsätze des Kragens
Die innere Seite des Kragens (s. die frühere Fig. 20) wird von
mehreren dicht aneinander gedrängten Reihen von Fortsätzen bedeckt,
welche in keiner wichtigen Beziehung von den viertheiligen abweichen,
ausgenommen darin, dasz sie nur zwei Arme tragen anstatt vier;
sie sind indessen eher etwas schmäler und zarter. Ich werde sie die
zweispaltigen Fortsätze nennen. Sie springen in die Blase vor und
sind nach deren hinterem Ende zu gerichtet.# Die Funktion der Blasen

Die wirkliche Function der Blasen ist, kleine Wasserthiere zu fangen, und dies thun sie in einem groszen Maszstabe. Von der ersten Anzahl Pflanzen, welche ich zeitig im Juli von dem New Forest erhielt, umschlossen verhältnismäszig viele der völlig erwachsenen Blasen Beute; bei einer zweiten Sendung, welche ich anfangs August erhielt, waren die meisten der Blasen leer; es waren indessen Pflanzen ausgewählt worden, welche in ungewöhnlich reinem Wasser wuchsen.

# Untersuchung der Blasen

Von der ersten Sendung untersuchte mein Sohn siebenzehn Blasen, welche Beute irgend welcher Art umschlossen, und acht derselben enthielten entomostrake Krustenthiere, drei Insectenlarven, von denen eine noch lebendig war, und sechs so stark zersetzte Überreste von Thieren, dasz ihre Natur nicht mehr unterschieden werden konnte. Ich wählte fünf Blasen heraus, welche sehr voll zu sein schienen, und fand in ihnen vier, fünf, acht und zehn Krustenthiere und in der fünften eine einzige sehr lang gestreckte Larve.

# Fangmechanismus der Blasen

Die Thiere gelangen in der Weise in die Blase, dasz sie den hintern freien Rand der Klappe abbiegen, welcher sich dann, da er in hohem Grade elastisch ist, augenblicklich wieder schlieszt. Da die Kante äuszerst dünn ist und dicht an den Rand des Kragens sich anlegt, wobei beide in die Blase vorspringen, so wird es offenbar für alle Thiere sehr schwierig sein, wieder herauszukommen, wenn sie sich einmal gefangen haben; und allem Anscheine nach ent- schlüpfen sie niemals.

# Schwierigkeiten beim Entkommen

Um zu zeigen, wie dicht der Rand schlieszt, will ich erwähnen, dasz mein Sohn eine Daphnia fand, welche eine ihrer Antennen in den Schlitz gesteckt hatte; und dadurch wurde sie einen ganzen Tag lang fest gehalten. Bei drei oder vier Gelegenheiten habe ich lange schmale Larven, sowohl todte als auch lebendige, zwischen die Klappe und den Kragen eingekeilt gefunden, wobei ihre Körper halb innerhalb und halb auszerhalb der Blasen waren.

# Versuche zur Ermittlung des Fangmechanismus

Da es mir sehr schwierig war, einzusehen, wie derartige minutiöse und schwache Thiere, wie sie so häufig gefangen werden, sich ihren Eintritt in die Blasen erzwingen können, habe ich viele Versuche angestellt, um zu ermitteln, wie dies ausgeführt wird. Der freie Rand der Klappe biegt sich so leicht, dasz man keinen Wider-# Einleitung
stand fühlt, wenn eine Nadel oder eine dünne Borste eingeführt wird. Ein dünnes menschliches Haar, an einen Griff befestigt und so weit abgeschnitten, dasz es kaum ¼ Zoll vorsprang, gieng mit etwas Schwierigkeit hinein; ein längeres Stück gab nach, anstatt einzugehn.

# Experimente mit Glasstückchen
Bei drei Gelegenheiten wurden äuszerst kleine Stückchen blauen Glases (um leicht erkannt zu werden) auf Klappen gelegt, während sie unter Wasser waren; als ich leise versuchte, sie mit einer Nadel zu bewegen, verschwanden sie so plötzlich, dasz ich, da ich nicht sah, was passiert war, glaubte, ich hätte sie fortgeschnellt; als ich aber die Blasen untersuchte, fand ich sie ganz sicher eingeschlossen.

# Beobachtungen mit Holzstückchen
Dasselbe passirte meinem Sohne, welcher kleine Würfelchen von grünem Buchsbaumholz (von ungefähr \frac {1}{60} Zoll oder 0,423 Mm. Seitenlänge) auf einige Klappen legte; und dreimal kaum es während des Actes, sie aufzulegen oder sie leise auf eine andere Steile zu bewegen, vor, dasz sich die Klappe plötzlich öffnete und sie verschluckt waren.

# Langsame Biegung der Klappen
Ferner brachte ich Stückchen von blauem Glas auf drei Klappen und äuszerst minutiöse abgeschabte Stückchen Blei auf zwei andere Klappen; nach 1 oder 2 Stunden war keines eingetreten, aber in einer Zeit von 2 bis 5 Stunden waren sie alle fünf eingeschlossen.

# Untersuchung der Blasen
Eines der Glasstückchen war ein langer Splitter, dessen eines Ende schräg auf der Klappe ruhte; nach wenig Stunden fand man es fixirt, halb innerhalb der Blase und halb nach auszen vorspringend; wobei der Rand der Klappe rings herum dicht anschlosz mit Ausnahme des einen Winkels, wo eine kleine Stelle offen gelassen war.

# Weitere Experimente mit Buchsbaumholz
Mein Sohn legte auch kleine Würfelchen (ungefähr \frac {1}{65} Zoll oder 0,391 Mm.) von grünem Buchsbaumholz, welche gerade schwer genug waren, um in Wasser unterzusinken, auf drei Klappen. Dieselben wurden nach 19 Stunden 30 Minuten untersucht und wurden noch immer auf den Klappen liegend gefunden; nach 22 Stunden 30 Minuten waren sie aber eingeschlossen.

# Zufällige Entdeckungen
Ich will hier erwähnen, dasz ich in einer Blase an einer in natürlichen Verhältnissen wachsenden Pflanze ein Körnchen Sand und in einer andern Blase drei Körnchen fand; diese müssen durch irgend welchen Zufall auf die Klappen gefallen und dann wie die Glastheilchen in die Blasen gelangt sein.

# Analogie zur Biegung colloider Substanzen
Die langsame Biegung der Klappe unter dem Gewicht der Glasstückchen und selbst der Buchsbaumholzwürfelchen, trotzdem sie in hohem Masze vom Wasser getragen werden, ist, wie ich vermuthe, der langsamen Biegung colloider Substanzen analog.

# Reaktion auf Reizung
Es wurden beispielsweise Glasstückchen auf verschiedene Stellen schmaler Streifen von angefeuchteter Gelatine gelegt; und diese gaben mit äuszerster Langsamkeit nach und bogen sich. Es ist viel schwerer zu verstehen, woher es kommt, dasz das leise Hin- und Herbewegen eines Stück-
chens von einem Theile der Klappe zu einem andern dieselbe veranlasst, sich plötzlich zu öffnen.

# Schlussfolgerungen
Wir können daher schlieszen, dasz Thiere einfach dadurch in die Blase gelangen, dasz sie sich einen Eingang durch die schlitzförmige Öffnung erzwingen; ihr Kopf dient dabei als Keil. Ich bin aber darüber überrascht, dasz so kleine und schwache Geschöpfe, wie häufig gefangen werden (so# Einleitung

z. B. der Nauplius eines Krustenthieres und ein Tardigrade) stark genug sein sollten, in dieser Weise vorzugehen, wenn ich daneben bedenke, dasz es schwer war, das Ende eines ¼ Zoll langen Stückchen Haares hineinzubringen. Demungeachtet ist es gewisz, dasz schwache und kleine Geschöpfe wirklich eindringen; Mrs. Treat in New-Jersey ist erfolgreicher als irgend ein anderer Beobachter gewesen und hat häufig bei der Utricularia clandestina den Vorgang mit angesehenNew York Tribune, wieder abgedruckt in The Gardener’s Chronicle, 1875, p. 303..

# Beobachtungen von Mrs. Treat

Sie sah ein tardigrades Thier langsam um eine Blase herumgehen, wie zum Recognosciren; endlich kroch es in die Vertiefung, in wel- cher die Klappe liegt, und dann gieng es leicht hinein. Sie war auch Zeuge von dem Fangen verschiedener sehr kleiner Krustenthiere. Cypris „war ganz schlau, wurde aber demungeachtet häufig gefangen. „Kam sie bis an den Eingang in die Blase, dann hielt sie für einen „Augenblick still und schosz dann hinweg; andere male kam sie ganz „nahe heran und wagte sich selbst ein Stückchen Wegs in den Ein- gang hinein, kehrte aber zurück, als fürchtete sie sich. Eine an- dere, unbedachtsamere, öffnete die Thüre und gieng hinein; sobald „sie indessen drin war, zeigte sie Unruhe, sie zog ihre Füsze und Antennen ein und schlosz ihre Schale.‟ Wenn Larven, dem An- scheine nach von Mücken, „in der Nähe des Eingangs fraszen, so „rannten sie ziemlich gewisz mit ihren Köpfen in das Netz, aus dem es kein Entrinnen gab. Ehe eine grosze Larve verschluckt wird, dauert es zuweilen drei oder vier Tage lang; der ganze Vorgang rief mir das Bild in das Gedächtnis, was ich erhielt, als eine kleine Schlange einen groszen Frosch verschlang.‟ Da aber die Klappe nicht im mindesten reizbar zu sein scheint, so musz der langsame Procesz des Verschlingens die Folge der Vorwärtsbewegung der Larve sein.

# Anreize für das Eindringen

Es ist schwer, sich darüber eine Vermuthung zu bilden, was wohl so viele Geschöpfe, fleisch- und pflanzenfressende Krustenthiere, Würmer, Tardigraden und verschiedene Larven anreizen kann, in die Blasen zu gehen. Mrs. Treat sagt, dasz die eben erwähnten Larven von Pflanzennahrung leben und eine besondere Liebhaberei für die langen Borsten rings um die Klappe haben; dieser Geschmack kann aber den Eintritt von fleischfressenden Krustenthieren nicht erklären. Vielleicht versuchen kleine im Wasser lebende Thiere gewohnheits- gemäsz in jeden kleinen Spalt einzutreten, wie in den zwischen Klappe und Kragen, um Nahrung oder Schutz zu suchen. Es ist nicht wahr- scheinlich, dasz die merkwürdige Durchsichtigkeit der Klappe ein zu- fälliger Umstand ist; der dadurch entstehende lichte Punkt könnte als Führer dienen. Die langen Borsten rings um den Eingang dienen allem Anscheine nach demselben Zwecke. Ich glaube deshalb, dasz dies der Fall ist, weil die Blasen einiger epiphytisch und auf Marsch- boden lebender Species von Utricularia, welche entweder in verfilzter Vegetation oder in Schlamm leben, keine Borsten um den Eingang haben; diese würden unter solchen Bedingungen von keinem Nutzen als Führer sein. Demungeachtet springen bei diesen epiphytischen auf Marschboden lebenden Arten zwei Paare Borsten von der Ober- fläche der Klappe wie in den wasserlebenden Arten vor; ihre Function ist wahrscheinlich die, gröszere Thiere von einem Versuche, in die Blase einzudringen, abzuhalten, damit nicht dadurch die Mündung eingerissen werde.

# Erfolgsquote beim Fangen von Beute

Da unter günstigen Umständen die meisten Blasen im Fangen von Beute Erfolg haben (in einem Falle selbst zehn Krustenthiere), — da die Klappe so gut dazu angepaszt ist, den Thieren den Eingang zwar zu gestatten, aber ihr Entweichen zu verhindern, — und da die Innenseite der Blase eine so eigenthümliche Structur darbietet, in ihrer Auskleidung mit unzähligen viertheiligen und zweigespaltenen Fortsätzen, so läszt sich unmöglich daran zweifeln, dasz die Pflanze speciell für das Fangen von Beute eingerichtet worden ist. Nach Anologie mit der zu derselben Familie gehörigen Pinguicula erwar-# Verdauungsfähigkeit der Utricularia

tete ich natürlich, dasz die Blasen ihre Beute verdauen würden; dies
Darwin, Insectenfressende Pflanzen. (VIII.) 24
Utricularia neglecta. Cap. 17.
ist aber nicht der Fall, es sind auch keine zur Absonderung der ge-
hörigen Flüssigkeit angepaszte Drüsen vorhanden. Nichtsdestoweniger
wurden, um ihre Verdauungsfähigkeit auf die Probe zu stellen, minu-
tiöse Fragmente gerösteten Fleisches, drei kleine Würfelchen von Ei-
weisz und drei dergleichen von Knorpel durch die Mündung in die
Blasen kräftiger Pflanzen geschoben. Sie wurden einen bis drei und
einen halben Tage lang darin gelassen und die Blasen dann aufge-
schnitten; aber keine einzige der erwähnten Substanzen liesz auch
nur das mindeste Zeichen von Verdauung oder Auflösung erkennen;
die Kanten der Würfel waren so scharf wie je. Diese Beobachtungen
wurden später gemacht als die an Drosera, Dionaea, Drosophyllum
und Pinguicula, so dasz ich mit der äuszern Erscheinung dieser Sub-
stanzen, wenn sie sich in den früheren oder letzten Stadien der Ver-
dauung befinden, wohl vertraut war. Wir können daher schlieszen,
dasz Utricularia die Thiere, welche sie gewohnheitsgemäzs fängt,
nicht verdauen kann.

# Zerfall der gefangenen Tiere

In den meisten Blasen sind die gefangenen Thiere so stark zer-
setzt, dasz sie eine blaszbraune, breiige Masse bilden, während ihre
chitinhaltigen Hüllen so zart geworden sind, dasz sie mit der grösz-
ten Leichtigkeit in Stücke zerfallen. Der schwarze Farbstoff der
Augenflecke erhält sich besser als irgend etwas anderes. Gliedmaszen,
Kiefer u. s. w. werden häufig vollständig losgetrennt gefunden; und
dies ist, wie ich vermuthe, die Folge des vergeblichen Sträubens
der später gefangenen Thiere. Ich bin zuweilen über das geringe
Verhältnis gefangener Thiere in einem frischen Zustande verglichen
mit den gänzlich zerfallenen überrascht gewesen. Mrs. Treat gibt
mit Bezug auf die oben angeführten Larven an, dasz „gewöhnlich in
„weniger als zwei Tagen, nachdem eine grosze Larve gefangen war,
„der flüssige Inhalt der Blasen ein wolkiges oder trübes Aussehen
„anzunehmen begann und dasz er oft so dick wurde, dasz die Um-
„risse des Thieres aus dem Gesichte verschwanden.‟ Diese Angabe
regt die Vermuthung an, dasz die Blasen irgend ein Ferment abson-
dern, welches den Procesz des Zerfalls beschleunigt. An und für sich
liegt in dieser Vermuthung nichts unwahrscheinliches, wenn man be-
denkt, dasz Fleisch, welches 10 Minuten lang in, mit dem milchigen
Safte des Traubenbaums (papaw) gemischtem Wasser eingeweicht wird,
völlig weich wird und, wie Browne in seiner Naturgeschichte von
Jamaica bemerkt, bald in einen Zustand von Fäulnis übergeht.

# Absorption von Stoffen

Mag der Zerfall der gefangen gehaltenen Thiere auf irgend eine
Weise beschleunigt werden oder nicht, so ist doch sicher, dasz durch
die viertheiligen und zweigespaltenen Fortsätze Stoffe aus ihnen ab-
sorbirt werden. Die äuszerst zarte Beschaffenheit der Membran, von
welcher diese Fortsätze gebildet werden, und die grosze Oberfläche,
welche sie darbieten, — in Folge ihrer groszen dicht gedrängt über
die ganze innere Fläche der Blase verbreiteten Zahl, — sind Um-
stände, welche alle den Procesz der Aufsaugung begünstigen. Viele
vollkommen reine Blasen, welche niemals irgend welche Beute ge-
fangen hatten, wurden geöffnet; es konnte aber mit einem Hartnack’-
schen Objectivglas Nr. 8 innerhalb der zarten structurlosen, proto-
plasmatischen Auskleidung ihre Arme nichts unterschieden werden,
ausgenommen das in jedem vorkommende einzelne gelbliche Körper-
chen oder der modificirte Kern. Zuweilen waren zwei oder selbst
drei derartige Körperchen vorhanden; in diesem Falle aber konnten
meist Spuren zerfallender Substanz entdeckt werden. Andererseits
boten die Fortsätze in Blasen, welche entweder ein groszes oder meh-
rere kleinere zerfallene Thiere enthielten, ein gänzlich verschiedenes
Ansehen dar. Sechs derartige Blasen wurden sorgfältig untersucht:
eine enthielt eine langgestreckte, aufgerollte Larve, eine andere ein
einzelnes groszes entomostrakes Krustenthier, und die übrigen von
zwei bis fünf kleinere, sämmtlich in einem zersetzten Zustande. In# Beobachtungen zu Protoplasma und Fortsätzen

diesen sechs Blasen enthielt eine grosze Zahl der viertheiligen Fort-
sätze durchsichtige, häufig gelbliche, mehr oder weniger zusammen-
flieszende sphärische oder unregelmäszig geformte Massen von Sub-
stanz. Einige von den Fortsätzen enthielten indessen nur fein gra-
nulirte Substanz, deren Theilchen so klein waren, dasz sie mit dem
System Hartnack Nr. 8 nicht deutlich definirt werden konnten. Die
zarte, ihre Wandungen auskleidende Schicht von Protoplasma war in
einigen Fällen etwas eingeschrumpft. Bei drei Gelegenheiten wurden
die eben erwähnten Substanzmassen beobachtet und nach kurzen
Intervallen gezeichnet; sie hatten ganz sicher ihre Stellungen im Ver-
hältnis zu einander wie zu den Wandungen der Arme geändert. Ein-
zelne Massen flossen zuweilen zusammen und theilten sich dann wieder.
Eine einzelne kleine Masse schickte einen Fortsatz ab, welcher sich
nach einiger Zeit lostrennte. Es konnte daher daran kein Zweifel
sein, dasz diese Massen aus Protoplasma bestanden. Bedenkt man
aber, dasz viele reine Blasen mit gleicher Sorgfalt untersucht wurden,
und dasz diese keine solche Erscheinung darboten, so können wir ge-
trost annehmen, dasz in den oben erwähnten Fällen das Protoplasma
durch die Aufsaugung stickstoffhaltiger Substanz aus den sich zer-
setzenden Thieren sich erzeugt hatte. In zwei oder drei Blasen, welche
anfangs völlig rein erschienen, fanden sich nach sorgfältigem Suchen
einige wenige Fortsätze, deren Auszenseite mit etwas brauner Sub-
stanz bedeckt war, woraus hervorgieng, dasz irgend ein kleines Thier
gefangen war und sich zersetzt hatte: hier schlossen die Arme sehr
wenige mehr oder weniger sphärische und zusammengeballte Massen
ein; die Fortsätze an anderen Stellen der Blasen waren leer und
durchscheinend. Andererseits musz noch angegeben werden, dasz in
drei, todte Krustenthiere enthaltenden Blasen die Fortsätze gleich-
falls leer waren. Diese Thatsache kann dadurch erklärt werden, dasz
die Thiere nicht hinreichend weit zersetzt waren oder dasz für die
Bildung von Protoplasma nicht genug Zeit gelassen worden war, oder
dasz es später absorbirt und anderen Theilen der Pflanze zugeführt
worden war. Wir werden nachher sehen, dasz in drei oder vier an-
dern Species von Utricularia die viertheiligen Fortsätze in Berührung
mit zerfallenden Thieren gleichfalls zusammengeballte Massen von
Protoplasma enthielten.

# Absorption gewisser Flüssigkeiten durch die viertheiligen Fortsätze

Diese Versuche wurden angestellt, um zu ermitteln, ob gewisse Flüssig-
keiten, welche zu diesem Zwecke passend zu sein schienen, dieselben
Wirkungen auf die Fortsätze hervorbringen würden, wie die Absorp-
tion zerfallner thierischer Substanz. Derartige Experimente sind in-
dessen mühsam; denn es ist nicht hinreichend, einen Zweig einfach in
die Flüssigkeit einzulegen, da die Klappe so dicht schliest, dasz die
Flüssigkeit dem Anscheine nach sobald nicht, wenn überhaupt, ein-
dringt. Selbst als Borsten in die Mündungen gesteckt wurden, wurde
sie in mehreren Fällen so dicht ringsum von dem dünnen biegsamen
Rande der Klappe umgeben, dasz die Flüssigkeit allem Anscheine
nach ausgeschlossen wurde. Die beste Methode würde gewesen sein,
die Blasen anzustechen; hieran dachte ich aber nicht eher, ausge-
nommen in einigen wenigen Fällen, als bis es zu spät war. In allen
derartigen Versuchen kann es indessen nicht positiv ermittelt werden,
ob die Blase, obschon sie durchscheinend ist, nicht irgend ein minu-
tiöses Thier auf dem letzten Stadium des Zerfalls enthalte. Es wur-
den daher die meisten meiner Experimente so angestellt, dasz die
Blasen längsweise in zwei Hälften zerschnitten wurden; die vierthei-
ligen Fortsätze wurden dann mit dem System Hartnack Nr. 8 unter-
sucht und, während sie unter dem Deckgläschen lagen, mit wenig
Tropfen der zum Versuche dienenden Flüssigkeit befeuchtet, in einer
feuchten Kammer erhalten und nach bestimmten Zwischenräumen mit
derselben Vergröszerung wie vorher wieder untersucht.# Experimentelle Beobachtungen

Vier Blasen wurden zuerst, als Controlversuch, in der so eben ge-
schilderten Weise in einer Auflösung von einem Theil arabischen Gummis
auf 218 Theile Wasser, und zwei Blasen in einer Auflösung von einem
Theil Zucker auf 437 Theile Wasser versucht; in keinem der beiden
Fälle war nach 21 Stunden weder in den viertheiligen noch in den zwei-
teiligen Fortsätzen irgend eine Veränderung bemerkbar. Vier Blasen
wurden dann in derselben Weise mit einer Lösung von einem Theile
salpetersauren Ammoniaks auf 437 Theile Wasser behandelt und nach
21 Stunden wieder untersucht. In zweien von diesen erschienen nur die
viertheiligen Fortsätze voll von sehr fein granulirter Substanz, und ihre
protoplasmatische Auskleidung oder der Primordialschlauch war ein wenig
geschrumpft. In der dritten Blase schlossen die viertheiligen Fortsätze
deutlich sichtbare Körnchen ein, und der Primordialschlauch war nach
nur 8 Stunden ein wenig geschrumpft. In der vierten Blase war der
Primordialschlauch in den meisten der Fortsätze hier und da in kleinen
unregelmäszigen, gelblichen Flecken verdickt; und nach den Abstufungen,
welche in diesen und andern Fällen verfolgt werden konnten, schienen
diese Flecke die gröszeren freien Körnchen entstehen zu lassen, welche
innerhalb einiger der Fortsätze enthalten waren. Andere Blasen, welche,
so weit es beurtheilt werden konnte, niemals irgend eine Beute gefangen
hatten, wurden angestochen und in der nämlichen Lösung 17 Stunden
lang liegen gelassen; ihre viertheiligen Fortsätze enthielten nun sehr fein
granulirte Substanz.

# Weitere Untersuchungen

Eine Blase wurde in zwei Hälften geschnitten, untersucht und mit
einer Lösung von einem Theile kohlensauren Ammoniaks auf 437 Theile
Wasser betropft. Nach 8 Stunden 30 Minuten enthielten die vierthei-
ligen Fortsätze ziemlich viele Körnchen und der Primordialschlauch war
etwas geschrumpft; nach 23 Stunden enthielten die viertheiligen und
zweigespaltenen Fortsätze viele Kugeln hyaliner Substanz; in einem Arm
wurden vierundzwanzig derartige Kugeln von mäsziger Grösse gezählt.
Zwei durchgeschnittene Blasen, welche vorher 21 Stunden lang in der
Gummiauflösung (ein Theil auf 218 Theile Wasser) liegen gelassen worden
waren, ohne afficirt worden zu sein, wurden mit der Lösung von kohlen-
saurem Ammoniak benetzt; und in beiden wurden die viertheiligen Fort-
sätze in nahezu derselben Art und Weise modificirt wie oben beschrieben
wurde, und zwar in der einen nach nur 9 Stunden und in der andern
nach 24 Stunden. Zwei Blasen, welche noch niemals irgend eine Beute
gefangen zu haben schienen, wurden angestochen und in die Lösung ge-
legt; die viertheiligen Fortsätze der einen wurden nach 17 Stunden unter-
Utricularia neglecta. Cap. 17.
sucht und leicht opak gefunden; die viertheiligen Fortsätze der andern
hatten bei ihrer Untersuchung nach 45 Stunden mehr oder weniger ge-
schrumpfte Primordialschläuche mit verdickten gelblichen Flecken, denen
ähnlich, welche in Folge der Einwirkung des salpetersauren Ammoniaks
auftraten. Mehrere unverletzte Blasen wurden in derselben Lösung, eben
so wie in einer schwächeren von einem Theile auf 1750 Theile Wasser,
oder 1 Gran auf 4 Unzen, liegen gelassen; nach zwei Tagen waren die
viertheiligen Fortsätze mehr oder weniger opak, ihr Inhalt fein granulirt;
ob aber die Lösung durch die Mündung eingetreten ist oder von der
äuszern Seite absorbirt worden war, weisz ich nicht.

# Einfluss von Harnstoff

Zwei durchschnittene Blasen wurden mit einer Lösung von einem
Theile Harnstoff auf 218 Theile Wasser benetzt; als aber diese Lösung
angewandt wurde, vergasz ich, dasz sie einige Tage lang in einem warmen
Zimmer gehalten worden war und daher wahrscheinlich etwas Ammoniak
erzeugt hatte; wie dem auch sein mag, nach 21 Stunden waren die vier-
theiligen Fortsätze so afficirt, als wenn eine Auflösung von kohlensaurem
Ammoniak gebraucht worden wäre; denn der Primordialschlauch war in
Flecken verdickt, welche in sich lösende Körnchen überzugehen schienen.
Die durchschnittenen Blasen wurden auch mit einer frischen Lösung von
Harnstoff benetzt; nach 21 Stunden waren die viertheiligen Fortsätze viel
weniger afficirt als in dem ersteren Falle; nichtsdestoweniger war der
Primordialschlauch in einigen der Arme ein wenig geschrumpft und in
andern in zwei beinahe symmetrische Schläuche getheilt.
Drei durchschnittene Blasen wurden, nachdem sie untersucht worden# Experimentelle Beobachtungen

waren, mit einem fauligen und sehr stark übel riechenden Aufgusse von rohem Fleische benetzt. Nach 23 Stunden waren in den viertheiligen und zweigespaltenen Fortsätzen aller drei Exemplare ungemein viel minutiöse, sphärische Massen vorhanden, und einige von den Primordialschläuchen waren etwas geschrumpft. Drei durchschnittene Blasen wurden auch mit einem frischen Aufguss von rohem Fleisch benetzt; und zu meiner Überraschung erschienen in einer von ihnen nach 23 Stunden die viertheiligen Fortsätze fein granuliert, der Primordialschlauch etwas geschrumpft und mit verdickten gelblichen Flecken gezeichnet, so dass die Flüssigkeit in derselben Art und Weise auf sie gewirkt hatte wie der faulende Aufguss oder die Ammoniaksalze. In der zweiten Blase hatte die Flüssigkeit in ähnlicher Weise, wennschon in einem sehr unbedeutenden Grade, auf die viertheiligen Fortsätze eingewirkt, während die dritte Blase durchaus nicht afficirt war.

# Absorption durch die viertheiligen Fortsätze

Nach diesen Experimenten ist es klar, dass die viertheiligen und zweigespaltenen Fortsätze das Vermögen haben, kohlensaures und salpetersaures Ammoniak, und Substanz von irgend welcher Art aus einem faulenden Aufgusse von rohem Fleische zu absorbieren. Es wurden Ammoniaksalze zum Versuche gewählt, weil bekannt ist, dass sie sich bei der Zersetzung thierischer Substanz in Gegenwart von Luft und Wasser außerordentlich schnell erzeugen und sich daher auch innerhalb der, gefangene Beute enthaltenden Blasen bilden werden.

# Vergleich der Ergebnisse

Der auf die Fortsätze durch Einwirkung dieser Salze und eines faulenden Aufgusses von rohem Fleisch hervorgebrachte Erfolg weicht von dem durch die Zersetzung der auf natürlichem Wege gefangenen Thiere hervorgebrachten nur darin ab, dass die zusammengeballten Massen von Protoplasma im letztern Falle von bedeutenderer Größe sind; es ist aber wahrscheinlich, dass die feinen Körnchen und die kleinen hyalinen Kugeln, welche die Lösungen erzeugen, zu größeren Massen verschmelzen würden, wenn man ihnen genug Zeit ließe. Wir haben bei Drosera gesehen, dass die erste Wirkung einer schwachen Auflösung von kohlensaurem Ammoniak auf den Zelleninhalt die Erzeugung der feinsten Körnchen ist, welche sich später zu größeren, mehr oder weniger abgerundeten Massen zusammenballen, und dass die Körnchen in der Protoplasmaschicht, welche rings um die Zellenwände herumfließt, schließlich mit diesen Massen verschmelzen. Veränderungen dieser Art sind indessen bei Drosera viel rapider als bei Utricularia.

# Überraschende Ergebnisse

Da die Blasen nicht das Vermögen besitzen, Eiweiß, Knorpel oder geröstetes Fleisch zu verdauen, so war ich überrascht, dass, mindestens in einem Falle, aus einem frischen Aufgusse von rohem Fleisch Substanz absorbiert wurde. Auch war ich, nach dem, was wir sofort in Bezug auf die Drüsen rings um die Mündung sehen werden, überrascht, dass eine frische Auflösung von Harnstoff nur eine mäßige Wirkung auf die viertheiligen Fortsätze ausübte.

# Entwicklung der viertheiligen Fortsätze

Da die viertheiligen Fortsätze sich aus Papillen entwickelt haben, welche anfangs denen auf der Außenseite der Blasen und auf der Oberfläche der Blätter sehr ähnlich sind, so will ich hier noch anführen, dass die zwei halbkugligen Zellen, welche auf der Spitze dieser letztern Papillen stehen und welche in ihrem natürlichen Zustande vollkommen durchsichtig sind, gleichfalls kohlensaures und salpetersaures Ammoniak absorbieren; denn nach einem 23 Stunden langen Eintauchen in Auflösungen von einem Teile dieser beiden Salze auf 437 Teile Wasser waren die Primordialschläuche ein wenig geschrumpft und von einer blass-braunen Färbung, auch zuweilen fein granuliert. Dasselbe Resultat erfolgte, als ein ganzer Zweig nahezu drei Tage lang in eine Auflösung von einem Teile des kohlensauren Salzes auf 1750 Teile Wasser gelegt worden war. Auch wurden die Chlorophyllkörner in den Zellen der Blätter an diesem Zweige an vielen Stellen zu kleinen grünen Massen zusammengeballt, welche häufig durch die feinsten Fäden miteinander verbunden wurden.

# Utricularia neglecta

Über die Absorption gewisser Flüssigkeiten durch die Drüsen an der Klappe und dem Kragen. — Die Drüsen# Absorption durch die Drüsen

rund um die Mündungen der Blasen, welche noch jung sind oder welche lange in mäszig reinem Wasser gehalten worden sind, sind farblos; und der Primordialschlauch in ihren Zellen ist nur unbedeutend oder kaum irgendwie körnig. Aber in der Mehrzahl der Pflanzen im Naturzustande — und hier müssen wir uns daran erinnern, dasz sie meistens in sehr fauligem Wasser wachsen — und in Pflanzen, welche in einem Aquarium mit faulem Wasser gehalten werden, sind die meisten Drüsen von einer blasz-bräunlichen Färbung; der Primordialschlauch ihrer Zellen war mehr oder weniger geschrumpft, zuweilen gerissen und der ganze Zelleninhalt häufig grob granulirt oder zu kleinen Massen zusammengeballt. Dasz dieser Zustand der Drüsen eine Folge davon ist, dasz sie Stoffe aus dem umgebenden Wasser absorbirt haben, daran kann ich nicht zweifeln, denn wie wir sofort sehen wer- den, tritt dasselbe Resultat ein, wenn sie wenige Stunden lang in verschiedene Lösung gelegt werden. Es ist auch nicht wahrschein- lich, dasz diese Aufsaugung nutzlos ist, wenn wir sehen, dasz sie bei Pflanzen, welche im Naturzustande wachsen, die Fälle ausgenommen, wo das Wasser merkwürdig rein ist, beinahe ganz allgemein ist.

# Struktur der Drüsen

Die Stiele der Drüsen, welche dicht an der schlitzförmigen Mün- dung sowohl auf der Klappe als auch auf dem Kragen stehen, sind kurz; während die Stiele der entfernter stehenden Drüsen sehr ver- längert sind und nach innen vorspringen. Hiernach sind die Drüsen ganz gut dazu angeordnet, dasz sie von jeder, durch die Mündung aus der Blase tretenden Flüssigkeit umspült werden. Nach den Er- folgen eines Einlegens unverletzter Blasen in verschiedenartige Lösun- gen zu urtheilen, schlieszt die Klappe so dicht an, dasz es zweifel- haft ist, ob irgend welche faulige Flüssigkeit für gewöhnlich nach auszen tritt. Wir müssen uns aber daran erinnern, dasz eine Blase meistens mehrere Thiere fängt, und dasz jedes Mal, wenn ein frisches Thier in dieselbe eintritt, ein Stosz fauligen Wassers austreten und die Drüsen umspülen musz.

# Experimente zur Überprüfung

Überdies habe ich wiederholt gefunden, dasz, wenn man Blasen, welche Luft enthalten, sanft drückt, äuszerst kleine Luftbläschen durch die Mündung nach auszen getrieben werden; und wenn eine Blase auf Löschpapier gelegt und leicht gedrückt wird, so quillt Wasser heraus. Sobald in diesem letzteren Falle mit dem Drucke nachgelassen wird, wird Luft eingezogen und die Blase erhält ihre frühere Form wieder. Wenn sie nun unter Wasser gelegt und wieder leicht gedrückt wird, so kommen sehr kleine Luftbläschen zu der Öffnung und nirgends anders heraus, wodurch bewiesen wird, dasz die Wände der Blase nicht gesprengt sind. Ich erwähne dies deshalb, weil Cohn eine Angabe von Treviranus anführt, dasz Luft nicht aus einer Blase herausgepreszt werden könne, ohne sie zu zer- sprengen. Wir können daher schlieszen, dasz, wenn überhaupt Luft in einer bereits mit Wasser erfüllten Blase abgesondert wird, etwas Wasser langsam durch die Mündung ausgetrieben werden wird. Ich kann daher kaum daran zweifeln, dasz die rings um die Mündung dicht gedrängt stehenden Drüsen dazu angepaszt sind, Stoffe aus dem fauligen Wasser zu absorbiren, welches gelegentlich aus Blasen, die zerfallende Thiere enthalten, ausflieszen wird.

# Versuche mit verschiedenen Flüssigkeiten

Um diese Schluszfolgerung zu prüfen, stellte ich Versuche mit ver- schiedenen Flüssigkeiten an den Drüsen an. Wie bei den viertheiligen Fortsätzen wurden auch hier Ammoniaksalze versucht, da sich diese bei dem endlichen Zerfall thierischer Substanz unter Wasser erzeugen. Unglücklicherweise können die Drüsen nicht sorgfältig untersucht werden, während sie noch an den Blasen in ihrem unverletzten Zustande angeheftet sind. Es wurden daher die Scheitel der Blasen, welche die Klappe, den Kragen und die Antennen enthielten, aufgeschlitzt und der Zustand der Drüsen beobachtet; sie wurden dann, während sie unter einem Deck- gläschen lagen, mit den Lösungen benetzt und nach einiger Zeit mit der nämlichen Vergröszerung wie vorher, nämlich mit dem System Hart- nack Nr. 8, wieder untersucht. In dieser Weise wurden die folgenden Experimente angestellt.# Experimentelle Beobachtungen an Drüsen

Es war auch nothwendig, darüber Beobachtungen an-
zustellen, ob die Drüsen durch das Abschneiden der Gipfel der Blasen afficirt
waren. Es wurden in dieser Weise vier Blasenscheitel versucht; der eine wurde
nach 2 Stunden 30 Minuten und die andern drei nach 23 Stunden unter-
sucht; es war aber in den Drüsen nicht eines einzigen von ihnen eine
ausgesprochene Veränderung eingetreten.

## Einfluss von kohlensauren Ammoniaks

Zwei Blasenscheitel, welche völlig farblose Drüsen trugen, wurden
mit einer Lösung kohlensauren Ammoniaks von derselben Stärke (nämlich
ein Theil auf 218 Theile Wasser) benetzt, und in 5 Minuten war der
Primordialschlauch der meisten Drüsenzellen etwas zusammengezogen; er
war auch in Flecken oder Punkten verdickt und hatte eine blasz-bräun-
liche Färbung angenommen. Als die Drüsen nach 1 Stunde 30 Minuten
wieder betrachtet wurden, boten die meisten von ihnen ein etwas ver-
schiedenes Ansehen dar. Ein drittes Präparat wurde mit einer schwäche-
ren Lösung, von einem Theile des kohlensauren Salzes auf 437 Theile
Wasser, behandelt, und nach 1 Stunde waren die Drüsen blasz braun
und enthielten zahlreiche Körnchen.

## Wirkung von salpetersauren Ammoniaks

Vier Scheitel wurden mit einer Lösung von einem Theile salpeter-
sauren Ammoniaks auf 437 Theile Wasser benetzt. Der eine wurde nach
15 Minuten untersucht, wo die Drüsen etwas afficirt zu sein schienen;
nach 1 Stunde 10 Minuten war die Veränderung bedeutender; der Pri-
mordialschlauch war in den meisten Zellen etwas geschrumpft und enthielt
viele Körnchen. In dem zweiten Exemplar war nach 2 Stunden der Pri-
mordialschlauch in den Zellen beträchtlicher eingeschrumpft und bräun-
lich. Ähnliche Wirkungen wurden in den beiden übrigen Exemplaren be-
obachtet; doch wurden diese nicht vor Ablauf von 21 Stunden untersucht.

## Beobachtungen an Blasen in reinem Wasser

Die Kerne vieler der Drüsenzellen hatten augenscheinlich an Grösse
zugenommen. Fünf Blasen an einem Zweige, welcher lange Zeit in mäszig
reinem Wasser gehalten worden war, wurden abgeschnitten und unter-
sucht; ihre Drüsen waren sehr wenig modificirt. Der Rest dieses Zweiges
wurde in die Lösung des salpetersauren Salzes gelegt, und nach 21 Stun-
den wurden zwei Blasen untersucht; alle ihre Drüsen waren bräunlich,
der Primordialschlauch ihrer Zellen etwas geschrumpft und fein granuliert.

## Einfluss einer gemischten Lösung

Der Scheitel einer andern Blase, deren Drüsen sich in einem wunder-
schönen klaren Zustande befanden, wurde mit einigen wenigen Tropfen
einer gemischten Lösung von salpetersaurem und phosphorsaurem Ammoniak,
jede von einem Theile auf 437 Theile Wasser, benetzt. Nach 2 Stunden
waren einige wenige von den Drüsen bräunlich. Nach 8 Stunden waren
beinahe sämmtliche oblonge Drüsen braun und viel opaker als sie vorher
gewesen waren; ihr Primordialschlauch war etwas eingeschrumpft und
enthielt ein wenig zusammengeballte granulöse Substanz. Die sphärischen
Drüsen waren noch immer weisz, aber ihre Primordialschläuche waren in
drei oder vier hyaline Kugeln aufgebrochen, mit einer unregelmäszig zu-
sammengezogenen Masse in der Mitte des basalen Theils. Diese kleineren
Kugeln änderten im Laufe einiger wenigen Stunden ihre Form, und einige
von ihnen verschwanden. Am nächsten Morgen, nach 23 Stunden 30
Minuten, waren sie sämmtlich verschwunden und die Drüsen waren braun;
der Primordialschlauch der Zellen bildete nun eine kuglige zusammen-
geschrumpfte Masse in der Mitte. Der Primordialschlauch in den Zellen
der oblongen Drüsen war sehr wenig geschrumpft, der Inhalt war aber
etwas zusammengeballt.

## Letzte Beobachtungen

Endlich wurde der Scheitel einer Blase, welche
vorher 21 Stunden lang mit einer Lösung eines Theils Zucker auf 218
Theile Wasser ohne irgend welche Wirkung benetzt worden war, mit der
erwähnten gemischten Lösung behandelt; und nach 8 Stunden 30 Minu-
ten wurden alle Drüsen braun, ihr Primordialschlauch unbedeutend ge-
schrumpft.

## Einfluss von fauligem Aufguss

Vier Scheitel wurden mit einem fauligen Aufgusse von rohem Fleisch
benetzt. Einige Stunden lang wurde in den Drüsen keine Veränderung
bemerkbar; aber nach 24 Stunden waren die meisten derselben bräunlich
geworden und opaker und körniger als sie vorher gewesen waren. In
diesen Exemplaren, ebenso wie in den mit den Ammoniaksalzen befeuch-# Untersuchung der Drüsen

teten, schienen die Kerne sowohl an Grösse als auch an Festigkeit zuge-
nommen zu haben, sie wurden aber nicht gemessen. Fünf Scheitel wur-
den auch mit einem frischen Aufgusse von rohem Fleisch benetzt; von
Cap. 17. Absorption durch die Drüsen.

# Ergebnisse der Drüsenuntersuchung

diesen waren drei in 24 Stunden durchaus gar nicht afficirt; die Drüsen
der beiden andern waren aber vielleicht etwas körniger geworden. Eines
der Exemplare, welches nicht afficirt worden war, wurde dann mit der
gemischten Lösung des salpetersauren und phosphorsauren Ammoniaks be-
netzt und nach nur 25 Minuten enthielten die Drüsen von vier oder fünf
bis zu einem Dutzend Körnchen. Nach weiteren 6 Stunden war ihr
Primordialschlauch bedeutend geschrumpft.

# Analyse der Blasen

Der Scheitel einer Blase wurde untersucht und sämmtliche Drüsen
farblos gefunden, auch war der Primordialschlauch ihrer Zellen durchaus
nicht eingeschrumpft; doch enthielten viele von den oblongen Drüsen
kleine, mit dem System Hartnack No. 8 gerade noch auflösbare Körnchen.
Er wurde dann mit einigen wenigen Tropfen einer Lösung von einem
Theil Harnstoff auf 218 Theile Wasser benetzt. Nach 2 Stunden 25 Mi-
nuten waren die sphärischen Drüsen noch immer farblos, während die
länglichen und zweiarmigen von einer bräunlichen Färbung und ihre Pri-
mordialschläuche bedeutend geschrumpft waren, auch einige deutlich sicht-
bare Körnchen enthielten. Nach 9 Stunden waren einige der kugligen
Drüsen bräunlich und die oblongen Drüsen waren noch mehr verändert,
sie enthielten aber weniger einzelne Körnchen; andererseits erschienen ihre
Kerne gröszer, als wenn sie Körnchen absorbirt hätten. Nach 23 Stun-
den waren sämmtliche Drüsen braun; der Primordialschlauch ihrer Zellen
war bedeutend geschrumpft und in vielen Fällen durchbrochen.

# Weitere Versuche mit Blasen

Es wurde nun mit einer Blase ein Versuch gemacht, welche bereits
etwas von dem umgebenden Wasser afficirt worden war; denn obschon
die sphärischen Drüsen farblos waren, war doch der Primordialschlauch
in ihren Zellen unbedeutend geschrumpft: auch waren die oblongen Drü-
sen bräunlich und deren Primordialschläuche bedeutend, aber unregelmäszige
eingeschrumpft. Der Scheitel wurde mit der Harnstoffauflösung behandelt,
wurde aber in 9 Stunden wenig von ihr afficirt; nichtsdestoweniger waren
in 23 Stunden die sphärischen Drüsen braun, der Primordialschlauch ihrer
Zellen mehr geschrumpft; mehrere von den andern Drüsen waren noch
brauner und ihr Primordialschlauch in unregelmäszige kleine Massen zu-
sammengezogen.

# Unterschiede in der Drüsenaffektion

Zwei andere Scheitel, deren Drüsen farblos und deren Primordial-
schläuche nicht geschrumpft waren, wurden mit derselben Harnstofflösung
behandelt. Nach 5 Stunden boten viele der Drüsen einen Stich in’s
Braune dar, auch war der Primordialschlauch unbedeutend geschrumpft.
Nach 20 Stunden 40 Minuten waren einige wenige von ihnen ganz braun
und enthielten unregelmäszig zusammengeballte Massen; andere waren
noch immer farblos, trotzdem der Primordialschlauch geschrumpft war;
aber die gröszere Anzahl war nicht bedeutend afficirt. Dies war ein gutes
Beispiel dafür, wie ungleich die Drüsen an einer und der nämlichen Blase
zuweilen afficirt werden; wie es auch häufig bei Pflanzen vorkommt, die
in faulem Wasser wachsen. Zwei andere Scheitel wurden mit einer Auf-
lösung behandelt, welche während mehrerer Tage in einem warmen Zimmer
gehalten worden war; als sie nach 21 Stunden untersucht wurden, waren
ihre Drüsen durchaus gar nicht afficirt.

# Anwendung einer schwächeren Lösung

Eine schwächere Auflösung von einem Theile Harnstoff auf 437
Theile Wasser wurde dann an den Scheiteln von sechs Blasen versucht,
Utricularia neglecta. Cap. 17.
welche sämmtlich sorgfältig untersucht wurden, ehe sie benetzt wurden.
Der erste wurde nach 8 Stunden 30 Minuten untersucht: die Drüsen, mit
Einschlusz der sphärischen, waren braun; bei vielen von den oblongen
Drüsen war der Primordialschlauch der Zellen bedeutend geschrumpft und
umschlosz Körnchen. Der zweite Scheitel war, ehe er mit der Lösung be-
netzt wurde, etwas von dem umgebenden Wasser afficirt worden, denn die
sphärischen Drüsen waren in ihrer äuszeren Erscheinung nicht völlig
gleichförmig; auch waren einige wenige der oblongen braun und ihr Pri-
mordialschlauch geschrumpft. Von den oblongen Drüsen waren diejenigen,
welche vorher farblos gewesen waren, in 3 Stunden 12 Minuten nach der# Beobachtungen über Absorption

Benetzung braun, der Primordialschlauch schrumpfte zusammen. Die sphä-
rischen Drüsen wurden nicht braun, aber ihr Zelleninhalt wurde dem
Aussehn nach verändert und war nach 23 Stunden noch mehr verändert
und granulirt. Die meisten der oblongen Drüsen waren jetzt dunkel braun,
aber ihre Primordialschläuche waren nicht sehr eingeschrumpft. Die vier
andern Präparate wurden nach 3 Stunden 20 Minuten, nach 4 Stunden
und nach 9 Stunden untersucht; es wird genügen, kurz ihren Zustand zu
schildern. Die sphärischen Drüsen waren nicht braun, einige von ihnen
aber waren fein körnig. Viele von den andern Drüsen waren braun; und
bei diesen, ebenso wie bei andern, welche noch immer farblos blieben,
war der Primordialschlauch in den Zellen mehr oder weniger geschrumpft,
bei einigen unter ihnen enthielt er kleine zusammengeballte Massen von
Substanz.

## Zusammenfassung der Beobachtungen über Absorption

Nach den jetzt mitgeteilten Thatsachen kann darüber kein
Zweifel sein, dasz die verschiedenartig geformten Drüsen auf der
Klappe und rings um den Kragen die Fähigkeit haben, Stoffe aus
schwachen Auflösungen von gewissen Ammoniaksalzen und von Harn-
stoff und aus einem fauligen Aufgusse von rohem Fleisch zu absor-
biren. Professor Cohn glaubt, dasz sie eine schleimige Substanz ab-
sondern; ich war aber nicht im Stande, irgend eine Spur einer solchen
Thätigkeit wahrzunehmen, ausgenommen, dasz nach Eintauchen in
Alkohol zuweilen äuszerst feine Linien sich strahlenförmig auf ihren
Oberflächen verbreitend gesehen werden konnten. Die Drüsen werden
durch die Aufsaugung verschiedenartig afficirt; sie werden oft braun,
zuweilen enthalten sie sehr feine Körnchen oder mäszig grosze Körner,
oder unregelmäszig zusammengeballte kleine Massen; zuweilen schei-
nen die Kerne an Grösse zugenommen zu haben; der Primordial-
schlauch ihrer Zellen ist meistens mehr oder weniger geschrumpft und
zuweilen durchbrochen. Genau die nämlichen Veränderungen sind an
den Drüsen von Pflanzen zu beobachten, welche in faulem Wasser
wachsen und gedeihn. Die sphärischen Drüsen werden meistens etwas
verschieden afficirt von den oblongen und zweiarmigen. Die erstern
werden nicht so gewöhnlich braun und die Einwirkung auf dieselben
ist langsamer. Wir können daher schlieszen, dasz sie in ihren natür-
lichen Functionen etwas von einander abweichen.

## Ungleichmäßige Affektion der Drüsen

Es ist merkwürdig, wie ungleichmäszig die Drüsen an den Blasen
an einem und demselben Zweige und selbst die Drüsen der nämlichen
Art an einer und derselben Blase durch das faulende Wasser, in wel-
chem die Pflanzen gewachsen sind, ebenso wie durch die Lösungen,
welche zur Anwendung kommen, afficirt werden. Im erstgenannten
Falle vermuthe ich, dasz dies Folge ist entweder von kleinen, Stoffe
zu einigen Drüsen aber nicht zu andern hinzuführenden Strömungen,
oder von unbekannten Verschiedenheiten in ihrer Constitution. Wenn
die Drüsen an der nämlichen Blase verschiedentlich von einer Lösung
afficirt werden, so können wir vermuthen, dasz einige von ihnen vor-
her schon eine geringe Menge von Substanz aus dem Wasser absor-
birt hatten. Wie sich dies aber auch verhalten mag, wir haben auch
gesehn, dasz die Drüsen an einem und demselben Blatte der Drosera
sehr ungleich afficirt wurden, ganz besonders, wenn sie der Einwir-
kung gewisser Dämpfe ausgesetzt wurden.

## Einfluss auf bereits braune Drüsen

Wenn Drüsen, welche bereits braun geworden waren und deren Pri-
mordialschlauch bereits eingeschrumpft war, mit einer der wirksamen
Lösungen benetzt werden, so erfolgt gar keine oder nur eine unbe-
deutende und langsame Einwirkung. Ich habe niemals irgend eine
Erscheinung gesehn, welche es wahrscheinlich machte, dasz Drüsen,
welche durch die Absorption von Substanz irgend welcher Art stark
afficirt waren, ihren ursprünglichen, farblosen und homogenen Zustand
und das Absorptionsvermögen wieder zu erlangen im Stande wären.
Nach der Natur der zu den Versuchen dienenden Lösungen nehme
ich an, dasz von den Drüsen Stickstoff absorbirt wird; aber weder
ich selbst noch mein Sohn haben jemals gesehn, dasz der modificierte,
bräunliche, mehr oder weniger eingeschrumpfte und zusammengeballte# Inhalt der Drüsen und deren Funktion

Inhalt der oblongen Drüsen jene spontanen Formveränderungen erlitten hätte, welche characteristisch für das Protoplasma sind. Andererseits trennte sich der Zelleninhalt der gröszeren sphärischen Drüsen häufig in kleine hyaline Kügelchen oder unregelmäszig geformte Massen, welche ihre Form sehr langsam veränderten und schlieszlich verschmolzen, um eine centrale zusammengeschrumpfte Masse zu bilden. Was auch immer die Natur des Zelleninhalts der verschiedenen Drüsenarten sein mag, so ist es, nachdem faulendes Wasser oder eine der stickstoffhaltigen Lösungen eingewirkt haben, wahrscheinlich, dasz die in dieser Weise erzeugte Substanz für die Pflanze von Nutzen ist und schlieszlich nach andern Theilen weiter geschafft wird.

# Absorption und Wirkung der Drüsen

Die Drüsen absorbiren augenscheinlich schneller als die vierthei- ligen und zweigespaltenen Fortsätze: und nach der oben aufgestellten Ansicht, nämlich dasz sie Substanz aus dem gelegentlich aus den Blasen abflieszenden faulenden Wasser absorbiren, müssen sie auch schneller wirken als die Fortsätze; die letzteren bleiben ja in beständiger Berührung mit gefangenen und sich zersetzenden Thieren. Die Schluszfolgerung endlich, zu welcher wir durch die vorstehend geschilderten Experimente und Beobachtungen geführt werden, ist die, dasz die Blasen nicht die Fähigkeit haben, animale Substanz zu verdauen, obschon augenscheinlich die viertheiligen Fortsätze von einem frischen Aufgusse von rohem Fleisch etwas afficirt werden.

# Wirkung von Harnstoff und rohem Fleisch

Es ist sicher, dasz die Fortsätze innerhalb der Blasen und die Drüsen auszerhalb derselben Substanz aus Ammoniaksalzen, aus einem faulen- den Aufgusz von rohem Fleisch und aus Harnstoff absorbiren. Eine Auflösung von Harnstoff wirkt augenscheinlich stärker und ein Auf- gusz von rohem Fleisch weniger stark auf die Drüsen ein als auf die Fortsätze. Die Thatsache mit dem Harnstoff ist besonders in- teressant, weil wir gesehen haben, dasz er auf Drosera keine Wir- kung hervorbringt, deren Blätter dazu angepaszt sind, frische animale Substanz zu verdauen. Aber die bedeutungsvollste Thatsache von allen ist, dasz in der vorliegenden wie in den folgenden Arten die viertheiligen und zweigespaltenen Fortsätze von Blasen, welche zer- fallene Thiere enthalten, kleine Massen von sich spontan bewegendem Protoplasma einschlieszen, während derartige Blasen in vollkommenen reinen Blasen niemals zu sehen sind.

# Entwicklung der Blasen

Entwickelung der Blasen. — Mein Sohn und ich ver- wandten viel Zeit auf diesen Gegenstand, aber mit geringem Erfolge. Unsere Beobachtungen beziehen sich auf die vorliegende Art und auf Utricularia vulgaris, wurden aber hauptsächlich an der letzteren an- gestellt, da dort die Blasen zweimal so grosz sind wie an der Utri- cularia neglecta. In der ersten Zeit des Herbstes endigen die Stengel in groszen Knospen, welche abfallen und während des Winters ruhend auf dem Boden liegen. Die jungen, diese Knospen bildenden Blätter tragen Blasen auf verschiedenen Stufen früher Entwickelung.

# Morphologie der Blasen

Wenn die Blasen der Utricularia vulgaris ungefähr \frac {1}{100} Zoll (0,254 Mm.) im Durchmesser haben (oder \frac {1}{200} Zoll bei Utricularia neglecta), so haben sie einen kreisförmigen Umrisz, eine schmale, beinahe ge- schlossene, quere Mündung, welche in eine mit Wasser gefüllte Höhle führt; die Blasen sind aber schon hohl, wenn sie noch viel unter \frac {1}{100} Zoll Durchmesser haben. Die Mündungen sehen nach innen oder nach der Axe der Pflanze hin. Auf diesem früheren Stadium sind die Blasen in der Ebene, in welcher die Mündung liegt, und daher recht- winklig auf die Stellung der reifen Blasen abgeplattet. Sie sind äuszerlich mit Papillen verschiedener Grösze bedeckt, von denen viele einen elliptischen Umrisz haben. Ein aus einfachen verlängerten Zellen gebildetes Gefäszbündel läuft den kurzen Stiel hinauf und theilt sich an der Basis der Blase. Ein Zweig desselben erstreckt sich die Mitte der dorsalen Fläche, das andere die Mitte der ventralen Fläche hinauf. Bei völlig ausgewachsenen Blasen theilt sich das ventrale Bündel dicht unterhalb des Kragens und die beiden Zweige laufen an jeder Seite bis nahe zu der Stelle, wo sich der Kragen mit den Win-# Entwicklung der Blasen

keln der Klappen vereinigt; diese Zweige konnten aber an jungen Blasen nicht erkannt werden. Die beistehende Figur (Fig. 23) stellt einen Durchschnitt dar, welcher zufällig genau durch die Mitte gieng, den Stiel hinauf und zwischen den sich entwickelnden Antennen einer Blase von Utricularia vulgaris von \frac {1}{100} Zoll im Durchmesser. Das Exemplar war weich und die junge Klappe löste sich vom Kragen in einem bedeutenderen Grade ab, als es natür- lich ist, und wurde, so dargestellt. Wir sehn hier deutlich, dasz die Klappe und der Kragen faltenartige Verlängerungen der Wandungen der Blase nach innen sind. Selbst in diesem frühen Alter konnten Drüsen an der Klappe entdeckt werden. Der Zustand der viertheiligen Fort- sätze wird sofort beschrieben werden. Die An- tennen bestehn auf dieser Entwickelungsperiode aus sehr kleinen zelligen Vorsprüngen (in der Fig. 23. (Utricularia vulgaris.) Längsdurchschnitt durch eine junge Blase, \frac {1}{100} Zoll lang, mit weit offener Mündung. obigen Figur nicht mit gezeichnet, da sie nicht in der mittleren Ebene liegen), welche bald Ansätze von Borsten tragen. In fünf Fällen waren die jungen Antennen nicht von vollständig gleicher Länge; und diese Thatsache ist verständlich, wenn ich in der Annahme Utricularia neglecta.

# Junge Blätter und ihre Entwicklung

Cap. 17. Recht habe, dasz sie zwei Abtheilungen des Blattes entsprechen, welche vom Ende der Blase ausgehn; denn bei echten Blättern sind, so lange sie sehr jung sind, nach dem, was ich gesehen habe, die Fiedertheile niemals genau einander gegenüber gestellt. Sie müssen sich daher eine nach der andern entwickeln, und das wird auch mit den beiden Antennen der Fall sein. Auf einem viel früheren Stadium, wenn die halb entwickelten Blasen nur \frac {1}{300} Zoll (0,0846 Mm.) Durchmesser haben oder wenig mehr, bieten sie ein gänzlich verschiedenes Ausehn dar. Eine solche ist auf der linken Seite der beistehenden Figur dargestellt (Fig. 24). Fig. 24. (Utricularia vulgaris.) Junges Blatt aus einer Winterknospe, welches auf der linken Seite eine Blase in ihrem frühesten Entwickelungsstadium zeigt. Die jungen Blätter haben in diesem Alter breite abgeplattete Seg- mente, an welchen die späteren Theilungen durch Vorragungen ange- deutet sind, wie auf der rechten Seite der Figur eine solche gezeichnet ist. In einer groszen Anzahl von Präparaten, welche mein Sohn un- tersucht hat, erschienen die jungen Blasen so, als würden sie durch das schräge Überschlagen der Spitze und des mit einer Vorragung versehenen einen Randes gegen den gegenüberstehenden Rand gebildet.

# Form und Struktur der Blasen

Die kreisförmige Höhlung zwischen der eingefalteten Spitze und der eingefalteten Vorragung zieht sich augenscheinlich zu der engen Mün- dung zusammen, worin die Klappe und der Kragen entwickelt wird, während die Blase selbst durch den Zusammenflusz der einander gegen- überliegenden Ränder des übrigen Blattes gebildet wird. Gegen diese Ansicht lassen sich aber schwere Einwendungen erheben; denn wir müssen in diesem Falle vermuthen, dasz die Klappe und der Kragen unsymmetrisch von den Seiten der Spitze und Vorragung aus entwickelt werden. Überdies haben sich Bündel von Gefäszgewebe in Zügen zu bilden, welche zu der ursprünglichen Form des Blattes in gar keiner Beziehung stehn. So lange noch nicht die Existenz von Übergangs- formen zwischen diesem frühesten Stadium und einer jungen, aber doch vollkommen entwickelten Blase nachgewiesen werden kann, musz die Sache zweifelhaft bleiben. Da die viertheiligen und zweispaltigen Fortsätze eine der gröszten Eigenthümlichkeiten dieser Gattung darbieten, beobachtete ich deren Entwickelung bei Utricularia neglecta. Bei Blasen von ungefähr \frac {1}{100}# Zoll Durchmesser und Papillen

Zoll Durchmesser ist die innere Oberfläche dicht mit Papillen bedeckt, welche sich von kleinen, an der Verbindungsstelle gröszerer stehenden Zellen aus erheben. Diese Papillen bestehn aus einem zarten conischen Vorsprung, welcher sich in einen sehr kurzen Stiel verschmälert und an seiner Spitze zwei äuszerst kleine Zellen trägt. Sie nehmen danach dieselbe relative Stellung ein, wie die Papillen an der Auszen- seite der Blasen und auf den Flächen der Blätter, sind diesen auch sehr ähnlich, ausgenommen dasz sie kleiner und eher etwas vor- springender sind. Die zwei endständigen Zellen der Papillen ver- längern sich zuerst in einer der inneren Oberfläche der Blase parallelen Richtung. Dann wird eine jede durch eine Längsscheidewand getheilt. Bald trennen die sich hierdurch bildenden halben Zellen von einander; wir haben nun vier Zellen vor uns oder einen beginnenden viertheili- gen Fortsatz. Da für die zwei neuen Zellen kein Platz vorhanden ist, in ihrer ursprünglichen Ebene an Breite zuzunehmen, gleitet die eine theilweise unter die andere. Ihre Art zu wachsen verändert sich nun, und anstatt ihrer Spitzen fahren nun ihre äuszeren Seiten zu wachsen fort. Die zwei untern Zellen, welche theilweise unter die beiden oberen geglitten sind, bilden das längere und aufrechter stehende Fortsatzpaar, während die beiden oberen Zellen das kürzere und hori- zontalere Paar bilden, so dasz nun alle vier zusammen einen voll- kommenen viertheiligen Fortsatz bilden. Eine Spur der anfänglichen Theilung zwischen den beiden Zellen auf dem Scheitel der Papillen kann man noch zwischen den Basen der längeren Fortsätze sehn. Die Entwickelung der viertheiligen Fortsätze wird sehr leicht unter- brochen. Ich habe eine \frac {1}{50} Zoll lange Blase gesehn, welche nur ur- sprüngliche Papillen umschlosz, und eine andere Blase, ungefähr von der halben vollen Grösze, in welcher die viertheiligen Fortsätze sich noch auf einem frühen Entwickelungsstadium befanden.

# Utricularia vulgaris

Soweit ich es ermitteln konnte, entwickeln sich die zweispaltigen Fortsätze in der nämlichen Weise wie die viertheiligen, ausgenommen dasz die zwei endständigen Zellen sich niemals theilen und nur an Länge zunehmen. Die Drüsen auf der Klappe und dem Kragen er- scheinen in einem so frühen Alter der Blase, dasz ich ihre Ent- wickelung nicht verfolgen konnte; wir können aber vernünftigerweise vermuthen, dasz sie sich aus Papillen entwickeln ähnlich denen auf der Auszenseite der Blase, aber ohne dasz sich ihre terminalen Zellen in zwei theilen. Die beiden, die Stiele der Drüsen bildenden Segmente entsprechen wahrscheinlich der conischen Protuberanz und dem kurzen Stiel der viertheiligen und zweitheiligen Fortsätze. Ich werde in die- ser Annahme, dasz sich die Drüsen aus Papillen entwickeln, welche denen an der Auszenseite der Blase gleich sind, durch die Thatsache bestärkt, dasz sich bei Utricularia amethystina die Drüsen der ganzen ventralen Oberfläche der Blase entlang bis dicht an den Stiel hin erstrecken.

# Unterschiede zwischen Utricularia-Arten

Ich erhielt durch Dr. Hooker lebende Pflanzen aus Yorkshire. Diese Art weicht von der vorhergehenden darin ab, dasz die Stengel und Blätter dicker und gröber sind; ihre Fiedertheilungen bilden einen spitzeren Win- kel gegen einander; die Einschnitte an den Blättern tragen drei oder vier kurze Borsten anstatt einer, und die Blasen sind zweimal so grosz, oder ungefähr ⅕ Zoll (5,08 Mm.) im Durchmesser. In allen wesentlichen Beziehungen sind die Blasen denjenigen der Utricularia neglecta ähnlich, aber die Seiten des Peristoms sind vielleicht ein wenig mehr vorspringend und tragen immer, so weit ich es gesehen habe, sieben oder acht lange vielzellige Borsten. An jeder Antenne finden sich elf lange Borsten, mit Einschlusz des terminalen Paares. Fünf, Beute irgend welcher Art ent- haltende Blasen wurden untersucht; die erste enthielt fünf Cypris, einen groszen Copepoden und einen Diaptomus, die zweite eine Cypris, die dritte ein einziges ziemlich groszes Krustenthier, die vierte sechs und die fünfte zehn Crustaceen. Mein Sohn untersuchte die viertheiligen Fort- sätze in einer Blase, welche die Überreste von zwei Krustenthieren ent-# Utricularia minor

Diese seltene Art wurde mir durch die Freundlichkeit des Mr. John Price im lebenden Zustande aus Cheshire geschickt. Die Blätter und Blasen sind viel kleiner als die der Utricularia neglecta. Die Blätter tragen weniger und kürzere Borsten und die Blasen sind kugliger. Die Antennen sind, anstatt vorn vor den Blasen vorzuspringen, unter die Klappe gebogen und mit zwölf oder vierzehn äuszerst langen vielzelligen, meistens paarweise angeordneten Borsten bewaffnet. Dieselben bilden mit sieben oder acht langen Borsten an beiden Seiten des Peristoms eine Art von Netz über der Klappe, welches allen Thieren, ausgenommen sehr kleinen, den Eintritt in die Blase verwehren dürfte. Die Klappe und der Kragen haben dieselbe wesentliche Structur wie in den beiden vorigen Species; aber die Drüsen sind nicht ganz so zahlreich: die oblongen sind eher etwas mehr verlängert, während die zweiarmigen eher etwas kürzer sind. Die vier Borsten, welche schräg vom untern Rande der Klappe vorspringen, sind kurz. Ihre Kürze, verglichen mit denen an den Klappen der vorausgehenden Species, ist verständlich, wenn meine Ansicht richtig ist, dasz sie dazu dienen, zu grosze Thiere daran zu hindern, sich einen Eingang durch die Klappe zu erzwingen und sie dabei zu verletzen; denn die Klappe wird bereits in einem gewissen Grade durch die eingebogenen Antennen, in Verbindung mit den seitlichen Borsten beschützt. Die zweispaltigen Fortsätze sind denen in den vorausgehenden Species gleich; aber die viertheiligen sind dadurch von jenen verschieden, dasz die vier Arme nach der nämlichen Seite hingerichtet sind; die zwei längeren stehn in der Mitte und die beiden kürzeren an der äuszeren Seite.

# Utricularia clandestina

Diese nordamericanische Species, welche gleich den drei vorhergehenden im Wasser lebt, ist von Mrs. Treat in New Jersey beschrieben worden, deren ausgezeichnete Beobachtungen bereits vielfach angeführt wurden. Ich habe bis jetzt noch keine ausführliche Beschreibung der Blase durch Mrs. Treat gesehen, es scheint aber, als sei sie mit viertheiligen Fortsätzen ausgekleidet. Eine ungeheure Anzahl gefangener Thiere wurde innerhalb der Blasen gefunden, einige davon waren Crustaceen, aber die grosze Mehrzahl waren zarte, gestreckte Larven, ich vermuthe von Culiciden. An einigen Stengeln enthielten reichlich neun unter je zehn Blasen derartige Larven oder ihre Überreste. Die Larven boten noch Lebenszeichen dar in einer Zeit von vierundzwanzig bis sechsunddreiszig Stunden, nachdem sie gefangen worden waren, und giengen dann schnell.# Achtzehntes Capitel

## Utricularia (Fortsetzung)

### Utricularia montana

### Beschreibung der Blasen

### Beute und Ernährungsweise

### Lebensraum und Wachstum

### Morphologie der Pflanze

### Blasenstruktur und Eigenschaften# Anatomie und Morphologie

gehenden Species entsprechen. Gleiche Papillen sind in groszer Menge auf den Rhizomen und selbst auf den ganzen Blättern vorhanden, aber sie sind etwas breiter auf den letzteren. Gefässe, die mit parallelen Balken, anstatt mit einer Spirallinie gezeichnet sind, laufen die Stiele hinauf und treten gerade in die Basen der Blasen; aber sie theilen sich nicht gabelförmig und erstrecken sich nicht die dorsalen und ventralen Flächen hinauf wie in den vorhergehenden Arten.

# Antennenstruktur

Die Antennen sind von mäsziger Länge und laufen in eine feine Spitze aus; sie sind von den vorher beschriebenen in so fern augenfällig verschieden, dasz sie nicht mit Borsten bewaffnet sind. Ihre Basen sind so plötzlich gebogen, dasz ihre Spitzen gewöhnlich eine auf jeder Seite der Mitte der Blase liegen, aber manchmal nahe dem Rand. Ihre gekrümmten Basen bilden so ein Dach über der Höhlung, in welcher die Klappe liegt; aber es ist immer auf jeder Seite ein kleiner runder Gang in die Höhlung frei gelassen, wie in der Zeichnung zu sehen ist, ebenso wie ein schmaler Gang zwischen den Basen der beiden Antennen. Da die Blasen unterirdisch sind, würde die Höhlung, in welcher die Klappe liegt, wenn nicht das Dach vorhanden wäre, leicht mit Erde und Abfällen verstopft werden; so dasz die Krümmungen der Antennen eine nützliche Einrichtung ist. Es sind keine Borsten auf der Auszenseite des Kragens oder Peristoms vorhanden, wie in den vorhergehenden Species.

# Klappenstruktur

Die Klappe ist klein und steil geneigt und stösst mit ihrem freien hinteren Rand gegen einen halbkreisförmigen, tief niedersteigenden Kragen an. Sie ist mäszig durchsichtig und trägt zwei Paar kurze steife Borsten, in derselben Stellung wie in den andern Arten. Das Vorhandensein dieser vier Borsten, im Gegensatz zu der Abwesenheit jener an den Antennen und dem Kragen, zeigt an, dasz sie von functioneller Wichtigkeit sind, nämlich, wie ich glaube, um zu verhindern, dasz grosze Thiere sich einen Eintritt durch die Klappe erzwingen. Die vielen Drüsen verschiedener Formen, welche an die Klappe und ringsum den Kragen in den vorhergehenden Species geheftet sind, fehlen hier, mit Ausnahme von ungefähr einem Dutzend der zweiarmigen oder quer verlängerten Art, welche nahe dem Rand der Klappe sitzen und auf sehr kurze Stiele geheftet sind. Diese Drüsen sind nur \frac {3}{4000} Zoll (0,019 Mm.) lang; obgleich sie so klein sind, fungiren sie doch als aufsaugende Organe. Der Kragen ist dick, steif und beinahe halbkreisförmig; er wird von demselben sonderbaren bräunlichen Gewebe gebildet, wie in den früheren Species.

# Blaseninhalt und Struktur

Die Blasen sind mit Wasser gefüllt, und schlieszen manchmal Luft ein. Sie tragen innen ziemlich kurze, dicke, viertheilige Fortsätze in annähernd concentrischen Reihen angeordnet. Die zwei Paar Arme, aus denen sie gebildet werden, variiren nur wenig in der Länge, und stehen in einer eigenthümlichen Stellung (Fig. 28); die zwei längeren bilden eine Linie und die zwei kürzeren eine andere parallele Linie. Jeder Arm schlieszt eine kleine kuglige Masse von bräunlicher Substanz ein, welche, wenn sie zerdrückt wird, in eckige Stücke zerbricht. Ich habe keinen Zweifel daran, dasz diese Kugeln Kerne sind, denn sehr nahe ähnliche sind in den Zellen vorhanden, welche die Wände der Blasen bilden. Zweispaltige Fortsätze, welche ziemlich kurze ovale Arme haben, erheben sich in der gewöhnlichen Stellung von der inneren Seite des Kragens.

# Vergleich mit vorhergehenden Species

Diese Blasen gleichen daher in allen wesentlichen Theilen den gröszeren der vorhergehenden Species. Sie weichen von ihnen hauptsächlich in der Abwesenheit der zahlreichen Drüsen auf der Klappe und rings um den Kragen herum ab, indem nur einige wenige kleine einer Art an der Klappe vorhanden sind. Noch augenfälliger sind sie durch die Abwesenheit der langen Borsten an den Antennen und an der Auszenseite des Kragens von jenen verschieden. Die Anwesenheit dieser Borsten in den früher erwähnten Arten hängt wahrscheinlich# Untersuchung der Utricularia montana

## Einleitung
mit dem Fangen von Wasserthierchen zusammen. Es schien mir eine interessante Frage zu sein, ob die kleinen Blasen der Utricularia montana wie in den vorhergehenden Arten dazu dienten, Thiere zu fangen, welche in der Erde oder in der dichten, die Bäume, auf denen diese Art epiphytisch wächst, bedeckenden Vegetation leben; denn in diesem Falle würden wir eine neue Unterklasse von fleischfressenden Pflanzen haben, nämlich solche, die sich unterirdisch ernähren.

## Ergebnisse der Blasenuntersuchung
Es wurden daher viele Blasen untersucht, und zwar mit den folgenden Resultaten:

### 1. Erste Blase
Eine kleine Blase, weniger als \frac {1}{30} Zoll (0,847 Mm.) im Durchmesser, enthielt eine kleine Masse von brauner sehr verwester Substanz; und in dieser wurde ein Tarsus mit vier oder fünf Gliedern, mit einer doppelten Klaue endend, deutlich unter dem Mikroskop unterschieden. Ich vermuthe, dasz es ein Überbleibsel von einem der Thysanuren war.

### 2. Zweite Blase
Eine andere Blase umschlosz einen noch kleineren Fleck von verwester brauner Substanz, und die anstoszenden viertheiligen Fortsätze enthielten zusammengeballte Substanz genau wie im letzten Fall.

### 3. Dritte Blase
Eine dritte Blase umschlosz einen gröszeren Organismus, welcher so sehr verwest war, dasz ich nur erkennen konnte, dasz er stachelig oder haarig war.

### 4. Vierte Blase
Eine vierte Blase enthielt die Überreste eines Gliederthieres, denn ich sah deutlich die Reste eines Glieds, welches in einer Klaue endigte.

### 5. Fünfte Blase
Eine fünfte umschlosz sehr verweste Substanz, augenscheinlich von einem Thier, aber ohne wieder erkennbare Züge.

### 6. Sechste Blase
Einige wenige Blasen auf der Pflanze, welche ich von Kew erhielt, wurden untersucht; in einer war ein wurmförmiges Thier, sehr wenig verwest, zusammen mit dem deutlichen Rest eines ähnlichen stark verwestem, vorhanden.

## Schlussfolgerung
Da es mir wahrscheinlich schien, dasz diese Pflanze in ihrem Geburtslande eine gröszere Anzahl Thiere fangen würde, als im Zustande der Cultur, erhielt ich Erlaubnis, kleine Theilchen der Rhizome von getrockneten Exemplaren in dem Herbarium in Kew zu entfernen.# Untersuchung von Organismen

Kopf von irgend einem Thier mit einer inneren Gabel, an welcher der Oesophagus aufgehangen war; ich konnte aber keine Mandibeln sehen; ferner die doppelte Kralle des Tarsus irgend eines Thiers; dann ein längliches, stark verwestes Thier; und endlich ein sonderbarer flaschenförmiger Organismus, dessen Wände von gerundeten Zellen gebildet wurden. Professor Claus hat diesen letzten Organismus angesehn, und denkt, dasz es die Schale eines Rhizopoden, wahrscheinlich einer Arcellide ist. In dieser Blase sowohl wie in mehreren andern fanden sich einige einzellige Algen und eine vielzellige Alge, welche ohne Zweifel als Eindringlinge dort gelebt hatten.

## Analyse der Blasen

Eine zweite Blase enthielt einen viel weniger als der frühere verwesten Acarus, dessen acht Beine erhalten waren; ebenso auch die Überreste von mehreren andern Gliederthieren. Eine dritte Blase enthielt das Ende des Abdomen mit den beiden hinteren Gliedmaszen eines Acarus, wie ich glaube. Eine vierte enthielt Reste von einem deutlich gegliederten borstigen Thier, und von mehreren anderen Organismen sowohl als viel dunkel braune organische Substanz, deren Natur nicht erkannt werden konnte.

## Untersuchung von Pflanzenresten

Einige Blasen von einer Pflanze, welche als ein Epiphyt auf Trinidad in Westindien gelebt hatte, wurden zunächst untersucht, aber nicht so sorgfältig wie die andern; auch waren sie nicht lange genug aufgeweicht worden. Vier derselben enthielten viel braune durchscheinende körnige Substanz, augenscheinlich organisch, aber mit keinen unterscheidbaren Theilen. Die viertheiligen Fortsätze in zweien derselben waren bräunlich und ihr Inhalt körnig; und es war augenscheinlich, dasz sie Substanz aufgesaugt hatten. In einer fünften Blase war ein flaschenförmiger Organismus, wie der oben erwähnte, vorhanden. Eine sechste enthielt ein sehr langes, stark verwestes, wurmförmiges Thier. Endlich enthielt eine siebente Blase einen Organismus, aber von welcher Art, konnte nicht entschieden werden.

## Experimentelle Ergebnisse

Nur ein Experiment wurde an den viertheiligen Processen und den Drüsen in Bezug auf ihr Aufsaugungsvermögen angestellt. Eine Blase wurde fein angestochen und 24 Stunden lang in einer Lösung von einem Theil Harnstoff auf 437 Theile Wasser gelassen; die viertheiligen und zweispaltigen Fortsätze wurden stark afficirt gefunden. In einigen Armen war nur eine einzige symmetrische kuglige Masse, gröszer als der gewöhnliche Kern, vorhanden, welche aus gelblicher Substanz bestand, meistentheils durchscheinend, aber zuweilen körnig; in andern waren zwei Massen von verschiedener Grösze, die eine grosz und die andere klein; und in noch anderen waren unregelmäßig geformte Körner, so dasz es schien, als ob der flüssige Inhalt der Fortsätze, in Folge der Aufsaugung von Substanz aus der Lösung, um den Kern herum zusammengeballt worden wäre, zuweilen auch zu separaten Massen, und als ob diese dann sich wieder zu vereinigen strebten.

## Beobachtungen zu Drüsen und Fortsätzen

Der Primordialschlauch oder das Protoplasma, welches die Fortsätze auskleidete, war auch hie und da zu unregelmäszigen und verschiedenartig geformten Flecken von gelblicher durchsichtiger Substanz verdickt, wie es bei Utricularia neglecta bei einer ähnlichen Behandlung vorkam. Diese Flecken veränderten augenscheinlich ihre Form nicht. Die kleinen zweiarmigen Drüsen auf der Klappe wurden auch durch die Lösung afficirt; denn sie enthielten nun mehrere, manchmal bis zu sechs oder acht, beinahe kuglige Massen von durchsichtiger Substanz, mit einem Stiche in’s Gelbe, welche ihre Formen und Stellungen langsam veränderten. Solche Massen wurden niemals in diesen Drüsen in ihrem gewöhnlichen Zustande beobachtet.

## Schlussfolgerungen

Wir können daher folgern, dasz diese zum Aufsaugen dienen. Sobald nur immer etwas Wasser aus einer Blase, welche Thierreste enthält, ausgetrieben wird (durch die früher speciell angeführten Mittel, besonders durch die Erzeugung von Luftblasen), wird es die Höhlung, in wel-cher die Klappe liegt, füllen; und so werden die Drüsen fähig sein, verweste Substanz, welche andernfalls sonst nutzlos sein würde, zu verwerten.# Wasser-Reservoirs

Da endlich zahllose kleine Thiere von dieser Pflanze in ihrem Heimathslande und wenn sie cultivirt wird, gefangen werden, so kann kein Zweifel darüber sein, dasz die Blasen, trotzdem sie so klein sind, sich durchaus nicht in einem rudimentären Zustande befinden; im Gegentheil stellen sie sehr wirksame Fallen dar. Ebensowenig kann ein Zweifel darüber sein, dasz Substanz aus der verwesten Beute durch die viertheiligen und zweispaltigen Fortsätze aufgesaugt wird, und dasz Protoplasma hierdurch gebildet wird. Was die Thiere so verschiedener Arten verführt, sich in die Höhlung unter den gebognen Antennen zu begeben, und dann ihren Weg durch das kleine schlitz- artige Loch zwischen der Klappe und dem Kragen in die mit Wasser gefüllten Blasen zu erzwingen, darüber kann ich nicht einmal eine Vermuthung äuszern.

## Knollen

Diese Organe, deren eines in einer früheren Figur (Fig. 26) in natürlicher Grösse dargestellt ist, verdienen einige wenige Bemerkungen. Es wurden zwanzig auf den Rhizomen einer einzigen Pflanze gefunden, aber sie können nicht genau gezählt werden; denn auszer den zwanzig waren alle möglichen Abstufungen von einer kurzen, eben bemerkbar geschwollnen Strecke eines Rhizoms und einer so stark geschwollnen Strecke vorhanden, dasz sie zweifelhafterweise schon ein Knollen genannt werden könnte. Wenn gut entwickelt, sind sie oval und symmetrisch, mehr als es in der Figur erscheint. Der gröszte, den ich sah, war 1 Zoll (25,4 Mm.) lang und 0,45 Zoll (11,43 Mm.) breit. Sie liegen gewöhnlich nahe der Oberfläche, aber einige sind bis zur Tiefe von 2 Zoll begraben. Die begrabnen sind schmutzig weisz, aber die dem Lichte theilweise ausgesetzten werden durch die Entwicklung von Chlorophyll in ihren oberflächlichen Zellen grünlich. Sie enden in einem Rhizom, aber dies verwelkt manchmal und fällt ab. Sie enthalten keine Luft und sinken im Wasser unter; ihre Ober- flächen sind mit den gewöhnlichen Papillen bedeckt. Das Bündel Gefäsze, welches in jedem Rhizom hinaufläuft, theilt sich, sobald es in den Knollen eintritt, in drei verschiedene Bündel, welche sich am entgegengesetzten Ende wieder vereinigen. Ein ziemlich dicker Schnitt eines Knollen ist beinahe so durchsichtig wie Glas, und besteht aus groszen eckigen Zellen voll Wasser, welche weder Stärke noch irgend eine andere solide Substanz enthalten. Einige Schnitte wurden mehrere Tage in Alkohol liegen gelassen; aber nur einige wenige auszer- ordentlich kleine Körnchen Substanz schlugen sich an den Wänden der Zellen nieder; und diese waren viel kleiner und der Zahl nach weniger als diejenigen, welche sich an den Zellenwänden der Rhizome und Blasen niederschlugen. Wir können daher schlieszen, dasz die Knollen nicht als Nahrungsbehälter dienen, sondern als Wasserbehälter während der trocknen Jahreszeit, welcher die Pflanze wahrscheinlich ausgesetzt ist. Die vielen kleinen mit Wasser gefüllten Blasen würden demselben Zwecke dienen.

## Experiment zur Überprüfung

Um die Richtigkeit dieser Ansicht zu prüfen, wurde eine kleine Pflanze, welche in leichtem Torfboden in einem Topfe (nur 4½ zu 4½ Zoll äuszeres Masz) wuchs, häufig begossen, und dann ohne einen Tropfen Wasser im Gewächshause gelassen. Zwei der oberen Knollen wurden vorher unbedeckt und gemessen und dann wieder leicht zu- gedeckt. Nach der Zeit von vierzehn Tagen schien die Erde in dem Topf auszerordentlich trocken zu sein; aber nicht vor dem fünfund- dreiszigsten Tage wurden die Blätter im geringsten afficirt; sie wur- den dann leicht zurückgebogen, obgleich sie noch weich und grün waren. Diese Pflanze, welche nur zehn Knollen trug, würde ohne Zweifel der Trockenheit noch eine viel längere Zeit widerstanden haben, wenn ich nicht vorher drei von den Knollen entfernt und mehrere lange Rhizome abgeschnitten hätte. Als am fünfunddreiszig- sten Tage die Erde aus dem Topfe geschüttet wurde, war sie so trocken, wie der Staub auf der Landstrasze. Alle Knollen hatten sehr gerunzelte Oberflächen anstatt platt und straff zu sein. Sie waren alle eingeschrumpft, aber ich kann nicht genau angeben, um wie viel;# Pflanzenstruktur und Wasseraufnahme

denn da sie anfangs symmetrisch oval waren, masz ich nur ihre
Länge und Dicke; sie zogen sich aber der Quere nach viel mehr in
einer Richtung als in einer andern zusammen, so dasz sie bedeutend
abgeplattet wurden. Einer der zwei Knollen, welche gemessen wor-
den waren, hatte nun nur drei Viertel seiner ursprünglichen Länge,
und zwei Drittel seiner ursprünglichen Dicke in der Richtung, in
welcher er gemessen worden war; aber in einer andern Richtung nur
ein Drittel seiner früheren Dicke. Der andere Knollen war ein Viertel
kürzer und ein Achtel weniger dick in der Richtung, in welcher er
gemessen worden war, und nur halb so dick in einer andern Richtung.
Ein Scheibchen wurde von einem dieser zusammengeschrumpften
Knollen ausgeschnitten und untersucht. Die Zellen enthielten noch
viel Wasser und keine Luft, aber sie waren abgerundeter und weniger
eckig als vorher; auch waren ihre Wände nicht so gerade; es war
daher klar, dasz sich die Zellen zusammengezogen hatten. Die Knollen
haben, so lange sie lebendig bleiben, eine starke Anziehungskraft für
Wasser; der zusammengeschrumpfte, von welchem eine Scheibe ab-
geschnitten worden war, wurde 22 Stunden 30 Minuten lang in Wasser
gelassen, und seine Oberfläche wurde so glatt und so straff wie sie
ursprünglich gewesen war. Auf der andern Seite schwoll ein ge-
schrumpfter Knollen, welcher durch Zufall von seinem Rhizome ge-
trennt worden wor, und abgestorben schien, nicht im Geringsten an,
obgleich er mehrere Tage in Wasser gelassen wurde.

# Bedeutung der Knollen

Bei vielen Arten Pflanzen dienen ohne Zweifel die Knollen, Zwie-
beln u. s. w. theilweise als Behälter für Wasser; aber ich weisz von
keinem Fall, auszer dem vorliegenden, wo solche Organe allein zu
diesem Zweck entwickelt worden wären. Prof. Oliver theilt mir mit,
dasz zwei oder drei andere Arten von Utricularia mit diesen An-
hängen versehen sind; und die Gruppe, welche diese umfaszt, hat in
Folge davon den Namen orchidioides erhalten. Alle die andern Arten
von Utricularia sowohl als von gewissen nahe verwandten Gattungen
sind entweder Wasser- oder Marsch-Pflanzen; es wird daher nach
dem Grundsatze, dasz nahe verwandte Pflanzen gewöhnlich von glei-
cher Constitution sind, ein niemals versiegender Vorrath von Wasser
wahrscheinlich von groszer Bedeutung für unsere vorliegende Art
sein. Wir können hiernach die Bedeutung der Entwickelung ihrer
Knollen und deren groszen Zahl auf einer und derselben Pflanze, die
in einem Falle bis zu wenigstens zwanzig anstieg, verstehen.
Utricularia nelumbifolia, amethystina, Griffithii, caerulea, orbiculata,
multicaulis.

# Untersuchung der Blasen

Da ich zu ermitteln wünschte, ob die Blasen auf den Rhizomen
andrer Arten von Utricularia und von Arten gewisser nahe verwandter
Gattungen dieselbe wesentliche Structur, wie diejenigen der Utricularia
montana hätten und ob sie Beute fiengen, bat ich Prof. Oliver, mir
Stücke aus dem Herbarium in Kew zu schicken. Er suchte freund-
lichst einige von den verschiedensten Formen aus, welche ganze Blät-
ter haben, und von denen man glaubt, dasz sie marschigen Boden
oder Wasser bewohnen. Mein Sohn, Francis Darwin, untersuchte sie
und hat mir folgende Beobachtungen mitgetheilt; aber man musz im
Auge behalten, dasz es auszerordentlich schwer ist, die Structur sol-
cher kleiner und zarter Gegenstände, nachdem sie getrocknet und ge-
preszt worden waren, zu erkennen. Prof. Oliver hat (Proc. Linn. Soc. Vol. IV, p.
169) Abbildungen von den
Blasen zweier südamericanischer Species, nämlich Utricularia Jamesoniana und
peltata gegeben; er scheint aber diesen Organen keine besondere Aufmerksamkeit
gewidmet zu haben.

# Lebensraum von Utricularia nelumbifolia

Utricularia nelumbifolia (Orgel-Berge, Brasilien). — Der Wohn-
ort dieser Art ist merkwürdig. Seinem Entdecker, Herrn Gardner,
zufolge lebt sie im Wasser, aber „wird nur in dem Wasser wachsend
„gefunden, welches sich auf dem Grunde der Blätter einer groszen
„Tillandsia ansammelt, welche sehr reichlich auf luftigen felsigen
„Theilen der Berge in einer Höhe von ungefähr 5000 Fusz über dem# Pflanzen und ihre Fortpflanzung

„Meeresspiegel vorkommt. Auszer der gewöhnlichen Methode durch
„Samen pflanzt sie sich auch durch Ausläufer fort, welche sie von
„der Basis des Blüthenstiels ausschickt; diesen Ausläufer findet man
„immer nach der nächsten Tillandsia hingerichtet, wo er seine Spitze
Utricularia Griffithii. Cap. 18.
„in das Wasser bringt, und so die Entstehung einer neuen Pflanze
„verursacht, welche dann ihrerseits andere Schöszlinge aussendet.
„Auf diese Weise habe ich nicht weniger denn sechs Pflanzen ver-
„bunden gesehen.‟ Die Blasen gleichen denen der Utricularia mon-
tana in allen wesentlichen Beziehungen, selbst in der Anwesenheit
einiger kleiner zweiarmigen Drüsen auf der Klappe. Innerhalb einer
Blase war der Rest von dem Abdomen irgend einer Larve oder eines
Krusters von bedeutender Grösze, welche an der Spitze eine Bürste
von langen scharfen Borsten hatte. Andere Blasen umschlossen Reste
von gegliederten Thieren, und viele derselben enthielten abgebrochene
Stücke eines merkwürdigen Organismus, dessen Natur von Niemand,
dem er gezeigt wurde, erkannt wurde.

# Utricularia amethystina

Utricularia amethystina (Guiana). — Diese Art hat kleine ganze
Blätter, und ist augenscheinlich eine Marsch-Pflanze; aber sie musz
in Gegenden, wo Kruster existiren, wachsen, denn es fanden sich zwei
kleine Arten solcher innerhalb einer der Blasen. Die Blasen sind
beinahe von derselben Form wie die der Utricularia montana, und sind
auszen mit den gewöhnlichen Papillen bedeckt; aber sie weichen in merk-
würdiger Weise darin von jenen ab, dasz die Antennen auf zwei kurze
Spitzen reducirt sind, welche durch eine in der Mitte ausgehöhlte
Membran verbunden sind. Diese Membran ist von unzähligen, läng-
lichen, auf langen Stielen stehenden Drüsen bedeckt, von denen die
meisten in zwei nach der Klappe zu convergirenden Reihen angeord-
net sind. Einige sitzen indessen an den Rändern der Membran; auch
ist die kurze ventrale Oberfläche der Blase, zwischen dem Stiel und
der Klappe, dicht mit Drüsen bedeckt. Die meisten der Köpfe waren
abgefallen und nur die Stiele waren geblieben, so dasz die ventrale
Oberfläche und die Mündung, unter schwacher Vergröszerung be-
trachtet, wie mit feinen Borsten bekleidet erschien. Die Klappe ist
schmal und trägt ein Paar beinahe sessiler Drüsen. Der Kragen,
gegen welchen der Rand schlieszt, ist gelblich und bietet die gewöhn-
liche Structur dar. Nach der gröszeren Anzahl Drüsen auf der ven-
tralen Fläche und um die Mündung ist es wahrscheinlich, dasz diese
Art in sehr faulem Wasser lebt, von welchem es ebenso wohl wie
aus der gefangenen und verwesenden Beute Substanz aufsaugt.

# Utricularia Griffithii

Utricularia Griffithii (Malay und Borneo). — Die Drüsen sind
durchsichtig und klein; eine, welche gemessen wurde, war nur \frac {28}{1000}
Zoll (0,711 Mm.) im Durchmesser. Die Antennen sind von mäsziger
Cap. 18. Polypompholyx.
Länge, und springen gerade vor; sie sind eine kurze Strecke an ihren
Basen durch eine Membran verbunden und tragen eine mäszige An-
zahl von Borsten oder Haaren, nicht wie bisher einfache, sondern mit
Drüsen versehene. Die Blasen sind auch darin merkbar von denen
der vorhergehenden Arten verschieden, dasz innen keine viertheiligen,
sondern nur zweispaltige Fortsätze vorhanden sind. In einer Blase
war eine kleine wasserbewohnende Larve; in einer andern fanden sich
die Reste von irgend einem gegliederten Thier, und in den meisten
Sandkörner.

# Utricularia caerulea

Utricularia caerulea (Indien). — Die Blasen sind denen der letz-
ten Art ähnlich, sowohl in dem allgemeinen Character der Antennen,
als auch dadurch, dasz die Fortsätze innen ausschlieszlich zweispaltig
sind. Sie enthielten Reste von entomostraken Krustern.

# Utricularia orbiculata

Utricularia orbiculata (Indien). — Die kreisförmigen Blätter und
die Stämme, welche die Blasen tragen, schwimmen augenscheinlich
im Wasser. Die Blasen sind nicht sehr von denen der zwei letzten
Arten verschieden. Die Antennen, welche eine kurze Strecke an ihren
Basen verbunden sind, tragen an ihren äuszern Flächen und Gipfeln
zahlreiche lange vielzellige Haare, welche Drüsen an ihrer Spitze
tragen. Die Fortsätze in den Blasen sind viertheilig, und die vier# Einleitung
divergirenden Arme sind von gleicher Länge. Die Beute, welche sie gefangen hatten, bestand aus entomostraken Krustern.

# Utricularia multicaulis
Utricularia multicaulis (Sikkim, Indien, 7000 bis 11,000 Fusz). — Die Blasen, welche an die Rhizome geheftet sind, sind wegen der Structur der Antennen merkwürdig. Diese sind breit, abgeplattet und von bedeutender Grösse; sie tragen an ihren Rändern vielzellige Haare mit Drüsen an ihren Spitzen. Ihre Basen sind zu einem einzigen ziemlich schmalen Stiel verbunden, und sie erscheinen dadurch wie eine grosze fingerförmige Ausbreitung an einem Ende der Blase. Innen haben die viertheiligen Fortsätze divergirende Arme von gleicher Länge. Die Blasen enthielten Reste von gegliederten Thieren.

# Polypompholyx
Polypompholyx. Diese Gattung, welche auf das westliche Australien beschränkt ist, ist dadurch characterisirt, dasz sie einen „viertheiligen Kelch‟ hat. In andrer Hinsicht ist sie, wie Prof. Oliver bemerktProceed. Linn. Soc Vol. IV, p. 171., „ganz eine Utricularia.‟

# Polypompholyx multifida
Genlisea ornata. Cap. 18. Polypompholyx multifida. — Die Blasen sind in Wirteln rings um die Spitzen steifer Stiele angeordnet. Die zwei Antennen werden durch eine kleine membranöse Gabel dargestellt, deren basaler Theil eine Art Kappe über der Mündung bildet. Diese Kappe breitet sich in zwei Flügel auf jeder Seite der Blase aus. Ein dritter Flügel oder Kamm scheint durch die Ausbreitung der dorsalen Fläche des Stiels gebildet zu werden; aber die Structur dieser drei Flügel konnte in Folge der Beschaffenheit der Exemplare nicht klar ermittelt werden. Die innere Oberfläche der Kappe ist mit langen einfachen Haaren ausgekleidet, welche zusammengeballte Substanz enthalten, wie die in den viertheiligen Fortsätzen der früher beschriebenen Species, wenn sie in Berührung mit verwesten Thieren gekommen waren. Diese Haare schienen daher als aufsaugende Organe zu dienen. Eine Klappe wurde gesehen, aber ihre Structur konnte nicht ermittelt werden. Auf dem Kragen um die Klappe finden sich anstatt der Drüsen zahlreiche einzellige Papillen, welche sehr kurze Stiele haben. Die viertheiligen Fortsätze haben divergirende Arme von gleicher Länge. Reste von entomostraken Krustern wurden in den Blasen gefunden.

# Polypompholyx tenella
Polypompholyx tenella. — Die Blasen sind kleiner als jene der letzten Art, aber haben dieselbe allgemeine Structur. Sie waren voll zerfallner, augenscheinlich organischer Substanz, aber es konnten keine Reste von Gliederthieren darin unterschieden werden.

# Genlisea
Genlisea. Diese merkwürdige Gattung wird, wie ich von Prof. Oliver höre, technisch dadurch von Utricularia unterschieden, dasz sie einen fünftheiligen Kelch hat. Arten davon werden in mehreren Theilen der Welt gefunden, und gelten für „herbae annuae paludosae.‟

# Genlisea ornata
Genlisea ornata (Brasilien). — Diese Art ist von Dr. Warming beschrieben und abgebildet wordenBidrag til Kundskaben om Lentibulariaceae. Copenhagen, 1874., welcher angibt, dasz sie zwei Arten Blätter trägt, die er spatelförmig und schlauchtragend nennt. Die letzteren umschlieszen Höhlungen; und da diese von den Blasen der vorhergehenden Arten sehr verschieden sind, so wird es zweckmäszig sein, von ihnen als „Schläuchen‟ zu sprechen. Die beistehende Abbildung (Fig. 29) eines der schlauchtragenden Blätter, ungefähr dreimal vergröszert, wird die folgende Beschreibung von meinem Sohn illustriren, welche in allen wesentlichen Punkten mit der von Cap. 18. Structur der Blätter. Dr. Warming gegebenen übereinstimmt. Der Schlauch (b) wird von einer unbedeutenden Erweiterung der schmalen Scheibe des Blattes gebildet. Ein hohler Hals (n), nicht weniger als fünfzehn Mal so lang wie der Schlauch selbst, bildet einen Gang von der schrägen schlitzartigen Mündung (o) in die Höhlung des Schlauchs. Ein Schlauch, welcher in seinem längeren Durchmesser \frac {1}{36} Zoll (0,705 Mm.) masz, hatte einen Hals, welcher \frac {15}{36} Zoll (10,583 Mm.) lang und \frac {1}{100} Zoll (0,254 Mm.) breit war. Auf# Bau und Struktur der Röhre

jeder Seite der Mündung ist ein langer spiraler Arm oder eine Röhre (a), deren Bauart am Besten durch folgende Erklärung verstanden werden wird. Man nehme ein schmales Band und winde es spiral um einen dünnen Cylinder, so dasz seine Ränder der ganzen Länge entlang in Berührung kommen, dann drücke man die beiden Bänder etwas zusammen, so dasz sie eine kleine Leiste bilden, welche sich natürlich um den Cylinder windet, wie ein Faden um eine Schraube. Wenn der Cylinder nun entfernt wird, wird man eine Röhre haben, welche einem der spiralen Arme gleich ist. Die zwei vorspringenden Ränder sind nicht that- sächlich verbunden, und eine Nadel kann leicht zwischen ihnen durchgeschoben werden. Sie sind in der That an vielen Stellen ein wenig von einan- der getrennt, dadurch schmale Einlässe in die Röhre bildend; aber dies kann das Resultat des Trocknens der Exemplare sein. Die Platte, aus der die Röhre gebildet wird, scheint eine seitliche Verlängerung der Lippe der Mündung zu sein; und die spirale Linie zwischen den zwei vorsprin- genden Kanten steht mit dem Winkel der Mün- dung in continuirlichem Zusammenhange.

# Innere Struktur des Schlauches

So viel über den äuszeren Bau. Innerlich ist der untere Theil des Schlauchs mit sphärischen, aus vier Zellen (manchmal acht, nach Dr. Warming) gebildeten Papillen bedeckt, welche augenscheinlich den viertheiligen Fortsätzen in den Blasen der Utricularia gleichkommen. Diese Papillen verbreiten sich eine kleine Strecke die dorsale und ventrale Fläche des Schlauchs hinauf; und nach Dr. Warming können einige wenige in dem oberen Theil gefunden werden. Diese obere Region ist durch viele quere Reihen, eine über der andern, von kur- zen, dicht an einander stehenden Haaren bedeckt, welche mit den Spitzen nach unten gerichtet sind. Diese Haare haben breite Basen und ihre Spitzen werden durch je eine besondere Zelle ge- bildet. Sie fehlen im unteren Theil des Schlauches, wo die Papillen äusserst zahl- reich vorhanden sind. Der Hals ist gleich- falls durch seine ganze Länge mit queren Reihen von langen, dünnen, durchsichtigen Haaren ausgekleidet, welche breite bulböse Basen und ähnlich gebaute scharfe Spitzen haben. Sie entspringen von kleinen vorspringenden Leisten, welche aus recht-# Anatomie der Genlisea

Die Haare variiren ein wenig in Länge, aber ihre Spitzen reichen meistens hinunter bis zu der zunächst darunter befindlichen Reihe, so dasz, wenn der Hals aufgeschlitzt und flach auseinander gelegt wird, die innere Oberfläche einem Stecknadelbriefe gleicht: die Haare stellen die Nadeln, und die kleinen schrägen Leisten die Papierfalten, durch welche die Nadeln gestoszen sind, dar.

## Innere Struktur des Halses

Das Innere des Halses ist auch mit Papillen besetzt; jene im unteren Theil sind sphärisch und werden von vier Zellen gebildet, wie im unteren Theil des Schlauchs; jene im oberen Theil werden von zwei Zellen gebildet, welche nach abwärts unterhalb ihres Befestigungspunktes sehr verlängert sind. Diese zweizelligen Papillen entsprechen augenscheinlich den zweispaltigen Fortsätzen im oberen Theil der Blasen der Utricularia.

### Mundöffnung und Lippen

Die schmale quere Mün-dung liegt zwischen den Basen der zwei spiralen Arme. Keine Klappe konnte hier entdeckt werden; auch hat Dr. Warming keine irgend derartige Bildung hier gesehen. Die Lippen der Mün-dung sind mit vielen kurzen, dicken, scharf zugespitzten, etwas ein-bogenen Haaren oder Zähnen bewaffnet.

## Spiralarmstruktur

Die zwei vorspringenden Ränder der spiral gewundenen Platte, welche die Arme bilden, sind mit kurzen eingebognen Haaren oder Zähnen, genau gleich denen auf den Lippen, versehen. Diese springen nach innen im rechten Winkel zu der Spirallinie der Verbindung zwischen den beiden Rändern vor.

### Papillen und Unterschiede

Die innere Oberfläche der Platte trägt zweizellige verlängerte Papillen, welche denen im oberen Theil des Halses gleich sind, aber Dr. Warming zufolge darin leicht von ihnen verschieden sind, dasz ihre Stiele von Verlängerungen groszer Epidermis-Zellen gebildet werden, während die Papillen im Halse auf kleinen, zwischen die gröszeren eingelassenen Zellen ruhen.

## Gefäßsystem

Endlich ist ein Bündel von Spiralgefäszen da, welches den unteren Theil des linearen Blattes hinauf laufend sich dicht unter dem Schlauche theilt. Ein Zweig erstreckt sich die dorsale und der andere die ventrale Seite sowohl des Schlauches als des Halses hinauf.

### Beute und Nahrungsaufnahme

Die Schläuche enthielten viel Abfall oder schmutzige Substanz, welche organisch zu sein schien, obgleich keine bestimmten Organismen erkannt werden konnten. Es ist in der That kaum möglich, dasz irgend ein anderer Gegenstand in die kleinen Mündungen eintreten und den langen schmalen Hals hinunter gehen könnte, auszer einem lebenden Wesen.

## Fazit zur Beutefangmethode

Aus dieser Beschreibung geht zur Genüge hervor, wie Genlisea sich ihrer Beute versichert. Kleine Thiere, welche in die schmale Mündung eintreten — (aber was sie bewegt, da hinein zu gehen, ist...# Genlisea ornata

## Anatomie und Fangmechanismus

ebenso wenig bekannt, wie im Fall der Utricularia) — werden ihren Wiederaustritt durch die scharfen eingebogenen Haare auf den Lippen erschwert finden, und sobald sie ein kleines Stück den Hals hinuntergegangen sind, wird es für sie kaum möglich sein umzukehren in Folge der vielen queren Reihen von langen geraden, mit den Spitzen nach unten gerichteten Haaren, zusammen mit den Leisten, von welchen diese vorspringen. Solche Geschöpfe werden daher entweder in dem Hals oder im Schlauche umkommen; und die viertheiligen und zweispaltigen Fortsätze werden aus ihren zerfallenen Resten Substanz aufsaugen. Die queren Reihen Haare sind so zahlreich, dasz sie blosz um das Entkommen der Beute zu verhindern, überflüssig scheinen, und da sie dünn und zart sind, so fungiren sie wahrscheinlich als weitere aufsaugende Organe, in derselben Weise, wie die biegsamen Borsten auf den eingebogenen Rändern der Blätter von Aldrovanda. Die Spiralarme fungiren ohne Zweifel als accessorische Fallen. Bis nicht frische Blätter untersucht worden sind, kann man nicht sagen, ob die Verbindungslinie der spiral gewundenen Platte ihrem ganzen Verlaufe entlang oder nur stellenweise etwas offen ist, aber ein kleines Geschöpf, welches seinen Weg an irgend einem Punkt in die Röhre erzwang, würde durch die eingebogenen Haare am Entkommen verhindert werden, und würde einen offnen Pfad nur die Röhre hinunter in den Hals und dadurch in den Schlauch finden. Wenn das Geschöpf in den Spiralarmen umkäme, würden seine verwesenden Reste von den zweispaltigen Papillen aufgesaugt und verwerthet werden. Wir sehen hieraus, dasz Thiere von Genlisea gefangen werden, nicht mittelst einer elastischen Klappe wie in den vorgehenden Arten, sondern durch eine, einer Aal-Falle ähnliche, wenngleich complicirtere Einrichtung.

## Genlisea africana

Genlisea africana (Süd-Africa.) — Reste der schlauchtragenden Blätter dieser Art boten dieselbe Bauart dar, wie die der Genlisea ornata. Ein beinahe vollkommener Acarus wurde in dem Schlauch oder Hals eines Blattes gefunden, aber in welchem von den beiden Theilen wurde nicht berichtet.

## Genlisea aurea

Genlisea aurea (Brasilien). — Ein Rest des Halses eines Schlauches war mit queren Reihen von Haaren ausgekleidet und mit verlängerten Papillen versehn, genau so wie die im Hals der Genlisea ornata. Es ist demzufolge wahrscheinlich, dasz der ganze Schlauch ähnlich gebaut ist.

## Genlisea filiformis

Genlisea filiformis (Bahia, Brasilien). — Viele Blätter wurden untersucht, und keine wurden mit Schläuchen versehen gefunden, während solche Blätter in den drei vorhergehenden Arten ohne Schwierigkeit gefunden worden waren. Auf der andern Seite tragen die Rhizome Blasen, welche dem wesentlichen Character nach denen an den Rhizomen der Utricularia ähnlich sind. Diese Blasen sind durchsichtig und sehr klein, nämlich nur \frac {1}{100} Zoll (0,254 Mm.) lang. Die Antennen sind an ihren Basen nicht verbunden und tragen augenscheinlich einige lange Haare. Auf der Auszenseite der Blasen sind nur einige wenige Papillen und innerlich sehr wenig viertheilige Fortsätze vorhanden. Diese letzteren jedoch sind von ungewöhnlich bedeutender Grösse im Verhältnis zu der Blase; ihre vier divergierenden Arme sind von gleicher Länge. In diesen kleinen Blasen war keine Beute zu sehen. Da die Rhizome dieser Art mit Blasen versehen waren, wurden die der Genlisea africana, ornata und aurea sorgfältig untersucht, aber es waren keine zu finden. Was sollen wir aus diesen Thatsachen schlieszen? Besaszen die drei eben genannten Arten, wie ihre nahen Verwandten, die verschiedenen Arten der Utricularia, ursprünglich Blasen an ihren Rhizomen, welche sie später verloren, wogegen sie an ihrer Stelle schlauchtragende Blätter erhiel-ten? Um diese Ansicht zu unterstützen, könnte hervorgehoben werden, dasz die Blasen der Genlisea filiformis wegen ihrer geringen Grösze und wegen der geringen Zahl ihrer viertheiligen Fortsätze, auf dem Wege zu verkümmern begriffen zu sein scheinen; aber warum hat diese Art nicht schlauchtragende Blätter erhalten, wie# Pflanzen und ihre Anpassungen

ihre Gattungsgenossen?
Schlusz. — Es ist nun gezeigt worden, dasz viele Arten von Utricularia und zweier nahe verwandter Gattungen, welche die von einander entferntesten Theile der Welt — Europa, Africa, Indien, den malayischen Archipel, Australien, Nord- und Süd-America — bewohnen, wunderbar schön dazu angepaszt sind, auf zwei Methoden kleine wasser- oder landlebende Thiere zu fangen, und dasz sie die Produkte von deren Zerfall aufsaugen.

# Nahrungsaufnahme und Verdauung

Gewöhnliche Pflanzen der höheren Classen verschaffen sich die nöthigen unorganischen Elemente aus dem Boden mittelst ihrer Wurzeln und absorbiren Kohlensäure aus der Luft mittelst ihrer Blätter und Stengel. Wir haben aber in einem früheren Theile dieses Werkes gesehen, dasz es eine Classe von Pflanzen gibt, welche thierische Substanz verdauen und nachher aufsaugen, nämlich alle Droseraceae, Pinguicula und, wie Dr. Hooker entdeckt hat, Nepenthes; und dieser Classe werden beinahe sicher bald noch andere Arten hinzugefügt werden. Diese Pflanzen können Substanz aus gewissen vegetabilischen Stoffen, wie Pollen, Samen und Stückchen von Blättern auflösen.

# Absorption von Nährstoffen

Ohne Zweifel saugen ihre Drüsen gleichfalls die ihnen vom Regen zugeführten Ammoniaksalze auf. Es ist auch gezeigt worden, dasz einige andere Pflanzen Ammoniak durch ihre drüsenartigen Haare aufsaugen können; und diese werden auch aus dem ihnen vom Regen zugeführten Nutzen ziehen. Es ist auch noch eine zweite Classe von Pflanzen da, welche, wie wir so eben gesehen haben, nicht verdauen können, aber die Produkte des Zerfalls von Thieren, welche sie fangen, aufsaugen, nämlich Utricularia und ihre nahen Verwandten; und nach den ausgezeichneten Beobachtungen von Dr. Mellichamp und Dr. Canby kann kaum ein Zweifel darüber bestehen, dasz Sarracenia und Darlingtonia dieser Classe zugefügt werden können, obgleich die Thatsache bis jetzt noch kaum als vollständig bewiesen angesehen werden kann.

# Pflanzen und ihre Lebensweise

Es gibt eine dritte Classe Pflanzen, welche, wie nun allgemein zugegeben wird, von Produkten des Zerfalls vegetabilischer Substanz leben, wie z. B. eine Orchidee (Neottia) u. s. w. Endlich findet sich noch die bekannte vierte Classe von Parasiten (so z. B. die Mistel), welche sich von den Säften lebender Pflanzen ernähren. Die meisten jedoch der Pflanzen, welche zu diesen vier Classen gehören, erhalten einen Theil ihres Kohlenstoffes wie die gewöhnlichen Arten aus der Luft. Dieses sind die verschiedenen Mittel, durch welche, so weit bis jetzt bekannt ist, höhere Pflanzen ihren Unterhalt gewinnen.

# Register

A.
Absorption bei Dionaea, 267; bei Drosera, 15; bei Drosophyllum, 305; bei Pinguicula, 344; durch drüsige Haare, 311; durch Drüsen bei Utricularia, 376, 380; durch viertheilige Fortsätze bei Utricularia, 372, 380; bei Utricularia montana, 393.
Aether, Wirkung auf Dionaea, 275; Wirkung auf Drosera, 198.
Aggregation, s. Zusammenballung.
Alaunsalze, Wirkung auf Drosera, 166.
Alkohol, verdünnter, Wirkung auf Drosera, 69, 196.
Aldrovanda vesiculosa, 290; Absorption und Verdauung, 293; Varietäten, 296.
Algen, Zusammenballung in Blättern, 57.
Alkalien hemmen den Verdauungsprocesz bei Drosera, 84.
Ameisensäure, Wirkung auf Drosera, 172.
Ammoniak, Menge im Regenwasser,# Wirkung auf Drosera

## Kohlensäure und ihre Effekte
—, kohlensaures, Wirkung auf er-
wärmte Blätter von Drosera, 60; Kleinheit der Dosen, die bei Drosera Zusammenballung bewirken, 128; Wirkung auf Drosera, 125; Dampf von den Drüsen der Drosera absorbirt, 125; Kleinheit der Dosen, die bei Drosera Einbiegung bewirken, 128, 151; —, phosphorsaures, Kleinheit der Dosen, die bei Drosera Einbiegung bewirken, 136, 151; Grösze der Theilchen, welche Drosera afficiren, 155; —, salpetersaures, Kleinheit der Dosen, die bei Drosera Einbiegung verursachen, 131, 151; —, -Salze, Wirkung auf Drosera, 120; Wirkung durch vorheriges Ein-
tauchen in Wasser und verschiedene Lösungen beeinflusst, 192; bewirken Zusammenballung bei Drosera, 38; Ammoniak, verschiedene Salze, bewirken Einbiegung bei Drosera, 149.

## Verschiedene chemische Substanzen
Antimon, weinsteinsaures, Wirkung auf Drosera, 166.
Äpfelsäure, Wirkung auf Drosera, 175.
Arsenige Säure, Wirkung auf Dro-
sera, 167.
Atropin, Wirkung auf Drosera, 183.

## Barytsalze und deren Effekte
Barytsalze, Wirkung auf Drosera, 164; Basen der Salze, vorwiegende Wirkung der — auf Drosera, 168.
Belladonna-Extract, Wirkung auf Drosera, 74.
Bennett, A. W., über Drosera, 1. Anm.; Schalen der Pollenkörner von Insecten nicht verdaut, 103.
Benzoësäure, Wirkung auf Drosera, 175.
Bernsteinsäure, Wirkung auf Dro-
sera, 175.

## Berührungen und Bewegungen
Berührungen, wiederholte, bewirken Einbiegung bei Drosera, 30.
Bewegung, Ursprung des Vermögens der —, 328.
Bewegungen der Blätter von Pinguicula, 335; der Tentakeln von Drosera, Mittel, 230; der Dionaea, Mittel, 283.

## Weitere Studien und Beobachtungen
Binz, über die Wirkung von Chinin auf die weiszen Blutkörperchen, 181; über die giftige Wirkung des Chinins auf niedrige Organismen, 182.
Blätter, Rücken der Drosera- — nicht empfindlich, 209.
Blausäure, Wirkung auf Dionaea, 275; Wirkung auf Drosera, 176.
Bleichlorid, Wirkung auf Drosera, 166.
Borsäure, Wirkung auf Drosera, 172.
Brillenschlange, Wirkung des Gif-
tes auf Drosera, 186.# Wissenschaftliche Studien über Drosera und verwandte Themen

## Verdauung und chemische Zusammensetzung
Brunton, Lauder, über Verdauung von Gelatine, 98; über die Zusammensetzung des Casein, 102; über die Verdauung von Harnstoff, 110; über die Verdauung von Chlorophyll, 111; über die Verdauung von Pepsin, 109.

## Chemische Einflüsse auf Drosera
Cadmium-Chlorid, Wirkung auf Drosera, 165.
Caesium-Chlorid, Wirkung auf Drosera, 163.
Campher, Wirkung auf Drosera, 188.
Carbolsäure, Wirkung auf Drosera, 173.
Chinin, Wirkung des — auf weiße Blutkörperchen, 181; giftige Wirkung auf niedere Organismen, 182; — -Salze, Wirkung auf Drosera, 181.
Chloroform, Wirkung auf Dionaea, 275; Wirkung auf Drosera, 197.
Chromsäure, Wirkung auf Drosera, 167.
Citronensäure, Wirkung auf Drosera, 175.
Cobra, Wirkung des Gifts auf Drosera, 186, s. auch 188, 203.
Colchicin, Wirkung auf Drosera, 184.
Curare, Wirkung auf Drosera, 184.

## Verdauung von Substanzen durch Drosera
Casein, verdaut von Drosera, 101.
Cellulose, nicht von Drosera verdaut, 110.
Chitin, nicht von Drosera verdaut, 110.
Chlorophyll, die Körner in lebenden Pflanzen von Drosera verdaut, 111; reines, nicht von Drosera verdaut, 111.
Chondrin, verdaut von Drosera, 99.
Crystallin, verdaut von Drosera, 106.
Dentin, verdaut von Drosera, 94.

## Beiträge von Wissenschaftlern
Cohn, Prof., über Aldrovanda, 290; über contractile Gewebe bei Pflanzen, 328; über Bewegungen der Staubfäden der Compositen, 232; über Utricularia, 357.
Darwin, Francis, über die Wirkung eines inducirten galvanischen Stromes auf Drosera, 32; über die Verdauung von Chlorophyllkörnern, 111; über Utricularia, 397.
Delpino, über Aldrovanda, 290; über Utricularia, 357.
Curtis, Dr., über Dionaea, 272.

## Eigenschaften von Dionaea muscipula
Dionaea muscipula, geringe Größe der Wurzeln, 259; Struktur der Blätter, 260; Empfindlichkeit der Filamente, 261; Absorption, 266; Absonderung, 267; Verdauung, 272; Wirkung des Chloroforms auf —, 275; Art Insekten zu fangen, 276.# Historische Impulse
torischen Impulses, 283; Wiederausbreitung der Lappen, 288.

# Forschung über Rhizocephale
Dohrn, Dr, A., über rhizocephale Kru- ster, 322.

# Atropin und seine Wirkung
Donders, Prof., geringe Menge von Atropin, welche die Iris des Hundes afficirt, 155.

# Drosera Arten
Drosera anglica, 252; —, binata vel dichotoma, 255; —, capensis, 253; —, filiformis, 255; —, heterophylla, 258; —, intermedia, 253; —, rotundifolia, Structur der Blätter, 3; Wirkung stickstoffhaltiger Flüssigkei- ten, 67; Wirkung der Wärme, 58; ihr Verdauungsvermögen, 76; Rücken der Blätter nicht empfindlich, 209; Fortleitung des motorischen Impulses, 212; allgemeine Zusammenfassung, 238; —, spathulata, 254.

# Droseraceae
Droseraceae, Schluszbemerkungen, 321; ihre Empfindlichkeit mit der der Thiere verglichen, 330.

# Drosophyllum
Drosophyllum, Structur der Blätter, 301; Absonderung, 302; Absorption, 305; Verdauung, 307.

# Drüsenhaare
Drüsenhaare, Absorption durch —, 311; Zusammenfassung über —, 319.

# Wirkung von Eisenchlorid
Eisenchlorid, Wirkung auf Dro- sera, 167.

# Eiweißverdauung
Eiweisz, von Drosera verdaut, 82; flüssiges, Wirkung auf Drosera, 70.

# Elastisches Fasergewebe
Elastisches Fasergewebe, nicht von Drosera verdaut, 108.

# Empfindlichkeit bei Drosera
Empfindlichkeit, Localisirung der —, bei Drosera, 208; der Dionaea, 262; der Pinguicula, 335.

# Wirkung von Erbsen
Erbsen, Abkochung von —, Wirkung auf Drosera, 73.

# Erica tetralix
Erica tetralix, Drüsenhaare, 317.

# Ernährung bei Pflanzen
Ernährung, verschiedene Mittel der — bei Pflanzen, 405.

# Essigsäure und Drosera
Essigsäure, Wirkung auf Drosera, 172.

# Euphorbia
Euphorbia, Zusammenballung in den Wurzeln, 56.

# Exosmose bei Drosera
Exosmose, an dem Rücken der Blätter bei Drosera, 210.

# Faserknorpel
Faserknorpel. Register. Klein.

# Verdauung von Faserknorpel
Faserknorpel, von Drosera ver- daut, 92.

# Faserstoff
Faserstoff, s. Fibrin.

# Cobra-Gift Forschung
Fayrer, Dr., über die Natur des Giftes der Cobra, 186; über die Wirkung des Cobra-Giftes auf thierisches Proto- plasma, 188; über die lähmende Wir- kung des Cobra-Giftes auf Nerven- centren, 203.

# Ferment in Drosera
Ferment, Natur des — s im Secret der Drosera, 83, 86.# Pflanzen und ihre Verdauung

## Drosera und ihre Verdauungsprozesse
Fett, nicht von der Drosera verdaut,
Fibrin, von Drosera verdaut, 100.
Fleisch, Aufgusz von —, bewirkt Zusammenballung bei Drosera, 44; Aufgusz von —, Wirkung auf Drosera, 70; verdaut von Drosera, 87.
Flüssigkeiten, stickstoffhaltige, Wirkung auf Drosera, 67.

## Motorische Impulse
Fortleitung des motorischen Impulses bei Dionaea, 283; bei Drosera, 212.

## Säuren und ihre Wirkungen
Fournier, über Säuren, die in den Staubfäden der Berberis Bewegung verursachen, 177.
Frankland, Prof., über die Natur der Säure im Secret der Drosera, 79.

## Chemische Verbindungen
Gallussäure, Wirkung auf Drosera, 175.
Gelatine, reines, verdaut von Drosera, 98; unreines, Wirkung auf Drosera, 71.
Globulin, von Drosera verdaut, 106.
Glycerin, bewirkt Zusammenballung bei Drosera, 45; Wirkung auf Drosera, 192.
Gold-Chlorid, Wirkung auf Drosera, 166.
Gummi, Wirkung auf Drosera, 68.

## Pflanzenarten und ihre Eigenschaften
Genlisea africana, 404;
—, filiformis, 404;
—, ornata, Structur, 400; Art Beute zu fangen, 403.
Gardner, über Utricularia montana, 397.

## Anatomie und Physiologie
Gefäsze in Blättern von Dionaea, 225; —, in Blättern von Drosera, 284.
Gewebe, durch welche der motorische Impuls fortgeleitet wird, bei Dionaea, 283; bei Drosera, 224.
Haare, drüsige, Absorption, 311; Zusammenfassung über —, 318.

## Abfallprodukte und deren Wirkung
Harn, Wirkung auf Drosera, 70.
Harnsäure, Wirkung auf Drosera, 176.
Harnstoff, nicht von Drosera verdaut, 109.

## Sonstige Beobachtungen
Gras, Abkochung von —, Wirkung auf Drosera, 74.
Grönland, über Drosera, 1, 5, Anm.
Haematin, von Drosera verdaut, 107.
Gift der Cobra und Otter, Wirkung auf Drosera, 186.# Hausenblase
Hausenblase, Lösung von —, Wirkung auf Drosera, 71.

# Heckel
Heckel, Staubfaden der Berberis nach Reizung, 37.

# Hippursäure
Hippursäure, Wirkung auf Drosera, 176.

# Hofmeister
Hofmeister, Druck hemmt die Bewegungen des Protoplasma, 54.

# Holland
Holland, über Utricularia, 357.

# Hooker
Hooker, Dr., über fleischfressende Pflanzen, 2; über das Verdauungsvermögen von Nepenthes, 86; Geschichte der Beobachtungen an Dionaea, 259.

# Hyoscyamus
Hyoscyamus, Wirkung auf Drosera, 185.

# Jod- und Jodwasserstoffsäure
Jod- und Jodwasserstoffsäure, Wirkung auf Drosera, 171.

# Johnson
Johnson, Dr., über Bewegung des Blüthenstiels bei Pinguicula, 344.

# Kali-Salze
Kali-Salze, Wirkung auf Drosera, 161; bewirken Zusammenballung bei Drosera, 44; —, phosphorsaures, durch Drosera nicht zersetzt, 168.

# Kalk
Kalk, kohlensaurer, präcipitirt, bewirkt Einbiegung bei Drosera, 28; —, phosphorsaurer, Wirkung auf Drosera, 97.

# Kalk-Salze
Kalk-Salze, Wirkung auf Drosera, 164.

# Käse
Käse, von Drosera verdaut, 103.

# Klein
Klein, Dr., über das mikroskopische Aussehen halbverdauten Knochens, 93; über den Zustand halbverdauten Faserknorpels, 93; über die Grösse von Mikrocokken, 155.

# Knight
Knight, über das Füttern von Dionaea, 272.

# Knochen
Knochen, von Drosera verdaut, 93.

# Knollen
Knollen, von Utricularia montana, 394.

# Knorpel
Knorpel, von Drosera verdaut, 91.

# Kobalt-Chlorid
Kobalt-Chlorid, Wirkung auf Drosera, 167.

# Kohl
Kohl, Abkochung von —, Wirkung auf Drosera, 73.

# Kohlensäure
Kohlensäure, Wirkung auf Drosera, 200; verzögert Zusammenballung bei Drosera, 51.

# Körperchen
Körperchen, minutiöse Grösse der —, welche Einbiegung bei Drosera bewirken, 24, 28.

# Kossmann
Kossmann, über rhizocephale Kruster, 322.

# Kreide
Kreide, präcipitirte, bewirkt Einbiegung bei Drosera, 28.

# Kümmel-Oel
Kümmel-Oel, Wirkung auf Drosera, 191.

# Kupfer-Chlorid
Kupfer-Chlorid, Wirkung auf Drosera, 167.

# Legumin
Legumin, von Drosera verdaut, 103.# Inhaltsverzeichnis

## A
- Lemna, Zusammenballung in den Blättern von, 56.
- Leim, verdaut von Drosera, 104.
- Libelle von Drosera gefangen, 2.
- Lithion-Salze, Wirkung auf Drosera, 163.

## M
- Magnesia-Salze, Wirkung auf Drosera, 164.
- Mangan-Chlorid, Wirkung auf Drosera, 167.
- Marshall, W., über Pinguicula, 333.
- Milch, bewirkt Zusammenballung bei Drosera, 45; Wirkung auf Drosera, 70; von Drosera verdaut, 100.
- Milchsäure, Wirkung auf Drosera, 174.
- Mirabilis longiflora, Drüsenhaare, 318.
- Mittel der Bewegung bei Dionaea, 283; bei Drosera, 130.
- Moggridge, Traherne, über Säuren, die Samen verletzen, 113.
- Moore, Dr., über Pinguicula, 353.
- Morphium, essigsaures, Wirkung auf Drosera, 185.
- Motorischer Impuls bei Dionaea, 212, 234; bei Drosera, 283.
- Mucin, nicht von Drosera verdaut, 108.
- Müller, Fritz, über rhizocephale Kruster, 322.

## N
- Natron-Salze, bewirken Zusammenballung bei Drosera, 158; Wirkung auf Drosera, 44.
- —, phosphorsaures, von Drosera zersetzt, 168.
- Nepenthes, Verdauungsvermögen, 86.
- Nelken-Oel, Wirkung auf Drosera, 191.
- Nickel-Chlorid, Wirkung auf Drosera, 167.
- Nicotiana tabacum, Drüsenhaare, 318.
- Nicotin, Wirkung auf Drosera, 183.
- Nitschke, Dr., Hinweise auf seine Arbeiten über Drosera, 1; über Empfindlichkeit des Blattrückens bei Drosera, 210; über die Richtung der eingeknickten Tentakeln bei Drosera, 221; über Aldrovanda, 291.
- Nuttall, über Wiederausbreitung bei Dionaea, 288.

## O
- Oel, Oliven-, Wirkung auf Drosera, 69, 112.
- Oelsäure, Wirkung auf Drosera, 173.
- Oliver, Prof., über Utricularia, 397—400.
- Otter, Gift-, Wirkung des Giftes auf Drosera, 186.
- Oxalsäure, Wirkung auf Drosera, 175.

## P
- Papaw, s. Traubenbaum.
- Pelargonium zonale, Drüsenhaare, 317.
- Pepsin, Geruch von, bei Drosera, 79; nicht von Drosera verdaut, 109; von# Inhaltsverzeichnis

## Absonderung und Absorption
Thieren nur nach Absorption abge-
sondert, 114.
Peptogene, 114.

## Wirkung auf Drosera
Phosphorsäure, Wirkung auf Dro-
sera, 172.
Platin-Chlorid, Wirkung auf Drosera,
167.
Propionsäure, Wirkung auf Drosera.
173.
Salpetersäure, Wirkung auf Drosera,
170.
Salpeter-Aether, Wirkung auf Dro-
sera, 199.
Quecksilber- Superchlorid, Wirkung
auf Drosera, 165.
Rubidium-Chlorid, Wirkung auf
Drosera, 163.

## Pinguicula
Pinguicula grandiflora, 352.
—, lusitanica, 353.
—, vulgaris, Structur der Blätter und
Wurzeln, 332; Zahl der gefangenen
Insecten, 333; Bewegungsvermögen,
334; Absonderung und Absorption, 344;
Verdauung, 344; Wirkung des Secrets
auf lebende Samen, 352.
Ralfs, über Pinguicula, 353.

## Protoplasma
Protoplasma, Zusammenballung bei
Drosera, 33; bei Drosera durch kleine
Dosen kohlensauren Ammoniaks be-
wirkt, 129; bei Drosera eine Reflex-
wirkung, 220.
—, zusammengeballtes, Wieder-
auflösung, 47.
—, Zusammenballung bei verschie-
denen Species von Drosera, 252; bei
Dionaea, 262, 272; bei Drosophyllum,
305, 306; bei Pinguicula, 334, 352;
bei Utricularia, 371, 374, 386, 389,
392.

## Pflanzen und Gifte
Ransom, Dr., Wirkung von Giften auf
den Dotter von Eiern, 204.

## Regenwasser
Regenwasser, Ammoniakmenge in,
154.

## Tentakeln
Richtung der eingebogenen Tentakeln
bei Drosera, 221.

## Sonstiges
Polypompholyx, Structur, 399.
Price, John, über Utricularia, 386.
Primula sinensis, Drüsenhaare, 314;
Zahl der Drüsenhaare, 320.
Salze und Säuren, verschiedene Wir-
kung auf die spätere Anwendung von
Ammoniak, 194.
Sachs, Prof., Wirkung der Wärme auf
Protoplasma, 58. 61; über die Auf-
lösung von Protëinverbindungen in
den Geweben von Pflanzen, 327.
Roridula, 309.# Chemische Wirkungen auf Drosera

## Salzsäure und ihre Wirkung
Salzsäure, Wirkung auf Drosera, 171.

## Samen und deren Einfluss
Samen, lebende, Wirkung der Drosera auf, 112; Wirkung der Pinguicula auf, 348. 352.

## Sandersons Forschungen
Sanderson, Burton, über Eiweiszgerinnung durch Hitze, 65; über die die Salzsäure bei der Verdauung ersetzenden Säuren, 79; über die Verdauung der fasrigen Grundsubstanz der Knochen, 96; über die Verdauung von Leim, 105; über die Verdauung von Globulin, 106; über die Verdauung von Chlorophyll, 111; über die verschiedene Wirkung von Kali und Natron auf Thiere, 168; über elektrische Ströme bei Dionaea, 288.

## Säure und ihre Natur
Säure, Natur der, im verdauenden Secret der Drosera, 78; Natur der — in der verdauenden Flüssigkeit verschiedener Arten von Drosera, Dionaea, Drosophyllum und Pinguicula, 252, 273, 307, 344.

## Wirkung verschiedener Säuren
Säuren, verschiedene, Wirkung auf Drosera, 169; der Essigreihe ersetzen Salzsäure bei der Verdauung, 79; —, arsenige und Chrom-, Wirkung auf Drosera, 167.

## Verdünnte Säuren
—, verdünnte, veranlassen negative Osmose, 178.

## Saxifraga umbrosa
Saxifraga umbrosa, 312.

## Schieszbaumwolle
Schieszbaumwolle, nicht von Drosera verdaut, 110.

## Schiff und die Eiweißverdauung
Schiff, Salzsäure löst geronnenes Eiweisz auf, 77; über die Art der Eiweiszverdauung, 82; über Veränderungen im Fleisch während der Verdauung, 88; über Milchgerinnung, 101; über Verdauung von Casein, 102; über Verdauung von Schleim, 109; über Peptogene, 114.

## Wirkung von Schleim
Schleim, Wirkung auf Drosera, 70.

## Schloesing und Stickstoffabsorption
Schloesing, über Stickstoffabsorption bei Nicotiana, 318.

## Wirkung von Schwefeläther
Schwefeläther, Wirkung auf Dionaea, 275; Wirkung auf Drosera, 198.

## Wirkung von Schwefelsäure
Schwefelsäure, Wirkung auf Drosera, 172.

## Scott über Drosera
Scott, über Drosera, 1.

## Secret der Drosera
Secret der Drosera, allgemeine Schilderung, 11; seine antiseptische Kraft, 13; wird bei Reizung sauer, 77; Natur seines Ferments, 83. 86.

## Secret der Dionaea
— der Dionaea, 266.

## Secret von Drosophyllum
— von Drosophyllum, 302.

## Secret von Pinguicula
— von Pinguicula, 344.

## Wirkung von Silber
Silber, salpetersaures, Wirkung auf Drosera, 163.

## Sondera heterophylla
Sondera heterophylla, 258.

## Sorby über Farbstoffe
Sorby, über Farbstoffe der Drosera, 4, Anm.

## Spectroskop und Drosera
Spectroskop, seine Kraft verglichen mit Drosera, 153.

## Wirkung von Speichel
Speichel, Wirkung auf Drosera, 71.

## Wirkung von Stärke
Stärke, Wirkung auf Drosera, 69, 112.# Wissenschaftliche Studien über Drosera und verwandte Pflanzen

## Chemische Einflüsse auf Drosera
Stein, über Aldrovanda, 290.
Strontiansalze, Wirkung auf Drosera, 165.
Strychnin-Salze, Wirkung auf Drosera, 179.
Syntonin, Wirkung auf Drosera, 90.

## Bewegungsmechanismen der Drosera
Tentakeln der Drosera bewegen sich, wenn die Drüsen abgeschnitten werden, 31. 208; Richtung der Einbiegung, 221; Mittel der Bewegung, 230; Wiederausbreitung, 235.

## Wirkung verschiedener Substanzen
Tanninsäure, Wirkung auf Drosera, 175.
Terpentin-Oel, Wirkung auf Drosera, 192.
Thee, Aufguss von, Wirkung auf Drosera, 69.
Thein, Wirkung auf Drosera, 184.

## Künstliche Zellen und deren Einfluss
Traube, über künstliche Zellen, 195.

## Studien über verschiedene Pflanzenarten
Treat, Mrs., über Drosera filiformis, 255; über Dionaea, 281; Utricularia, 369. 387.
Trécul, über Drosera, 1. 5, Anm.

## Utricularia und deren Eigenschaften
Utricularia clandestina, 387.
— minor, 386.
— montana, Struktur der Blasen, 389; Tiere von ihr gefangen, 391; Absorption, 393; Knollen als Reservoirs, 394.
— neglecta, Struktur der Blasen, 358; Tiere von ihr gefangen, 365; Absorption, 372; Zusammenfassung über Absorption, 380; Entwicklung der Blasen, 382.
Utricularia, verschiedene Species, 397.
— vulgaris, 386.

## Verdauung und deren Ursprung
Verdauung verschiedener Substanzen von Dionaea, 273; von Drosera, 76; von Drosophyllum, 307; von Pinguicula, 344.
—, Ursprung des Verdauungsvermögens, 326.

## Pflanzenreaktionen auf Wärme
Wärme, bewirkt Zusammenballung bei Drosera, 46; Wirkung auf Drosera, 58; Wirkung auf Dionaea, 266. 289.

## Forschung über Drosera und verwandte Pflanzen
Warming, Dr., über Drosera, 1, 6; über Wurzeln von Utricularia, 359; über Trichome, 324; über Genlisea, 400; über Parenchymzellen in den Tentakeln der Drosera, 229.

## Einfluss von Wasser auf Drosera
Wasser, Tropfen bewirken keine Zu-# Zusammenballung bei Drosera
sammenballung bei Drosera, 31; seine Kraft bei Drosera Zusammenballung zu bewirken, 46; seine Kraft bei Drosera Einbiegung zu bewirken, 123; und verschiedene Lösungen, Wirkung auf spätere Einwirkung von Ammoniak, 192.

# Weinsteinsäure
Weinsteinsäure, Wirkung auf Drosera, 175.

# Wiederausbreitung kopfloser Tentakeln
Wiederausbreitung kopfloser Tentakeln bei Drosera, 208; der Tentakeln bei Drosera, 235; bei Dionaea, 288.

# Wilkinson über Utricularia
Wilkinson, über Utricularia, 359. 360.

# Wurzeln der Drosera
Wurzeln der Drosera, 15; Zusammenballung, 53; absorbiren kohlensaures Ammoniak, 125. — der Dionaea, 259. — von Drosophyllum, 300. — von Pinguicula, 333.

# Zahnbein und Zahnschmelz
Zahnbein, von Drosera verdaut, 94. Zahnschmelz, von Drosera verdaut, 94. Zellgewebe, von Drosera verdaut, 91.

# Ziegler und seine Angaben
Ziegler, seine Angaben in Bezug auf Drosera, 21, Anm.; Versuche mit Gefäszdurchschneidung bei Drosera, 226.

# Zink-Chlorid und Zinn-Chlorid
Zink-Chlorid, Wirkung auf Drosera, 165. Zinn-Chlorid, Wirkung auf Drosera, 166.

# Zuckerlösung
Zuckerlösung, Wirkung auf Drosera, 68; bewirkt Zusammenballung bei Drosera, 45.

# Zusammenballung des Protoplasma
Zusammenballung des Protoplasma bei Drosera, 33; durch Ammoniaksalze bewirkt, 38; durch kleine Dosen kohlensauren Ammoniaks bewirkt, 145; als Reflexwirkung, 220; bei verschiedenen Arten von Drosera, 252; bei Dionaea, 263, 272; bei Drosophyllum, 305, 306; bei Pinguicula, 334, 352; bei Utricularia, 371, 374, 386, 387, 392.

# Druck der E. Schweizerbart’schen Buchdruckerei
Druck der E. Schweizerbart’schen Buchdruckerei in Stuttgart.

# Veröffentlichungen der E. Schweizerbart’schen Verlagshandlung
In der E. Schweizerbart’schen Verlagshandlung (E. Koch) in Stuttgart ist erschienen:
Bach, H., Geologische Karte von Central-Europa bearbeitet nach den besten bekannten Quellen. In Farbendruck mit 28 Farben. Folio. Zweiter Abdruck. 1868. Mark 8. —
Blum, Dr. J. R., Lehrbuch der Mineralogie (Oryktognosie). Vierte verbesserte und vermehrte Auflage. 1874. Mark 12. —
Bronn, Dr. H. G., Untersuchungen über die Entwicklungs-Gesetze der organischen Welt während der Bildungs-Zeit unserer Erd-Oberfläche. Eine von der französischen Akademie im Jahre 1858 gekrönte Preisschrift. gr. 8. 1858. Mark 6. —
Burbidge, F. W., Die Orchideen des temperierten und kalten Hauses. Aus dem Englischen von M. Lebl. Mit 23 Holzschnitten und 4 Farbendruckbildern. 1875. Mark 8. —
Fischer, H., Nephrit und Jadeit, nach ihren mineralogischen Eigenschaften sowie nach ihrer urgeschichtlichen und ethnographischen Bedeutung. Mit 131 Holzschnitten und 2 Farbentafeln. 1875. Mark 14. 40.
Gartenzeitung, illustrirte, Eine monatliche Zeitschrift für Gartenbau, Obstbau und Blumenzucht. Verantwortlicher Redacteur Hofgärtner Lebl in Langenburg. Zwanzigster Jahrgang 1876. Preis eines Jahrgangs von 12 Heften.# Buchveröffentlichungen und Preise

mit je 1 Abbildung in schönstem Farbendruck und 1 schwarze Tafel
nebst prachtvoller Prämie in Farbendruck. Mark 9. —

# Einleitung in die Krystallberechnung

Klein, Karl, Einleitung in die Krystallberechnung. Mit 196 Holzschnitten
und 12 Tafeln. 1875. Mark 12. —

# Zeitschrift für Rosenfreunde

Illustrirter Rosengarten. Eine Zeitschrift für Rosenfreunde und Rosengärtner.
Herausgegeben von M. Lebl. Neue Folge: Erstes bis drittes Heft. Mit
je vier Blatt in Farbendruck. 1875. à Mark 5. —

# Monatschrift für Forst- und Jagdwesen

Monatschrift für das Forst- und Jagdwesen. Herausgegeben von Prof. Dr.
Franz Baur in Hohenheim. Jährlich 12 Hefte. Zwanzigster Jahrgang.
1876. Mark 10. —

# Jahrbuch für Mineralogie und Geologie

Neues Jahrbuch für Mineralogie, Geologie und Palaeontologie. Herausgegeben
von Professor Dr. G. Leonhard in Heidelberg und Professor H. B. Geinitz
in Dresden. Jahrgang 1876. Mark 24. —

# Die Frucht-Häuser

Pynaert, E., Die Frucht-Häuser. Eine vollständige Abhandlung über die Treib-
und die künstliche Cultur der Obstbäume und der Beerensträucher unter
Glasschutz. Aus dem Französischen von M. Lebl. Mit 65 Holzschnitten.
1874. Mark 4. —

# Pflanzenblätter in Naturdruck

Reuss, Dr. G. Ch., Pflanzenblätter in Naturdruck mit der botanischen Kunst-
sprache für die Blattform. 42 Foliotafeln mit erläuterndem Text. Zweite
Auflage. 1872. Mark 22. —

# Handbuch der technischen Chemie

Stohmann, F., und Carl Engler, Handbuch der technischen Chemie. Nach
der fünften Auflage der „Chimie industrielle‟ von A. Payen frei bearbeitet.
I. Band mit 193 Holzschnitten und 17 Kupfertafeln. Mark 12. —
II. Band mit 209 Holzschnitten und 33 Kupfertafeln. Mark 16. —

# Druckinformation

Druck der E. Schwelzerbart’schen Buchdruckerel in Stuttgart.